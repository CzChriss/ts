# MeliPRO-V3
Essa Versão do meliPRO usar o manifesto V3