/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */

const config = {

  meliAPI: {

    baseURL: "https://api.mercadolibre.com",
    delivery: "/items",
    seller: "/users",
    address: "/shipping_options?&zip_code=",
    taxa: "/sites/MLB/listing_prices?",
    vendedorNickname: "/sites/MLB/search?nickname=",
    tendencias: "/sites/MLB/search?q=",
    baseURLHeroku: "https://portalramempresa-backend.herokuapp.com",
    baseURLBI: "https://ramcloud.com.br:19000/ram/xdados",
    baseURLAuthNode: "https://ramcloud.com.br:9001",
  
  },


}