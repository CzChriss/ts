/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */

class Page {
  static hasItems() {
    if ($('.ui-search-layout > .ui-search-layout__item').length) {
      return true
    }
    return false
  }

  static hasItemsMaisVendidos() {
    if ($('.ui-best-seller-content-main-components > .ui-search-layout--grid__container > .ui-search-layout--grid__grid > .ui-recommendations-card')
    .length) {
      return true
    }
    return false
  }

  static hasItemsOfertas() {
    if ($('.items_container > .promotion-item').length) {
      return true
    }
    return false
  }

  static hasItemsLogados() {
    if ($('.sc-item-rows > .sc-list-item-row').length) {
      return true
    }
    return false
  }

  static hasItemsTendencias() {
    if ($('.searches__list > .searches__item').length) {
      return true
    }
    return false
  }

  static searchIds() {
    let itemList = []

    // Colect ID for each item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      const id = $(this).find('input[name=itemId]').val()
      if (id) {
        const item = new Item(id)
        item.index = itemList.length;
        itemList.push(item)
      }
    })

    return itemList
  }

  static searchIdsOfertas() {
    let itemList = []

    // Colect ID for each item
    $('.items_container > .promotion-item').each(function () {
      let id = $(this).find('.promotion-item__link-container').attr('href');
      if (id.includes('produto.mercadolivre')) {
        id = id.split('-')[1];
        id = 'MLB' + id;
        const item = new Item(id)
        item.index = itemList.length;
        itemList.push(item)
      } else {
        id = id.split('/p/')[1];
        id = id.split('?')[0];
        const item = new Item(id)
        item.index = itemList.length;
        itemList.push(item)
      }

    })

    return itemList
  }


  static searchIdsMaisVendidos() {
    let itemList = []

    // Colect ID for each item
    $('.ui-best-seller-content-main-components > .ui-search-layout--grid__container > .ui-search-layout--grid__grid > .ui-recommendations-card').each(function () {
      let id = $(this).find('.ui-recommendations-card__title > .ui-recommendations-card__link').attr('href');
      if (id.includes('produto.mercadolivre')) {
        id = id.split('-')[1];
        id = 'MLB' + id;
        const item = new Item(id)
        item.index = itemList.length;
        itemList.push(item);
        item.catalogo = false;
      } else {
        id = id.split('/p/')[1];
        id = id.split('?')[0];
        const item = new Item(id)
        item.index = itemList.length;
        item.catalogo = true;
        itemList.push(item);
      }
    })

    return itemList
  }

  static searchIdsLogados() {
    let itemList = []

    // Colect ID
    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = '';

      try {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML;
      } catch (error) {
       try {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .andes-tooltip__trigger > .sc-list-item-row-description__id")[0].innerHTML;
       } catch (error) {
        try {
         id = $(this).find(".sc-list-item-row-description__id")[0].innerHTML;
        } catch (error) {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-vis-item-row-description > .sc-list-vis-item-row-description__upper-row > .upper-row__overflow > .sc-list-vis-item-row-description__id")[0].innerHTML;
       }
      }
    }

    
      if ($(this).find(".sc-list-item-row__visible > .sc-list-channel-content.sc-list-channel-content--ml > .sc-list-channel-content__grid  > .andes-badge > .andes-badge__content")[0]) {
        let dadosVisitas = $(this).find(".sc-list-item-row__visible > .sc-list-channel-content.sc-list-channel-content--ml > .sc-list-channel-content__grid  > .andes-badge > .andes-badge__content")[0].innerHTML;
        
        try {
          dadosVisitas = dadosVisitas.replaceAll('</span>', ' ');
          dadosVisitas = dadosVisitas.replaceAll('<span>', '');
        } catch (error) {
          
        }

        let frete;
        try {
          frete = $(this).find(".sc-list-actionable-cell.sc-list-actionable-cell__shipping > .sc-list-actionable-cell__group-text > .sc-list-actionable-cell__description.sc-list-text--secondary > p")[0];
          frete = frete != undefined ? frete.innerHTML : 'sem frete';
        } catch (error) {
          frete = 'erro';
        }
        
        let visitas = 0;
        let vendas = 0;

        let dadosVisitasSeparadas = dadosVisitas.split(' ');

        try {
          visitas = dadosVisitasSeparadas[0].replace('.', '');  
        } catch (error) {
          
        }

        visitas = parseInt(visitas);

      try {
        vendas = dadosVisitasSeparadas[2].replace('.', '');
      } catch (error) {
        
      }
        vendas = parseInt(vendas);
        
        let conversao = (visitas / vendas);
        conversao = ((1 / conversao) * 100);


        id = id.replace('#', 'MLB');

        let item = new Item(id);
        item.visitas = visitas;
        item.vendas = vendas;
        item.vendasreal = parseInt(vendas);
        item.conversaoreal = conversao;
        item.frete = frete;

        itemList.push(item)
      }

    })

    return itemList
  }


  static searchFull(itemList) {
    // For each item
    $('li.ui-search-layout__item').each(function () {
      const result = $(this).find(
        '.ui-search-item__fulfillment'
      )

      const id = $(this).find('input[name=itemId]').val()

      const item = itemList.find((item) => item.id === id)

      // Calculate the total value if installment payment
      if ($(result).length) {
        item.full = true
      }
    })

    return itemList
  }


  static searchTermosTendencias() {
    let itemList = []

    $('.searches__list > .searches__item').each(function () {
      let termo = $(this).find("a")[0].innerHTML;

      const item = {};
      item.termo = termo;

      itemList.push(item)
    })

    return itemList
  }
}