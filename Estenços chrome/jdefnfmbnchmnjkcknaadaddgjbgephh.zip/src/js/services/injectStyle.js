/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */

 var info = document.getElementsByClassName('StyleStart');
 for (let index = 0; index < info.length; index++) {
     const element = info[index];
     var dados = element.id;
     var s = document.createElement('style');
     s.id = dados.split('|')[1] != 'null' ? dados.split('|')[1] :`Null-${dados.split('|')[0]}-${Math.floor(+new Date() / 1000)}`;
     s.src = `${dados.split('|')[0]}`;
     (document.head || document.documentElement).appendChild(s);
 }

