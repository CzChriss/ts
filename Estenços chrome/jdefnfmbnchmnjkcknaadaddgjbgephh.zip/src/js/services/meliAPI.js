/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


class MeliAPI {
  static searchSellerById(id) { }


  static getItems(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(MeliAPI.getItemById(item.id));
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let item = []; item[0] = data; resolve(item); }
        const args = Array.from(arguments);
        if (data.length == undefined) resolve(data);

        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }

  static getItemById(id) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.delivery}/${id}?include_attributes=all`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }

  static getSellers(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getSellerById(item.seller_id)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {

        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getSellerById(id) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.seller}/${id}`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    })
  }




  static getTaxas(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getTaxasById(item.category_id, item.price, item.listing_type_id)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let taxas = []; taxas[0] = data; resolve(taxas); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getTaxasById(categoria, preco, tipoAnuncio) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.taxa}price=${preco}&category_id=${categoria}&listing_type_id=${tipoAnuncio}`


    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    })
  }

  static getTaxasByIdEspecifico(categoria, preco, tipoAnuncio) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.taxa}price=${preco}&category_id=${categoria}&listing_type_id=${tipoAnuncio}`


    return $.ajax({
      type: "GET",
      url: url,
      dataType: 'json',
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    })
  }





  static getFrete(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getFreteById(item.seller_id, item.id)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let frete = []; frete[0] = data; resolve(frete); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getFreteById(vendedor, anuncio) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.seller}/${vendedor}/shipping_options/free?item_id=${anuncio}`


    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }


  static getFreteDiferenca(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getFreteDiferencaById(item.seller_id, item.id)
        );
      });
      $.when.apply(this, ajax_requests)
      .done(function (data) {
        if (data.length == undefined) { let frete = []; frete[0] = data; resolve(frete); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0].coverage.all_country;
        });
        resolve(args);
      })
      .fail(function(data){ 
        let frete = []; resolve(frete);
       });
    });
  }

  static getFreteDiferencaById(vendedor, anuncio) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.seller}/${vendedor}/shipping_options/free?item_id=${anuncio}`
    let data = {};

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      }
    }).done(function (response) {
      data = response.coverage.all_country;
      data.id = anuncio;
      return data;
    });

  }



  static getVendedor(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getVendedorByNickname(item.nickname)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }

  static getVendedorByNickname(nickname) {
    let vendedorEncoded = encodeURIComponent(nickname).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
    const url = `${config.meliAPI.baseURL}${config.meliAPI.vendedorNickname}${vendedorEncoded}`
    

    let erro = false;
    let resultado = [];

    try {
      resultado = $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        cache: false,
        error: function (xhr) {
          erro = true;
        },
      });
    } catch (error) {
      return [];
    }

    if (erro) {
      return [];
    } else {
      return resultado;
    }

   
  }


  static getVendedorHoje(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getVendedorByNicknameHoje(item.nickname)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }

  static getVendedorByNicknameHoje(nickname) {
    let vendedorEncoded = encodeURIComponent(nickname).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
    const url = `${config.meliAPI.baseURL}${config.meliAPI.vendedorNickname}${vendedorEncoded}&since=today`
    
    let erro = false;
    let resultado = [];

    resultado = $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        erro = true;
      },
    });


    if (erro) {
      return [];
    } else {
      return resultado;
    }

  }


  static getItemUnico(id) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.delivery}/${id}?include_attributes=all`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }




  static getTendencias(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getTendenciasBy(item.termo)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let frete = []; frete[0] = data; resolve(frete); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getTendenciasBy(termo) {
    const url = `${config.meliAPI.baseURL}${config.meliAPI.tendencias}${termo}`


    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 80000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
          console.log('TIMEOUT');
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }



  static getVisitaUnico(id) {
    const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETVISITASUNICO?ITEM=${id}`;

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }




  static getVisitas(itemList) {
    console.log('getVisitas');
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getVisitasById(itemList)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {

        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getVisitasById(array) {
    //const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETMULTIVISITAS`;
    const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETMULTIVISITAS`;

    return $.ajax({
      type: "POST",
      url: url,
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(array),
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - Visitas não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    })
  }

  /** VISITAS */
  static getVisitasNovo(itemList) {
    console.log('getVisitas');
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getVisitasById(itemList)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {

        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);
        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getVisitasByIdNovo(array) {
    //const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETMULTIVISITAS`;
    const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETMULTIVISITASNOVO`;


    // const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETVISITAS?ITEM=${id}`

    return $.ajax({
      type: "POST",
      url: url,
      dataType: 'json',
      contentType: 'application/json',
      data: JSON.stringify(array),
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - Visitas não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    })
  }

  /** VISITAS */



  static getValidaUsuario(email, token) {
    const url = `${config.meliAPI.baseURLAuthNode}/validausuario?EMAIL=${email}&TOKEN=${token}`
    //const url = `${config.meliAPI.baseURLHeroku}/validausuario?EMAIL=${email}&TOKEN=${token}`
    //const url = `${config.meliAPI.baseURLAuth}/MLPRO/LOGIN/VALIDAR?EMAIL=${email}&TOKEN=${token}`

    console.log(url);

    let retorno = $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - usuario não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });

    return retorno;
  }


  static getValidaUsuarioSenha(email, token, senha) {
    const url = `${config.meliAPI.baseURLHeroku}/validausuariosenha?EMAIL=${email}&TOKEN=${token}&SENHA=${senha}`

    let retorno = $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - fretusuarioe não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });

    return retorno;
  }

  static getValidaAssinante(email, token) {
    const url = `${config.meliAPI.baseURLAuthNode}/validaassinantenovo?EMAIL=${email}&TOKEN=${token}`
    //const url = `${config.meliAPI.baseURLHeroku}/validaassinantenovo?EMAIL=${email}&TOKEN=${token}`
    //const url = `${config.meliAPI.baseURLAuth}/MLPRO/LOGIN/ASSINANTE?EMAIL=${email}&TOKEN=${token}`


    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - assinante não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - assinante não encontrada");
            break;
        }
      },
    });
  }



  static getTendenciasExtra(id) {
    const url = `https://ramcloud.com.br:9001/tendenciasextra?id=${id}`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 80000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
          console.log('TIMEOUT');
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
        }
      },
    });
  }




  static getTendenciasDadosExtra(id) {
    const url = `https://api.mercadolibre.com/sites/MLB/search?category=MLB${id}`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 80000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
          console.log('TIMEOUT');
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - tendencias dados extra não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - tendencias dados extra não encontrada.");
            break;
        }
      },
    });
  }




  static getEanVariacoes(itemList) {
    return new Promise((resolve, reject) => {

      let ajax_requests = [];
      $.each(itemList, function (index, item) {
        ajax_requests.push(
          MeliAPI.getEanVariacoesById(item)
        );
      });
      $.when.apply(this, ajax_requests).done(function (data) {
        if (data.length == undefined) { let vendedor = []; vendedor[0] = data; resolve(vendedor); }
        const args = Array.from(arguments);

        args.forEach(function (data, index) {
          args[index] = data[0];
        });
        resolve(args);
      });
    });
  }


  static getEanVariacoesById(itemList) {
    const url = `${config.meliAPI.baseURLHeroku}/eanvariacoes`

    console.log(itemList);

    return $.ajax({
      type: "POST",
      url: url,
      dataType: 'json',
      type: 'post',
      contentType: 'application/json',
      data: JSON.stringify(itemList.jsonVariacao),
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - Variacoes não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - Variacoes não encontrada");
            break;
        }
      },
    })

  }


  static getAnunciosMaisVendidos(id) {
    const url = `https://ramcloud.com.br:12000/ram/xdados/MLANALYTICS/GETMAISVENDIDOS?CATEGORIA=MLB${id}`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 80000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - mais vendidos não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - mais vendidos não encontrado.");
            break;
        }
      },
    });
  }


  static getAviso() {
    const url = `https://ramcloud.com.br:12998/ram/xdados/alerta_vendas`;

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
        }
      },
    });
  }



  static postBIPesquisa(email, pesquisa) {
    const url = `${config.meliAPI.baseURLBI}/bi/savesearch`

    return $.ajax({
      type: "POST",
      url: url,
      data: JSON.stringify({ EMAIL: email, PESQUISA: pesquisa.substring(0, 250) }),
      dataType: 'json',
      contentType: 'application/json',
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - Erro ao enviar termo buscado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - Erro ao enviar termo buscado.");
            break;
        }
      },
    })
  }






  static getItemsMaisVendidos(itemList) {
    console.log(itemList);
    let url = `https://ramcloud.com.br:9001/mlpro/pesquisacatalogo`;


    return $.ajax({
      type: "POST",
      url: url,
      dataType: "json",
      contentType: 'application/json',
      data: JSON.stringify({ items: itemList }),
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - frete não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - página não encontrada");
            break;
        }
      },
    });
  }



  static getSazonalidade() {
    const url = `https://ramcloud.com.br:12998/ram/xdados/SqlListaPedidosService/GetListarTabelaJson?Campos=*&Tabela=SAZONALIDADES&Filtro=%20`;

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
        }
      },
    });
  }



  static getTaxaCategoria(id) {
    const url = `https://ramcloud.com.br:9001/mlpro/taxacategoria?id=${id}`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 10000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {

        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
        }
      },
    });
  }


  
  static postDadosTeste(dados, email, tipo, versao) {
    const url = `https://ramcloud.com.br:9001/mlpro/dadosregistro`;

    let versaoString = String(versao);

    return $.ajax({
      type: "POST",
      url: url,
      dataType: "json",
      cache: false,
      data: JSON.stringify({ dados: dados }),
      contentType: 'application/json',
      headers: {emailmlpro:email, tipomlpro:tipo, versaomlpro:versaoString},
      error: function (xhr) {
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - aviso não encontrado.");
            break;
        }
      },
    });
  }

  static getTaxaClassico(id) {
    const url = `https://api.mercadolibre.com/sites/MLB/listing_prices?price=100&category_id=${id}&listing_type_id=gold_special`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 10000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
          console.log('TIMEOUT');
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
        }
      },
    });
  }

  static getTaxaPremium(id) {
    const url = `https://api.mercadolibre.com/sites/MLB/listing_prices?price=100&category_id=${id}&listing_type_id=gold_pro`

    return $.ajax({
      type: "GET",
      url: url,
      dataType: "json",
      cache: false,
      timeout: 10000,
      error: function (xhr, textStatus, errorThrown) {
        if (textStatus === "timeout") {
          console.log('TIMEOUT');
        }
        switch (xhr.status) {
          case 400:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
          case 404:
            console.log("Erro: " + xhr.status + " - categorias extra não encontrada.");
            break;
        }
      },
    });
  }




  static async scriptBase(url){
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('src/js/services/inject.js');
    s.id = `${url}|null`;
    s.classList.add('ScriptStart');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
  }


  static async scriptBase2(url, id){
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('src/js/services/inject.js');
    s.id = `${url}|${id}`;
    s.classList.add('ScriptStart');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
  }

  static async styleBase(url){
    var s = document.createElement('script');
    s.src = chrome.runtime.getURL('src/js/services/injectStyle.js');
    s.id = `${url}|null`;
    s.classList.add('StyleStart');
    s.onload = function() {
        this.remove();
    };
    (document.head || document.documentElement).appendChild(s);
  }

}




