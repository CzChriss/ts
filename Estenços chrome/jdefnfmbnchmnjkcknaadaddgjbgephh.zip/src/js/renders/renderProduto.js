/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


class RenderProdutos {
    static Produto(rawItems, ultra) {
        var divSubtitle = document.createElement('div');
        divSubtitle.className = 'divSubtitle';

        divSubtitle.style.border

        var Titulo = document.getElementsByClassName('ui-pdp-header__subtitle')[0];

        if (Titulo == undefined) {
            if (document.getElementsByClassName('ui-pdp-header__tag').length > 0) {
                Titulo = document.createElement('div');
                Titulo.appendChild(document.getElementsByClassName('ui-pdp-header__tag')[0]);
            } else {
                var Titulo2 = document.getElementsByClassName('ui-pdp-container__row ui-pdp-container__row--header')[0];
                var Titulo = document.createElement('div');
                Titulo.classList.add("ui-pdp-header__subtitle");
                Titulo2.insertAdjacentElement("afterbegin", Titulo);
            }
        }

        divSubtitle.appendChild(Titulo);

        var header = document.getElementsByClassName('ui-pdp-header')[0];

        var vendas = document.createElement('div');
        vendas.className = 'vendas';
        vendas.insertBefore(divSubtitle, vendas.firstChild);

        header.insertBefore(vendas, document.getElementsByClassName("ui-pdp-header__title-container")[0]);

        var conteudo = document.createElement('div');
        if (rawItems.catalogo) {
            conteudo.className = "conteudoProdutoCatalogo";
        }
        else {
            conteudo.className = "conteudoProduto";
        }

        let visitas = '';
        let vendasHTML = 0;


        try {
            vendasHTML = document.getElementsByClassName('ui-pdp-subtitle')[0].innerHTML;
            vendasHTML = vendasHTML.split("|")[1];
            vendasHTML = vendasHTML.replace(" vendidos", "");
            vendasHTML = vendasHTML.replace("mil", "000");
            vendasHTML = vendasHTML.replace(" ", "");
            vendasHTML = vendasHTML.replace("+", "");
            vendasHTML = vendasHTML.trim();
            vendasHTML = parseInt(vendasHTML);
        } catch (error) {
            vendasHTML = 0;
        }

        let oficial = '';
        oficial = rawItems.seller.seller.tags.filter(x => x == 'brand');

        if (rawItems.event.pageId == 'VIP' && rawItems.event.soldStock != 0) {
            vendasHTML = rawItems.event.soldStock;
            rawItems.numero_vendas = rawItems.event.soldStock;
        }

        var ValorString = '';

        try {
            ValorString = rawItems.event.soldStock.toLocaleString('pt-BR', {});
            rawItems.numero_vendas_string = ValorString;
        } catch (error) {
            ValorString = '0';
            rawItems.numero_vendas_string = ValorString;
        }

        try {
            ValorString = rawItems.availableStock ? rawItems.availableStock.toLocaleString('pt-BR', {}) : rawItems.event.availableStock.toLocaleString('pt-BR', {});
            rawItems.numero_stock_string = ValorString;
        } catch (error) {
            ValorString = '0';
            rawItems.numero_stock_string = ValorString;
        }

        try {
            var meses = (rawItems.days / 30);
            var mediaMes = meses < 1 ? 'Menos de um Mês Vendendo' : (rawItems.numero_vendas / meses);
            var mediaDia = (rawItems.numero_vendas / rawItems.days);
            rawItems.mediaMes = mediaMes;
            rawItems.mediaDia = mediaDia;
        } catch (error) {

        }

        visitas = `
        <div class="cardInfos" style="display: flex; min-height: auto !important; border-radius: 50px;"><div style="margin: 0 auto 0 auto;">
            ${rawItems.visitas > 0 && vendasHTML > 0 ? `<p class="tituloCard" ><svg width="15" height="9" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.5 1.73333C11.088 1.72804 12.6453 2.17255 13.9927 3.01576C15.3402 3.85898 16.4232 5.06667 17.1173 6.5C15.6923 9.42067 12.7818 11.2667 9.5 11.2667C6.21818 11.2667 3.30773 9.42067 1.88273 6.5C2.57676 5.06667 3.65977 3.85898 5.00726 3.01576C6.35474 2.17255 7.912 1.72804 9.5 1.73333ZM9.5 0C5.18182 0 1.49409 2.69533 0 6.5C1.49409 10.3047 5.18182 13 9.5 13C13.8182 13 17.5059 10.3047 19 6.5C17.5059 2.69533 13.8182 0 9.5 0ZM9.5 4.33333C10.0726 4.33333 10.6218 4.56161 11.0267 4.96794C11.4316 5.37426 11.6591 5.92536 11.6591 6.5C11.6591 7.07464 11.4316 7.62574 11.0267 8.03206C10.6218 8.43839 10.0726 8.66667 9.5 8.66667C8.92737 8.66667 8.3782 8.43839 7.97329 8.03206C7.56838 7.62574 7.34091 7.07464 7.34091 6.5C7.34091 5.92536 7.56838 5.37426 7.97329 4.96794C8.3782 4.56161 8.92737 4.33333 9.5 4.33333ZM9.5 2.6C7.35818 2.6 5.61364 4.35067 5.61364 6.5C5.61364 8.64933 7.35818 10.4 9.5 10.4C11.6418 10.4 13.3864 8.64933 13.3864 6.5C13.3864 4.35067 11.6418 2.6 9.5 2.6Z" fill="#303030"/></svg> Visitas</p><p><strong> ${rawItems.visitas.toLocaleString('pt-BR', {})} </strong></p></div>` +
                `<div class="colVendeCada" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="15" height="12" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.8335 0.796875V1.14551C11.0557 1.18535 11.271 1.23516 11.4654 1.28496C11.9099 1.39785 12.1737 1.83613 12.0557 2.26113C11.9376 2.68613 11.4793 2.93848 11.0348 2.82559C10.6564 2.7293 10.3022 2.66289 9.98622 2.65957C9.73275 2.65625 9.4758 2.71602 9.3126 2.80566C9.23968 2.84883 9.20496 2.88535 9.19107 2.90527C9.18066 2.92188 9.16677 2.94512 9.16677 2.99824V3.01816C9.17371 3.0248 9.19802 3.05801 9.28135 3.10449C9.48274 3.2207 9.78136 3.31035 10.2328 3.43984L10.264 3.4498C10.6494 3.55938 11.1633 3.70879 11.58 3.95781C12.0557 4.24336 12.4862 4.71816 12.4967 5.44863C12.5071 6.1957 12.1008 6.74023 11.5696 7.05898C11.3369 7.19512 11.0869 7.29141 10.83 7.35117V7.70312C10.83 8.14473 10.4584 8.5 9.99664 8.5C9.53483 8.5 9.16329 8.14473 9.16329 7.70312V7.32461C8.83343 7.24824 8.53134 7.14863 8.2744 7.06563C8.20148 7.04238 8.13203 7.01914 8.06606 6.99922C7.62856 6.85977 7.39244 6.4082 7.53828 5.98984C7.68411 5.57148 8.15634 5.3457 8.59384 5.48516C8.68412 5.51504 8.76746 5.5416 8.84732 5.56816C9.31955 5.7209 9.65983 5.83047 10.0244 5.84375C10.3022 5.85371 10.5487 5.79062 10.6911 5.70762C10.7571 5.66777 10.7883 5.63457 10.8022 5.61133C10.8161 5.59141 10.8335 5.55156 10.83 5.47519V5.46855C10.83 5.43535 10.83 5.39883 10.6911 5.31582C10.4932 5.19629 10.1946 5.10332 9.75011 4.97383L9.68413 4.95391C9.30913 4.84766 8.81607 4.70488 8.42023 4.47578C7.95148 4.20684 7.50008 3.74531 7.49661 3.01152C7.49314 2.25117 7.94453 1.72988 8.45843 1.4377C8.68065 1.31152 8.92024 1.2252 9.15982 1.16543V0.796875C9.15982 0.355273 9.53135 0 9.99316 0C10.455 0 10.8265 0.355273 10.8265 0.796875H10.8335ZM19.7294 11.1662C20.1842 11.7572 20.0523 12.5873 19.4342 13.0223L15.0384 16.1201C14.2258 16.6912 13.2467 17 12.2362 17H1.11112C0.496533 17 0 16.5252 0 15.9375V13.8125C0 13.2248 0.496533 12.75 1.11112 12.75H2.38892L3.94796 11.5547C4.73616 10.9504 5.71534 10.625 6.72577 10.625H12.2224C12.8369 10.625 13.3335 11.0998 13.3335 11.6875C13.3335 12.2752 12.8369 12.75 12.2224 12.75H9.44455C9.13899 12.75 8.88899 12.9891 8.88899 13.2812C8.88899 13.5734 9.13899 13.8125 9.44455 13.8125H13.6321L17.7884 10.884C18.4065 10.449 19.2745 10.5752 19.7294 11.1662ZM6.7223 12.75H6.69104H6.7223Z" fill="#303030"/></svg> Vende a Cada</p><strong>${(rawItems.visitas / vendasHTML).toFixed(0)}</strong> Visitas</div>` +
                `<div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="7" height="12" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.71429 0H10.2857C10.7404 0 11.1764 0.179107 11.4979 0.497918C11.8194 0.81673 12 1.24913 12 1.7V15.3C12 15.7509 11.8194 16.1833 11.4979 16.5021C11.1764 16.8209 10.7404 17 10.2857 17H1.71429C1.25963 17 0.823594 16.8209 0.502103 16.5021C0.180612 16.1833 0 15.7509 0 15.3V1.7C0 1.24913 0.180612 0.81673 0.502103 0.497918C0.823594 0.179107 1.25963 0 1.71429 0ZM1.71429 1.7V5.1H10.2857V1.7H1.71429ZM1.71429 6.8V8.5H3.42857V6.8H1.71429ZM5.14286 6.8V8.5H6.85714V6.8H5.14286ZM8.57143 6.8V8.5H10.2857V6.8H8.57143ZM1.71429 10.2V11.9H3.42857V10.2H1.71429ZM5.14286 10.2V11.9H6.85714V10.2H5.14286ZM8.57143 10.2V11.9H10.2857V10.2H8.57143ZM1.71429 13.6V15.3H3.42857V13.6H1.71429ZM5.14286 13.6V15.3H6.85714V13.6H5.14286ZM8.57143 13.6V15.3H10.2857V13.6H8.57143Z" fill="#303030"/></svg> Conversão</p><strong>${((1 / (rawItems.visitas / vendasHTML)) * 100).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%</strong></div>` : `${rawItems.visitas > 0 ? `<div><p class="tituloCard" ><svg width="15" height="9" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.5 1.73333C11.088 1.72804 12.6453 2.17255 13.9927 3.01576C15.3402 3.85898 16.4232 5.06667 17.1173 6.5C15.6923 9.42067 12.7818 11.2667 9.5 11.2667C6.21818 11.2667 3.30773 9.42067 1.88273 6.5C2.57676 5.06667 3.65977 3.85898 5.00726 3.01576C6.35474 2.17255 7.912 1.72804 9.5 1.73333ZM9.5 0C5.18182 0 1.49409 2.69533 0 6.5C1.49409 10.3047 5.18182 13 9.5 13C13.8182 13 17.5059 10.3047 19 6.5C17.5059 2.69533 13.8182 0 9.5 0ZM9.5 4.33333C10.0726 4.33333 10.6218 4.56161 11.0267 4.96794C11.4316 5.37426 11.6591 5.92536 11.6591 6.5C11.6591 7.07464 11.4316 7.62574 11.0267 8.03206C10.6218 8.43839 10.0726 8.66667 9.5 8.66667C8.92737 8.66667 8.3782 8.43839 7.97329 8.03206C7.56838 7.62574 7.34091 7.07464 7.34091 6.5C7.34091 5.92536 7.56838 5.37426 7.97329 4.96794C8.3782 4.56161 8.92737 4.33333 9.5 4.33333ZM9.5 2.6C7.35818 2.6 5.61364 4.35067 5.61364 6.5C5.61364 8.64933 7.35818 10.4 9.5 10.4C11.6418 10.4 13.3864 8.64933 13.3864 6.5C13.3864 4.35067 11.6418 2.6 9.5 2.6Z" fill="#303030"/></svg> Visitas</p><p><strong> ${rawItems.visitas} </strong></p></div>` : '<p><strong>Erro ao obter dados de visitas</strong></p>'}`}
            </div>
        </div>`

        /** PONTOS NEGATIVOS */

        var pontosNegativos = '';

        let estoque = '';
        try {
            estoque = document.getElementsByClassName("ui-pdp-buybox__quantity__available")[0].innerHTML;
            estoque = estoque.replace(/\D/g, "");
        } catch (error) {
            try {
                estoque = document.getElementsByClassName("ui-pdp-color--BLACK ui-pdp-size--MEDIUM ui-pdp-family--SEMIBOLD")[0].innerHTML;
            } catch (error) {

            }
            if (estoque == 'Último disponível!') estoque = 1;
        }
        let descricao = document.getElementsByClassName("ui-pdp-description__content")[0] != undefined ? document.getElementsByClassName("ui-pdp-description__content")[0].innerHTML : '';

        descricao.replaceAll('<br>');


        rawItems.descricao = descricao;
        rawItems.estoque = parseInt(estoque);


        rawItems.pictures ? '' : rawItems.pictures = [];

        if (rawItems.estoque < 100) pontosNegativos += `<li class="subtitleData">Estoque baixo, menos de 100 unidades</li>`;
        if (rawItems.video_id == '' || rawItems.video_id == null) pontosNegativos += `<li class="subtitleData">Não possui vídeo</li>`;
        if (rawItems.descricao.length < 500) pontosNegativos += `<li class="subtitleData">Descrição muito curta, menos de 500 caracteres</li>`;
        if (rawItems.pictures.length < 5) pontosNegativos += `<li class="subtitleData">Possui menos de 5 fotos no anúncio</li>`;
        if (rawItems.warranty == 'Sem garantia') pontosNegativos += `<li class="subtitleData">Não fornece garantia</li>`;
        if (rawItems.ean == 'Sem EAN' || rawItems.ean == null || rawItems.ean == '') pontosNegativos += `<li class="subtitleData">Não possui EAN (Código de Barras)</li>`;
        if (rawItems.semResolucao > 0) pontosNegativos += `<li class="subtitleData">${rawItems.semResolucao} foto(s) sem resolução mínima <small>(1200x1200)</small></li>`;

        if (pontosNegativos == '') pontosNegativos = 'Sem Pontos Negativos';

        $('.ui-pdp-thumbnail__picture').each(function () {
            setTimeout(() => {
                if ($(this).find('.ui-pdp-image')) {
                    for (let i = 0; i < rawItems.pictures.length; i++) {
                        if ($(this).find('.ui-pdp-image')[0].currentSrc.includes(rawItems.pictures[i].id.split('-')[1])) {
                            if (!$(this)[0].classList.contains('ui-pdp-thumbnail__picture--LARGE')) {
                                let tamanho = rawItems.pictures[i].max_size.split('x');
                                if (parseInt(tamanho[0]) < 1200 || parseInt(tamanho[1]) < 1200) {
                                    $(this)[0].style.border = 'solid red';
                                    var span = document.createElement("span");
                                    span.classList.add("imagemInvalida");
                                    $(this)[0].prepend(span);
                                }
                            }
                        }
                    }
                }
            }, 500)
        });

        // Tooltip de imagem inválida
        var contador = document.getElementsByClassName("ui-pdp-gallery__label");
        for (let i = 0; i < contador.length; i++) {
            if (contador[i].getElementsByClassName("imagemInvalida").length > 0) {
                var div = document.createElement("div");
                div.classList.add("tooltiptext");
                div.classList.add("tooltipImagemInvalida");
                div.innerHTML = "Fotos com borda vermelha não possuem a resolução mínima (1200x1200)";

                contador[i].insertAdjacentElement("afterbegin", div);
            }
        }

        /** FIM PONTOS NEGATIVOS */


        let faturando = '';
        faturando = vendasHTML > 0 ? `<span id="precoFaturamento">${(rawItems.price * vendasHTML).toLocaleString('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })}</span>` : '0,00'

        let faturamento = '';
        faturamento = vendasHTML > 0 ? `<div><span class="subtitleData">Considerando</span> <span class="subtitleData" id="mediaTxt">${vendasHTML.toLocaleString('pt-BR')} unidade(s) vendida(s) no total</span> <span class="subtitleData">e o valor de R$${rawItems.price.toLocaleString('pt-BR', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        })} a unidade, concluimos que esse item gerou uma arrecadação bruta de R$</span><span class="subtitleData" id="faturamentoTxt">${faturando}.</span>
        ${rawItems.catalogo ? '<p style="margin-top: 5px;color: red;font-weight: bold;">Número de venda Aproximado para catálogo</p>' : ''}        
        </div>` : '';

        let ean = '';
        if (rawItems.ean != null) {
            if (rawItems.ean != 'Sem EAN') {
                ean = rawItems.ean.split(',');
                ean = ean.filter(x => x.trim());
                ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs' : ean[0];
            } else {
                ean = rawItems.ean;
            }
        }

        MeliAPI.scriptBase('https://ramcloud.com.br/scriptranking3.js')
        MeliAPI.scriptBase('https://ramcloud.com.br/dropproduto.js')

        // var script = document.createElement('script');
        // script.src = 'https://ramcloud.com.br/scriptranking.js?' + Math.round((new Date()).getTime() / 1000);
        // header.appendChild(script);


        conteudo.innerHTML = /* html */`

            ${ultra ? '' : `<center><button class="botaoUltra" onClick="javascript:window.open('https://avantpro.com.br/ml/', '_blank');">Conheça o Avantpro Ultra</button> </center>`}

            <button type="button" class="fechaInfos"><svg width="10" height="10" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></button>
            <div class="headerProduto"><svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
            <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
            <defs>
            <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
            <stop offset="0.380208" stop-color="#F2A008"/>
            <stop offset="0.792994" stop-color="#F9D043"/>
            </linearGradient>
            <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
            <stop stop-color="#1B22B8"/>
            <stop offset="1" stop-color="#4D43FA"/>
            </linearGradient>
            </defs>
            </svg><h4 style="margin-right: auto; font-weight: 800; color: var(--grey);">Informações Avantpro</h4></div>
            <span id="precoProdutoReal" style="display: none;">${rawItems.price}</span>

            <div style="position:relative;align-items: center; ${rawItems.catalogo ? "display: block" : "display: flex"}">
                ${rawItems.catalogo ? `<div class="cardInfos" style="display: flex;align-items: center;justify-content: center;font-size: 13.5px !important;min-height: auto !important;border-color: var(--warning);width: fit-content;margin: 0 auto 12px auto;padding: 6px 12px 6px 12px;">` : `<div class="cardInfos cardApendice" style="display: flex;align-items: center; justify-content: center; font-size: 13.5px !important; min-height: auto !important; border-color: var(--warning); width: fit-content; margin: 0 auto 12px auto; padding: 6px 12px 6px 12px; ${oficial == 'brand' ? 'margin-right: 2px;' : ''}" >`}
                    <div style="display: flex; position: relative; color: var(--warning) !important;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24"><path fill="currentColor" d="M9.5 10.5H12a1 1 0 0 0 0-2h-1V8a1 1 0 0 0-2 0v.55a2.5 2.5 0 0 0 .5 4.95h1a.5.5 0 0 1 0 1H8a1 1 0 0 0 0 2h1v.5a1 1 0 0 0 2 0v-.55a2.5 2.5 0 0 0-.5-4.95h-1a.5.5 0 0 1 0-1ZM21 12h-3V3a1 1 0 0 0-.5-.87a1 1 0 0 0-1 0l-3 1.72l-3-1.72a1 1 0 0 0-1 0l-3 1.72l-3-1.72a1 1 0 0 0-1 0A1 1 0 0 0 2 3v16a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-6a1 1 0 0 0-1-1ZM5 20a1 1 0 0 1-1-1V4.73l2 1.14a1.08 1.08 0 0 0 1 0l3-1.72l3 1.72a1.08 1.08 0 0 0 1 0l2-1.14V19a3 3 0 0 0 .18 1Zm15-1a1 1 0 0 1-2 0v-5h2Z"/></svg>
                    <p class="tituloCard" style="color: var(--warning) !important; margin: 0 4px 0 4px;">Vendidos: </p>
                    <p style="font-size: 12.5px; margin-left: margin: 0;">
                        <strong class="numeroExatoVendas" style="position: relative;">
                            ${rawItems.catalogo ? '<div class="tooltiptext tolltipInformaçãoIndisponivel">Informação disponível apenas para produtos fora do catálogo</div><strong style="position: relative;">Indisponível</strong>' : `${rawItems.numero_vendas_string}`}
                        </strong>
                    </p>

                    ${!rawItems.catalogo ? `<span style="top: -16px; right: -16px;"><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="var(--info)" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="var(--info)"/></svg></span><div class="tooltiptext" style="color: white; left: 110%; bottom: 230%;">
                        <p>Quantidade de vendas aproximada conforme tabela de range ML.</p>
                        <p style="text-decoration: underline; margin-top: 8px; cursor: pointer; width: fit-content; margin-left: auto; margin-right: 8px" id="btnModalRange">Saiba mais.</p>
                    </div>` : ''}
                    
                    </div>     
                </div>

                ${rawItems.catalogo ? `<div class="cardInfos" style="display: flex;align-items: center;justify-content: center;font-size: 13.5px !important;min-height: auto !important;border-color: var(--info);width: fit-content;margin: 0 auto 12px auto;padding: 6px 12px 6px 12px;">` : `<div class="cardInfos" style="display: flex;align-items: center; justify-content: center; font-size: 13.5px !important; min-height: auto !important; border-color: var(--info); width: fit-content; margin: 0 auto 12px auto; padding: 6px 12px 6px 12px; ${oficial == 'brand' ? 'margin-right: 2px;' : ''}" >`}
                    <div style="display: flex; position: relative; color: var(--info) !important;align-items:center">
                    <svg style="margin-right: 4px;" width="12" height="13" viewBox="0 0 14 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13 4.58252L7 1.58252L1 4.58252V10.5825L7 13.5825L13 10.5825V4.58252Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"></path><path d="M1 4.58252L7 7.58252M7 7.58252V13.5825M7 7.58252L13 4.58252M10 3.08252L4 6.08252" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                    <p class="tituloCard" style="color: var(--info) !important; margin: 0 4px 0 4px;">Estoque: </p>
                    <p style="font-size: 12.5px; margin-left: margin: 0;"><strong class="numeroExatoVendas" style="position: relative;">${rawItems.catalogo ? '<div class="tooltiptext tolltipInformaçãoIndisponivel">Informação disponível apenas para produtos fora do catálogo</div><strong style="position: relative;">Indisponível</strong>' : `${rawItems.numero_stock_string}`}</strong> </p>
                    </div>     
                </div>

                ${rawItems.catalogo ? '<div style="position: absolute;right: 0%; top: 10%;">' : '<div style=" "> '}
                    ${oficial == 'brand' ? ' <svg style=" " width="15" height="15" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg> <p style="color: #2AC568;font-weight: bold;font-size: 13px">Loja</p><p style="color: #2AC568;font-weight: bold;font-size: 13px"> Oficial</p>' : ''}
                </div>
            </div>

            <div class="linha-3" style="margin: 7px 0 7px 0; display: flex; align-items: center;">
                ${rawItems.TAXA ? /* html */`<p class="tituloCard" style="margin-right: 14px; font-size: 13.5px !important;"><strong><svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.02 10.22L10.955 5.285L9.975 4.305L6.02 8.26L4.025 6.265L3.045 7.245L6.02 10.22ZM7 14C6.03167 14 5.12167 13.8161 4.27 13.4484C3.41833 13.0811 2.6775 12.5825 2.0475 11.9525C1.4175 11.3225 0.918867 10.5817 0.5516 9.73C0.183867 8.87833 0 7.96833 0 7C0 6.03167 0.183867 5.12167 0.5516 4.27C0.918867 3.41833 1.4175 2.6775 2.0475 2.0475C2.6775 1.4175 3.41833 0.918633 4.27 0.5509C5.12167 0.183633 6.03167 0 7 0C7.96833 0 8.87833 0.183633 9.73 0.5509C10.5817 0.918633 11.3225 1.4175 11.9525 2.0475C12.5825 2.6775 13.0811 3.41833 13.4484 4.27C13.8161 5.12167 14 6.03167 14 7C14 7.96833 13.8161 8.87833 13.4484 9.73C13.0811 10.5817 12.5825 11.3225 11.9525 11.9525C11.3225 12.5825 10.5817 13.0811 9.73 13.4484C8.87833 13.8161 7.96833 14 7 14ZM7 12.6C8.56333 12.6 9.8875 12.0575 10.9725 10.9725C12.0575 9.8875 12.6 8.56333 12.6 7C12.6 5.43667 12.0575 4.1125 10.9725 3.0275C9.8875 1.9425 8.56333 1.4 7 1.4C5.43667 1.4 4.1125 1.9425 3.0275 3.0275C1.9425 4.1125 1.4 5.43667 1.4 7C1.4 8.56333 1.9425 9.8875 3.0275 10.9725C4.1125 12.0575 5.43667 12.6 7 12.6Z" fill="#4F4F4F"/></svg> ${rawItems.TAXA.listing_type_name}</strong></p>` : '<p style="display: none;"> </p>'}
                ${rawItems.catalogo ? /* html */ `<p class="tituloCard" style="font-size: 13.5px !important; margin-right: 14px; align-item: center; displat: flex;"><svg style="margin-right: 5px;" width="12" height="12" viewBox="0 0 16 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.2973 5.2C0.579459 5.2 0 5.78067 0 6.5C0 7.21933 0.579459 7.8 1.2973 7.8C2.01514 7.8 2.59459 7.21933 2.59459 6.5C2.59459 5.78067 2.01514 5.2 1.2973 5.2ZM1.2973 0C0.579459 0 0 0.580667 0 1.3C0 2.01933 0.579459 2.6 1.2973 2.6C2.01514 2.6 2.59459 2.01933 2.59459 1.3C2.59459 0.580667 2.01514 0 1.2973 0ZM1.2973 10.4C0.579459 10.4 0 10.9893 0 11.7C0 12.4107 0.588108 13 1.2973 13C2.00649 13 2.59459 12.4107 2.59459 11.7C2.59459 10.9893 2.01514 10.4 1.2973 10.4ZM4.75676 12.5667H15.1351C15.6108 12.5667 16 12.1767 16 11.7C16 11.2233 15.6108 10.8333 15.1351 10.8333H4.75676C4.28108 10.8333 3.89189 11.2233 3.89189 11.7C3.89189 12.1767 4.28108 12.5667 4.75676 12.5667ZM4.75676 7.36667H15.1351C15.6108 7.36667 16 6.97667 16 6.5C16 6.02333 15.6108 5.63333 15.1351 5.63333H4.75676C4.28108 5.63333 3.89189 6.02333 3.89189 6.5C3.89189 6.97667 4.28108 7.36667 4.75676 7.36667ZM3.89189 1.3C3.89189 1.77667 4.28108 2.16667 4.75676 2.16667H15.1351C15.6108 2.16667 16 1.77667 16 1.3C16 0.823333 15.6108 0.433333 15.1351 0.433333H4.75676C4.28108 0.433333 3.89189 0.823333 3.89189 1.3Z" fill="#4F4F4F"/></svg>Item Catálogo</p> <span id="vendasCatalogoNovo" style="display: none;">${vendasHTML}</span>` : '<p style="display: none;"> </p>'}
                <div style="display: flex; align-items:center;">${rawItems.FRETE ? `<p class="tituloCard" style="font-size: 13.5px !important; display: flex; align-items: center;"><svg style="margin-right: 5px;" width="13" height="12" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.8 0C1.32261 0 0.864773 0.187091 0.527208 0.520114C0.189642 0.853138 0 1.30482 0 1.77578V11.2466C3.55766e-05 11.6889 0.167343 12.1152 0.469184 12.4422C0.771025 12.7691 1.18568 12.9732 1.632 13.0145C1.72413 13.5678 2.01232 14.0709 2.44527 14.4343C2.87822 14.7976 3.42782 14.9975 3.99621 14.9984C4.5646 14.9994 5.11488 14.8013 5.54907 14.4394C5.98326 14.0776 6.27318 13.5754 6.3672 13.0224H8.0328C8.12638 13.5751 8.4156 14.0771 8.84904 14.4392C9.28247 14.8013 9.83203 15 10.4 15C10.968 15 11.5175 14.8013 11.951 14.4392C12.3844 14.0771 12.6736 13.5751 12.7672 13.0224H14.2C14.4364 13.0224 14.6704 12.9765 14.8888 12.8872C15.1072 12.798 15.3056 12.6672 15.4728 12.5023C15.6399 12.3374 15.7725 12.1416 15.863 11.9262C15.9534 11.7107 16 11.4798 16 11.2466V6.97448C15.9999 6.71158 15.9406 6.45199 15.8264 6.21445L14.4672 3.38346C14.3214 3.07964 14.0911 2.8229 13.8032 2.64309C13.5153 2.46328 13.1816 2.36778 12.8408 2.36771H11.6V1.77578C11.6 1.30482 11.4104 0.853138 11.0728 0.520114C10.7352 0.187091 10.2774 0 9.8 0H1.8ZM12.664 11.8385C12.4726 11.3065 12.0954 10.8591 11.6 10.5766V7.49775H14.8V9.86545H13.8C13.6409 9.86545 13.4883 9.92782 13.3757 10.0388C13.2632 10.1498 13.2 10.3004 13.2 10.4574C13.2 10.6144 13.2632 10.7649 13.3757 10.8759C13.4883 10.9869 13.6409 11.0493 13.8 11.0493H14.8V11.2466C14.8 11.4036 14.7368 11.5542 14.6243 11.6652C14.5117 11.7762 14.3591 11.8385 14.2 11.8385H12.664ZM10.4 10.2601C9.90351 10.2599 9.41918 10.4117 9.01372 10.6943C8.60826 10.977 8.30161 11.3768 8.136 11.8385H6.264C6.09872 11.3768 5.79246 10.977 5.38736 10.6941C4.98227 10.4112 4.49825 10.2591 4.00193 10.2588C3.50561 10.2584 3.02138 10.4099 2.61588 10.6922C2.21038 10.9745 1.90354 11.3739 1.7376 11.8354C1.59007 11.8202 1.45348 11.7516 1.3542 11.6428C1.25492 11.5341 1.19999 11.393 1.2 11.2466V1.77578C1.2 1.61879 1.26321 1.46823 1.37574 1.35723C1.48826 1.24622 1.64087 1.18385 1.8 1.18385H9.8C9.95913 1.18385 10.1117 1.24622 10.2243 1.35723C10.3368 1.46823 10.4 1.61879 10.4 1.77578V10.2601ZM11.6 3.55156H12.84C12.9538 3.55139 13.0652 3.58313 13.1614 3.64307C13.2576 3.70302 13.3345 3.78871 13.3832 3.89015L14.5464 6.31389H11.6V3.55156ZM4 13.8116C3.68174 13.8116 3.37652 13.6869 3.15147 13.4649C2.92643 13.2429 2.8 12.9418 2.8 12.6278C2.8 12.3138 2.92643 12.0127 3.15147 11.7907C3.37652 11.5687 3.68174 11.4439 4 11.4439C4.31826 11.4439 4.62348 11.5687 4.84853 11.7907C5.07357 12.0127 5.2 12.3138 5.2 12.6278C5.2 12.9418 5.07357 13.2429 4.84853 13.4649C4.62348 13.6869 4.31826 13.8116 4 13.8116ZM11.6 12.6278C11.6 12.9418 11.4736 13.2429 11.2485 13.4649C11.0235 13.6869 10.7183 13.8116 10.4 13.8116C10.0817 13.8116 9.77652 13.6869 9.55147 13.4649C9.32643 13.2429 9.2 12.9418 9.2 12.6278C9.2 12.3138 9.32643 12.0127 9.55147 11.7907C9.77652 11.5687 10.0817 11.4439 10.4 11.4439C10.7183 11.4439 11.0235 11.5687 11.2485 11.7907C11.4736 12.0127 11.6 12.3138 11.6 12.6278Z" fill="#303030"/></svg> ${rawItems.shipping.free_shipping ? `Frete: </p> <p style="font-size: 12.5px; margin-left: 4px; margin-bottom: 5px;"><strong> R$ ${rawItems.FRETE.coverage.all_country.list_cost.toFixed(2)}</strong></p>` : `Frete: </p><p style="font-size: 12.5px; margin-left: 4px; display: flex; align-items: center; margin-bottom: 5px;"><strong>Comprador</strong></p>`}` : '<p style="display: none;"> </p>'}</div>
            </div>
            ${visitas}
            <div class="infoEscondida escondeInfo">
            <div class="linha-3">
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6667 1.3H10V0H8.66667V1.3H3.33333V0H2V1.3H1.33333C0.593333 1.3 0.00666666 1.885 0.00666666 2.6L0 11.7C0 12.0448 0.140476 12.3754 0.390524 12.6192C0.640573 12.863 0.979711 13 1.33333 13H10.6667C11.4 13 12 12.415 12 11.7V2.6C12 1.885 11.4 1.3 10.6667 1.3ZM10.6667 11.7H1.33333V5.2H10.6667V11.7ZM4 7.8H2.66667V6.5H4V7.8ZM6.66667 7.8H5.33333V6.5H6.66667V7.8ZM9.33333 7.8H8V6.5H9.33333V7.8ZM4 10.4H2.66667V9.1H4V10.4ZM6.66667 10.4H5.33333V9.1H6.66667V10.4ZM9.33333 10.4H8V9.1H9.33333V10.4Z" fill="#303030"/></svg> Criado</p> <div class="linhaCard">há <strong>${rawItems.days.toLocaleString('pt-BR', {})}  </strong>  dia(s) <strong></div> <div>${rawItems.past.toLocaleDateString()} </strong> </div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="12" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.22222 6.21111L9.02778 8.01667C9.16019 8.14907 9.22639 8.31759 9.22639 8.52222C9.22639 8.72685 9.16019 8.89537 9.02778 9.02778C8.89537 9.16019 8.72685 9.22639 8.52222 9.22639C8.31759 9.22639 8.14907 9.16019 8.01667 9.02778L5.99444 7.00556C5.92222 6.93333 5.86806 6.85196 5.83194 6.76144C5.79583 6.67141 5.77778 6.57824 5.77778 6.48194V3.61111C5.77778 3.40648 5.84711 3.23483 5.98578 3.09617C6.12396 2.95798 6.29537 2.88889 6.5 2.88889C6.70463 2.88889 6.87628 2.95798 7.01494 3.09617C7.15313 3.23483 7.22222 3.40648 7.22222 3.61111V6.21111ZM6.5 13C5.59722 13 4.75174 12.8286 3.96356 12.4858C3.17489 12.1425 2.48878 11.6788 1.90522 11.0948C1.32119 10.5112 0.857518 9.82511 0.514222 9.03644C0.171407 8.24826 0 7.40278 0 6.5C0 5.59722 0.171407 4.7515 0.514222 3.96283C0.857518 3.17465 1.32119 2.48854 1.90522 1.9045C2.48878 1.32094 3.17489 0.857518 3.96356 0.514222C4.75174 0.171407 5.59722 0 6.5 0C7.48704 0 8.42304 0.210648 9.308 0.631944C10.1925 1.05324 10.9417 1.64907 11.5556 2.41944V1.44444C11.5556 1.23981 11.6249 1.06817 11.7636 0.9295C11.9017 0.791315 12.0731 0.722222 12.2778 0.722222C12.4824 0.722222 12.6538 0.791315 12.792 0.9295C12.9307 1.06817 13 1.23981 13 1.44444V4.33333C13 4.53796 12.9307 4.70937 12.792 4.84756C12.6538 4.98622 12.4824 5.05556 12.2778 5.05556H9.38889C9.18426 5.05556 9.01285 4.98622 8.87467 4.84756C8.736 4.70937 8.66667 4.53796 8.66667 4.33333C8.66667 4.1287 8.736 3.95706 8.87467 3.81839C9.01285 3.6802 9.18426 3.61111 9.38889 3.61111H10.6528C10.1593 2.93704 9.55139 2.40741 8.82917 2.02222C8.10694 1.63704 7.33056 1.44444 6.5 1.44444C5.09167 1.44444 3.89711 1.93483 2.91633 2.91561C1.93507 3.89687 1.44444 5.09167 1.44444 6.5C1.44444 7.90833 1.93507 9.10289 2.91633 10.0837C3.89711 11.0649 5.09167 11.5556 6.5 11.5556C7.60741 11.5556 8.60961 11.2306 9.50661 10.5806C10.4031 9.93056 11.0079 9.07593 11.3208 8.01667C11.381 7.81204 11.4925 7.64039 11.6552 7.50172C11.8175 7.36354 12.0009 7.31852 12.2056 7.36667C12.4222 7.41481 12.5816 7.53518 12.6837 7.72778C12.7862 7.92037 12.8074 8.125 12.7472 8.34167C12.35 9.72593 11.5736 10.8483 10.4181 11.7087C9.2625 12.5696 7.95648 13 6.5 13Z" fill="#303030"/></svg> Atualizado</p> <div class="linhaCard"> há <strong>  ${rawItems.AtualizadoDays}  </strong> dia(s)</div> <div><strong> ${rawItems.AtualizadoBruto.toLocaleDateString()} </strong></div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="12" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.4549 7.15C9.94226 7.15 10.3711 6.8835 10.5921 6.4805L12.9184 2.262C12.9732 2.16348 13.0013 2.05236 13 1.93964C12.9986 1.82692 12.9678 1.7165 12.9107 1.61932C12.8536 1.52214 12.7721 1.44156 12.6743 1.38555C12.5765 1.32955 12.4658 1.30006 12.3531 1.3H2.73575L2.12491 0H0V1.3H1.29964L3.639 6.2335L2.76174 7.8195C2.28737 8.6905 2.9112 9.75 3.89893 9.75H11.6968V8.45H3.89893L4.61373 7.15H9.4549ZM3.35308 2.6H11.2484L9.4549 5.85H4.89315L3.35308 2.6ZM3.89893 10.4C3.18412 10.4 2.60578 10.985 2.60578 11.7C2.60578 12.415 3.18412 13 3.89893 13C4.61373 13 5.19857 12.415 5.19857 11.7C5.19857 10.985 4.61373 10.4 3.89893 10.4ZM10.3971 10.4C9.68233 10.4 9.10399 10.985 9.10399 11.7C9.10399 12.415 9.68233 13 10.3971 13C11.1119 13 11.6968 12.415 11.6968 11.7C11.6968 10.985 11.1119 10.4 10.3971 10.4Z" fill="#303030"/></svg>            
                    Vendas</p>
                    <div class="linhaCard">${Math.round(rawItems.mediaMes) > 0 ? `${Math.round(rawItems.mediaMes)}</strong>/Mês<strong>` : (rawItems.mediaMes == 'Menos de um Mês Vendendo' ? rawItems.mediaMes + '</strong>' : `0/Mês</strong>`)}</div>
                    <div>${Math.round(rawItems.mediaDia) > 0 ? `<span id="mediaDia">${Math.round(rawItems.mediaDia)}</span></strong>/dia` : `<strong>0/Dia</strong>`}</div>
                </div>
            </div>
            ${rawItems.internacional ? /* html */`<div class="cardInfos" style="width: 97%; margin-right: auto; margin-right: auto;"><p class="tituloCard"><svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.2226 12.6463L10.3883 5.55484L13.4642 2.4789C13.9284 2.01471 13.9284 1.2653 13.4642 0.801112C13 0.336925 12.2506 0.336925 11.7864 0.801112L8.71047 3.87705L1.61904 2.04267C1.33941 1.96438 1.03181 2.04827 0.824886 2.25519C0.433403 2.64668 0.528478 3.30101 1.00944 3.56946L6.1882 6.39932L3.11786 9.46967L1.09892 8.96074C0.964701 8.92718 0.819293 8.97192 0.724219 9.067L0.399847 9.39137C0.215291 9.57593 0.254439 9.88352 0.472551 10.0121L2.51386 11.2369L2.83823 11.4271L3.00041 11.6899L3.17378 11.9863L3.96794 13.3174L4.24757 13.7872C4.38179 14.0109 4.68379 14.0444 4.86835 13.8599L5.19272 13.5355C5.29339 13.4348 5.33253 13.295 5.29898 13.1608L4.79564 11.1475L7.87158 8.07151L10.7014 13.2503C10.9643 13.7368 11.6186 13.8319 12.0101 13.4404C12.217 13.2335 12.3009 12.9259 12.2226 12.6463Z" fill="black"/></svg> Vendedor Internacional</p><div style="padding: 7px 0 7px 0; font-size: 14.5px !important;"><strong>Alguns dados não podem ser calculados</strong></div></div>`
                : /* html */`
            <div class="linha-3">
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="15" viewBox="0 0 14 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.28564 10.0357L9.21422 5.10718" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.69636 5.92861C4.92319 5.92861 5.10707 5.74472 5.10707 5.51789C5.10707 5.29106 4.92319 5.10718 4.69636 5.10718C4.46953 5.10718 4.28564 5.29106 4.28564 5.51789C4.28564 5.74472 4.46953 5.92861 4.69636 5.92861Z" fill="#303030" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.80354 10.0357C9.03037 10.0357 9.21425 9.85178 9.21425 9.62495C9.21425 9.39812 9.03037 9.21423 8.80354 9.21423C8.57671 9.21423 8.39282 9.39812 8.39282 9.62495C8.39282 9.85178 8.57671 10.0357 8.80354 10.0357Z" fill="#303030" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 15.7857V2.64286C1 2.20714 1.17309 1.78928 1.48118 1.48118C1.78928 1.17309 2.20714 1 2.64286 1H10.8571C11.2929 1 11.7107 1.17309 12.0188 1.48118C12.3269 1.78928 12.5 2.20714 12.5 2.64286V15.7857L10.0357 14.1429L8.39286 15.7857L6.75 14.1429L5.10714 15.7857L3.46429 14.1429L1 15.7857Z" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Imposto</p> <strong><div class="linhaCard">R$${rawItems.ValorImposto.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div><div>(7%)</strong></div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.66726 6.77824V6.78546M2.56997 4.88457C2.2532 4.64111 2.00992 4.31481 1.867 3.94173C1.72409 3.56865 1.68711 3.16332 1.76015 2.77054C1.8332 2.37775 2.01342 2.01281 2.2809 1.71605C2.54839 1.41929 2.89271 1.20227 3.27583 1.08896C3.65894 0.975656 4.06592 0.970484 4.45179 1.07402C4.83766 1.17755 5.18739 1.38576 5.46233 1.67563C5.73726 1.9655 5.9267 2.32574 6.0097 2.71654C6.0927 3.10734 6.06603 3.51348 5.93264 3.89007" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.3896 1.72266V4.46927C11.2834 4.98647 11.964 5.80499 12.3093 6.77822H13.2778C13.4693 6.77822 13.653 6.85431 13.7885 6.98976C13.9239 7.1252 14 7.3089 14 7.50044V8.94489C14 9.13644 13.9239 9.32014 13.7885 9.45558C13.653 9.59102 13.4693 9.66711 13.2778 9.66711H12.3086C12.0659 10.3532 11.6535 10.9671 11.1111 11.4532V12.9171C11.1111 13.2044 10.997 13.48 10.7938 13.6832C10.5906 13.8863 10.3151 14.0005 10.0278 14.0005C9.74045 14.0005 9.4649 13.8863 9.26174 13.6832C9.05857 13.48 8.94444 13.2044 8.94444 12.9171V12.4961C8.70577 12.536 8.4642 12.5561 8.22221 12.556H5.33332C5.09133 12.5561 4.84976 12.536 4.61109 12.4961V12.9171C4.61109 13.2044 4.49696 13.48 4.29379 13.6832C4.09063 13.8863 3.81508 14.0005 3.52776 14.0005C3.24044 14.0005 2.96489 13.8863 2.76173 13.6832C2.55856 13.48 2.44442 13.2044 2.44442 12.9171V11.4727L2.44515 11.4532C1.79083 10.8682 1.32957 10.0983 1.12242 9.24541C0.915273 8.39252 0.971996 7.49683 1.28508 6.67688C1.59817 5.85694 2.15286 5.15139 2.87575 4.65362C3.59863 4.15586 4.45563 3.88933 5.33332 3.88933H7.13888L10.3889 1.72266H10.3896Z" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Recebe</p> <div class="linhaCard"><strong>R$${rawItems.ValorVendedor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div><div>(${rawItems.ProcentagemValorVendedor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%</strong>)</div></div>
                <div class="cardInfos"><div style="margin-bottom: auto;"><p class="tituloCard"><svg width="17" height="14" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 1C1.36739 1 1.24022 1.05268 1.14645 1.14645C1.05268 1.24022 1 1.36739 1 1.5V12.5C1 12.6326 1.05268 12.7598 1.14645 12.8536C1.24022 12.9473 1.36739 13 1.5 13C1.63261 13 1.75979 12.9473 1.85355 12.8536C1.94732 12.7598 2 12.6326 2 12.5V1.5C2 1.36739 1.94732 1.24022 1.85355 1.14645C1.75979 1.05268 1.63261 1 1.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M3.5 1C3.36739 1 3.24022 1.05268 3.14645 1.14645C3.05268 1.24022 3 1.36739 3 1.5V10.5C3 10.6326 3.05268 10.7598 3.14645 10.8536C3.24022 10.9473 3.36739 11 3.5 11C3.63261 11 3.75979 10.9473 3.85355 10.8536C3.94732 10.7598 4 10.6326 4 10.5V1.5C4 1.36739 3.94732 1.24022 3.85355 1.14645C3.75979 1.05268 3.63261 1 3.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M5.5 1C5.36739 1 5.24022 1.05268 5.14645 1.14645C5.05268 1.24022 5 1.36739 5 1.5V10.5C5 10.6326 5.05268 10.7598 5.14645 10.8536C5.24022 10.9473 5.36739 11 5.5 11C5.63261 11 5.75979 10.9473 5.85355 10.8536C5.94732 10.7598 6 10.6326 6 10.5V1.5C6 1.36739 5.94732 1.24022 5.85355 1.14645C5.75979 1.05268 5.63261 1 5.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M7.5 1C7.36739 1 7.24021 1.05268 7.14645 1.14645C7.05268 1.24022 7 1.36739 7 1.5V10.5C7 10.6326 7.05268 10.7598 7.14645 10.8536C7.24021 10.9473 7.36739 11 7.5 11C7.63261 11 7.75979 10.9473 7.85355 10.8536C7.94732 10.7598 8 10.6326 8 10.5V1.5C8 1.36739 7.94732 1.24022 7.85355 1.14645C7.75979 1.05268 7.63261 1 7.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M9.5 1C9.36739 1 9.24021 1.05268 9.14645 1.14645C9.05268 1.24022 9 1.36739 9 1.5V10.5C9 10.6326 9.05268 10.7598 9.14645 10.8536C9.24021 10.9473 9.36739 11 9.5 11C9.63261 11 9.75979 10.9473 9.85355 10.8536C9.94732 10.7598 10 10.6326 10 10.5V1.5C10 1.36739 9.94732 1.24022 9.85355 1.14645C9.75979 1.05268 9.63261 1 9.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M11.5 1C11.3674 1 11.2402 1.05268 11.1464 1.14645C11.0527 1.24022 11 1.36739 11 1.5V10.5C11 10.6326 11.0527 10.7598 11.1464 10.8536C11.2402 10.9473 11.3674 11 11.5 11C11.6326 11 11.7598 10.9473 11.8536 10.8536C11.9473 10.7598 12 10.6326 12 10.5V1.5C12 1.36739 11.9473 1.24022 11.8536 1.14645C11.7598 1.05268 11.6326 1 11.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M13.5 1C13.3674 1 13.2402 1.05268 13.1464 1.14645C13.0527 1.24022 13 1.36739 13 1.5V10.5C13 10.6326 13.0527 10.7598 13.1464 10.8536C13.2402 10.9473 13.3674 11 13.5 11C13.6326 11 13.7598 10.9473 13.8536 10.8536C13.9473 10.7598 14 10.6326 14 10.5V1.5C14 1.36739 13.9473 1.24022 13.8536 1.14645C13.7598 1.05268 13.6326 1 13.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M15.5 1C15.3674 1 15.2402 1.05268 15.1464 1.14645C15.0527 1.24022 15 1.36739 15 1.5V12.5C15 12.6326 15.0527 12.7598 15.1464 12.8536C15.2402 12.9473 15.3674 13 15.5 13C15.6326 13 15.7598 12.9473 15.8536 12.8536C15.9473 12.7598 16 12.6326 16 12.5V1.5C16 1.36739 15.9473 1.24022 15.8536 1.14645C15.7598 1.05268 15.6326 1 15.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/></svg> EAN(s)</p></div> <div style="padding: 7px 0 7px 0;"><strong> ${ean == '' || ean == null ? 'Sem EAN' : ean} </strong> </div></div>
            </div>
            <div class="linha-2">
                <div class="cardInfos"><p class="tituloCard" ><svg width="10" height="13" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg> Recomendação</p> <div style="padding: 7px 0 7px 0;"><strong> Entre R$${(rawItems.ValorBase * 0.5).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} e R$${(rawItems.ValorBase * 0.9).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} </strong></div></div>
                <div class="cardInfos cardApendice"><p class="tituloCard" ><svg width="19" height="12" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.7665 14C16.1604 14 20.5331 11.0899 20.5331 7.5C20.5331 3.91015 16.1604 1 10.7665 1C5.37262 1 1 3.91015 1 7.5C1 11.0899 5.37262 14 10.7665 14Z" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.60645 3.25781C4.61564 3.73866 5.69554 4.05421 6.80486 4.19239C7.57493 4.14055 8.33778 4.01084 9.08171 3.80524" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.2203 3.29999C17.4593 3.81737 16.5529 4.07797 15.6334 4.04375C13.9631 4.04375 12.5156 2.94238 11.0181 2.94238C9.68181 2.94238 7.41748 5.13259 7.41748 5.52876C7.41748 5.92493 8.07359 6.15983 8.60549 5.89939C8.91652 5.74763 10.2633 4.43992 11.3521 4.43992C12.441 4.43992 15.9695 8.01397 16.289 8.34953C16.7843 8.86941 15.8252 9.98931 15.2127 9.37627C14.6001 8.76323 13.5048 7.79259 13.5048 7.79259" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.483 6.84033C18.9841 7.017 17.5319 7.4744 16.2023 8.18861M15.0638 9.23088C15.5592 9.75026 14.6 10.8702 13.9875 10.2576C13.375 9.64508 12.6948 8.99898 12.6948 8.99898" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.8391 10.1121C14.3339 10.6314 13.3748 11.7513 12.7623 11.1388C12.1497 10.5263 11.748 10.1561 11.748 10.1561" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8672 11.1642C10.9822 11.2983 11.1265 11.4043 11.2888 11.474C11.4512 11.5437 11.6274 11.5752 11.8039 11.5663C11.9803 11.5573 12.1524 11.5079 12.3068 11.4221C12.4613 11.3363 12.594 11.2162 12.6948 11.071" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8673 11.1642C11.1332 10.8151 11.1127 9.5705 9.74388 9.81792C10.0654 9.20739 9.77694 8.24225 8.54786 8.81122C8.52852 8.63359 8.45346 8.46663 8.33344 8.33427C8.21342 8.2019 8.05458 8.11091 7.87969 8.07433C7.70479 8.03775 7.5228 8.05745 7.35979 8.13062C7.19678 8.20379 7.0611 8.32667 6.97219 8.48166C6.94726 8.32244 6.87022 8.17599 6.75314 8.06525C6.63606 7.95451 6.48555 7.88574 6.32519 7.8697C6.16483 7.85367 6.00369 7.89128 5.86699 7.97664C5.7303 8.062 5.62579 8.1903 5.56982 8.34142C5.29736 8.89386 5.71807 9.89205 6.61759 9.3311C6.52644 10.3047 7.03831 10.6017 7.96187 10.2226C8.01145 11.1792 8.64653 11.0966 9.1003 10.8737C9.14448 11.06 9.24278 11.2291 9.38282 11.3596C9.52286 11.4902 9.69839 11.5764 9.88732 11.6075C10.0762 11.6385 10.2701 11.613 10.4446 11.5341C10.6191 11.4553 10.7663 11.3265 10.8678 11.1642H10.8673Z" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.08496 6.63806C2.7146 6.76051 4.2819 7.31626 5.62464 8.24779" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/></svg> ${rawItems.TAXA ? `Comissão ML</p> <strong> <div class="linhaCard">R$${rawItems.TAXA.sale_fee_amount.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div><div>(${rawItems.COMISSAO.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%) ` : ''}</div></strong>
                    <div><span><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="#3166FE" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="#3166FE"/></svg></span><p class="tooltiptext" style="color: white;">Comissão Composta por: Taxa da categoria do ML + R$6,00 se o preço for abaixo de R$79,00</p>
                    </div>
                </div>
            </div>`
            }

            <button type="button" class="btnFaturamento" id="btnModalFaturamento" data-target="btnModal" data-backdrop="static" data-keyboard="false"><div style="display: flex; align-items: center;"><svg style="margin: 0 10px 0 auto;" width="14" height="12" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 13.087C16 13.3291 15.9063 13.5613 15.7396 13.7326C15.573 13.9038 15.3469 14 15.1111 14H0.888889C0.653141 14 0.427049 13.9038 0.26035 13.7326C0.0936506 13.5613 0 13.3291 0 13.087V0.913043C0 0.670889 0.0936506 0.438653 0.26035 0.267424C0.427049 0.0961953 0.653141 0 0.888889 0C1.12464 0 1.35073 0.0961953 1.51743 0.267424C1.68413 0.438653 1.77778 0.670889 1.77778 0.913043V8.44565L5 5.13587C5.08258 5.05075 5.18071 4.98321 5.28875 4.93713C5.3968 4.89104 5.51264 4.86732 5.62963 4.86732C5.74662 4.86732 5.86246 4.89104 5.97051 4.93713C6.07855 4.98321 6.17668 5.05075 6.25926 5.13587L8 6.92391L11.7778 3.04348H10.963C10.7272 3.04348 10.5011 2.94728 10.3344 2.77605C10.1677 2.60483 10.0741 2.37259 10.0741 2.13043C10.0741 1.88828 10.1677 1.65604 10.3344 1.48482C10.5011 1.31359 10.7272 1.21739 10.963 1.21739H13.9259C14.1617 1.21739 14.3878 1.31359 14.5545 1.48482C14.7212 1.65604 14.8148 1.88828 14.8148 2.13043V5.17391C14.8148 5.41607 14.7212 5.6483 14.5545 5.81953C14.3878 5.99076 14.1617 6.08696 13.9259 6.08696C13.6902 6.08696 13.4641 5.99076 13.2974 5.81953C13.1307 5.6483 13.037 5.41607 13.037 5.17391V4.33696L8.62963 8.86413C8.54705 8.94925 8.44892 9.01679 8.34088 9.06287C8.23283 9.10895 8.11699 9.13268 8 9.13268C7.88301 9.13268 7.76717 9.10895 7.65912 9.06287C7.55108 9.01679 7.45295 8.94925 7.37037 8.86413L5.62963 7.07609L1.77778 11.0326V12.1739H15.1111C15.3469 12.1739 15.573 12.2701 15.7396 12.4413C15.9063 12.6126 16 12.8448 16 13.087Z" fill="currentColor"/></svg><p style="margin-right: auto">Faturando: R$${faturando}</p></div></button>
            

            ${ultra ? /* html */`
                <div style="margin: 20px 0 20px 0;">
                <p class="tituloCard"><svg style="margin-right: 10px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#303030"/></svg>Rankeamento</p>
                <div class="divRanking" id="divRanking"> </div>
                </div>
            `: /* html */`
            <div style="margin: 20px 0 20px 0;">
                <p class="tituloCard"><svg style="margin-right: 10px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#303030"/></svg>Rankeamento</p>
                <div class="divRanking rankGratis"> 
                    <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
                    <input class="inputRanking" style="position: relative !important;" placeholder="Digite um termo para saber a posição do produto" type="text" disabled></input>
                    <button class="botaoRanking">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>        
                    </button>
                </div>
            </div>
            `}

            <ul>
            <button type="button" class="collapsible-negativos">
                <div style="display: flex; align-items: center; text-align: center;">
                    <svg style="margin-left: auto;" width="20" height="18" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 12V0H22V12H18ZM14 0C14.5304 0 15.0391 0.210714 15.4142 0.585786C15.7893 0.960859 16 1.46957 16 2V12C16 12.55 15.78 13.05 15.41 13.41L8.83 20L7.77 18.94C7.5 18.67 7.33 18.3 7.33 17.88L7.36 17.57L8.31 13H2C1.46957 13 0.960859 12.7893 0.585786 12.4142C0.210714 12.0391 0 11.5304 0 11V9C0 8.74 0.05 8.5 0.14 8.27L3.16 1.22C3.46 0.5 4.17 0 5 0H14ZM14 2H4.97L2 9V11H10.78L9.65 16.32L14 11.97V2Z" fill="#303030"/></svg>
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Pontos Negativos</p>
                    <svg class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>
            <div class="content-negativos">
                ${pontosNegativos}
            </div>
            </ul>
            </div>
            <button class="btnMostrarInfos" id="btnMostrarInfos"><svg width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg></button>
            </div>
            <div id="modalFaturamento" class="modalFaturamento">
                <div class="modalBody">
                    <div class="closeModal" id="closeMdlRange"><svg width="13" height="13" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></div>
                    <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 25px; color: var(--grey);"><svg style="margin: 0 10px 0 0;" width="20" height="18" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 13.087C16 13.3291 15.9063 13.5613 15.7396 13.7326C15.573 13.9038 15.3469 14 15.1111 14H0.888889C0.653141 14 0.427049 13.9038 0.26035 13.7326C0.0936506 13.5613 0 13.3291 0 13.087V0.913043C0 0.670889 0.0936506 0.438653 0.26035 0.267424C0.427049 0.0961953 0.653141 0 0.888889 0C1.12464 0 1.35073 0.0961953 1.51743 0.267424C1.68413 0.438653 1.77778 0.670889 1.77778 0.913043V8.44565L5 5.13587C5.08258 5.05075 5.18071 4.98321 5.28875 4.93713C5.3968 4.89104 5.51264 4.86732 5.62963 4.86732C5.74662 4.86732 5.86246 4.89104 5.97051 4.93713C6.07855 4.98321 6.17668 5.05075 6.25926 5.13587L8 6.92391L11.7778 3.04348H10.963C10.7272 3.04348 10.5011 2.94728 10.3344 2.77605C10.1677 2.60483 10.0741 2.37259 10.0741 2.13043C10.0741 1.88828 10.1677 1.65604 10.3344 1.48482C10.5011 1.31359 10.7272 1.21739 10.963 1.21739H13.9259C14.1617 1.21739 14.3878 1.31359 14.5545 1.48482C14.7212 1.65604 14.8148 1.88828 14.8148 2.13043V5.17391C14.8148 5.41607 14.7212 5.6483 14.5545 5.81953C14.3878 5.99076 14.1617 6.08696 13.9259 6.08696C13.6902 6.08696 13.4641 5.99076 13.2974 5.81953C13.1307 5.6483 13.037 5.41607 13.037 5.17391V4.33696L8.62963 8.86413C8.54705 8.94925 8.44892 9.01679 8.34088 9.06287C8.23283 9.10895 8.11699 9.13268 8 9.13268C7.88301 9.13268 7.76717 9.10895 7.65912 9.06287C7.55108 9.01679 7.45295 8.94925 7.37037 8.86413L5.62963 7.07609L1.77778 11.0326V12.1739H15.1111C15.3469 12.1739 15.573 12.2701 15.7396 12.4413C15.9063 12.6126 16 12.8448 16 13.087Z" fill="currentColor"/></svg>
                    <h2 style="font-weight: 900;">Faturando: R$</h2><h2 id="totalFaturamento" style="font-weight: 900;">${faturando}</h2></div>
                    <span id="dias" style="display: none;">${rawItems.days}</span>
                    ${ultra ? `
                    <div>
                        ${Math.round(rawItems.mediaDia) > 0 ? `<button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(0)>1 dia</button>` : `<button type="button" class="btnCalcFtrmt" disabled>1 dia <div class="tooltiptext tooltipBtnFatr">Menos de uma venda por dia</div></button>`} 
                        ${rawItems.days > 7 && Math.round(rawItems.mediaDia) * 7 > 0 ? `<button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(1)>7 dias</button>` : `<button type="button" class="btnCalcFtrmt" disabled>7 dias ${rawItems.days < 7 ? `<div class="tooltiptext tooltipBtnFatr">Anúncio criado a menos de 7 dias</div>` : `<div class="tooltiptext tooltipBtnFatr">Menos de uma venda por semana</div>`}</button>`}

                        ${rawItems.days > 30 && Math.round(rawItems.mediaMes) > 0 ? `<button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(2)>30 dias</button>` : `<button type="button" class="btnCalcFtrmt" disabled>30 dias ${rawItems.days < 30 ? `<div class="tooltiptext tooltipBtnFatr">Anúncio criado a menos de 30 dias</div>` : `<div class="tooltiptext tooltipBtnFatr">Menos de uma venda por mês</div>`}</button>`}
                    </div>
                    <div>
                        ${rawItems.days > 60 && Math.round(rawItems.mediaMes) * 2 > 0 ? `<button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(3)>60 dias</button>` : `<button type="button" class="btnCalcFtrmt" disabled>60 dias ${rawItems.days < 60 ? `<div class="tooltiptext tooltipBtnFatr">Anúncio criado a menos de 60 dias</div>` : `<div class="tooltiptext tooltipBtnFatr">Menos de uma venda /2 mêses</div>`}</button>`}
                        ${rawItems.days > 90 && Math.round(rawItems.mediaMes) * 3 > 0 ? `<button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(4)>90 dias</button>` : `<button type="button" class="btnCalcFtrmt" disabled>90 dias ${rawItems.days < 90 ? `<div class="tooltiptext tooltipBtnFatr">Anúncio criado a menos de 30 dias</div>` : `<div class="tooltiptext tooltipBtnFatr">Menos de uma venda /3 mêses</div>`}</button>`}
                        <button type="button" class="btnCalcFtrmt" onClick=botaoFaturamento(5)>Total</button>
                    </div>
                    ` : /* html */`
                        <div>
                            <button type="button" class="btnCalcFtrmt" disabled>1 dia<div class="tooltiptext tooltipBtnFatr" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
                            <button type="button" class="btnCalcFtrmt" disabled>7 dias<div class="tooltiptext tooltipBtnFatr" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
                            <button type="button" class="btnCalcFtrmt" disabled>30 dias<div class="tooltiptext tooltipBtnFatr" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
                        </div>
                        <div>
                            <button type="button" class="btnCalcFtrmt" disabled>60 dias<div class="tooltiptext tooltipBtnFatr" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
                            <button type="button" class="btnCalcFtrmt" disabled>90 dias<div class="tooltiptext tooltipBtnFatr" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
                            <button type="button" class="btnCalcFtrmt">Total</button>
                        </div>
                        <h4 style="font-weight: 800; margin: 20px;">Quer ver o valor do faturamento por períodos específicos? Assine já o <a href="https://avantpro.com.br/ml/" target="blank";>Avantpro Ultra!</a></h4>
                    `}
                    
                    <div style="padding: 8px 40px 0 40px; font-size: 20px !important;">${faturamento}</div>
                </div>
            </div>

            <div id="modalRange" class="modalFaturamento">
                <div class="modalBody">
                    <div class="closeModal" id="closeMdlFaturamento"><svg width="13" height="13" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></div>
                    <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 25px; color: var(--grey);">
                    <h2 style="font-weight: 900;">Range de vendas ML</h2></div>
                    
                    <div style="display: flex; justify-content: center">
                        <div class="cardInfos tabela">
                            <div class="header-tabela">
                                <p>Dado real</p>
                                <p>Referência</p>
                            </div>
                            <div class="body-tabela">
                                <div class="row-tabela">
                                    <p>1 venda</p>
                                    <p>1 vendido</p>
                                </div>
                                <div class="row-tabela">
                                    <p>2 vendas</p>
                                    <p>2 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>3 vendas</p>
                                    <p>3 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>4 vendas</p>
                                    <p>4 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>5 vendas</p>
                                    <p>5 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 6 a 25 vendas</p>
                                    <p>+5 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 26 a 50 vendas</p>
                                    <p>+25 vendidos</p>
                                </div>
                            </div>
                        </div>

                        <div class="cardInfos tabela">
                            <div class="header-tabela">
                                <p>Dado real</p>
                                <p>Referência</p>
                            </div>
                            <div class="body-tabela">
                                <div class="row-tabela">
                                    <p>De 51 a 100 vendas</p>
                                    <p>+50 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 101 a 150 vendas</p>
                                    <p>+100 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 151 a 200 vendas</p>
                                    <p>+150 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 201 a 250 vendas</p>
                                    <p>+200 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 251 a 500 vendas</p>
                                    <p>+250 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 501 a 5.000 vendas</p>
                                    <p>+500 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 5.001 a 50.000 vendas</p>
                                    <p>+5.000 vendidos</p>
                                </div>
                                <div class="row-tabela">
                                    <p>De 50.001 a 500.000 vendas</p>
                                    <p>+50.000 vendidos</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div style="text-align: center; margin-top: 16px; font-weight: normal;"><p>Informações oficiais oferecidas pelo ML. <a href="https://developers.mercadolivre.com.br/pt_br/itens-e-buscas#Valores-nos-campos-sold-quantity-e-available-quantity" target="_blank">Leia aqui.</a></p></div>

                </div>
                    
            </div>
        `;
        var url = new window.URL(window.location.href)

        if (url.searchParams.has('conversao')) {
            url.searchParams.set('conversao', String(((1 / (rawItems.visitas / vendasHTML)) * 100).toFixed(2)));
        } else {
            url.searchParams.append('conversao', String(((1 / (rawItems.visitas / vendasHTML)) * 100).toFixed(2)));
        }

        window.history.pushState({ path: url.href }, '', url.href);

        Titulo.appendChild(conteudo);
    }

    static ProdutoUltra(rawItems) {

        var ranking = document.getElementsByClassName('divRanking')[0];
        var conteudo = document.createElement('div');


        conteudo.innerHTML = `<strong><p style="color: var(--primary); margin-bottom: 10px;" class="resultadoRanking" id="resultadoRanking"></p></strong>
        <div style="position: relative;">
        <input class="inputRanking" id="inputRanking" placeholder="Digite um termo para saber a posição do produto" type="text" maxlength="55"></input>
        <button class="botaoRanking" id="botaoRanking" onclick="cliqueBotaoRank('${rawItems.id}')">
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
        </button>
        <button class="botaoRankingDisabled" style="display: none;">
            <svg width="20" height="20" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 22C2 33.0457 10.9543 42 22 42C33.0457 42 42 33.0457 42 22C42 10.9543 33.0457 2 22 2" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        </div>
        `;

        ranking.appendChild(conteudo);
    }

    static Vendedor(rawItems) {
        const InfoVendedor = document.getElementsByClassName('ui-box-component__title')[0];

        // console.log('info', rawItems.seller)

        var BoxInfoVendedor = document.createElement('div');
        BoxInfoVendedor.className = 'vendas2';
        BoxInfoVendedor.id = 'BoxVenda1';

        /*Get information */
        var Categorias = []
        var Range = []
        var full = 0
        var has_video = 0
        var price_campaign_id = 0
        var gratis = 0
        var cont = 0

        try {
            for (let x = 0; x < rawItems.seller.available_filters.length; x++) {
                if (rawItems.seller.available_filters[x].id == "category") Categorias = rawItems.seller.available_filters[x].values;
                if (rawItems.seller.available_filters[x].id == "price") Range = rawItems.seller.available_filters[x].values;
                if (rawItems.seller.available_filters[x].id == "shipping") full = rawItems.seller.available_filters[x].values.length == 2 ? rawItems.seller.available_filters[x].values[1].results : 0;
                if (rawItems.seller.available_filters[x].id == "has_video") has_video = rawItems.seller.available_filters[x].values[0].results;
                if (rawItems.seller.available_filters[x].id == "price_campaign_id") price_campaign_id = rawItems.seller.available_filters[x].values.length
                if (rawItems.seller.available_filters[x].id == "shipping_cost") gratis = rawItems.seller.available_filters[x].values[0].results
            }

            let oficial = '';
            oficial = rawItems.seller.seller.tags.filter(x => x == 'brand');

            if (!rawItems.catalogo) {

                var dataFormat = ("0" + rawItems.seller.Criacao.getDate().toString()).substr(-2) + '/' + ("0" + (rawItems.seller.Criacao.getMonth() + 1).toString()).substr(-2) + '/' + rawItems.seller.Criacao.getFullYear().toString().substr(-2);

                BoxInfoVendedor.innerHTML = /* html */ `

                <p style="display: flex;justify-content: center;position: relative;top: -11px;">
                    <svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
                    <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
                    <defs>
                    <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
                    <stop offset="0.380208" stop-color="#F2A008"/>
                    <stop offset="0.792994" stop-color="#F9D043"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#1B22B8"/>
                    <stop offset="1" stop-color="#4D43FA"/>
                    </linearGradient>
                    </defs>
                    </svg>

                    <b style="font-size: 17px;padding-bottom: 2px;position: relative;top: 2px;margin-right: auto;">Informações Avantpro</b>
                </p>
                    
                <p style="margin-top: 12px;margin-bottom: 15px;"><b style="font-size: 16px;">Informações do vendedor</b></p>
                <p style="margin-top: 10px;margin-bottom: -2px;">
                    <img style="width: 17px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA70lEQVR4nO3UQUrDQBSH8R8umqVdWrrWK+hJxEPYHsNuRPFAurR1ZfEAuinVlUUUXVYGJiCCdNJObCn54A8heeGbl8wbGjaUAn2M8BETrnvxWS10Mcb8j9zHmqwUC6Q/5Vk77ydIy5zmFN9VEA9zit8riENtNuYVs5aO37biH/fWtauLOKMpc9ySme4CeS0nV0krfsph3HAht/Fe9k4b/pUdHGGAGzzjK2aKa5zhMNauTAcXeKkwx2FR59hbRtjGFT6XOKfLhHcvsZsqPcDTCsLfecR+ivgho7TMOEU8rUE8SRGfYJZR+orjFHHDdvENyZP0ibBvoI8AAAAASUVORK5CYII="> 
                    <b style="vertical-align: text-top;font-size: 13px">Nome:</b> 
                    <a href="https://www.mercadolivre.com.br/perfil/${rawItems.sellerBase.nickname}" target="_blank">
                        <span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;font-size: 13px;position: relative;top: -3px;">${rawItems.sellerBase.nickname.length > 15 ?
                        rawItems.sellerBase.nickname.substring(0, 15) + "..." :
                        rawItems.sellerBase.nickname}
                        </span>
                    </a>
                    ${oficial == 'brand' ? ' <svg style="margin-left: 4px;" width="19" height="19" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg> <span style="color: #2AC568;font-weight: bold;position: relative;top: -13px;left: 3px;font-size: 13px">Loja</span><span style="position: relative;right: 32px;top: 2px;color: #2AC568;font-weight: bold;font-size: 13px"> Oficial</span>'
                        : ''}
                </p>
                <div style="margin-top: 5px;margin-left: 3px;display: flex;width: 125%;">
                    <div style="width: 45%;">
                        <svg width="13" height="18" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 20C1.45 20 0.979333 19.8043 0.588 19.413C0.196 19.021 0 18.55 0 18V6C0 5.45 0.196 4.97933 0.588 4.588C0.979333 4.196 1.45 4 2 4H4C4 2.9 4.39167 1.95833 5.175 1.175C5.95833 0.391667 6.9 0 8 0C9.1 0 10.0417 0.391667 10.825 1.175C11.6083 1.95833 12 2.9 12 4H14C14.55 4 15.021 4.196 15.413 4.588C15.8043 4.97933 16 5.45 16 6V18C16 18.55 15.8043 19.021 15.413 19.413C15.021 19.8043 14.55 20 14 20H2ZM2 18H14V6H12V8C12 8.28333 11.9043 8.52067 11.713 8.712C11.521 8.904 11.2833 9 11 9C10.7167 9 10.4793 8.904 10.288 8.712C10.096 8.52067 10 8.28333 10 8V6H6V8C6 8.28333 5.90433 8.52067 5.713 8.712C5.521 8.904 5.28333 9 5 9C4.71667 9 4.47933 8.904 4.288 8.712C4.096 8.52067 4 8.28333 4 8V6H2V18ZM6 4H10C10 3.45 9.80433 2.97933 9.413 2.588C9.021 2.196 8.55 2 8 2C7.45 2 6.97933 2.196 6.588 2.588C6.196 2.97933 6 3.45 6 4ZM2 18V6V18Z" fill="#303030"/></svg>
                        <b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Vendas:</b>
                        <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.seller.seller_reputation.transactions.total.toLocaleString('pt-BR')}</span>
                    </div>
                    <div style="margin-top: 3px;">
                        <svg width="14" height="16" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1375 1C2.5706 1 2.02692 1.22451 1.62606 1.62414C1.2252 2.02377 1 2.56578 1 3.13094V14.4959C1.00004 15.0266 1.19872 15.5382 1.55716 15.9306C1.91559 16.323 2.40799 16.5679 2.938 16.6174C3.0474 17.2814 3.38963 17.8851 3.90376 18.3211C4.41789 18.7571 5.07054 18.997 5.7455 18.9981C6.42046 18.9993 7.07392 18.7616 7.58952 18.3273C8.10512 17.8931 8.4494 17.2905 8.56105 16.6269H10.5389C10.6501 17.2901 10.9935 17.8925 11.5082 18.327C12.0229 18.7615 12.6755 19 13.35 19C14.0245 19 14.6771 18.7615 15.1918 18.327C15.7065 17.8925 16.0499 17.2901 16.161 16.6269H17.8625C18.1432 16.6269 18.4212 16.5718 18.6805 16.4647C18.9398 16.3576 19.1755 16.2006 19.3739 16.0027C19.5724 15.8049 19.7299 15.57 19.8373 15.3114C19.9447 15.0529 20 14.7758 20 14.4959V9.36938C19.9999 9.0539 19.9294 8.74239 19.7938 8.45734L18.1798 5.06015C18.0066 4.69556 17.7332 4.38748 17.3913 4.1717C17.0494 3.95593 16.6531 3.84134 16.2485 3.84125H14.775V3.13094C14.775 2.56578 14.5498 2.02377 14.1489 1.62414C13.7481 1.22451 13.2044 1 12.6375 1H3.1375ZM16.0385 15.2063C15.8112 14.5678 15.3633 14.031 14.775 13.6919V9.99729H18.575V12.8385H17.3875C17.1985 12.8385 17.0173 12.9134 16.8837 13.0466C16.7501 13.1798 16.675 13.3605 16.675 13.5489C16.675 13.7372 16.7501 13.9179 16.8837 14.0511C17.0173 14.1843 17.1985 14.2592 17.3875 14.2592H18.575V14.4959C18.575 14.6843 18.4999 14.865 18.3663 14.9982C18.2327 15.1314 18.0515 15.2063 17.8625 15.2063H16.0385ZM13.35 13.3121C12.7604 13.3119 12.1853 13.494 11.7038 13.8332C11.2223 14.1724 10.8582 14.6521 10.6615 15.2063H8.4385C8.24223 14.6522 7.87854 14.1724 7.39749 13.833C6.91644 13.4935 6.34167 13.311 5.75229 13.3106C5.16291 13.3101 4.58789 13.4918 4.10636 13.8306C3.62483 14.1694 3.26046 14.6487 3.0634 15.2025C2.88821 15.1842 2.72601 15.1019 2.60811 14.9714C2.49022 14.8409 2.42498 14.6715 2.425 14.4959V3.13094C2.425 2.94255 2.50007 2.76188 2.63369 2.62867C2.76731 2.49546 2.94853 2.42063 3.1375 2.42063H12.6375C12.8265 2.42063 13.0077 2.49546 13.1413 2.62867C13.2749 2.76188 13.35 2.94255 13.35 3.13094V13.3121ZM14.775 5.26188H16.2475C16.3826 5.26167 16.515 5.29975 16.6292 5.37169C16.7434 5.44363 16.8347 5.54645 16.8925 5.66817L18.2738 8.57667H14.775V5.26188ZM5.75 17.574C5.37207 17.574 5.00961 17.4243 4.74237 17.1579C4.47513 16.8915 4.325 16.5301 4.325 16.1533C4.325 15.7766 4.47513 15.4152 4.74237 15.1488C5.00961 14.8824 5.37207 14.7327 5.75 14.7327C6.12793 14.7327 6.49039 14.8824 6.75763 15.1488C7.02487 15.4152 7.175 15.7766 7.175 16.1533C7.175 16.5301 7.02487 16.8915 6.75763 17.1579C6.49039 17.4243 6.12793 17.574 5.75 17.574ZM14.775 16.1533C14.775 16.5301 14.6249 16.8915 14.3576 17.1579C14.0904 17.4243 13.7279 17.574 13.35 17.574C12.9721 17.574 12.6096 17.4243 12.3424 17.1579C12.0751 16.8915 11.925 16.5301 11.925 16.1533C11.925 15.7766 12.0751 15.4152 12.3424 15.1488C12.6096 14.8824 12.9721 14.7327 13.35 14.7327C13.7279 14.7327 14.0904 14.8824 14.3576 15.1488C14.6249 15.4152 14.775 15.7766 14.775 16.1533Z" fill="#303030" stroke="black" stroke-width="0.5"/></svg>
                        <b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Frete Grátis:</b> 
                        <span style="position: relative;top: -4px;font-size: 13px">${gratis.toLocaleString('pt-BR')}</span>
                    </div>
                </div>

                <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 125%;">
                    <div style="width: 46%;margin-top: 3px;">
                        <svg width="15" height="14" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 9H13V7H4V9ZM4 6H13V4H4V6ZM2 16C1.45 16 0.979333 15.8043 0.588 15.413C0.196 15.021 0 14.55 0 14V2C0 1.45 0.196 0.979333 0.588 0.588C0.979333 0.196 1.45 0 2 0H18C18.55 0 19.021 0.196 19.413 0.588C19.8043 0.979333 20 1.45 20 2V14C20 14.55 19.8043 15.021 19.413 15.413C19.021 15.8043 18.55 16 18 16H2ZM2 14H18V2H2V14ZM2 14V2V14Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Anúncios:</b> <a href="http://lista.mercadolivre.com.br/_CustId_${rawItems.seller_id}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;position: relative;top: -3px;font-size: 13px">${rawItems.seller.paging.total.toLocaleString('pt-BR')}</span></a> </div><div><svg width="12" height="19" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6859 0.211277L0.325939 9.49128C-0.314061 10.0713 0.0459388 11.1413 0.905939 11.2213L8.99594 12.0013L4.14594 18.7613C3.92594 19.0713 3.95594 19.5013 4.22594 19.7713C4.52594 20.0713 4.99594 20.0813 5.30594 19.7913L15.6659 10.5113C16.3059 9.93128 15.9459 8.86128 15.0859 8.78128L6.99594 8.00128L11.8459 1.24128C12.0659 0.931277 12.0359 0.501277 11.7659 0.231277C11.6246 0.0868922 11.4321 0.00387373 11.23 0.000132156C11.028 -0.00360942 10.8326 0.0722258 10.6859 0.211277Z" fill="#303030"/></svg>
                        <b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">FULL:</b>
                        <span style="position: relative;top: -4px;font-size: 13px">${full.toLocaleString('pt-BR')}</span>
                    </div>
                </div>
                <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 125%;">
                    <div style="width: 47%;">
                        <svg width="14" height="15" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#303030"/></svg>
                        <b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Videos:</b> 
                        <span style="position: relative;top: -3px;font-size: 13px">${has_video.toLocaleString('pt-BR')}</span> 
                    </div>
                    <div>
                        <svg width="9" height="17" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg>
                        <b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Campanhas pagas:</b> 
                        <span style="position: relative;top: -4px;font-size: 13px">${price_campaign_id}</span>
                    </div>
                </div>

                <p style="margin-top: 5px;margin-left: 5px;">
                    <svg width="11" height="15" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8.075C5.43168 8.075 4.88663 7.85112 4.48477 7.4526C4.08291 7.05409 3.85714 6.51359 3.85714 5.95C3.85714 5.38642 4.08291 4.84591 4.48477 4.4474C4.88663 4.04888 5.43168 3.825 6 3.825C6.56832 3.825 7.11337 4.04888 7.51523 4.4474C7.91709 4.84591 8.14286 5.38642 8.14286 5.95C8.14286 6.22906 8.08743 6.50539 7.97974 6.7632C7.87205 7.02102 7.71421 7.25528 7.51523 7.4526C7.31625 7.64993 7.08002 7.80645 6.82004 7.91324C6.56005 8.02004 6.2814 8.075 6 8.075ZM6 0C4.4087 0 2.88258 0.626873 1.75736 1.74271C0.632141 2.85856 0 4.37196 0 5.95C0 10.4125 6 17 6 17C6 17 12 10.4125 12 5.95C12 4.37196 11.3679 2.85856 10.2426 1.74271C9.11742 0.626873 7.5913 0 6 0Z" fill="#303030"/></svg> <b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Localização: 
                    </b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.sellerBase.tags?.includes('international_seller') ? 'Vendedor Internacional' : (rawItems.sellerBase.address.city + ' / ' + rawItems.sellerBase.address.state.replace('BR-', ''))}</span>
                </p>
                
                <p style="margin: 4px 0px 6px 3px;">
                    <svg width="19" height="15" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.37413 8.585C8.7052 7.87387 9.17635 7.23347 9.76067 6.70037C10.345 6.16726 11.031 5.7519 11.7796 5.478C12.5282 5.2041 13.3246 5.07703 14.1234 5.10406C14.9222 5.13108 15.7078 5.31167 16.4352 5.6355C17.1627 5.95911 17.8179 6.41965 18.3633 6.9908C18.9087 7.56196 19.3336 8.23254 19.6138 8.96425C19.894 9.69596 20.024 10.4745 19.9964 11.2553C19.9687 12.0361 19.784 12.804 19.4527 13.515C18.9705 14.5554 18.1914 15.4377 17.2088 16.0559C16.2262 16.6741 15.0819 17.0019 13.9134 17C11.5655 17 9.41763 15.674 8.40891 13.6H0V11.9C0.0521752 10.931 0.730453 10.1405 2.03483 9.503C3.33922 8.8655 4.97404 8.534 6.9567 8.5C7.45236 8.5 7.92194 8.5425 8.37413 8.585ZM6.9567 0C7.93064 0.0255 8.74805 0.357 9.40024 0.9945C10.0524 1.632 10.3742 2.431 10.3742 3.4C10.3742 4.369 10.0524 5.168 9.40024 5.8055C8.74805 6.443 7.93064 6.7575 6.9567 6.7575C5.98276 6.7575 5.16535 6.443 4.51316 5.8055C3.86097 5.168 3.53922 4.369 3.53922 3.4C3.53922 2.431 3.86097 1.632 4.51316 0.9945C5.16535 0.357 5.98276 0.0255 6.9567 0ZM13.9134 15.3C15.0665 15.3 16.1725 14.8522 16.9879 14.0552C17.8033 13.2582 18.2613 12.1772 18.2613 11.05C18.2613 9.92282 17.8033 8.84182 16.9879 8.04479C16.1725 7.24776 15.0665 6.8 13.9134 6.8C12.7603 6.8 11.6543 7.24776 10.8389 8.04479C10.0235 8.84182 9.56546 9.92282 9.56546 11.05C9.56546 12.1772 10.0235 13.2582 10.8389 14.0552C11.6543 14.8522 12.7603 15.3 13.9134 15.3ZM13.0438 8.5H14.3482V10.897L16.47 12.0955L15.8178 13.2005L13.0438 11.6365V8.5Z" fill="#303030"/></svg>
                    <b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Criação da conta:</b>
                    <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.CriacaoDays === NaN ? 'Não informada' : `${dataFormat}  |  há  ${rawItems.seller.CriacaoDays.toLocaleString('pt-BR')} dias`}</span>
                </p>
                
                `;

                if (InfoVendedor) {
                    InfoVendedor.insertAdjacentElement('beforebegin', BoxInfoVendedor);
                }


                var BoxInfoVendedor2 = document.createElement('div');
                BoxInfoVendedor2.className = 'vendas2';
                BoxInfoVendedor2.id = 'BoxVenda2';

                let dadosp = '';

                dadosp = `
                <button type="button" id="dropCategoria" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px;">
                    <div style="display: flex; align-items: center; text-align: center;">
                        <img style="margin-right: 5px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA8ElEQVR4nO3UsUrDUBjF8R8inXWpk4tLF8Whi1NBdOnSzaWvonRT9Bm66hIUuguCi1AQ9DW6dqxD5cpHCXITMwmFHjhw75dz/iHhJqyL9jHAKbo4QKsm34pMNzqDYKz0gOUvL/CJMc7D45gtMvn7MvAJE+yhgxMMcYdpqTSN2TAynehMgvGjI3yhqHnEx3CVimAcps1F3L0OWDS4vgzWBpjX5h02Ozav6OEY7QbnsB3ZXnRXwH7mu0ye4wUjvIVHMZtXdPoJuI1bPOMDs4pwzrPopG5iJFZWOzjDNd5LgLS+iT/PblX5L23hCpex/l99A1DwdkWrfsugAAAAAElFTkSuQmCC">
                        <p class="tituloCard" style="margin: 0 auto 0 10px;">Categorias que o vendedor atua</p>
                        <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                    </div>
                </button>

                <div class="vendas3" id="internoCategoria">
                `
                cont = 0;
                Categorias.sort(function (a, b) {
                    if (a.name < b.name) {
                        return -1;
                    } else {
                        return true;
                    }
                });
                if (Categorias.length > 0) {
                    Categorias.forEach(element => {
                        cont++;
                        dadosp = dadosp + `<p style="border: 2px solid #f0f0f0;border-radius: 16px;text-align: center;font-size: 12px;padding: 5px 15px;font-weight: bold;margin-right: 4px; width: fit-content;">${element.name}</p>`;
                    });
                }
                else {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
                }


                dadosp = dadosp + `
                    </div>
                </div>
            </div> 
            <button type="button" id="dropCategoria1" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px; margin-bottom: 10px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="width: 20px;position: relative;top: 2px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAqklEQVR4nO2SOw4CMQxE3yV2xQW4KSxHgFshsQXn4FOQKiiSi7B8dpykoNiR3DjWPNsxLKrUCMQsjj9qB+AObD2AwwSQ4puCvT88gBVwEQFKzYv6bEXX1oDcfLRJ9jN/IAM64GSFZzNXJAG6See9aC4DdoXmMmBt95wmwXnz7ivCefNNAfGD2f8CBnHfxYAg7lsC1HQbFUBNt7EUECpyb0qruQGbRrlFzOoJTXuISVuPFksAAAAASUVORK5CYII=">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Quantidade de Anúncios por Preço</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria1">
            `;

                if (Range.length > 0) {

                    Range.forEach(element => {
                        dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">${element.name.replace('Up to', 'Até ').replace('to', 'a').replace('More than', 'Mais de')}  :  <span style="font-weight: 100;">${element.results}<span> </p>`;
                    });

                } else {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
                }

                BoxInfoVendedor2.innerHTML = dadosp + `
                
                    </div>
                </div>     
                <br>
            `;


                document.getElementById('BoxVenda1').insertAdjacentElement('afterend', BoxInfoVendedor2)
            } else {

                var dataFormat = ("0" + rawItems.seller.Criacao.getDate().toString()).substr(-2) + '/' + ("0" + (rawItems.seller.Criacao.getMonth() + 1).toString()).substr(-2) + '/' + rawItems.seller.Criacao.getFullYear().toString().substr(-2);

                BoxInfoVendedor.innerHTML = `

            <p style="display: flex;justify-content: center;position: relative;top: -11px;"><svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
            <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
            <defs>
            <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
            <stop offset="0.380208" stop-color="#F2A008"/>
            <stop offset="0.792994" stop-color="#F9D043"/>
            </linearGradient>
            <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
            <stop stop-color="#1B22B8"/>
            <stop offset="1" stop-color="#4D43FA"/>
            </linearGradient>
            </defs>
            </svg><b style="font-size: 17px;padding-bottom: 2px;position: relative;top: 2px;margin-right: auto;">Informações Avantpro</b></p>
            <p style="margin-top: 12px;margin-bottom: 15px;"><b style="font-size: 16px;">Informações do vendedor</b></p>
            <p style="margin-top: 10px;margin-bottom: -2px;"><img style="width: 17px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA70lEQVR4nO3UQUrDQBSH8R8umqVdWrrWK+hJxEPYHsNuRPFAurR1ZfEAuinVlUUUXVYGJiCCdNJObCn54A8heeGbl8wbGjaUAn2M8BETrnvxWS10Mcb8j9zHmqwUC6Q/5Vk77ydIy5zmFN9VEA9zit8riENtNuYVs5aO37biH/fWtauLOKMpc9ySme4CeS0nV0krfsph3HAht/Fe9k4b/pUdHGGAGzzjK2aKa5zhMNauTAcXeKkwx2FR59hbRtjGFT6XOKfLhHcvsZsqPcDTCsLfecR+ivgho7TMOEU8rUE8SRGfYJZR+orjFHHDdvENyZP0ibBvoI8AAAAASUVORK5CYII="> <b style="vertical-align: text-top;font-size: 13px">Nome:</b> <a href="https://www.mercadolivre.com.br/perfil/${rawItems.sellerBase.nickname}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;font-size: 13px;position: relative;top: -3px;">${rawItems.sellerBase.nickname.length > 12 ? rawItems.sellerBase.nickname.substring(0, 12) + "..." : rawItems.sellerBase.nickname}</span></a> ${oficial == 'brand' ? ' <svg style="margin-left: 4px;" width="19" height="19" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg> <span style="color: #2AC568;font-weight: bold;position: relative;top: -13px;left: 3px;font-size: 13px">Loja</span><span style="position: relative;right: 32px;top: 2px;color: #2AC568;font-weight: bold;font-size: 13px"> Oficial</span>' : ''}</p>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 50%;"><svg width="13" height="18" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 20C1.45 20 0.979333 19.8043 0.588 19.413C0.196 19.021 0 18.55 0 18V6C0 5.45 0.196 4.97933 0.588 4.588C0.979333 4.196 1.45 4 2 4H4C4 2.9 4.39167 1.95833 5.175 1.175C5.95833 0.391667 6.9 0 8 0C9.1 0 10.0417 0.391667 10.825 1.175C11.6083 1.95833 12 2.9 12 4H14C14.55 4 15.021 4.196 15.413 4.588C15.8043 4.97933 16 5.45 16 6V18C16 18.55 15.8043 19.021 15.413 19.413C15.021 19.8043 14.55 20 14 20H2ZM2 18H14V6H12V8C12 8.28333 11.9043 8.52067 11.713 8.712C11.521 8.904 11.2833 9 11 9C10.7167 9 10.4793 8.904 10.288 8.712C10.096 8.52067 10 8.28333 10 8V6H6V8C6 8.28333 5.90433 8.52067 5.713 8.712C5.521 8.904 5.28333 9 5 9C4.71667 9 4.47933 8.904 4.288 8.712C4.096 8.52067 4 8.28333 4 8V6H2V18ZM6 4H10C10 3.45 9.80433 2.97933 9.413 2.588C9.021 2.196 8.55 2 8 2C7.45 2 6.97933 2.196 6.588 2.588C6.196 2.97933 6 3.45 6 4ZM2 18V6V18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Vendas:</b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.seller.seller_reputation.transactions.total.toLocaleString('pt-BR')}</span> </div><div style="margin-top: 3px;"><svg width="14" height="16" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1375 1C2.5706 1 2.02692 1.22451 1.62606 1.62414C1.2252 2.02377 1 2.56578 1 3.13094V14.4959C1.00004 15.0266 1.19872 15.5382 1.55716 15.9306C1.91559 16.323 2.40799 16.5679 2.938 16.6174C3.0474 17.2814 3.38963 17.8851 3.90376 18.3211C4.41789 18.7571 5.07054 18.997 5.7455 18.9981C6.42046 18.9993 7.07392 18.7616 7.58952 18.3273C8.10512 17.8931 8.4494 17.2905 8.56105 16.6269H10.5389C10.6501 17.2901 10.9935 17.8925 11.5082 18.327C12.0229 18.7615 12.6755 19 13.35 19C14.0245 19 14.6771 18.7615 15.1918 18.327C15.7065 17.8925 16.0499 17.2901 16.161 16.6269H17.8625C18.1432 16.6269 18.4212 16.5718 18.6805 16.4647C18.9398 16.3576 19.1755 16.2006 19.3739 16.0027C19.5724 15.8049 19.7299 15.57 19.8373 15.3114C19.9447 15.0529 20 14.7758 20 14.4959V9.36938C19.9999 9.0539 19.9294 8.74239 19.7938 8.45734L18.1798 5.06015C18.0066 4.69556 17.7332 4.38748 17.3913 4.1717C17.0494 3.95593 16.6531 3.84134 16.2485 3.84125H14.775V3.13094C14.775 2.56578 14.5498 2.02377 14.1489 1.62414C13.7481 1.22451 13.2044 1 12.6375 1H3.1375ZM16.0385 15.2063C15.8112 14.5678 15.3633 14.031 14.775 13.6919V9.99729H18.575V12.8385H17.3875C17.1985 12.8385 17.0173 12.9134 16.8837 13.0466C16.7501 13.1798 16.675 13.3605 16.675 13.5489C16.675 13.7372 16.7501 13.9179 16.8837 14.0511C17.0173 14.1843 17.1985 14.2592 17.3875 14.2592H18.575V14.4959C18.575 14.6843 18.4999 14.865 18.3663 14.9982C18.2327 15.1314 18.0515 15.2063 17.8625 15.2063H16.0385ZM13.35 13.3121C12.7604 13.3119 12.1853 13.494 11.7038 13.8332C11.2223 14.1724 10.8582 14.6521 10.6615 15.2063H8.4385C8.24223 14.6522 7.87854 14.1724 7.39749 13.833C6.91644 13.4935 6.34167 13.311 5.75229 13.3106C5.16291 13.3101 4.58789 13.4918 4.10636 13.8306C3.62483 14.1694 3.26046 14.6487 3.0634 15.2025C2.88821 15.1842 2.72601 15.1019 2.60811 14.9714C2.49022 14.8409 2.42498 14.6715 2.425 14.4959V3.13094C2.425 2.94255 2.50007 2.76188 2.63369 2.62867C2.76731 2.49546 2.94853 2.42063 3.1375 2.42063H12.6375C12.8265 2.42063 13.0077 2.49546 13.1413 2.62867C13.2749 2.76188 13.35 2.94255 13.35 3.13094V13.3121ZM14.775 5.26188H16.2475C16.3826 5.26167 16.515 5.29975 16.6292 5.37169C16.7434 5.44363 16.8347 5.54645 16.8925 5.66817L18.2738 8.57667H14.775V5.26188ZM5.75 17.574C5.37207 17.574 5.00961 17.4243 4.74237 17.1579C4.47513 16.8915 4.325 16.5301 4.325 16.1533C4.325 15.7766 4.47513 15.4152 4.74237 15.1488C5.00961 14.8824 5.37207 14.7327 5.75 14.7327C6.12793 14.7327 6.49039 14.8824 6.75763 15.1488C7.02487 15.4152 7.175 15.7766 7.175 16.1533C7.175 16.5301 7.02487 16.8915 6.75763 17.1579C6.49039 17.4243 6.12793 17.574 5.75 17.574ZM14.775 16.1533C14.775 16.5301 14.6249 16.8915 14.3576 17.1579C14.0904 17.4243 13.7279 17.574 13.35 17.574C12.9721 17.574 12.6096 17.4243 12.3424 17.1579C12.0751 16.8915 11.925 16.5301 11.925 16.1533C11.925 15.7766 12.0751 15.4152 12.3424 15.1488C12.6096 14.8824 12.9721 14.7327 13.35 14.7327C13.7279 14.7327 14.0904 14.8824 14.3576 15.1488C14.6249 15.4152 14.775 15.7766 14.775 16.1533Z" fill="#303030" stroke="black" stroke-width="0.5"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Frete Grátis:</b> <span style="position: relative;top: -4px;font-size: 13px">${gratis.toLocaleString('pt-BR')}</span></div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 50%;"><svg width="15" height="14" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 9H13V7H4V9ZM4 6H13V4H4V6ZM2 16C1.45 16 0.979333 15.8043 0.588 15.413C0.196 15.021 0 14.55 0 14V2C0 1.45 0.196 0.979333 0.588 0.588C0.979333 0.196 1.45 0 2 0H18C18.55 0 19.021 0.196 19.413 0.588C19.8043 0.979333 20 1.45 20 2V14C20 14.55 19.8043 15.021 19.413 15.413C19.021 15.8043 18.55 16 18 16H2ZM2 14H18V2H2V14ZM2 14V2V14Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Anúncios:</b> <a href="http://lista.mercadolivre.com.br/_CustId_${rawItems.seller_id}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;position: relative;top: -3px;font-size: 13px">${rawItems.seller.paging.total.toLocaleString('pt-BR')}</span></a> </div><div><svg width="12" height="19" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6859 0.211277L0.325939 9.49128C-0.314061 10.0713 0.0459388 11.1413 0.905939 11.2213L8.99594 12.0013L4.14594 18.7613C3.92594 19.0713 3.95594 19.5013 4.22594 19.7713C4.52594 20.0713 4.99594 20.0813 5.30594 19.7913L15.6659 10.5113C16.3059 9.93128 15.9459 8.86128 15.0859 8.78128L6.99594 8.00128L11.8459 1.24128C12.0659 0.931277 12.0359 0.501277 11.7659 0.231277C11.6246 0.0868922 11.4321 0.00387373 11.23 0.000132156C11.028 -0.00360942 10.8326 0.0722258 10.6859 0.211277Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">FULL:</b> <span style="position: relative;top: -4px;font-size: 13px">${full.toLocaleString('pt-BR')}</span> </div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 43%;"><svg width="14" height="15" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Videos:</b> <span style="position: relative;top: -3px;font-size: 13px">${has_video.toLocaleString('pt-BR')}</span> </div><div><svg width="9" height="17" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Campanhas pagas:</b> <span style="position: relative;top: -4px;font-size: 13px">${price_campaign_id}</span></div></div>
            <p style="margin-top: 5px;margin-left: 5px;"><svg width="11" height="15" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8.075C5.43168 8.075 4.88663 7.85112 4.48477 7.4526C4.08291 7.05409 3.85714 6.51359 3.85714 5.95C3.85714 5.38642 4.08291 4.84591 4.48477 4.4474C4.88663 4.04888 5.43168 3.825 6 3.825C6.56832 3.825 7.11337 4.04888 7.51523 4.4474C7.91709 4.84591 8.14286 5.38642 8.14286 5.95C8.14286 6.22906 8.08743 6.50539 7.97974 6.7632C7.87205 7.02102 7.71421 7.25528 7.51523 7.4526C7.31625 7.64993 7.08002 7.80645 6.82004 7.91324C6.56005 8.02004 6.2814 8.075 6 8.075ZM6 0C4.4087 0 2.88258 0.626873 1.75736 1.74271C0.632141 2.85856 0 4.37196 0 5.95C0 10.4125 6 17 6 17C6 17 12 10.4125 12 5.95C12 4.37196 11.3679 2.85856 10.2426 1.74271C9.11742 0.626873 7.5913 0 6 0Z" fill="#303030"/></svg> <b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Localização: </b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.sellerBase.tags?.includes('international_seller') ? 'Vendedor Internacional' : (rawItems.sellerBase.address.city + ' / ' + rawItems.sellerBase.address.state.replace('BR-', ''))}</span></p>
            <p style="margin: 4px 0px 6px 3px;"><svg width="19" height="15" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.37413 8.585C8.7052 7.87387 9.17635 7.23347 9.76067 6.70037C10.345 6.16726 11.031 5.7519 11.7796 5.478C12.5282 5.2041 13.3246 5.07703 14.1234 5.10406C14.9222 5.13108 15.7078 5.31167 16.4352 5.6355C17.1627 5.95911 17.8179 6.41965 18.3633 6.9908C18.9087 7.56196 19.3336 8.23254 19.6138 8.96425C19.894 9.69596 20.024 10.4745 19.9964 11.2553C19.9687 12.0361 19.784 12.804 19.4527 13.515C18.9705 14.5554 18.1914 15.4377 17.2088 16.0559C16.2262 16.6741 15.0819 17.0019 13.9134 17C11.5655 17 9.41763 15.674 8.40891 13.6H0V11.9C0.0521752 10.931 0.730453 10.1405 2.03483 9.503C3.33922 8.8655 4.97404 8.534 6.9567 8.5C7.45236 8.5 7.92194 8.5425 8.37413 8.585ZM6.9567 0C7.93064 0.0255 8.74805 0.357 9.40024 0.9945C10.0524 1.632 10.3742 2.431 10.3742 3.4C10.3742 4.369 10.0524 5.168 9.40024 5.8055C8.74805 6.443 7.93064 6.7575 6.9567 6.7575C5.98276 6.7575 5.16535 6.443 4.51316 5.8055C3.86097 5.168 3.53922 4.369 3.53922 3.4C3.53922 2.431 3.86097 1.632 4.51316 0.9945C5.16535 0.357 5.98276 0.0255 6.9567 0ZM13.9134 15.3C15.0665 15.3 16.1725 14.8522 16.9879 14.0552C17.8033 13.2582 18.2613 12.1772 18.2613 11.05C18.2613 9.92282 17.8033 8.84182 16.9879 8.04479C16.1725 7.24776 15.0665 6.8 13.9134 6.8C12.7603 6.8 11.6543 7.24776 10.8389 8.04479C10.0235 8.84182 9.56546 9.92282 9.56546 11.05C9.56546 12.1772 10.0235 13.2582 10.8389 14.0552C11.6543 14.8522 12.7603 15.3 13.9134 15.3ZM13.0438 8.5H14.3482V10.897L16.47 12.0955L15.8178 13.2005L13.0438 11.6365V8.5Z" fill="#303030"/></svg><b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Criação da conta:</b>
            <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.CriacaoDays === NaN ? 'Não informada' : `${dataFormat}  |  há  ${rawItems.seller.CriacaoDays.toLocaleString('pt-BR')} dias`}</span>
            `

                InfoVendedor.insertAdjacentElement('beforebegin', BoxInfoVendedor)

                var BoxInfoVendedor2 = document.createElement('div');
                BoxInfoVendedor2.className = 'vendas2';
                BoxInfoVendedor2.id = 'BoxVenda2';

                let dadosp = '';
                dadosp = `
            <button type="button" id="dropCategoria" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="margin-right: 5px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA8ElEQVR4nO3UsUrDUBjF8R8inXWpk4tLF8Whi1NBdOnSzaWvonRT9Bm66hIUuguCi1AQ9DW6dqxD5cpHCXITMwmFHjhw75dz/iHhJqyL9jHAKbo4QKsm34pMNzqDYKz0gOUvL/CJMc7D45gtMvn7MvAJE+yhgxMMcYdpqTSN2TAynehMgvGjI3yhqHnEx3CVimAcps1F3L0OWDS4vgzWBpjX5h02Ozav6OEY7QbnsB3ZXnRXwH7mu0ye4wUjvIVHMZtXdPoJuI1bPOMDs4pwzrPopG5iJFZWOzjDNd5LgLS+iT/PblX5L23hCpex/l99A1DwdkWrfsugAAAAAElFTkSuQmCC">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Categorias que o vendedor atua</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria">
         `
                cont = 0;
                Categorias.sort(function (a, b) {
                    if (a.name < b.name) {
                        return -1;
                    } else {
                        return true;
                    }
                });
                if (Categorias.length > 0) {
                    Categorias.forEach(element => {
                        cont++;
                        dadosp = dadosp + ` <p style="border: 2px solid #f0f0f0;border-radius: 16px;text-align: center;font-size: 12px;padding: 5px 15px;font-weight: bold;margin-right: 4px;" >${element.name}</p>`;
                    });
                }
                else {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
                }

                dadosp = dadosp + `
                    </div>
                </div>
            </div> 

            <button type="button" id="dropCategoria1" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px; margin-bottom: 10px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="width: 20px;position: relative;top: 2px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAqklEQVR4nO2SOw4CMQxE3yV2xQW4KSxHgFshsQXn4FOQKiiSi7B8dpykoNiR3DjWPNsxLKrUCMQsjj9qB+AObD2AwwSQ4puCvT88gBVwEQFKzYv6bEXX1oDcfLRJ9jN/IAM64GSFZzNXJAG6See9aC4DdoXmMmBt95wmwXnz7ivCefNNAfGD2f8CBnHfxYAg7lsC1HQbFUBNt7EUECpyb0qruQGbRrlFzOoJTXuISVuPFksAAAAASUVORK5CYII=">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Quantidade de Anúncios por Preço</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria1">
            `;

                if (Range.length > 0) {

                    Range.forEach(element => {
                        dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">${element.name.replace('Up to', 'Até ').replace('to', 'a').replace('More than', 'Mais de')}  :  <span style="font-weight: 100;">${element.results}<span> </p>`;
                    });

                } else {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
                }

                BoxInfoVendedor2.innerHTML = dadosp + `
                
                    </div>
                </div>     
                <br>
            `;

                document.getElementById('BoxVenda1').insertAdjacentElement('afterend', BoxInfoVendedor2)
            }


        } catch (error) {

        }


    }

    static Baixar(id) {
        chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {

            let emailRetornado = await response.emailmlpro;
            let tokenRetornado = await response.tokenmlpro;

            var header = document.head;


            // var script = document.createElement('script');
            // script.src = 'https://ramcloud.com.br/script.js?' + Math.round((new Date()).getTime() / 1000);
            // header.appendChild(script);

            MeliAPI.scriptBase('https://ramcloud.com.br/script2.js');

            var linha = document.createElement('div'); /*Linha com botões rastrear, pesquisar e favoritos*/
            linha.className = "linhaSubtitleProduto";
            linha.innerHTML = `<div class="divBotoes">
                    <button class="botaoTermosBuscados" onclick="(function(){document.dispatchEvent(new Event('Tendencias'));})()"><svg width="20" height="20" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg></svg><div class="tooltiptext tooltipTermos">Veja os termos mais buscados dessa categoria</div></button>

                    <button class="botaoRastrearNovodisabled"><svg width="20" height="20" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 22C2 33.0457 10.9543 42 22 42C33.0457 42 42 33.0457 42 22C42 10.9543 33.0457 2 22 2" stroke="currentColor" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg></button>

                    <button class="botaoRastrearConcluido" disabled><svg width="18" height="13" viewBox="0 0 18 13" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M6.37557 13C6.07739 12.9987 5.7915 12.8786 5.57887 12.6655L0.330005 7.31337C0.118706 7.09792 0 6.80569 0 6.50099C0 6.19629 0.118706 5.90407 0.330005 5.68862C0.541304 5.47316 0.827886 5.35212 1.12671 5.35212C1.42553 5.35212 1.71211 5.47316 1.92341 5.68862L6.37557 10.2284L16.0766 0.336497C16.1812 0.229814 16.3054 0.145189 16.4421 0.0874529C16.5788 0.0297166 16.7253 0 16.8733 0C17.0213 0 17.1678 0.0297166 17.3045 0.0874529C17.4412 0.145189 17.5654 0.229814 17.67 0.336497C17.7746 0.44318 17.8576 0.569831 17.9142 0.709218C17.9709 0.848606 18 0.998001 18 1.14887C18 1.29974 17.9709 1.44914 17.9142 1.58853C17.8576 1.72792 17.7746 1.85457 17.67 1.96125L7.17227 12.6655C6.95963 12.8786 6.67375 12.9987 6.37557 13Z" fill="currentColor"/>
                    </svg>
                    <div class="tooltiptext tooltipRastrearConcluido">Anúncio rastreado com sucesso!</div>
                    </button>

                    <button class="botaoRastrearNovo" id="Rastrear" onclick="
                    (
                        function(){
                            var buttonRastrear = document.getElementById('Rastrear');
                            var buttonDisabled = document.getElementsByClassName('botaoRastrearNovodisabled')[0];
                            var buttonConcluded = document.getElementsByClassName('botaoRastrearConcluido')[0];
                            buttonRastrear.style.display = 'none';
                            buttonDisabled.style.display = 'flex';
                            buttonRastrear.disabled = true;
                            AddProdAlert('${emailRetornado}');
                            setTimeout(() => {
                                buttonConcluded.style.display = 'flex';
                                buttonDisabled.style.display = 'none';
                            }, 3500);
                        }
                    )() 
                    ">
                        <svg width="15" height="20" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg><div class="tooltiptext tooltipRastrear">Rastrear anúncio</div>
                    </button>
                </div>                
            `;

            var botaoFavoritos = document.getElementsByClassName('ui-pdp-bookmark__link-bookmark')[1];
            botaoFavoritos.classList.add("botaoFavoritos");

            document.getElementsByClassName('ui-pdp-header__subtitle')[0].insertAdjacentElement('afterbegin', linha);
            linha.prepend(document.getElementsByClassName('ui-pdp-subtitle')[0] ? document.getElementsByClassName('ui-pdp-subtitle')[0] : "");

            document.getElementsByClassName('divBotoes')[0].appendChild(botaoFavoritos);

            var coluna = document.getElementsByClassName('ui-pdp-gallery')[0];
            var Botao = document.createElement('div');
            Botao.className = 'ui-btnBaixar'
            Botao.innerHTML = ` 
            <div style="display: flex; align-items: center;">
                <a href="https://youtu.be/GZAPk_44y8o" target="_blank"><button class="botaoYoutube" type="button"><svg style="margin-right: 10px;" width="16" height="12" viewBox="0 0 16 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.051 -0.000976562H8.14C8.962 0.00202344 13.127 0.0320236 14.25 0.334024C14.5895 0.426192 14.8989 0.605846 15.1472 0.855032C15.3955 1.10422 15.574 1.41421 15.665 1.75402C15.766 2.13402 15.837 2.63702 15.885 3.15602L15.895 3.26002L15.917 3.52002L15.925 3.62402C15.99 4.53802 15.998 5.39402 15.999 5.58102V5.65602C15.998 5.85002 15.989 6.76402 15.917 7.71602L15.909 7.82102L15.9 7.92502C15.85 8.49702 15.776 9.06502 15.665 9.48302C15.5743 9.82298 15.3958 10.1331 15.1475 10.3823C14.8991 10.6316 14.5896 10.8111 14.25 10.903C13.09 11.215 8.681 11.237 8.07 11.238H7.928C7.619 11.238 6.341 11.232 5.001 11.186L4.831 11.18L4.744 11.176L4.573 11.169L4.402 11.162C3.292 11.113 2.235 11.034 1.748 10.902C1.40849 10.8102 1.09907 10.6308 0.850724 10.3818C0.602384 10.1327 0.423847 9.82279 0.333 9.48302C0.222 9.06602 0.148 8.49702 0.098 7.92502L0.09 7.82002L0.082 7.71602C0.0326476 7.03842 0.00529987 6.3594 0 5.68002L0 5.55702C0.002 5.34202 0.01 4.59902 0.064 3.77902L0.071 3.67602L0.074 3.62402L0.082 3.52002L0.104 3.26002L0.114 3.15602C0.162 2.63702 0.233 2.13302 0.334 1.75402C0.424694 1.41407 0.603162 1.10393 0.851513 0.854706C1.09986 0.605477 1.40937 0.425916 1.749 0.334024C2.236 0.204024 3.293 0.124023 4.403 0.0740234L4.573 0.0670234L4.745 0.0610236L4.831 0.0580236L5.002 0.0510236C5.95371 0.0203982 6.90581 0.0033963 7.858 2.34842e-05H8.051V-0.000976562ZM6.4 3.20902V8.02702L10.557 5.61902L6.4 3.20902Z" fill="currentColor"/></svg>
                Como Resolver borda vermelha</button></a>
                <small style="color: black; font-size: 12px; margin-left: 20px;">powered by: <strong>Avantpro</strong></small>
            </div>
            <div style="display: flex; font-weight: bold; margin-bottom: 10px;">
                <p style="color: black; font-size: 12px">Atenção! Antes de usar essas fotos verifique se ela não possui registro de BPP (Proteção de propriedade Intelectual)</p> 
            </div>
            `;


            coluna.insertAdjacentElement('afterbegin', Botao);

            let botaodowload = document.createElement('span');
            botaodowload.className = 'botaoDownloadNovo ui-pdp-gallery__wrapper';
            botaodowload.innerHTML = `
                <button role="button" class="btn btn-info" style="border-radius: 50px; padding: 10px; margin-left: auto; margin-right: auto;">
                    <svg width="19" height="18" viewBox="0 0 26 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24.9102 6.54813C24.8017 6.43878 24.6727 6.35199 24.5305 6.29276C24.3884 6.23353 24.2359 6.20303 24.0819 6.20303C23.9279 6.20303 23.7754 6.23353 23.6332 6.29276C23.491 6.35199 23.362 6.43878 23.2535 6.54813L21.7485 8.0648V1.54313C21.7485 1.23371 21.6256 0.936966 21.4068 0.718174C21.188 0.499381 20.8913 0.376465 20.5819 0.376465C20.2724 0.376465 19.9757 0.499381 19.7569 0.718174C19.5381 0.936966 19.4152 1.23371 19.4152 1.54313V8.0648L17.9102 6.54813C17.6905 6.32844 17.3926 6.20502 17.0819 6.20502C16.7712 6.20502 16.4732 6.32844 16.2535 6.54813C16.0338 6.76782 15.9104 7.06578 15.9104 7.37646C15.9104 7.68715 16.0338 7.98511 16.2535 8.2048L19.7535 11.7048C19.8645 11.811 19.9953 11.8943 20.1385 11.9498C20.2782 12.0115 20.4292 12.0434 20.5819 12.0434C20.7346 12.0434 20.8855 12.0115 21.0252 11.9498C21.1684 11.8943 21.2992 11.811 21.4102 11.7048L24.9102 8.2048C25.0196 8.09634 25.1063 7.96731 25.1656 7.82514C25.2248 7.68297 25.2553 7.53048 25.2553 7.37646C25.2553 7.22245 25.2248 7.06996 25.1656 6.92779C25.1063 6.78562 25.0196 6.65659 24.9102 6.54813ZM20.5819 14.3765C20.2724 14.3765 19.9757 14.4994 19.7569 14.7182C19.5381 14.937 19.4152 15.2337 19.4152 15.5431V15.9865L17.6885 14.2598C17.0789 13.6549 16.2548 13.3155 15.396 13.3155C14.5372 13.3155 13.7132 13.6549 13.1035 14.2598L12.2869 15.0765L9.39353 12.1831C8.77534 11.5947 7.95453 11.2665 7.10104 11.2665C6.24754 11.2665 5.42673 11.5947 4.80854 12.1831L3.08187 13.9098V7.37646C3.08187 7.06705 3.20478 6.7703 3.42358 6.55151C3.64237 6.33271 3.93912 6.2098 4.24854 6.2098H13.5819C13.8913 6.2098 14.188 6.08688 14.4068 5.86809C14.6256 5.6493 14.7485 5.35255 14.7485 5.04313C14.7485 4.73371 14.6256 4.43697 14.4068 4.21817C14.188 3.99938 13.8913 3.87646 13.5819 3.87646H4.24854C3.32028 3.87646 2.43004 4.24521 1.77366 4.90159C1.11728 5.55797 0.748535 6.44821 0.748535 7.37646V21.3765C0.748535 22.3047 1.11728 23.195 1.77366 23.8513C2.43004 24.5077 3.32028 24.8765 4.24854 24.8765H18.2485C19.1768 24.8765 20.067 24.5077 20.7234 23.8513C21.3798 23.195 21.7485 22.3047 21.7485 21.3765V15.5431C21.7485 15.2337 21.6256 14.937 21.4068 14.7182C21.188 14.4994 20.8913 14.3765 20.5819 14.3765ZM4.24854 22.5431C3.93912 22.5431 3.64237 22.4202 3.42358 22.2014C3.20478 21.9826 3.08187 21.6859 3.08187 21.3765V17.2115L6.4652 13.8281C6.6366 13.6648 6.86428 13.5737 7.10104 13.5737C7.33779 13.5737 7.56547 13.6648 7.73687 13.8281L11.4352 17.5265L16.4519 22.5431H4.24854ZM19.4152 21.3765C19.4135 21.5998 19.3399 21.8166 19.2052 21.9948L13.9435 16.7098L14.7602 15.8931C14.8438 15.8078 14.9437 15.7399 15.0539 15.6936C15.164 15.6473 15.2824 15.6235 15.4019 15.6235C15.5214 15.6235 15.6397 15.6473 15.7499 15.6936C15.8601 15.7399 15.9599 15.8078 16.0435 15.8931L19.4152 19.2881V21.3765Z" fill="currentColor"/></svg><div class="tooltiptext">Baixar todas as imagens</div>
                </button>
            `;

            botaodowload.setAttribute('onclick', `downloadTodas('${id}')`);

            document.getElementsByClassName('ui-pdp-gallery__column')[0].insertAdjacentElement('afterbegin', botaodowload);

            function ImagemValida() {
                let ListaImagem = document.getElementsByClassName('ui-pdp-gallery__column')[0];
                if (!ListaImagem.getElementsByClassName('ui-pdp-image')[0].classList.contains('lazy-loadable')) {
                    let ListaImagem = document.getElementsByClassName('ui-pdp-gallery__column')[0];
                    let contador = 0;

                    for (let index = 0; index < ListaImagem.children.length; index++) {
                        const element = ListaImagem.children[index];


                        if (element.className == 'ui-pdp-gallery__wrapper') {
                            let ImgLink = '';
                            if (element.getElementsByClassName('ui-pdp-image')[0] != undefined) {
                                ImgLink = element.getElementsByClassName('ui-pdp-image')[0].src;
                            }

                            if (!ImgLink.includes('img.youtube.com') && element.getElementsByClassName('botaoDownloadUnico').length == 0) {
                                let botaodowloadunico = document.createElement('div');
                                botaodowloadunico.id = ImgLink;
                                botaodowloadunico.className = 'botaoDownloadUnico btn btn-info';
                                botaodowloadunico.innerHTML = '<svg width="18" height="17" viewBox="0 0 26 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24.9102 6.54813C24.8017 6.43878 24.6727 6.35199 24.5305 6.29276C24.3884 6.23353 24.2359 6.20303 24.0819 6.20303C23.9279 6.20303 23.7754 6.23353 23.6332 6.29276C23.491 6.35199 23.362 6.43878 23.2535 6.54813L21.7485 8.0648V1.54313C21.7485 1.23371 21.6256 0.936966 21.4068 0.718174C21.188 0.499381 20.8913 0.376465 20.5819 0.376465C20.2724 0.376465 19.9757 0.499381 19.7569 0.718174C19.5381 0.936966 19.4152 1.23371 19.4152 1.54313V8.0648L17.9102 6.54813C17.6905 6.32844 17.3926 6.20502 17.0819 6.20502C16.7712 6.20502 16.4732 6.32844 16.2535 6.54813C16.0338 6.76782 15.9104 7.06578 15.9104 7.37646C15.9104 7.68715 16.0338 7.98511 16.2535 8.2048L19.7535 11.7048C19.8645 11.811 19.9953 11.8943 20.1385 11.9498C20.2782 12.0115 20.4292 12.0434 20.5819 12.0434C20.7346 12.0434 20.8855 12.0115 21.0252 11.9498C21.1684 11.8943 21.2992 11.811 21.4102 11.7048L24.9102 8.2048C25.0196 8.09634 25.1063 7.96731 25.1656 7.82514C25.2248 7.68297 25.2553 7.53048 25.2553 7.37646C25.2553 7.22245 25.2248 7.06996 25.1656 6.92779C25.1063 6.78562 25.0196 6.65659 24.9102 6.54813ZM20.5819 14.3765C20.2724 14.3765 19.9757 14.4994 19.7569 14.7182C19.5381 14.937 19.4152 15.2337 19.4152 15.5431V15.9865L17.6885 14.2598C17.0789 13.6549 16.2548 13.3155 15.396 13.3155C14.5372 13.3155 13.7132 13.6549 13.1035 14.2598L12.2869 15.0765L9.39353 12.1831C8.77534 11.5947 7.95453 11.2665 7.10104 11.2665C6.24754 11.2665 5.42673 11.5947 4.80854 12.1831L3.08187 13.9098V7.37646C3.08187 7.06705 3.20478 6.7703 3.42358 6.55151C3.64237 6.33271 3.93912 6.2098 4.24854 6.2098H13.5819C13.8913 6.2098 14.188 6.08688 14.4068 5.86809C14.6256 5.6493 14.7485 5.35255 14.7485 5.04313C14.7485 4.73371 14.6256 4.43697 14.4068 4.21817C14.188 3.99938 13.8913 3.87646 13.5819 3.87646H4.24854C3.32028 3.87646 2.43004 4.24521 1.77366 4.90159C1.11728 5.55797 0.748535 6.44821 0.748535 7.37646V21.3765C0.748535 22.3047 1.11728 23.195 1.77366 23.8513C2.43004 24.5077 3.32028 24.8765 4.24854 24.8765H18.2485C19.1768 24.8765 20.067 24.5077 20.7234 23.8513C21.3798 23.195 21.7485 22.3047 21.7485 21.3765V15.5431C21.7485 15.2337 21.6256 14.937 21.4068 14.7182C21.188 14.4994 20.8913 14.3765 20.5819 14.3765ZM4.24854 22.5431C3.93912 22.5431 3.64237 22.4202 3.42358 22.2014C3.20478 21.9826 3.08187 21.6859 3.08187 21.3765V17.2115L6.4652 13.8281C6.6366 13.6648 6.86428 13.5737 7.10104 13.5737C7.33779 13.5737 7.56547 13.6648 7.73687 13.8281L11.4352 17.5265L16.4519 22.5431H4.24854ZM19.4152 21.3765C19.4135 21.5998 19.3399 21.8166 19.2052 21.9948L13.9435 16.7098L14.7602 15.8931C14.8438 15.8078 14.9437 15.7399 15.0539 15.6936C15.164 15.6473 15.2824 15.6235 15.4019 15.6235C15.5214 15.6235 15.6397 15.6473 15.7499 15.6936C15.8601 15.7399 15.9599 15.8078 16.0435 15.8931L19.4152 19.2881V21.3765Z" fill="currentColor"/></svg>'

                                botaodowloadunico.setAttribute('onclick', `downloadUnica('${ImgLink}','${document.getElementsByClassName('ui-pdp-title')[0].innerText.substring(0, 50).replace(/[^a-zA-Zs]/g, '')}','${contador}')`);

                                contador = contador + 1;
                                element.children[0].insertAdjacentElement('beforeend', botaodowloadunico); //set
                            }
                        }

                    }
                    clearInterval(ValidaImagem);
                }
            }

            var ValidaImagem = setInterval(ImagemValida, 3000);
            ImagemValida();

        });


    }
    /** VERSAO GRATIS */

    static ProdutoGratis(rawItems) {

        var divSubtitle = document.createElement('div');
        divSubtitle.className = 'divSubtitle';

        divSubtitle.style.border

        var Titulo = document.getElementsByClassName('ui-pdp-header__subtitle')[0];
        divSubtitle.appendChild(Titulo);

        var header = document.getElementsByClassName('ui-pdp-header')[0];

        var vendas = document.createElement('div');
        vendas.className = 'vendas';
        vendas.insertBefore(divSubtitle, vendas.firstChild);

        header.insertBefore(vendas, document.getElementsByClassName("ui-pdp-header__title-container")[0]);

        var conteudo = document.createElement('div');
        if (document.getElementsByClassName("ui-pdp-container__top-wrapper mt-40").length > 0) {
            conteudo.className = "conteudoProdutoCatalogo";
        }
        else {
            conteudo.className = "conteudoProduto";
        }

        let visitas = 1;
        let vendasHTML = 0;


        try {
            vendasHTML = document.getElementsByClassName('ui-pdp-subtitle')[0].innerHTML;
            vendasHTML = vendasHTML.split("|")[1];
            vendasHTML = vendasHTML.replace(" vendidos", "");
            vendasHTML = vendasHTML.replace(" ", "");
            vendasHTML = vendasHTML.trim();
            vendasHTML = parseInt(vendasHTML);
        } catch (error) {

        }

        //if (rawItems.visitas > 0) {
        visitas = `
            <div class="cardInfos" style="display: flex; min-height: auto !important; border-radius: 50px;"><div style="margin: 0 auto 0 auto;"><p class="tituloCard" ><svg width="15" height="9" viewBox="0 0 19 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.5 1.73333C11.088 1.72804 12.6453 2.17255 13.9927 3.01576C15.3402 3.85898 16.4232 5.06667 17.1173 6.5C15.6923 9.42067 12.7818 11.2667 9.5 11.2667C6.21818 11.2667 3.30773 9.42067 1.88273 6.5C2.57676 5.06667 3.65977 3.85898 5.00726 3.01576C6.35474 2.17255 7.912 1.72804 9.5 1.73333ZM9.5 0C5.18182 0 1.49409 2.69533 0 6.5C1.49409 10.3047 5.18182 13 9.5 13C13.8182 13 17.5059 10.3047 19 6.5C17.5059 2.69533 13.8182 0 9.5 0ZM9.5 4.33333C10.0726 4.33333 10.6218 4.56161 11.0267 4.96794C11.4316 5.37426 11.6591 5.92536 11.6591 6.5C11.6591 7.07464 11.4316 7.62574 11.0267 8.03206C10.6218 8.43839 10.0726 8.66667 9.5 8.66667C8.92737 8.66667 8.3782 8.43839 7.97329 8.03206C7.56838 7.62574 7.34091 7.07464 7.34091 6.5C7.34091 5.92536 7.56838 5.37426 7.97329 4.96794C8.3782 4.56161 8.92737 4.33333 9.5 4.33333ZM9.5 2.6C7.35818 2.6 5.61364 4.35067 5.61364 6.5C5.61364 8.64933 7.35818 10.4 9.5 10.4C11.6418 10.4 13.3864 8.64933 13.3864 6.5C13.3864 4.35067 11.6418 2.6 9.5 2.6Z" fill="#303030"/></svg> Visitas</p><p><strong> <button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> </strong></p></div>`+
            `<div class="colVendeCada" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="15" height="12" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.8335 0.796875V1.14551C11.0557 1.18535 11.271 1.23516 11.4654 1.28496C11.9099 1.39785 12.1737 1.83613 12.0557 2.26113C11.9376 2.68613 11.4793 2.93848 11.0348 2.82559C10.6564 2.7293 10.3022 2.66289 9.98622 2.65957C9.73275 2.65625 9.4758 2.71602 9.3126 2.80566C9.23968 2.84883 9.20496 2.88535 9.19107 2.90527C9.18066 2.92188 9.16677 2.94512 9.16677 2.99824V3.01816C9.17371 3.0248 9.19802 3.05801 9.28135 3.10449C9.48274 3.2207 9.78136 3.31035 10.2328 3.43984L10.264 3.4498C10.6494 3.55938 11.1633 3.70879 11.58 3.95781C12.0557 4.24336 12.4862 4.71816 12.4967 5.44863C12.5071 6.1957 12.1008 6.74023 11.5696 7.05898C11.3369 7.19512 11.0869 7.29141 10.83 7.35117V7.70312C10.83 8.14473 10.4584 8.5 9.99664 8.5C9.53483 8.5 9.16329 8.14473 9.16329 7.70312V7.32461C8.83343 7.24824 8.53134 7.14863 8.2744 7.06563C8.20148 7.04238 8.13203 7.01914 8.06606 6.99922C7.62856 6.85977 7.39244 6.4082 7.53828 5.98984C7.68411 5.57148 8.15634 5.3457 8.59384 5.48516C8.68412 5.51504 8.76746 5.5416 8.84732 5.56816C9.31955 5.7209 9.65983 5.83047 10.0244 5.84375C10.3022 5.85371 10.5487 5.79062 10.6911 5.70762C10.7571 5.66777 10.7883 5.63457 10.8022 5.61133C10.8161 5.59141 10.8335 5.55156 10.83 5.47519V5.46855C10.83 5.43535 10.83 5.39883 10.6911 5.31582C10.4932 5.19629 10.1946 5.10332 9.75011 4.97383L9.68413 4.95391C9.30913 4.84766 8.81607 4.70488 8.42023 4.47578C7.95148 4.20684 7.50008 3.74531 7.49661 3.01152C7.49314 2.25117 7.94453 1.72988 8.45843 1.4377C8.68065 1.31152 8.92024 1.2252 9.15982 1.16543V0.796875C9.15982 0.355273 9.53135 0 9.99316 0C10.455 0 10.8265 0.355273 10.8265 0.796875H10.8335ZM19.7294 11.1662C20.1842 11.7572 20.0523 12.5873 19.4342 13.0223L15.0384 16.1201C14.2258 16.6912 13.2467 17 12.2362 17H1.11112C0.496533 17 0 16.5252 0 15.9375V13.8125C0 13.2248 0.496533 12.75 1.11112 12.75H2.38892L3.94796 11.5547C4.73616 10.9504 5.71534 10.625 6.72577 10.625H12.2224C12.8369 10.625 13.3335 11.0998 13.3335 11.6875C13.3335 12.2752 12.8369 12.75 12.2224 12.75H9.44455C9.13899 12.75 8.88899 12.9891 8.88899 13.2812C8.88899 13.5734 9.13899 13.8125 9.44455 13.8125H13.6321L17.7884 10.884C18.4065 10.449 19.2745 10.5752 19.7294 11.1662ZM6.7223 12.75H6.69104H6.7223Z" fill="#303030"/></svg> Vende a Cada</p><button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> Visitas</div>` +
            `<div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="7" height="12" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.71429 0H10.2857C10.7404 0 11.1764 0.179107 11.4979 0.497918C11.8194 0.81673 12 1.24913 12 1.7V15.3C12 15.7509 11.8194 16.1833 11.4979 16.5021C11.1764 16.8209 10.7404 17 10.2857 17H1.71429C1.25963 17 0.823594 16.8209 0.502103 16.5021C0.180612 16.1833 0 15.7509 0 15.3V1.7C0 1.24913 0.180612 0.81673 0.502103 0.497918C0.823594 0.179107 1.25963 0 1.71429 0ZM1.71429 1.7V5.1H10.2857V1.7H1.71429ZM1.71429 6.8V8.5H3.42857V6.8H1.71429ZM5.14286 6.8V8.5H6.85714V6.8H5.14286ZM8.57143 6.8V8.5H10.2857V6.8H8.57143ZM1.71429 10.2V11.9H3.42857V10.2H1.71429ZM5.14286 10.2V11.9H6.85714V10.2H5.14286ZM8.57143 10.2V11.9H10.2857V10.2H8.57143ZM1.71429 13.6V15.3H3.42857V13.6H1.71429ZM5.14286 13.6V15.3H6.85714V13.6H5.14286ZM8.57143 13.6V15.3H10.2857V13.6H8.57143Z" fill="#303030"/></svg> Conversão</p><strong><button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> %</strong></div>
            </div>`;
        //}

        /** PONTOS NEGATIVOS */

        var pontosNegativos = '';

        let estoque = '';
        try {
            estoque = document.getElementsByClassName("ui-pdp-buybox__quantity__available")[0].innerHTML;
            estoque = estoque.replace(/\D/g, "");
        } catch (error) {
            estoque = document.getElementsByClassName("ui-pdp-color--BLACK ui-pdp-size--MEDIUM ui-pdp-family--SEMIBOLD")[0].innerHTML;
            if (estoque == 'Último disponível!') estoque = 1;
        }
        let descricao = document.getElementsByClassName("ui-pdp-description__content")[0].innerHTML;

        descricao.replaceAll('<br>');


        rawItems.descricao = descricao;
        rawItems.estoque = parseInt(estoque);

        pontosNegativos = `<p><button style="width: 320px; background: var(--grey-thin); height: 12px; border-radius: 4px; border: none; "></button></p>`;
        pontosNegativos += `<p><button style="width: 320px; background: var(--grey-thin); height: 12px; border-radius: 4px; border: none; "></button></p>`;
        pontosNegativos += `<p><button style="width: 320px; background: var(--grey-thin); height: 12px; border-radius: 4px; border: none; "></button></p>`;

        /** FIM PONTOS NEGATIVOS */

        let faturamento = ` <center><p style="margin-top: 10px;" class="subtitleData"><strong>Faturamento</strong></p></center> 
        <p  class="subtitleData" ><button style="width: 320px; background: var(--grey-thin); height: 12px; border-radius: 4px; border: none; "></button></p>
        <p  class="subtitleData" ><button style="width: 320px; background: var(--grey-thin); height: 12px; border-radius: 4px; border: none; "></button></p>
        `;

        MeliAPI.scriptBase('https://ramcloud.com.br/dropproduto.js')

        conteudo.innerHTML = `

            <button type="button" class="fechaInfos"><svg width="10" height="10" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></button>
            <div class="headerProduto"><svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
            <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
            <defs>
            <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
            <stop offset="0.380208" stop-color="#F2A008"/>
            <stop offset="0.792994" stop-color="#F9D043"/>
            </linearGradient>
            <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
            <stop stop-color="#1B22B8"/>
            <stop offset="1" stop-color="#4D43FA"/>
            </linearGradient>
            </defs>
            </svg><h4 style="margin-right: auto; font-weight: 800; color: var(--grey);">Informações Avantpro</h4></div>
            <div style="margin-bottom: 20px;">
                <h3>Quer liberar todos os recursos?</h3>
                <a href="https://www.avantpro.com.br/" target="_blank"><button class="assineja">ASSINE JÁ O AVANTPRO!</button></a>
            </div>

            <div class="cardInfos" style="display: flex; align-items: center; justify-content: center; font-size: 13.5px !important; min-height: auto !important; border-color: var(--warning); width: fit-content; margin: 0 auto 12px auto; padding: 6px 12px 6px 12px;" >
                <div style="display: flex; color: var(--warning) !important;">
                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24"><path fill="currentColor" d="M9.5 10.5H12a1 1 0 0 0 0-2h-1V8a1 1 0 0 0-2 0v.55a2.5 2.5 0 0 0 .5 4.95h1a.5.5 0 0 1 0 1H8a1 1 0 0 0 0 2h1v.5a1 1 0 0 0 2 0v-.55a2.5 2.5 0 0 0-.5-4.95h-1a.5.5 0 0 1 0-1ZM21 12h-3V3a1 1 0 0 0-.5-.87a1 1 0 0 0-1 0l-3 1.72l-3-1.72a1 1 0 0 0-1 0l-3 1.72l-3-1.72a1 1 0 0 0-1 0A1 1 0 0 0 2 3v16a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3v-6a1 1 0 0 0-1-1ZM5 20a1 1 0 0 1-1-1V4.73l2 1.14a1.08 1.08 0 0 0 1 0l3-1.72l3 1.72a1.08 1.08 0 0 0 1 0l2-1.14V19a3 3 0 0 0 .18 1Zm15-1a1 1 0 0 1-2 0v-5h2Z"/></svg>
                <p class="tituloCard" style="color: var(--warning) !important; margin: 0 4px 0 4px;">Vendidos: </p>
                <button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button>
                </div>
            </div>

            <div class="linha-3" style="margin: 7px 0 7px 0; display: flex; align-items: center;">
                ${rawItems.TAXA ? `<p class="tituloCard" style="margin-right: 14px; font-size: 13.5px !important;"><strong><svg width="12" height="12" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.02 10.22L10.955 5.285L9.975 4.305L6.02 8.26L4.025 6.265L3.045 7.245L6.02 10.22ZM7 14C6.03167 14 5.12167 13.8161 4.27 13.4484C3.41833 13.0811 2.6775 12.5825 2.0475 11.9525C1.4175 11.3225 0.918867 10.5817 0.5516 9.73C0.183867 8.87833 0 7.96833 0 7C0 6.03167 0.183867 5.12167 0.5516 4.27C0.918867 3.41833 1.4175 2.6775 2.0475 2.0475C2.6775 1.4175 3.41833 0.918633 4.27 0.5509C5.12167 0.183633 6.03167 0 7 0C7.96833 0 8.87833 0.183633 9.73 0.5509C10.5817 0.918633 11.3225 1.4175 11.9525 2.0475C12.5825 2.6775 13.0811 3.41833 13.4484 4.27C13.8161 5.12167 14 6.03167 14 7C14 7.96833 13.8161 8.87833 13.4484 9.73C13.0811 10.5817 12.5825 11.3225 11.9525 11.9525C11.3225 12.5825 10.5817 13.0811 9.73 13.4484C8.87833 13.8161 7.96833 14 7 14ZM7 12.6C8.56333 12.6 9.8875 12.0575 10.9725 10.9725C12.0575 9.8875 12.6 8.56333 12.6 7C12.6 5.43667 12.0575 4.1125 10.9725 3.0275C9.8875 1.9425 8.56333 1.4 7 1.4C5.43667 1.4 4.1125 1.9425 3.0275 3.0275C1.9425 4.1125 1.4 5.43667 1.4 7C1.4 8.56333 1.9425 9.8875 3.0275 10.9725C4.1125 12.0575 5.43667 12.6 7 12.6Z" fill="#4F4F4F"/></svg> ${rawItems.TAXA.listing_type_name}</strong></p>` : '<p style="display: none;"> </p>'}
                ${document.getElementsByClassName("ui-pdp-container__top-wrapper mt-40").length > 0 ? '<p class="tituloCard" style="font-size: 13.5px !important; margin-right: 14px;"><svg width="12" height="12" viewBox="0 0 16 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.2973 5.2C0.579459 5.2 0 5.78067 0 6.5C0 7.21933 0.579459 7.8 1.2973 7.8C2.01514 7.8 2.59459 7.21933 2.59459 6.5C2.59459 5.78067 2.01514 5.2 1.2973 5.2ZM1.2973 0C0.579459 0 0 0.580667 0 1.3C0 2.01933 0.579459 2.6 1.2973 2.6C2.01514 2.6 2.59459 2.01933 2.59459 1.3C2.59459 0.580667 2.01514 0 1.2973 0ZM1.2973 10.4C0.579459 10.4 0 10.9893 0 11.7C0 12.4107 0.588108 13 1.2973 13C2.00649 13 2.59459 12.4107 2.59459 11.7C2.59459 10.9893 2.01514 10.4 1.2973 10.4ZM4.75676 12.5667H15.1351C15.6108 12.5667 16 12.1767 16 11.7C16 11.2233 15.6108 10.8333 15.1351 10.8333H4.75676C4.28108 10.8333 3.89189 11.2233 3.89189 11.7C3.89189 12.1767 4.28108 12.5667 4.75676 12.5667ZM4.75676 7.36667H15.1351C15.6108 7.36667 16 6.97667 16 6.5C16 6.02333 15.6108 5.63333 15.1351 5.63333H4.75676C4.28108 5.63333 3.89189 6.02333 3.89189 6.5C3.89189 6.97667 4.28108 7.36667 4.75676 7.36667ZM3.89189 1.3C3.89189 1.77667 4.28108 2.16667 4.75676 2.16667H15.1351C15.6108 2.16667 16 1.77667 16 1.3C16 0.823333 15.6108 0.433333 15.1351 0.433333H4.75676C4.28108 0.433333 3.89189 0.823333 3.89189 1.3Z" fill="#4F4F4F"/></svg> Item Catálogo</p>' : '<p style="display: none;"> </p>'}
                <div style="display: flex;">${rawItems.FRETE ? `<p class="tituloCard" style="font-size: 13.5px !important;">
                <svg width="13" height="12" viewBox="0 0 16 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.8 0C1.32261 0 0.864773 0.187091 0.527208 0.520114C0.189642 0.853138 0 1.30482 0 1.77578V11.2466C3.55766e-05 11.6889 0.167343 12.1152 0.469184 12.4422C0.771025 12.7691 1.18568 12.9732 1.632 13.0145C1.72413 13.5678 2.01232 14.0709 2.44527 14.4343C2.87822 14.7976 3.42782 14.9975 3.99621 14.9984C4.5646 14.9994 5.11488 14.8013 5.54907 14.4394C5.98326 14.0776 6.27318 13.5754 6.3672 13.0224H8.0328C8.12638 13.5751 8.4156 14.0771 8.84904 14.4392C9.28247 14.8013 9.83203 15 10.4 15C10.968 15 11.5175 14.8013 11.951 14.4392C12.3844 14.0771 12.6736 13.5751 12.7672 13.0224H14.2C14.4364 13.0224 14.6704 12.9765 14.8888 12.8872C15.1072 12.798 15.3056 12.6672 15.4728 12.5023C15.6399 12.3374 15.7725 12.1416 15.863 11.9262C15.9534 11.7107 16 11.4798 16 11.2466V6.97448C15.9999 6.71158 15.9406 6.45199 15.8264 6.21445L14.4672 3.38346C14.3214 3.07964 14.0911 2.8229 13.8032 2.64309C13.5153 2.46328 13.1816 2.36778 12.8408 2.36771H11.6V1.77578C11.6 1.30482 11.4104 0.853138 11.0728 0.520114C10.7352 0.187091 10.2774 0 9.8 0H1.8ZM12.664 11.8385C12.4726 11.3065 12.0954 10.8591 11.6 10.5766V7.49775H14.8V9.86545H13.8C13.6409 9.86545 13.4883 9.92782 13.3757 10.0388C13.2632 10.1498 13.2 10.3004 13.2 10.4574C13.2 10.6144 13.2632 10.7649 13.3757 10.8759C13.4883 10.9869 13.6409 11.0493 13.8 11.0493H14.8V11.2466C14.8 11.4036 14.7368 11.5542 14.6243 11.6652C14.5117 11.7762 14.3591 11.8385 14.2 11.8385H12.664ZM10.4 10.2601C9.90351 10.2599 9.41918 10.4117 9.01372 10.6943C8.60826 10.977 8.30161 11.3768 8.136 11.8385H6.264C6.09872 11.3768 5.79246 10.977 5.38736 10.6941C4.98227 10.4112 4.49825 10.2591 4.00193 10.2588C3.50561 10.2584 3.02138 10.4099 2.61588 10.6922C2.21038 10.9745 1.90354 11.3739 1.7376 11.8354C1.59007 11.8202 1.45348 11.7516 1.3542 11.6428C1.25492 11.5341 1.19999 11.393 1.2 11.2466V1.77578C1.2 1.61879 1.26321 1.46823 1.37574 1.35723C1.48826 1.24622 1.64087 1.18385 1.8 1.18385H9.8C9.95913 1.18385 10.1117 1.24622 10.2243 1.35723C10.3368 1.46823 10.4 1.61879 10.4 1.77578V10.2601ZM11.6 3.55156H12.84C12.9538 3.55139 13.0652 3.58313 13.1614 3.64307C13.2576 3.70302 13.3345 3.78871 13.3832 3.89015L14.5464 6.31389H11.6V3.55156ZM4 13.8116C3.68174 13.8116 3.37652 13.6869 3.15147 13.4649C2.92643 13.2429 2.8 12.9418 2.8 12.6278C2.8 12.3138 2.92643 12.0127 3.15147 11.7907C3.37652 11.5687 3.68174 11.4439 4 11.4439C4.31826 11.4439 4.62348 11.5687 4.84853 11.7907C5.07357 12.0127 5.2 12.3138 5.2 12.6278C5.2 12.9418 5.07357 13.2429 4.84853 13.4649C4.62348 13.6869 4.31826 13.8116 4 13.8116ZM11.6 12.6278C11.6 12.9418 11.4736 13.2429 11.2485 13.4649C11.0235 13.6869 10.7183 13.8116 10.4 13.8116C10.0817 13.8116 9.77652 13.6869 9.55147 13.4649C9.32643 13.2429 9.2 12.9418 9.2 12.6278C9.2 12.3138 9.32643 12.0127 9.55147 11.7907C9.77652 11.5687 10.0817 11.4439 10.4 11.4439C10.7183 11.4439 11.0235 11.5687 11.2485 11.7907C11.4736 12.0127 11.6 12.3138 11.6 12.6278Z" fill="#303030"/></svg> Frete: 
                <button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button>` : '<p style="display: none;"> </p>'}</div>
            </div>
            ${visitas}
            <div class="infoEscondida escondeInfo">
            <div class="linha-3">
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="13" viewBox="0 0 12 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6667 1.3H10V0H8.66667V1.3H3.33333V0H2V1.3H1.33333C0.593333 1.3 0.00666666 1.885 0.00666666 2.6L0 11.7C0 12.0448 0.140476 12.3754 0.390524 12.6192C0.640573 12.863 0.979711 13 1.33333 13H10.6667C11.4 13 12 12.415 12 11.7V2.6C12 1.885 11.4 1.3 10.6667 1.3ZM10.6667 11.7H1.33333V5.2H10.6667V11.7ZM4 7.8H2.66667V6.5H4V7.8ZM6.66667 7.8H5.33333V6.5H6.66667V7.8ZM9.33333 7.8H8V6.5H9.33333V7.8ZM4 10.4H2.66667V9.1H4V10.4ZM6.66667 10.4H5.33333V9.1H6.66667V10.4ZM9.33333 10.4H8V9.1H9.33333V10.4Z" fill="#303030"/></svg> Criado</p> <div class="linhaCard">há 
                <button style="width: 20px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> dia(s) </div> <div>
                <button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> </div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="12" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.22222 6.21111L9.02778 8.01667C9.16019 8.14907 9.22639 8.31759 9.22639 8.52222C9.22639 8.72685 9.16019 8.89537 9.02778 9.02778C8.89537 9.16019 8.72685 9.22639 8.52222 9.22639C8.31759 9.22639 8.14907 9.16019 8.01667 9.02778L5.99444 7.00556C5.92222 6.93333 5.86806 6.85196 5.83194 6.76144C5.79583 6.67141 5.77778 6.57824 5.77778 6.48194V3.61111C5.77778 3.40648 5.84711 3.23483 5.98578 3.09617C6.12396 2.95798 6.29537 2.88889 6.5 2.88889C6.70463 2.88889 6.87628 2.95798 7.01494 3.09617C7.15313 3.23483 7.22222 3.40648 7.22222 3.61111V6.21111ZM6.5 13C5.59722 13 4.75174 12.8286 3.96356 12.4858C3.17489 12.1425 2.48878 11.6788 1.90522 11.0948C1.32119 10.5112 0.857518 9.82511 0.514222 9.03644C0.171407 8.24826 0 7.40278 0 6.5C0 5.59722 0.171407 4.7515 0.514222 3.96283C0.857518 3.17465 1.32119 2.48854 1.90522 1.9045C2.48878 1.32094 3.17489 0.857518 3.96356 0.514222C4.75174 0.171407 5.59722 0 6.5 0C7.48704 0 8.42304 0.210648 9.308 0.631944C10.1925 1.05324 10.9417 1.64907 11.5556 2.41944V1.44444C11.5556 1.23981 11.6249 1.06817 11.7636 0.9295C11.9017 0.791315 12.0731 0.722222 12.2778 0.722222C12.4824 0.722222 12.6538 0.791315 12.792 0.9295C12.9307 1.06817 13 1.23981 13 1.44444V4.33333C13 4.53796 12.9307 4.70937 12.792 4.84756C12.6538 4.98622 12.4824 5.05556 12.2778 5.05556H9.38889C9.18426 5.05556 9.01285 4.98622 8.87467 4.84756C8.736 4.70937 8.66667 4.53796 8.66667 4.33333C8.66667 4.1287 8.736 3.95706 8.87467 3.81839C9.01285 3.6802 9.18426 3.61111 9.38889 3.61111H10.6528C10.1593 2.93704 9.55139 2.40741 8.82917 2.02222C8.10694 1.63704 7.33056 1.44444 6.5 1.44444C5.09167 1.44444 3.89711 1.93483 2.91633 2.91561C1.93507 3.89687 1.44444 5.09167 1.44444 6.5C1.44444 7.90833 1.93507 9.10289 2.91633 10.0837C3.89711 11.0649 5.09167 11.5556 6.5 11.5556C7.60741 11.5556 8.60961 11.2306 9.50661 10.5806C10.4031 9.93056 11.0079 9.07593 11.3208 8.01667C11.381 7.81204 11.4925 7.64039 11.6552 7.50172C11.8175 7.36354 12.0009 7.31852 12.2056 7.36667C12.4222 7.41481 12.5816 7.53518 12.6837 7.72778C12.7862 7.92037 12.8074 8.125 12.7472 8.34167C12.35 9.72593 11.5736 10.8483 10.4181 11.7087C9.2625 12.5696 7.95648 13 6.5 13Z" fill="#303030"/></svg> Atualizado</p> <div class="linhaCard"> há 
                <button style="width: 20px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> dia(s)</div> <div>
                <button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button></div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="12" viewBox="0 0 13 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.4549 7.15C9.94226 7.15 10.3711 6.8835 10.5921 6.4805L12.9184 2.262C12.9732 2.16348 13.0013 2.05236 13 1.93964C12.9986 1.82692 12.9678 1.7165 12.9107 1.61932C12.8536 1.52214 12.7721 1.44156 12.6743 1.38555C12.5765 1.32955 12.4658 1.30006 12.3531 1.3H2.73575L2.12491 0H0V1.3H1.29964L3.639 6.2335L2.76174 7.8195C2.28737 8.6905 2.9112 9.75 3.89893 9.75H11.6968V8.45H3.89893L4.61373 7.15H9.4549ZM3.35308 2.6H11.2484L9.4549 5.85H4.89315L3.35308 2.6ZM3.89893 10.4C3.18412 10.4 2.60578 10.985 2.60578 11.7C2.60578 12.415 3.18412 13 3.89893 13C4.61373 13 5.19857 12.415 5.19857 11.7C5.19857 10.985 4.61373 10.4 3.89893 10.4ZM10.3971 10.4C9.68233 10.4 9.10399 10.985 9.10399 11.7C9.10399 12.415 9.68233 13 10.3971 13C11.1119 13 11.6968 12.415 11.6968 11.7C11.6968 10.985 11.1119 10.4 10.3971 10.4Z" fill="#303030"/></svg>            
                    Vendas</p>
                    <div class="linhaCard">
                    <button style="width: 30px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button>/Mês<strong></div>
                    <div>
                    <button style="width: 25px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button>/Dia</strong></div>
                </div>
            </div>
            <div class="linha-3">
                <div class="cardInfos"><p class="tituloCard"><svg width="12" height="15" viewBox="0 0 14 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.28564 10.0357L9.21422 5.10718" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M4.69636 5.92861C4.92319 5.92861 5.10707 5.74472 5.10707 5.51789C5.10707 5.29106 4.92319 5.10718 4.69636 5.10718C4.46953 5.10718 4.28564 5.29106 4.28564 5.51789C4.28564 5.74472 4.46953 5.92861 4.69636 5.92861Z" fill="#303030" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M8.80354 10.0357C9.03037 10.0357 9.21425 9.85178 9.21425 9.62495C9.21425 9.39812 9.03037 9.21423 8.80354 9.21423C8.57671 9.21423 8.39282 9.39812 8.39282 9.62495C8.39282 9.85178 8.57671 10.0357 8.80354 10.0357Z" fill="#303030" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 15.7857V2.64286C1 2.20714 1.17309 1.78928 1.48118 1.48118C1.78928 1.17309 2.20714 1 2.64286 1H10.8571C11.2929 1 11.7107 1.17309 12.0188 1.48118C12.3269 1.78928 12.5 2.20714 12.5 2.64286V15.7857L10.0357 14.1429L8.39286 15.7857L6.75 14.1429L5.10714 15.7857L3.46429 14.1429L1 15.7857Z" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Imposto</p> <strong><div class="linhaCard">R$ 
                <button style="width: 25px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button></div><div>( 
                    <button style="width: 25px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> %)</strong></div></div>
                <div class="cardInfos"><p class="tituloCard"><svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.66726 6.77824V6.78546M2.56997 4.88457C2.2532 4.64111 2.00992 4.31481 1.867 3.94173C1.72409 3.56865 1.68711 3.16332 1.76015 2.77054C1.8332 2.37775 2.01342 2.01281 2.2809 1.71605C2.54839 1.41929 2.89271 1.20227 3.27583 1.08896C3.65894 0.975656 4.06592 0.970484 4.45179 1.07402C4.83766 1.17755 5.18739 1.38576 5.46233 1.67563C5.73726 1.9655 5.9267 2.32574 6.0097 2.71654C6.0927 3.10734 6.06603 3.51348 5.93264 3.89007" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.3896 1.72266V4.46927C11.2834 4.98647 11.964 5.80499 12.3093 6.77822H13.2778C13.4693 6.77822 13.653 6.85431 13.7885 6.98976C13.9239 7.1252 14 7.3089 14 7.50044V8.94489C14 9.13644 13.9239 9.32014 13.7885 9.45558C13.653 9.59102 13.4693 9.66711 13.2778 9.66711H12.3086C12.0659 10.3532 11.6535 10.9671 11.1111 11.4532V12.9171C11.1111 13.2044 10.997 13.48 10.7938 13.6832C10.5906 13.8863 10.3151 14.0005 10.0278 14.0005C9.74045 14.0005 9.4649 13.8863 9.26174 13.6832C9.05857 13.48 8.94444 13.2044 8.94444 12.9171V12.4961C8.70577 12.536 8.4642 12.5561 8.22221 12.556H5.33332C5.09133 12.5561 4.84976 12.536 4.61109 12.4961V12.9171C4.61109 13.2044 4.49696 13.48 4.29379 13.6832C4.09063 13.8863 3.81508 14.0005 3.52776 14.0005C3.24044 14.0005 2.96489 13.8863 2.76173 13.6832C2.55856 13.48 2.44442 13.2044 2.44442 12.9171V11.4727L2.44515 11.4532C1.79083 10.8682 1.32957 10.0983 1.12242 9.24541C0.915273 8.39252 0.971996 7.49683 1.28508 6.67688C1.59817 5.85694 2.15286 5.15139 2.87575 4.65362C3.59863 4.15586 4.45563 3.88933 5.33332 3.88933H7.13888L10.3889 1.72266H10.3896Z" stroke="#303030" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg> Recebe</p> <div class="linhaCard"><strong>R$ 
                <button style="width: 40px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button></div><div> 
                <button style="width: 30px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> %</div></div>
                <div class="cardInfos"><div style="margin-bottom: auto;"><p class="tituloCard"><svg width="17" height="14" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.5 1C1.36739 1 1.24022 1.05268 1.14645 1.14645C1.05268 1.24022 1 1.36739 1 1.5V12.5C1 12.6326 1.05268 12.7598 1.14645 12.8536C1.24022 12.9473 1.36739 13 1.5 13C1.63261 13 1.75979 12.9473 1.85355 12.8536C1.94732 12.7598 2 12.6326 2 12.5V1.5C2 1.36739 1.94732 1.24022 1.85355 1.14645C1.75979 1.05268 1.63261 1 1.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M3.5 1C3.36739 1 3.24022 1.05268 3.14645 1.14645C3.05268 1.24022 3 1.36739 3 1.5V10.5C3 10.6326 3.05268 10.7598 3.14645 10.8536C3.24022 10.9473 3.36739 11 3.5 11C3.63261 11 3.75979 10.9473 3.85355 10.8536C3.94732 10.7598 4 10.6326 4 10.5V1.5C4 1.36739 3.94732 1.24022 3.85355 1.14645C3.75979 1.05268 3.63261 1 3.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M5.5 1C5.36739 1 5.24022 1.05268 5.14645 1.14645C5.05268 1.24022 5 1.36739 5 1.5V10.5C5 10.6326 5.05268 10.7598 5.14645 10.8536C5.24022 10.9473 5.36739 11 5.5 11C5.63261 11 5.75979 10.9473 5.85355 10.8536C5.94732 10.7598 6 10.6326 6 10.5V1.5C6 1.36739 5.94732 1.24022 5.85355 1.14645C5.75979 1.05268 5.63261 1 5.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M7.5 1C7.36739 1 7.24021 1.05268 7.14645 1.14645C7.05268 1.24022 7 1.36739 7 1.5V10.5C7 10.6326 7.05268 10.7598 7.14645 10.8536C7.24021 10.9473 7.36739 11 7.5 11C7.63261 11 7.75979 10.9473 7.85355 10.8536C7.94732 10.7598 8 10.6326 8 10.5V1.5C8 1.36739 7.94732 1.24022 7.85355 1.14645C7.75979 1.05268 7.63261 1 7.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M9.5 1C9.36739 1 9.24021 1.05268 9.14645 1.14645C9.05268 1.24022 9 1.36739 9 1.5V10.5C9 10.6326 9.05268 10.7598 9.14645 10.8536C9.24021 10.9473 9.36739 11 9.5 11C9.63261 11 9.75979 10.9473 9.85355 10.8536C9.94732 10.7598 10 10.6326 10 10.5V1.5C10 1.36739 9.94732 1.24022 9.85355 1.14645C9.75979 1.05268 9.63261 1 9.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M11.5 1C11.3674 1 11.2402 1.05268 11.1464 1.14645C11.0527 1.24022 11 1.36739 11 1.5V10.5C11 10.6326 11.0527 10.7598 11.1464 10.8536C11.2402 10.9473 11.3674 11 11.5 11C11.6326 11 11.7598 10.9473 11.8536 10.8536C11.9473 10.7598 12 10.6326 12 10.5V1.5C12 1.36739 11.9473 1.24022 11.8536 1.14645C11.7598 1.05268 11.6326 1 11.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M13.5 1C13.3674 1 13.2402 1.05268 13.1464 1.14645C13.0527 1.24022 13 1.36739 13 1.5V10.5C13 10.6326 13.0527 10.7598 13.1464 10.8536C13.2402 10.9473 13.3674 11 13.5 11C13.6326 11 13.7598 10.9473 13.8536 10.8536C13.9473 10.7598 14 10.6326 14 10.5V1.5C14 1.36739 13.9473 1.24022 13.8536 1.14645C13.7598 1.05268 13.6326 1 13.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/><path d="M15.5 1C15.3674 1 15.2402 1.05268 15.1464 1.14645C15.0527 1.24022 15 1.36739 15 1.5V12.5C15 12.6326 15.0527 12.7598 15.1464 12.8536C15.2402 12.9473 15.3674 13 15.5 13C15.6326 13 15.7598 12.9473 15.8536 12.8536C15.9473 12.7598 16 12.6326 16 12.5V1.5C16 1.36739 15.9473 1.24022 15.8536 1.14645C15.7598 1.05268 15.6326 1 15.5 1Z" fill="#303030" stroke="#303030" stroke-width="0.5"/></svg> EAN(s)</p></div> <div style="padding: 7px 0 7px 0;"><strong> 
                <button style="width: 90px; background: var(--grey-thin); height: 30px; border-radius: 4px; border: none;"></button></strong> </div></div>
            </div>

            <div class="linha-2">
                <div class="cardInfos"><p class="tituloCard" ><svg width="10" height="13" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg> Recomendação</p> <div style="padding: 7px 0 7px 0;"><strong> Entre R$ 
                <button style="width: 45px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> e R$
                <button style="width: 45px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> </strong></div></div>
                <div class="cardInfos cardApendice"><p class="tituloCard" ><svg width="19" height="12" viewBox="0 0 22 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.7665 14C16.1604 14 20.5331 11.0899 20.5331 7.5C20.5331 3.91015 16.1604 1 10.7665 1C5.37262 1 1 3.91015 1 7.5C1 11.0899 5.37262 14 10.7665 14Z" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M3.60645 3.25781C4.61564 3.73866 5.69554 4.05421 6.80486 4.19239C7.57493 4.14055 8.33778 4.01084 9.08171 3.80524" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M18.2203 3.29999C17.4593 3.81737 16.5529 4.07797 15.6334 4.04375C13.9631 4.04375 12.5156 2.94238 11.0181 2.94238C9.68181 2.94238 7.41748 5.13259 7.41748 5.52876C7.41748 5.92493 8.07359 6.15983 8.60549 5.89939C8.91652 5.74763 10.2633 4.43992 11.3521 4.43992C12.441 4.43992 15.9695 8.01397 16.289 8.34953C16.7843 8.86941 15.8252 9.98931 15.2127 9.37627C14.6001 8.76323 13.5048 7.79259 13.5048 7.79259" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M20.483 6.84033C18.9841 7.017 17.5319 7.4744 16.2023 8.18861M15.0638 9.23088C15.5592 9.75026 14.6 10.8702 13.9875 10.2576C13.375 9.64508 12.6948 8.99898 12.6948 8.99898" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.8391 10.1121C14.3339 10.6314 13.3748 11.7513 12.7623 11.1388C12.1497 10.5263 11.748 10.1561 11.748 10.1561" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8672 11.1642C10.9822 11.2983 11.1265 11.4043 11.2888 11.474C11.4512 11.5437 11.6274 11.5752 11.8039 11.5663C11.9803 11.5573 12.1524 11.5079 12.3068 11.4221C12.4613 11.3363 12.594 11.2162 12.6948 11.071" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M10.8673 11.1642C11.1332 10.8151 11.1127 9.5705 9.74388 9.81792C10.0654 9.20739 9.77694 8.24225 8.54786 8.81122C8.52852 8.63359 8.45346 8.46663 8.33344 8.33427C8.21342 8.2019 8.05458 8.11091 7.87969 8.07433C7.70479 8.03775 7.5228 8.05745 7.35979 8.13062C7.19678 8.20379 7.0611 8.32667 6.97219 8.48166C6.94726 8.32244 6.87022 8.17599 6.75314 8.06525C6.63606 7.95451 6.48555 7.88574 6.32519 7.8697C6.16483 7.85367 6.00369 7.89128 5.86699 7.97664C5.7303 8.062 5.62579 8.1903 5.56982 8.34142C5.29736 8.89386 5.71807 9.89205 6.61759 9.3311C6.52644 10.3047 7.03831 10.6017 7.96187 10.2226C8.01145 11.1792 8.64653 11.0966 9.1003 10.8737C9.14448 11.06 9.24278 11.2291 9.38282 11.3596C9.52286 11.4902 9.69839 11.5764 9.88732 11.6075C10.0762 11.6385 10.2701 11.613 10.4446 11.5341C10.6191 11.4553 10.7663 11.3265 10.8678 11.1642H10.8673Z" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/><path d="M1.08496 6.63806C2.7146 6.76051 4.2819 7.31626 5.62464 8.24779" stroke="#303030" stroke-linecap="round" stroke-linejoin="round"/></svg> Comissão ML</p> <strong> <div class="linhaCard">R$ 
                <button style="width: 45px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button></div><div>( 
                    <button style="width: 45px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button> %)</div></strong>
                    <div><span><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="#3166FE" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="#3166FE"/></svg></span><center><div class="tooltiptext" style="color: white;">Informação disponível para assinantes Avantpro</div></center>
                    </div>
                </div>
            </div>

            <button type="button" class="btnFaturamento faturamentoGratis" style="position: relative;"><div style="display: flex; align-items: center;"><svg style="margin: 0 10px 0 auto;" width="14" height="12" viewBox="0 0 16 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M16 13.087C16 13.3291 15.9063 13.5613 15.7396 13.7326C15.573 13.9038 15.3469 14 15.1111 14H0.888889C0.653141 14 0.427049 13.9038 0.26035 13.7326C0.0936506 13.5613 0 13.3291 0 13.087V0.913043C0 0.670889 0.0936506 0.438653 0.26035 0.267424C0.427049 0.0961953 0.653141 0 0.888889 0C1.12464 0 1.35073 0.0961953 1.51743 0.267424C1.68413 0.438653 1.77778 0.670889 1.77778 0.913043V8.44565L5 5.13587C5.08258 5.05075 5.18071 4.98321 5.28875 4.93713C5.3968 4.89104 5.51264 4.86732 5.62963 4.86732C5.74662 4.86732 5.86246 4.89104 5.97051 4.93713C6.07855 4.98321 6.17668 5.05075 6.25926 5.13587L8 6.92391L11.7778 3.04348H10.963C10.7272 3.04348 10.5011 2.94728 10.3344 2.77605C10.1677 2.60483 10.0741 2.37259 10.0741 2.13043C10.0741 1.88828 10.1677 1.65604 10.3344 1.48482C10.5011 1.31359 10.7272 1.21739 10.963 1.21739H13.9259C14.1617 1.21739 14.3878 1.31359 14.5545 1.48482C14.7212 1.65604 14.8148 1.88828 14.8148 2.13043V5.17391C14.8148 5.41607 14.7212 5.6483 14.5545 5.81953C14.3878 5.99076 14.1617 6.08696 13.9259 6.08696C13.6902 6.08696 13.4641 5.99076 13.2974 5.81953C13.1307 5.6483 13.037 5.41607 13.037 5.17391V4.33696L8.62963 8.86413C8.54705 8.94925 8.44892 9.01679 8.34088 9.06287C8.23283 9.10895 8.11699 9.13268 8 9.13268C7.88301 9.13268 7.76717 9.10895 7.65912 9.06287C7.55108 9.01679 7.45295 8.94925 7.37037 8.86413L5.62963 7.07609L1.77778 11.0326V12.1739H15.1111C15.3469 12.1739 15.573 12.2701 15.7396 12.4413C15.9063 12.6126 16 12.8448 16 13.087Z" fill="currentColor"/></svg><p>Faturando: R$ 
            <div style="width: 80px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none; margin-right: auto; margin-left: 5px;"></div></p></div>
            <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro</div>      
            </button>

            <div style="margin: 20px 0 20px 0;">
                <p class="tituloCard"><svg style="margin-right: 10px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#303030"/></svg>Rankeamento</p>
                <div class="divRanking rankGratis"> 
                    <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>   
                    <input class="inputRanking" style="position: relative !important;" placeholder="Digite um termo para saber a posição do produto" type="text" disabled></input>
                    <button class="botaoRanking">
                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>        
                    </button>
                </div>
            </div>
            

            <button type="button" class="collapsible-negativos negativosGratis" style="position: relative;" disabled>
                <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro</div>
                <div style="display: flex; align-items: center; text-align: center;">
                    <svg style="margin-left: auto;" width="20" height="18" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M18 12V0H22V12H18ZM14 0C14.5304 0 15.0391 0.210714 15.4142 0.585786C15.7893 0.960859 16 1.46957 16 2V12C16 12.55 15.78 13.05 15.41 13.41L8.83 20L7.77 18.94C7.5 18.67 7.33 18.3 7.33 17.88L7.36 17.57L8.31 13H2C1.46957 13 0.960859 12.7893 0.585786 12.4142C0.210714 12.0391 0 11.5304 0 11V9C0 8.74 0.05 8.5 0.14 8.27L3.16 1.22C3.46 0.5 4.17 0 5 0H14ZM14 2H4.97L2 9V11H10.78L9.65 16.32L14 11.97V2Z" fill="#303030"/></svg>
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Pontos Negativos</p>
                    <svg class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                    
                </div>
            </button>
            </div>
            </div>
            <button class="btnMostrarInfos" id="btnMostrarInfos"><svg width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg></button>
        `;

        Titulo.appendChild(conteudo);
    }

    static VendedorGratis(rawItems) {

        MeliAPI.scriptBase('https://ramcloud.com.br/dropproduto.js')

        const InfoVendedor = document.getElementsByClassName('ui-box-component__title')[0]

        var BoxInfoVendedor = document.createElement('div');
        BoxInfoVendedor.className = 'vendas2';
        BoxInfoVendedor.id = 'BoxVenda1';

        /*Get information */
        var Categorias = []
        var Range = []
        var full = 0
        var has_video = 0
        var price_campaign_id = 0
        var gratis = 0
        var cont = 0

        for (let x = 0; x < rawItems.seller.available_filters.length; x++) {
            if (rawItems.seller.available_filters[x].id == "category") Categorias = rawItems.seller.available_filters[x].values;
            if (rawItems.seller.available_filters[x].id == "price") Range = rawItems.seller.available_filters[x].values;
            if (rawItems.seller.available_filters[x].id == "shipping") full = rawItems.seller.available_filters[x].values.length == 2 ? rawItems.seller.available_filters[x].values[1].results : 0;
            if (rawItems.seller.available_filters[x].id == "has_video") has_video = rawItems.seller.available_filters[x].values[0].results;
            if (rawItems.seller.available_filters[x].id == "price_campaign_id") price_campaign_id = rawItems.seller.available_filters[x].values.length
            if (rawItems.seller.available_filters[x].id == "shipping_cost") gratis = rawItems.seller.available_filters[x].values[0].results
        }

        if (document.getElementsByClassName('ui-pdp-container__col col-2 mr-32').length == 0) {

            var dataFormat = ("0" + rawItems.seller.Criacao.getDate().toString()).substr(-2) + '/' + ("0" + (rawItems.seller.Criacao.getMonth() + 1).toString()).substr(-2) + '/' + rawItems.seller.Criacao.getFullYear().toString().substr(-2);

            BoxInfoVendedor.innerHTML = `

            <p style="display: flex;justify-content: center;position: relative;top: -11px;"><svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
            <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
            <defs>
            <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
            <stop offset="0.380208" stop-color="#F2A008"/>
            <stop offset="0.792994" stop-color="#F9D043"/>
            </linearGradient>
            <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
            <stop stop-color="#1B22B8"/>
            <stop offset="1" stop-color="#4D43FA"/>
            </linearGradient>
            </defs>
            </svg><b style="font-size: 17px;padding-bottom: 2px;position: relative;top: 2px;margin-right: auto;">Informações Avantpro</b></p>
            <p style="margin-top: 12px;margin-bottom: 15px;"><b style="font-size: 16px;">Informações do vendedor</b></p>
            <p style="margin-top: 10px;margin-bottom: -2px;"><img style="width: 17px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA70lEQVR4nO3UQUrDQBSH8R8umqVdWrrWK+hJxEPYHsNuRPFAurR1ZfEAuinVlUUUXVYGJiCCdNJObCn54A8heeGbl8wbGjaUAn2M8BETrnvxWS10Mcb8j9zHmqwUC6Q/5Vk77ydIy5zmFN9VEA9zit8riENtNuYVs5aO37biH/fWtauLOKMpc9ySme4CeS0nV0krfsph3HAht/Fe9k4b/pUdHGGAGzzjK2aKa5zhMNauTAcXeKkwx2FR59hbRtjGFT6XOKfLhHcvsZsqPcDTCsLfecR+ivgho7TMOEU8rUE8SRGfYJZR+orjFHHDdvENyZP0ibBvoI8AAAAASUVORK5CYII="> <b style="vertical-align: text-top;font-size: 13px">Nome:</b> <a href="https://www.mercadolivre.com.br/perfil/${rawItems.sellerBase.nickname}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;font-size: 13px;position: relative;top: -3px;">${rawItems.sellerBase.nickname.length > 15 ? rawItems.sellerBase.nickname.substring(0, 15) + "..." : rawItems.sellerBase.nickname}</span></a></p>
            <div style="margin-top: 5px;margin-left: 3px;display: flex;width: 125%;"><div style="width: 45%;"><svg width="13" height="18" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 20C1.45 20 0.979333 19.8043 0.588 19.413C0.196 19.021 0 18.55 0 18V6C0 5.45 0.196 4.97933 0.588 4.588C0.979333 4.196 1.45 4 2 4H4C4 2.9 4.39167 1.95833 5.175 1.175C5.95833 0.391667 6.9 0 8 0C9.1 0 10.0417 0.391667 10.825 1.175C11.6083 1.95833 12 2.9 12 4H14C14.55 4 15.021 4.196 15.413 4.588C15.8043 4.97933 16 5.45 16 6V18C16 18.55 15.8043 19.021 15.413 19.413C15.021 19.8043 14.55 20 14 20H2ZM2 18H14V6H12V8C12 8.28333 11.9043 8.52067 11.713 8.712C11.521 8.904 11.2833 9 11 9C10.7167 9 10.4793 8.904 10.288 8.712C10.096 8.52067 10 8.28333 10 8V6H6V8C6 8.28333 5.90433 8.52067 5.713 8.712C5.521 8.904 5.28333 9 5 9C4.71667 9 4.47933 8.904 4.288 8.712C4.096 8.52067 4 8.28333 4 8V6H2V18ZM6 4H10C10 3.45 9.80433 2.97933 9.413 2.588C9.021 2.196 8.55 2 8 2C7.45 2 6.97933 2.196 6.588 2.588C6.196 2.97933 6 3.45 6 4ZM2 18V6V18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Vendas:</b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.seller.seller_reputation.transactions.total.toLocaleString('pt-BR')}</span> </div><div style="margin-top: 3px;"><svg width="14" height="16" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1375 1C2.5706 1 2.02692 1.22451 1.62606 1.62414C1.2252 2.02377 1 2.56578 1 3.13094V14.4959C1.00004 15.0266 1.19872 15.5382 1.55716 15.9306C1.91559 16.323 2.40799 16.5679 2.938 16.6174C3.0474 17.2814 3.38963 17.8851 3.90376 18.3211C4.41789 18.7571 5.07054 18.997 5.7455 18.9981C6.42046 18.9993 7.07392 18.7616 7.58952 18.3273C8.10512 17.8931 8.4494 17.2905 8.56105 16.6269H10.5389C10.6501 17.2901 10.9935 17.8925 11.5082 18.327C12.0229 18.7615 12.6755 19 13.35 19C14.0245 19 14.6771 18.7615 15.1918 18.327C15.7065 17.8925 16.0499 17.2901 16.161 16.6269H17.8625C18.1432 16.6269 18.4212 16.5718 18.6805 16.4647C18.9398 16.3576 19.1755 16.2006 19.3739 16.0027C19.5724 15.8049 19.7299 15.57 19.8373 15.3114C19.9447 15.0529 20 14.7758 20 14.4959V9.36938C19.9999 9.0539 19.9294 8.74239 19.7938 8.45734L18.1798 5.06015C18.0066 4.69556 17.7332 4.38748 17.3913 4.1717C17.0494 3.95593 16.6531 3.84134 16.2485 3.84125H14.775V3.13094C14.775 2.56578 14.5498 2.02377 14.1489 1.62414C13.7481 1.22451 13.2044 1 12.6375 1H3.1375ZM16.0385 15.2063C15.8112 14.5678 15.3633 14.031 14.775 13.6919V9.99729H18.575V12.8385H17.3875C17.1985 12.8385 17.0173 12.9134 16.8837 13.0466C16.7501 13.1798 16.675 13.3605 16.675 13.5489C16.675 13.7372 16.7501 13.9179 16.8837 14.0511C17.0173 14.1843 17.1985 14.2592 17.3875 14.2592H18.575V14.4959C18.575 14.6843 18.4999 14.865 18.3663 14.9982C18.2327 15.1314 18.0515 15.2063 17.8625 15.2063H16.0385ZM13.35 13.3121C12.7604 13.3119 12.1853 13.494 11.7038 13.8332C11.2223 14.1724 10.8582 14.6521 10.6615 15.2063H8.4385C8.24223 14.6522 7.87854 14.1724 7.39749 13.833C6.91644 13.4935 6.34167 13.311 5.75229 13.3106C5.16291 13.3101 4.58789 13.4918 4.10636 13.8306C3.62483 14.1694 3.26046 14.6487 3.0634 15.2025C2.88821 15.1842 2.72601 15.1019 2.60811 14.9714C2.49022 14.8409 2.42498 14.6715 2.425 14.4959V3.13094C2.425 2.94255 2.50007 2.76188 2.63369 2.62867C2.76731 2.49546 2.94853 2.42063 3.1375 2.42063H12.6375C12.8265 2.42063 13.0077 2.49546 13.1413 2.62867C13.2749 2.76188 13.35 2.94255 13.35 3.13094V13.3121ZM14.775 5.26188H16.2475C16.3826 5.26167 16.515 5.29975 16.6292 5.37169C16.7434 5.44363 16.8347 5.54645 16.8925 5.66817L18.2738 8.57667H14.775V5.26188ZM5.75 17.574C5.37207 17.574 5.00961 17.4243 4.74237 17.1579C4.47513 16.8915 4.325 16.5301 4.325 16.1533C4.325 15.7766 4.47513 15.4152 4.74237 15.1488C5.00961 14.8824 5.37207 14.7327 5.75 14.7327C6.12793 14.7327 6.49039 14.8824 6.75763 15.1488C7.02487 15.4152 7.175 15.7766 7.175 16.1533C7.175 16.5301 7.02487 16.8915 6.75763 17.1579C6.49039 17.4243 6.12793 17.574 5.75 17.574ZM14.775 16.1533C14.775 16.5301 14.6249 16.8915 14.3576 17.1579C14.0904 17.4243 13.7279 17.574 13.35 17.574C12.9721 17.574 12.6096 17.4243 12.3424 17.1579C12.0751 16.8915 11.925 16.5301 11.925 16.1533C11.925 15.7766 12.0751 15.4152 12.3424 15.1488C12.6096 14.8824 12.9721 14.7327 13.35 14.7327C13.7279 14.7327 14.0904 14.8824 14.3576 15.1488C14.6249 15.4152 14.775 15.7766 14.775 16.1533Z" fill="#303030" stroke="black" stroke-width="0.5"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Frete Grátis:</b> <span style="position: relative;top: -4px;font-size: 13px">${gratis.toLocaleString('pt-BR')}</span></div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 125%;"><div style="width: 46%;margin-top: 3px;"><svg width="15" height="14" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 9H13V7H4V9ZM4 6H13V4H4V6ZM2 16C1.45 16 0.979333 15.8043 0.588 15.413C0.196 15.021 0 14.55 0 14V2C0 1.45 0.196 0.979333 0.588 0.588C0.979333 0.196 1.45 0 2 0H18C18.55 0 19.021 0.196 19.413 0.588C19.8043 0.979333 20 1.45 20 2V14C20 14.55 19.8043 15.021 19.413 15.413C19.021 15.8043 18.55 16 18 16H2ZM2 14H18V2H2V14ZM2 14V2V14Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Anúncios:</b> <a href="http://lista.mercadolivre.com.br/_CustId_${rawItems.seller_id}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;position: relative;top: -3px;font-size: 13px">${rawItems.seller.paging.total.toLocaleString('pt-BR')}</span></a> </div><div><svg width="12" height="19" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6859 0.211277L0.325939 9.49128C-0.314061 10.0713 0.0459388 11.1413 0.905939 11.2213L8.99594 12.0013L4.14594 18.7613C3.92594 19.0713 3.95594 19.5013 4.22594 19.7713C4.52594 20.0713 4.99594 20.0813 5.30594 19.7913L15.6659 10.5113C16.3059 9.93128 15.9459 8.86128 15.0859 8.78128L6.99594 8.00128L11.8459 1.24128C12.0659 0.931277 12.0359 0.501277 11.7659 0.231277C11.6246 0.0868922 11.4321 0.00387373 11.23 0.000132156C11.028 -0.00360942 10.8326 0.0722258 10.6859 0.211277Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">FULL:</b> <span style="position: relative;top: -4px;font-size: 13px">${full.toLocaleString('pt-BR')}</span> </div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 125%;"><div style="width: 47%;"><svg width="14" height="15" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Videos:</b> <span style="position: relative;top: -3px;font-size: 13px">${has_video.toLocaleString('pt-BR')}</span> </div><div><svg width="9" height="17" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Campanhas pagas:</b> <span style="position: relative;top: -4px;font-size: 13px">${price_campaign_id}</span></div></div>
            <p style="margin-top: 5px;margin-left: 5px;"><svg width="11" height="15" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8.075C5.43168 8.075 4.88663 7.85112 4.48477 7.4526C4.08291 7.05409 3.85714 6.51359 3.85714 5.95C3.85714 5.38642 4.08291 4.84591 4.48477 4.4474C4.88663 4.04888 5.43168 3.825 6 3.825C6.56832 3.825 7.11337 4.04888 7.51523 4.4474C7.91709 4.84591 8.14286 5.38642 8.14286 5.95C8.14286 6.22906 8.08743 6.50539 7.97974 6.7632C7.87205 7.02102 7.71421 7.25528 7.51523 7.4526C7.31625 7.64993 7.08002 7.80645 6.82004 7.91324C6.56005 8.02004 6.2814 8.075 6 8.075ZM6 0C4.4087 0 2.88258 0.626873 1.75736 1.74271C0.632141 2.85856 0 4.37196 0 5.95C0 10.4125 6 17 6 17C6 17 12 10.4125 12 5.95C12 4.37196 11.3679 2.85856 10.2426 1.74271C9.11742 0.626873 7.5913 0 6 0Z" fill="#303030"/></svg> <b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Localização: </b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.sellerBase.tags?.includes('international_seller') ? 'Vendedor Internacional' : (rawItems.sellerBase.address.city + ' / ' + rawItems.sellerBase.address.state.replace('BR-', ''))}</span></p>
            <p style="margin: 4px 0px 6px 3px;"><svg width="19" height="15" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.37413 8.585C8.7052 7.87387 9.17635 7.23347 9.76067 6.70037C10.345 6.16726 11.031 5.7519 11.7796 5.478C12.5282 5.2041 13.3246 5.07703 14.1234 5.10406C14.9222 5.13108 15.7078 5.31167 16.4352 5.6355C17.1627 5.95911 17.8179 6.41965 18.3633 6.9908C18.9087 7.56196 19.3336 8.23254 19.6138 8.96425C19.894 9.69596 20.024 10.4745 19.9964 11.2553C19.9687 12.0361 19.784 12.804 19.4527 13.515C18.9705 14.5554 18.1914 15.4377 17.2088 16.0559C16.2262 16.6741 15.0819 17.0019 13.9134 17C11.5655 17 9.41763 15.674 8.40891 13.6H0V11.9C0.0521752 10.931 0.730453 10.1405 2.03483 9.503C3.33922 8.8655 4.97404 8.534 6.9567 8.5C7.45236 8.5 7.92194 8.5425 8.37413 8.585ZM6.9567 0C7.93064 0.0255 8.74805 0.357 9.40024 0.9945C10.0524 1.632 10.3742 2.431 10.3742 3.4C10.3742 4.369 10.0524 5.168 9.40024 5.8055C8.74805 6.443 7.93064 6.7575 6.9567 6.7575C5.98276 6.7575 5.16535 6.443 4.51316 5.8055C3.86097 5.168 3.53922 4.369 3.53922 3.4C3.53922 2.431 3.86097 1.632 4.51316 0.9945C5.16535 0.357 5.98276 0.0255 6.9567 0ZM13.9134 15.3C15.0665 15.3 16.1725 14.8522 16.9879 14.0552C17.8033 13.2582 18.2613 12.1772 18.2613 11.05C18.2613 9.92282 17.8033 8.84182 16.9879 8.04479C16.1725 7.24776 15.0665 6.8 13.9134 6.8C12.7603 6.8 11.6543 7.24776 10.8389 8.04479C10.0235 8.84182 9.56546 9.92282 9.56546 11.05C9.56546 12.1772 10.0235 13.2582 10.8389 14.0552C11.6543 14.8522 12.7603 15.3 13.9134 15.3ZM13.0438 8.5H14.3482V10.897L16.47 12.0955L15.8178 13.2005L13.0438 11.6365V8.5Z" fill="#303030"/></svg><b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Criação da conta:</b>
            <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.CriacaoDays === NaN ? 'Não informada' : `${dataFormat}  |  há  ${rawItems.seller.CriacaoDays.toLocaleString('pt-BR')} dias`}</span>
            
            `

            InfoVendedor.insertAdjacentElement('beforebegin', BoxInfoVendedor)

            var BoxInfoVendedor2 = document.createElement('div');
            BoxInfoVendedor2.className = 'vendas2';
            BoxInfoVendedor2.id = 'BoxVenda2';

            let dadosp = '';

            dadosp = `
            <button type="button" id="dropCategoria" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="margin-right: 5px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA8ElEQVR4nO3UsUrDUBjF8R8inXWpk4tLF8Whi1NBdOnSzaWvonRT9Bm66hIUuguCi1AQ9DW6dqxD5cpHCXITMwmFHjhw75dz/iHhJqyL9jHAKbo4QKsm34pMNzqDYKz0gOUvL/CJMc7D45gtMvn7MvAJE+yhgxMMcYdpqTSN2TAynehMgvGjI3yhqHnEx3CVimAcps1F3L0OWDS4vgzWBpjX5h02Ozav6OEY7QbnsB3ZXnRXwH7mu0ye4wUjvIVHMZtXdPoJuI1bPOMDs4pwzrPopG5iJFZWOzjDNd5LgLS+iT/PblX5L23hCpex/l99A1DwdkWrfsugAAAAAElFTkSuQmCC">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Categorias que o vendedor atua</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria">
            `
            cont = 0;
            Categorias.sort(function (a, b) {
                if (a.name < b.name) {
                    return -1;
                } else {
                    return true;
                }
            });
            if (Categorias.length > 0) {
                Categorias.forEach(element => {
                    cont++;
                    dadosp = dadosp + ` <p style="border: 2px solid #f0f0f0;border-radius: 16px;text-align: center;font-size: 12px;padding: 5px 15px;font-weight: bold;margin-right: 4px;" >${element.name}</p>`;
                });
            }
            else {
                dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
            }

            dadosp = dadosp + `
                    </div>
                </div>
            </div> 
            <button type="button" id="dropCategoria1" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px; margin-bottom: 10px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="width: 20px;position: relative;top: 2px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAqklEQVR4nO2SOw4CMQxE3yV2xQW4KSxHgFshsQXn4FOQKiiSi7B8dpykoNiR3DjWPNsxLKrUCMQsjj9qB+AObD2AwwSQ4puCvT88gBVwEQFKzYv6bEXX1oDcfLRJ9jN/IAM64GSFZzNXJAG6See9aC4DdoXmMmBt95wmwXnz7ivCefNNAfGD2f8CBnHfxYAg7lsC1HQbFUBNt7EUECpyb0qruQGbRrlFzOoJTXuISVuPFksAAAAASUVORK5CYII=">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Quantidade de Anúncios por Preço</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria1">
            `;

            if (Range.length > 0) {

                Range.forEach(element => {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">${element.name.replace('Up to', 'Até ').replace('to', 'a').replace('More than', 'Mais de')}  :  <span style="font-weight: 100;">${element.results}<span> </p>`;
                });

            } else {
                dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
            }

            BoxInfoVendedor2.innerHTML = dadosp + `
                    </div>
                </div>     
                <br>
            `;


            document.getElementById('BoxVenda1').insertAdjacentElement('afterend', BoxInfoVendedor2)
        } else {

            var dataFormat = ("0" + rawItems.seller.Criacao.getDate().toString()).substr(-2) + '/' + ("0" + (rawItems.seller.Criacao.getMonth() + 1).toString()).substr(-2) + '/' + rawItems.seller.Criacao.getFullYear().toString().substr(-2);

            BoxInfoVendedor.innerHTML = `

            <p style="display: flex;justify-content: center;position: relative;top: -11px;"><svg width="25" height="30" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
            <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
            <defs>
            <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
            <stop offset="0.380208" stop-color="#F2A008"/>
            <stop offset="0.792994" stop-color="#F9D043"/>
            </linearGradient>
            <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
            <stop stop-color="#1B22B8"/>
            <stop offset="1" stop-color="#4D43FA"/>
            </linearGradient>
            </defs>
            </svg><b style="font-size: 17px;padding-bottom: 2px;position: relative;top: 2px;margin-right: auto;">Informações Avantpro</b></p>
            <p style="margin-top: 12px;margin-bottom: 15px;"><b style="font-size: 16px;">Informações do vendedor</b></p>
            <p style="margin-top: 10px;margin-bottom: -2px;"><img style="width: 17px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA70lEQVR4nO3UQUrDQBSH8R8umqVdWrrWK+hJxEPYHsNuRPFAurR1ZfEAuinVlUUUXVYGJiCCdNJObCn54A8heeGbl8wbGjaUAn2M8BETrnvxWS10Mcb8j9zHmqwUC6Q/5Vk77ydIy5zmFN9VEA9zit8riENtNuYVs5aO37biH/fWtauLOKMpc9ySme4CeS0nV0krfsph3HAht/Fe9k4b/pUdHGGAGzzjK2aKa5zhMNauTAcXeKkwx2FR59hbRtjGFT6XOKfLhHcvsZsqPcDTCsLfecR+ivgho7TMOEU8rUE8SRGfYJZR+orjFHHDdvENyZP0ibBvoI8AAAAASUVORK5CYII="> <b style="vertical-align: text-top;font-size: 13px">Nome:</b> <a href="https://www.mercadolivre.com.br/perfil/${rawItems.sellerBase.nickname}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;font-size: 13px;position: relative;top: -3px;">${rawItems.sellerBase.nickname.length > 15 ? rawItems.sellerBase.nickname.substring(0, 15) + "..." : rawItems.sellerBase.nickname}</span></a></p>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 50%;"><svg width="13" height="18" viewBox="0 0 16 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 20C1.45 20 0.979333 19.8043 0.588 19.413C0.196 19.021 0 18.55 0 18V6C0 5.45 0.196 4.97933 0.588 4.588C0.979333 4.196 1.45 4 2 4H4C4 2.9 4.39167 1.95833 5.175 1.175C5.95833 0.391667 6.9 0 8 0C9.1 0 10.0417 0.391667 10.825 1.175C11.6083 1.95833 12 2.9 12 4H14C14.55 4 15.021 4.196 15.413 4.588C15.8043 4.97933 16 5.45 16 6V18C16 18.55 15.8043 19.021 15.413 19.413C15.021 19.8043 14.55 20 14 20H2ZM2 18H14V6H12V8C12 8.28333 11.9043 8.52067 11.713 8.712C11.521 8.904 11.2833 9 11 9C10.7167 9 10.4793 8.904 10.288 8.712C10.096 8.52067 10 8.28333 10 8V6H6V8C6 8.28333 5.90433 8.52067 5.713 8.712C5.521 8.904 5.28333 9 5 9C4.71667 9 4.47933 8.904 4.288 8.712C4.096 8.52067 4 8.28333 4 8V6H2V18ZM6 4H10C10 3.45 9.80433 2.97933 9.413 2.588C9.021 2.196 8.55 2 8 2C7.45 2 6.97933 2.196 6.588 2.588C6.196 2.97933 6 3.45 6 4ZM2 18V6V18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Vendas:</b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.seller.seller_reputation.transactions.total.toLocaleString('pt-BR')}</span> </div><div style="margin-top: 3px;"><svg width="14" height="16" viewBox="0 0 21 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1375 1C2.5706 1 2.02692 1.22451 1.62606 1.62414C1.2252 2.02377 1 2.56578 1 3.13094V14.4959C1.00004 15.0266 1.19872 15.5382 1.55716 15.9306C1.91559 16.323 2.40799 16.5679 2.938 16.6174C3.0474 17.2814 3.38963 17.8851 3.90376 18.3211C4.41789 18.7571 5.07054 18.997 5.7455 18.9981C6.42046 18.9993 7.07392 18.7616 7.58952 18.3273C8.10512 17.8931 8.4494 17.2905 8.56105 16.6269H10.5389C10.6501 17.2901 10.9935 17.8925 11.5082 18.327C12.0229 18.7615 12.6755 19 13.35 19C14.0245 19 14.6771 18.7615 15.1918 18.327C15.7065 17.8925 16.0499 17.2901 16.161 16.6269H17.8625C18.1432 16.6269 18.4212 16.5718 18.6805 16.4647C18.9398 16.3576 19.1755 16.2006 19.3739 16.0027C19.5724 15.8049 19.7299 15.57 19.8373 15.3114C19.9447 15.0529 20 14.7758 20 14.4959V9.36938C19.9999 9.0539 19.9294 8.74239 19.7938 8.45734L18.1798 5.06015C18.0066 4.69556 17.7332 4.38748 17.3913 4.1717C17.0494 3.95593 16.6531 3.84134 16.2485 3.84125H14.775V3.13094C14.775 2.56578 14.5498 2.02377 14.1489 1.62414C13.7481 1.22451 13.2044 1 12.6375 1H3.1375ZM16.0385 15.2063C15.8112 14.5678 15.3633 14.031 14.775 13.6919V9.99729H18.575V12.8385H17.3875C17.1985 12.8385 17.0173 12.9134 16.8837 13.0466C16.7501 13.1798 16.675 13.3605 16.675 13.5489C16.675 13.7372 16.7501 13.9179 16.8837 14.0511C17.0173 14.1843 17.1985 14.2592 17.3875 14.2592H18.575V14.4959C18.575 14.6843 18.4999 14.865 18.3663 14.9982C18.2327 15.1314 18.0515 15.2063 17.8625 15.2063H16.0385ZM13.35 13.3121C12.7604 13.3119 12.1853 13.494 11.7038 13.8332C11.2223 14.1724 10.8582 14.6521 10.6615 15.2063H8.4385C8.24223 14.6522 7.87854 14.1724 7.39749 13.833C6.91644 13.4935 6.34167 13.311 5.75229 13.3106C5.16291 13.3101 4.58789 13.4918 4.10636 13.8306C3.62483 14.1694 3.26046 14.6487 3.0634 15.2025C2.88821 15.1842 2.72601 15.1019 2.60811 14.9714C2.49022 14.8409 2.42498 14.6715 2.425 14.4959V3.13094C2.425 2.94255 2.50007 2.76188 2.63369 2.62867C2.76731 2.49546 2.94853 2.42063 3.1375 2.42063H12.6375C12.8265 2.42063 13.0077 2.49546 13.1413 2.62867C13.2749 2.76188 13.35 2.94255 13.35 3.13094V13.3121ZM14.775 5.26188H16.2475C16.3826 5.26167 16.515 5.29975 16.6292 5.37169C16.7434 5.44363 16.8347 5.54645 16.8925 5.66817L18.2738 8.57667H14.775V5.26188ZM5.75 17.574C5.37207 17.574 5.00961 17.4243 4.74237 17.1579C4.47513 16.8915 4.325 16.5301 4.325 16.1533C4.325 15.7766 4.47513 15.4152 4.74237 15.1488C5.00961 14.8824 5.37207 14.7327 5.75 14.7327C6.12793 14.7327 6.49039 14.8824 6.75763 15.1488C7.02487 15.4152 7.175 15.7766 7.175 16.1533C7.175 16.5301 7.02487 16.8915 6.75763 17.1579C6.49039 17.4243 6.12793 17.574 5.75 17.574ZM14.775 16.1533C14.775 16.5301 14.6249 16.8915 14.3576 17.1579C14.0904 17.4243 13.7279 17.574 13.35 17.574C12.9721 17.574 12.6096 17.4243 12.3424 17.1579C12.0751 16.8915 11.925 16.5301 11.925 16.1533C11.925 15.7766 12.0751 15.4152 12.3424 15.1488C12.6096 14.8824 12.9721 14.7327 13.35 14.7327C13.7279 14.7327 14.0904 14.8824 14.3576 15.1488C14.6249 15.4152 14.775 15.7766 14.775 16.1533Z" fill="#303030" stroke="black" stroke-width="0.5"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Frete Grátis:</b> <span style="position: relative;top: -4px;font-size: 13px">${gratis.toLocaleString('pt-BR')}</span></div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 50%;"><svg width="15" height="14" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 9H13V7H4V9ZM4 6H13V4H4V6ZM2 16C1.45 16 0.979333 15.8043 0.588 15.413C0.196 15.021 0 14.55 0 14V2C0 1.45 0.196 0.979333 0.588 0.588C0.979333 0.196 1.45 0 2 0H18C18.55 0 19.021 0.196 19.413 0.588C19.8043 0.979333 20 1.45 20 2V14C20 14.55 19.8043 15.021 19.413 15.413C19.021 15.8043 18.55 16 18 16H2ZM2 14H18V2H2V14ZM2 14V2V14Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Anúncios:</b> <a href="http://lista.mercadolivre.com.br/_CustId_${rawItems.seller_id}" target="_blank"><span style="color: rgb(72 145 253);font-weight: 400;text-decoration: underline;position: relative;top: -3px;font-size: 13px">${rawItems.seller.paging.total.toLocaleString('pt-BR')}</span></a> </div><div><svg width="12" height="19" viewBox="0 0 16 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6859 0.211277L0.325939 9.49128C-0.314061 10.0713 0.0459388 11.1413 0.905939 11.2213L8.99594 12.0013L4.14594 18.7613C3.92594 19.0713 3.95594 19.5013 4.22594 19.7713C4.52594 20.0713 4.99594 20.0813 5.30594 19.7913L15.6659 10.5113C16.3059 9.93128 15.9459 8.86128 15.0859 8.78128L6.99594 8.00128L11.8459 1.24128C12.0659 0.931277 12.0359 0.501277 11.7659 0.231277C11.6246 0.0868922 11.4321 0.00387373 11.23 0.000132156C11.028 -0.00360942 10.8326 0.0722258 10.6859 0.211277Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">FULL:</b> <span style="position: relative;top: -4px;font-size: 13px">${full.toLocaleString('pt-BR')}</span> </div></div>
            <div style="margin-top: 2px;margin-left: 3px;display: flex;width: 110%;"><div style="width: 43%;"><svg width="14" height="15" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -3px;font-size: 13px">Videos:</b> <span style="position: relative;top: -3px;font-size: 13px">${has_video.toLocaleString('pt-BR')}</span> </div><div><svg width="9" height="17" viewBox="0 0 10 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.44087 18C4.15754 18 3.91988 17.904 3.72788 17.712C3.53654 17.5207 3.44087 17.2833 3.44087 17V15.85C2.69087 15.6833 2.03254 15.3917 1.46588 14.975C0.899209 14.5583 0.440875 13.975 0.0908754 13.225C-0.0257913 12.9917 -0.0301246 12.746 0.0778754 12.488C0.186542 12.2293 0.382542 12.0417 0.665875 11.925C0.899209 11.825 1.14088 11.8293 1.39088 11.938C1.64088 12.046 1.83254 12.225 1.96588 12.475C2.24921 12.975 2.60754 13.3543 3.04088 13.613C3.47421 13.871 4.00754 14 4.64088 14C5.32421 14 5.90354 13.846 6.37888 13.538C6.85354 13.2293 7.09088 12.75 7.09088 12.1C7.09088 11.5167 6.90754 11.054 6.54087 10.712C6.17421 10.3707 5.32421 9.98333 3.99088 9.55C2.55754 9.1 1.57421 8.56267 1.04088 7.938C0.507542 7.31267 0.240875 6.55 0.240875 5.65C0.240875 4.56667 0.590875 3.725 1.29088 3.125C1.99088 2.525 2.70754 2.18333 3.44087 2.1V1C3.44087 0.716667 3.53654 0.479 3.72788 0.287C3.91988 0.0956666 4.15754 0 4.44087 0C4.72421 0 4.96187 0.0956666 5.15387 0.287C5.34521 0.479 5.44087 0.716667 5.44087 1V2.1C6.07421 2.2 6.62421 2.40433 7.09088 2.713C7.55754 3.021 7.94088 3.4 8.24088 3.85C8.39087 4.06667 8.42021 4.30833 8.32888 4.575C8.23688 4.84167 8.04921 5.03333 7.76588 5.15C7.53254 5.25 7.29087 5.254 7.04087 5.162C6.79087 5.07067 6.55754 4.90833 6.34088 4.675C6.12421 4.44167 5.87021 4.26233 5.57888 4.137C5.28688 4.01233 4.92421 3.95 4.49087 3.95C3.75754 3.95 3.19921 4.11267 2.81587 4.438C2.43254 4.76267 2.24088 5.16667 2.24088 5.65C2.24088 6.2 2.49088 6.63333 2.99088 6.95C3.49088 7.26667 4.35754 7.6 5.59088 7.95C6.74088 8.28333 7.61188 8.81233 8.20388 9.537C8.79521 10.2623 9.09087 11.1 9.09087 12.05C9.09087 13.2333 8.74088 14.1333 8.04088 14.75C7.34088 15.3667 6.47421 15.75 5.44087 15.9V17C5.44087 17.2833 5.34521 17.5207 5.15387 17.712C4.96187 17.904 4.72421 18 4.44087 18Z" fill="#303030"/></svg><b style="margin-left: 6px;position: relative;top: -4px;font-size: 13px">Campanhas pagas:</b> <span style="position: relative;top: -4px;font-size: 13px">${price_campaign_id}</span></div></div>
            <p style="margin-top: 5px;margin-left: 5px;"><svg width="11" height="15" viewBox="0 0 12 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8.075C5.43168 8.075 4.88663 7.85112 4.48477 7.4526C4.08291 7.05409 3.85714 6.51359 3.85714 5.95C3.85714 5.38642 4.08291 4.84591 4.48477 4.4474C4.88663 4.04888 5.43168 3.825 6 3.825C6.56832 3.825 7.11337 4.04888 7.51523 4.4474C7.91709 4.84591 8.14286 5.38642 8.14286 5.95C8.14286 6.22906 8.08743 6.50539 7.97974 6.7632C7.87205 7.02102 7.71421 7.25528 7.51523 7.4526C7.31625 7.64993 7.08002 7.80645 6.82004 7.91324C6.56005 8.02004 6.2814 8.075 6 8.075ZM6 0C4.4087 0 2.88258 0.626873 1.75736 1.74271C0.632141 2.85856 0 4.37196 0 5.95C0 10.4125 6 17 6 17C6 17 12 10.4125 12 5.95C12 4.37196 11.3679 2.85856 10.2426 1.74271C9.11742 0.626873 7.5913 0 6 0Z" fill="#303030"/></svg> <b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Localização: </b> <span style="position: relative;top: -3px;font-size: 13px">${rawItems.sellerBase.tags?.includes('international_seller') ? 'Vendedor Internacional' : (rawItems.sellerBase.address.city + ' / ' + rawItems.sellerBase.address.state.replace('BR-', ''))}</span></p>
            <p style="margin: 4px 0px 6px 3px;"><svg width="19" height="15" viewBox="0 0 20 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.37413 8.585C8.7052 7.87387 9.17635 7.23347 9.76067 6.70037C10.345 6.16726 11.031 5.7519 11.7796 5.478C12.5282 5.2041 13.3246 5.07703 14.1234 5.10406C14.9222 5.13108 15.7078 5.31167 16.4352 5.6355C17.1627 5.95911 17.8179 6.41965 18.3633 6.9908C18.9087 7.56196 19.3336 8.23254 19.6138 8.96425C19.894 9.69596 20.024 10.4745 19.9964 11.2553C19.9687 12.0361 19.784 12.804 19.4527 13.515C18.9705 14.5554 18.1914 15.4377 17.2088 16.0559C16.2262 16.6741 15.0819 17.0019 13.9134 17C11.5655 17 9.41763 15.674 8.40891 13.6H0V11.9C0.0521752 10.931 0.730453 10.1405 2.03483 9.503C3.33922 8.8655 4.97404 8.534 6.9567 8.5C7.45236 8.5 7.92194 8.5425 8.37413 8.585ZM6.9567 0C7.93064 0.0255 8.74805 0.357 9.40024 0.9945C10.0524 1.632 10.3742 2.431 10.3742 3.4C10.3742 4.369 10.0524 5.168 9.40024 5.8055C8.74805 6.443 7.93064 6.7575 6.9567 6.7575C5.98276 6.7575 5.16535 6.443 4.51316 5.8055C3.86097 5.168 3.53922 4.369 3.53922 3.4C3.53922 2.431 3.86097 1.632 4.51316 0.9945C5.16535 0.357 5.98276 0.0255 6.9567 0ZM13.9134 15.3C15.0665 15.3 16.1725 14.8522 16.9879 14.0552C17.8033 13.2582 18.2613 12.1772 18.2613 11.05C18.2613 9.92282 17.8033 8.84182 16.9879 8.04479C16.1725 7.24776 15.0665 6.8 13.9134 6.8C12.7603 6.8 11.6543 7.24776 10.8389 8.04479C10.0235 8.84182 9.56546 9.92282 9.56546 11.05C9.56546 12.1772 10.0235 13.2582 10.8389 14.0552C11.6543 14.8522 12.7603 15.3 13.9134 15.3ZM13.0438 8.5H14.3482V10.897L16.47 12.0955L15.8178 13.2005L13.0438 11.6365V8.5Z" fill="#303030"/></svg><b style="margin-left: 4px;position: relative;top: -3px;font-size: 13px">Criação da conta:</b>
            <span style="position: relative;top: -3px;font-size: 13px">${rawItems.seller.CriacaoDays === NaN ? 'Não informada' : `${dataFormat}  |  há  ${rawItems.seller.CriacaoDays.toLocaleString('pt-BR')} dias`}</span>
            `

            InfoVendedor.insertAdjacentElement('beforebegin', BoxInfoVendedor)

            var BoxInfoVendedor2 = document.createElement('div');
            BoxInfoVendedor2.className = 'vendas2';
            BoxInfoVendedor2.id = 'BoxVenda2';

            let dadosp = '';

            dadosp = `
            <button type="button" id="dropCategoria" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="margin-right: 5px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAACXBIWXMAAAsTAAALEwEAmpwYAAAA8ElEQVR4nO3UsUrDUBjF8R8inXWpk4tLF8Whi1NBdOnSzaWvonRT9Bm66hIUuguCi1AQ9DW6dqxD5cpHCXITMwmFHjhw75dz/iHhJqyL9jHAKbo4QKsm34pMNzqDYKz0gOUvL/CJMc7D45gtMvn7MvAJE+yhgxMMcYdpqTSN2TAynehMgvGjI3yhqHnEx3CVimAcps1F3L0OWDS4vgzWBpjX5h02Ozav6OEY7QbnsB3ZXnRXwH7mu0ye4wUjvIVHMZtXdPoJuI1bPOMDs4pwzrPopG5iJFZWOzjDNd5LgLS+iT/PblX5L23hCpex/l99A1DwdkWrfsugAAAAAElFTkSuQmCC">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Categorias que o vendedor atua</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria">
         `
            cont = 0;
            Categorias.sort(function (a, b) {
                if (a.name < b.name) {
                    return -1;
                } else {
                    return true;
                }
            });
            if (Categorias.length > 0) {
                Categorias.forEach(element => {
                    cont++;
                    dadosp = dadosp + ` <p style="border: 2px solid #f0f0f0;border-radius: 16px;text-align: center;font-size: 12px;padding: 5px 15px;font-weight: bold;margin-right: 4px;" >${element.name}</p>`;
                });
            }
            else {
                dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
            }


            dadosp = dadosp + `
                    </div>
                </div>
            </div> 
            <button type="button" id="dropCategoria1" class="collapsible-categoria" style="cursor: pointer;width: 108%;border: 1px solid #bbb7b7;border-radius: 13px;position: relative;right: 13px; margin-bottom: 10px;">
                <div style="display: flex; align-items: center; text-align: center;">
                    <img style="width: 20px;position: relative;top: 2px; margin-left: auto;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAAAqklEQVR4nO2SOw4CMQxE3yV2xQW4KSxHgFshsQXn4FOQKiiSi7B8dpykoNiR3DjWPNsxLKrUCMQsjj9qB+AObD2AwwSQ4puCvT88gBVwEQFKzYv6bEXX1oDcfLRJ9jN/IAM64GSFZzNXJAG6See9aC4DdoXmMmBt95wmwXnz7ivCefNNAfGD2f8CBnHfxYAg7lsC1HQbFUBNt7EUECpyb0qruQGbRrlFzOoJTXuISVuPFksAAAAASUVORK5CYII=">
                    <p class="tituloCard" style="margin: 0 auto 0 10px;">Quantidade de Anúncios por Preço</p>
                    <svg style="margin-left: auto;" class="seta" width="9" height="13" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78341 0.257257L8.77189 6.01979C8.85484 6.08839 8.91346 6.16271 8.94774 6.24274C8.98258 6.32278 9 6.40853 9 6.5C9 6.59147 8.98258 6.67722 8.94774 6.75726C8.91346 6.83729 8.85484 6.91161 8.77189 6.98021L1.78341 12.7599C1.58986 12.92 1.34793 13 1.0576 13C0.767282 13 0.518434 12.9142 0.31106 12.7427C0.103687 12.5712 0 12.3712 0 12.1425C0 11.9138 0.103687 11.7137 0.31106 11.5422L6.40783 6.5L0.31106 1.45778C0.117512 1.29771 0.0207376 1.1006 0.0207376 0.866439C0.0207376 0.631822 0.124424 0.428761 0.331798 0.257257C0.53917 0.0857525 0.781106 0 1.0576 0C1.3341 0 1.57604 0.0857525 1.78341 0.257257Z" fill="#303030"/></svg>
                </div>
            </button>

            <div class="vendas3" id="internoCategoria1">
            `;

            if (Range.length > 0) {

                Range.forEach(element => {
                    dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">${element.name.replace('Up to', 'Até ').replace('to', 'a').replace('More than', 'Mais de')}  :  <span style="font-weight: 100;">${element.results}<span> </p>`;
                });

            } else {
                dadosp = dadosp + `<p style="display: list-item;font-size: 15px;margin-left: 20px;font-weight: bold;">Nenhuma informação Retornada</p>`;
            }

            BoxInfoVendedor2.innerHTML = dadosp + `
                
                    </div>
                </div>     
                <br>
            `;

            document.getElementById('BoxVenda1').insertAdjacentElement('afterend', BoxInfoVendedor2)
        }
    }

    static BaixarGratis() {

        var linha = document.createElement('div'); /*Linha com botões rastrear, pesquisar e favoritos*/
        linha.className = "linhaSubtitleProduto";
        linha.innerHTML = `
            <div class="divBotoes">
                <button class="botaoTermosBuscados btnTermosGratis" disabled><svg width="20" height="20" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg></svg><div class="tooltiptext tooltipGratis">Recurso dsiponível para assinantes Avantpro</div></button>

            <div class="divBotoes">
                <button class="botaoRastrearNovodisabled btnRastrearGratis" style="display: flex;" disabled><svg width="15" height="20" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg><div class="tooltiptext tooltipGratis">Recurso dsiponível para assinantes Avantpro</div></button>
            </div>
            
        `;

        var botaoFavoritos = document.getElementsByClassName('ui-pdp-bookmark__link-bookmark')[1];
        botaoFavoritos.classList.add("botaoFavoritos");

        document.getElementsByClassName('ui-pdp-header__subtitle')[0].insertAdjacentElement('afterbegin', linha);
        linha.prepend(document.getElementsByClassName('ui-pdp-subtitle')[0]);
        document.getElementsByClassName('divBotoes')[0].appendChild(botaoFavoritos);

        var coluna = document.getElementsByClassName('ui-pdp-gallery')[0];
        var Botao = document.createElement('div');
        Botao.className = 'ui-btnBaixar'
        Botao.innerHTML = `
        <p style="color: red; font-size: 14px">* Fotos com borda vermelha não possuem a resolução mínima (1200x1200) 
        <small style="color: black; font-size: 12px">(Disponível para assinantes)</small>
        </p>  
        `;

        coluna.insertAdjacentElement('afterbegin', Botao);
    }

    /** FIM VERSAO GRATIS */
}