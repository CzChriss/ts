/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


class Render {
  static pesquisaPorAnuncioLoading(itemList) {
    // Para cada item
    // console.log('pesquisaPorAnuncioLoading');
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {
        let loading = document.createElement('div')
        loading.className = 'loading'
        loading.setAttribute("style", "margin-bottom: 10px;")

        loading.innerHTML =
          `<center><div class="loader"><svg width="37" height="50" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <defs>
          <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
          <stop offset="0.139315" stop-color="#271BEF"/>
          <stop offset="0.942129" stop-color="#00C2FF"/>
          </linearGradient>
          <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
          <stop offset="0.0921191" stop-color="#00C2FF"/>
          <stop offset="0.970863" stop-color="#271BEF"/>
          </linearGradient>
          </defs>
          </svg>
          <p>Carregando dados Avantpro...</p>
          </div>
          </center>`
        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(loading)
      }
    })
  }

  static botaoPalavrasChaves(itemList, ultra) {
    var Titulo = document.getElementsByClassName('ui-search-view-options__group')[0];

    /* Criando botao  */
    var TermosValue = document.createElement('div');
    TermosValue.className = 'subtitleData'
    TermosValue.innerHTML = `<button class="botaoPalavrasChaves" onclick="(function(){
     document.dispatchEvent(new CustomEvent('PalavrasChaves',{detail : { teste: '${itemList}' } } ));
     })()      
     "> Veja os termos mais usados nos títulos</button>`;
    Titulo.appendChild(TermosValue);

    let linkVendedor = false;
    try {
      var url_atual = document.URL;
      linkVendedor = url_atual.includes('CustId');
    } catch (error) {

    }



    if (ultra) {
      try {
        /** TESTE DISPLAY */


        chrome.storage.local.get(['displaypesquisa'], async function (response) {
          let StoregeDisplay = await response.displaypesquisa;

          StoregeDisplay == undefined ? StoregeDisplay = true : StoregeDisplay;

          var Cabecalho = document.getElementsByClassName('ui-search-view-options__container')[0];
          var Teste = document.createElement('div');
          Teste.className = 'switch-pesquisa'
          Teste.innerHTML = `
          <label class="switch"> 
            <input type="checkbox" id="display-pesquisa" ${StoregeDisplay ? "checked" : ""} >
            <span class="slider round"></span>
          </label>
          <label class="lbl-display-pesquisa">Desativar Dados Avantpro </label>`;

          Cabecalho.appendChild(Teste);

          if (StoregeDisplay) {
            let pesquisa = document.getElementsByClassName('medalha-vendedor');
            let altura = document.getElementsByClassName('ui-search-layout ui-search-layout--grid');
            document.getElementsByClassName('lbl-display-pesquisa')[0].innerText = "Desativar Dados Avantpro";
            for (let i = 0; i < pesquisa.length; i++) {
              pesquisa[i].style.display = 'block';
            }

            for (let i = 0; i < altura.length; i++) {
              altura[i].style.setProperty('--min-content-height', '295px');
              //altura[i].style.setProperty('--min-image-height', '400px !important');
            }
          } else {
            let pesquisa = document.getElementsByClassName('medalha-vendedor');
            let altura = document.getElementsByClassName('ui-search-layout ui-search-layout--grid');
            document.getElementsByClassName('lbl-display-pesquisa')[0].innerText = "Ativar Dados Avantpro   ";
            for (let i = 0; i < pesquisa.length; i++) {
              pesquisa[i].style.display = 'none';
            }

            for (let i = 0; i < altura.length; i++) {
              altura[i].style.setProperty('--min-content-height', '155px');
              //altura[i].style.setProperty('--min-image-height', '285px !important');
            }
          }

          $('#display-pesquisa').click(function () {
            const dp = document.querySelector('#display-pesquisa');
            if (dp.checked) {
              let pesquisa = document.getElementsByClassName('medalha-vendedor');
              let altura = document.getElementsByClassName('ui-search-layout ui-search-layout--grid');
              document.getElementsByClassName('lbl-display-pesquisa')[0].innerText = "Desativar Dados Avantpro";
              for (let i = 0; i < pesquisa.length; i++) {
                pesquisa[i].style.display = 'block';
              }

              for (let i = 0; i < altura.length; i++) {
                altura[i].style.setProperty('--min-content-height', '295px');
                //altura[i].style.setProperty('--min-image-height', '400px !important');
              }
            } else {
              let pesquisa = document.getElementsByClassName('medalha-vendedor');
              let altura = document.getElementsByClassName('ui-search-layout ui-search-layout--grid');
              document.getElementsByClassName('lbl-display-pesquisa')[0].innerText = "Ativar Dados Avantpro   ";
              for (let i = 0; i < pesquisa.length; i++) {
                pesquisa[i].style.display = 'none';
              }

              for (let i = 0; i < altura.length; i++) {
                altura[i].style.setProperty('--min-content-height', '155px');
                //altura[i].style.setProperty('--min-image-height', '285px !important');
              }
            }

            chrome.storage.local.set({ displaypesquisa: dp.checked }, function () { });

          });


        });


        /** TESTE DISPLAY */
      } catch (error) {

      }
    }

    if (ultra) {
      //Ordenar na primeira tela
      function VerificarDropDown() {
        var Lista = undefined;

        try {
          Lista = document.getElementsByClassName('andes-list andes-floating-menu andes-list--default andes-list--selectable')[0];
        } catch (error) {
          Lista = undefined;
        }

        if (Lista && !document.getElementById('IsRedyDropAvant')) {
          var IsRedySpawn = document.createElement('spawn');
          IsRedySpawn.id = 'IsRedyDropAvant';
          IsRedySpawn.style.display = 'none';
          Lista.appendChild(IsRedySpawn);

          Lista.insertAdjacentHTML('beforeend', `

            <li id="OrdenarMaisVendas" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Mais Venda</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarMenosVenda" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Menos Venda</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarMaisNovo" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Mais Novo</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarMaisAntigo" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Mais Antigo</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarMenorPreco" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Menor preço</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarMaiorPreco" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Maior preço</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarFull" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>FULL</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

            <li id="OrdenarCatalogo" class="andes-list__item andes-list__item--size-compact">
            <div class="andes-list__item-first-column">
            <div class="andes-list__item-text">
            <span class="andes-list__item-primary">
              <p>Catalogo</p> <svg width="20" height="20" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: auto;position: absolute;right: 5px;top: 5px;">
              <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"></path>
              <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"></path>
              <defs>
              <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
              <stop offset="0.380208" stop-color="#F2A008"></stop>
              <stop offset="0.792994" stop-color="#F9D043"></stop>
              </linearGradient>
              <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
              <stop stop-color="#1B22B8"></stop>
              <stop offset="1" stop-color="#4D43FA"></stop>
              </linearGradient>
              </defs>
              </svg>
            </span>
            </div>
            </div>
            </li>

          `);


          function MaiorVenda() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (bData.vendas - aData.vendas);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMaisVendas').onclick = () => {
            MaiorVenda();
            Selecao('OrdenarMaisVendas');
          }

          function MenorVenda() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (aData.vendas - bData.vendas);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMenosVenda').onclick = () => {
            MenorVenda();
            Selecao('OrdenarMenosVenda');
          }

          function MaisRecentes() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (aData.dias - bData.dias);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMaisNovo').onclick = () => {
            MaisRecentes();
            Selecao('OrdenarMaisNovo');
          }

          function MaisAntigo() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (bData.dias - aData.dias);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMaisAntigo').onclick = () => {
            MaisAntigo();
            Selecao('OrdenarMaisAntigo');
          }

          function MaiorPreco() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (bData.price - aData.price);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMaiorPreco').onclick = () => {
            MaiorPreco();
            Selecao('OrdenarMaiorPreco');
          }

          function MenorPreco() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              return (aData.price - bData.price);
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarMenorPreco').onclick = () => {
            MenorPreco();
            Selecao('OrdenarMenorPreco');
          }

          function OrdenarFull() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              if (bData.full && aData.full) {
                return 0;
              } else if (aData.full) {
                return -1;
              } else if (bData.full) {
                return 1;
              }
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarFull').onclick = () => {
            OrdenarFull();
            Selecao('OrdenarFull');
          }

          function OrdenarCatalogo() {
            var listaAnuncios = document.getElementsByClassName('ui-search-results')[0].getElementsByClassName('ui-search-layout__item');
            listaAnuncios = Array.prototype.slice.call(listaAnuncios);
            listaAnuncios.sort((a, b) => {
              var aData = a.getElementsByClassName('DadosProduto')[0].innerText;
              var bData = b.getElementsByClassName('DadosProduto')[0].innerText;
              aData = JSON.parse(aData);
              bData = JSON.parse(bData);
              if (bData.catalogo && aData.catalogo) {
                return 0;
              } else if (aData.catalogo) {
                return -1;
              } else if (bData.catalogo) {
                return 1;
              }
            });
            RenderAnuncios(listaAnuncios);
          }
          document.getElementById('OrdenarCatalogo').onclick = () => {
            OrdenarCatalogo();
            Selecao('OrdenarCatalogo');
          }

          function RenderAnuncios(listaAnuncios) {
            var itemsPorLinhas = undefined;

            try {
              itemsPorLinhas = document.getElementsByClassName('ui-search-layout ui-search-layout--grid')[0].getElementsByClassName('ui-search-layout__item').length;
            } catch (error) {
              itemsPorLinhas = undefined;
            }

            if (itemsPorLinhas) {
              let linha = 0;
              // For Para cada linha
              for (let index = 0; index < listaAnuncios.length; index = index + itemsPorLinhas) {
                for (let index2 = 0; index2 < itemsPorLinhas; index2++) {
                  const element = listaAnuncios[index + index2];
                  var parent = element.parentNode;
                  var detatchedItem = parent.removeChild(element);
                  document.getElementsByClassName('ui-search-layout ui-search-layout--grid')[linha].appendChild(detatchedItem);
                }
                linha = linha + 1;
              }
            } else {
              for (let index = 0; index < listaAnuncios.length; index++) {
                const element = listaAnuncios[index];
                var parent = element.parentNode;
                var detatchedItem = parent.removeChild(element);
                document.getElementsByClassName('ui-search-layout ui-search-layout--stack shops__layout')[0].appendChild(detatchedItem);
              }
            }

          }

          function Selecao(item) {
            var ListaDeLinhas = Lista.getElementsByClassName('andes-list__item--selected');
            for (let index = 0; index < ListaDeLinhas.length; index++) {
              const element = ListaDeLinhas[index];
              element.classList.remove('andes-list__item--selected');
            }
            document.getElementById(item).classList.add('andes-list__item--selected');
            document.getElementsByClassName('andes-dropdown__display-values')[0].innerHTML = document.getElementById(item).getElementsByTagName('p')[0].innerHTML
            document.getElementsByClassName('andes-dropdown__display-values')[0].click();
          }

          if (window.location.pathname.includes('PRICE*DESC')) { // Maior preco
            document.getElementById('andes-dropdown-maior-preço-list-option-price_desc').insertAdjacentHTML('afterend', `
                <li id="ReloadValueAvantPRO" class="andes-list__item andes-list__item--size-compact andes-list__item--selected">
                  <div class="andes-list__item-first-column">
                  <div class="andes-list__item-text">
                  <span class="andes-list__item-primary">
                    Maior preço
                  </span>
                  </div>
                  </div>
                </li>  
            `);
            document.getElementById('andes-dropdown-maior-preço-list-option-price_desc').remove();
          } else if (window.location.pathname.includes('PRICE')) { // Menor Proco
            document.getElementById('andes-dropdown-menor-preço-list-option-price_asc').insertAdjacentHTML('afterend', `
                <li id="ReloadValueAvantPRO" class="andes-list__item andes-list__item--size-compact andes-list__item--selected">
                  <div class="andes-list__item-first-column">
                  <div class="andes-list__item-text">
                  <span class="andes-list__item-primary">
                    Menor preço
                  </span>
                  </div>
                  </div>
                </li>  
            `);
            document.getElementById('andes-dropdown-menor-preço-list-option-price_asc').remove();
          } else { // Mais relevant 
            document.getElementById('andes-dropdown-mais-relevantes-list-option-relevance').insertAdjacentHTML('afterend', `
                <li id="ReloadValueAvantPRO" class="andes-list__item andes-list__item--size-compact andes-list__item--selected">
                  <div class="andes-list__item-first-column">
                  <div class="andes-list__item-text">
                  <span class="andes-list__item-primary">
                    Mais relevantes
                  </span>
                  </div>
                  </div>
                </li>  
            `);
            document.getElementById('andes-dropdown-mais-relevantes-list-option-relevance').remove();
          }

          document.getElementById('ReloadValueAvantPRO').onclick = (e) => {
            e.preventDefault();
            window.location.reload();
            window.location.reload();
          }
        }
      }
      var TimerverificarDropDown = setInterval(VerificarDropDown, 100);
    }

    if (ultra && !linkVendedor) {
      //adiciona scripts

      var Cabecalho = document.getElementsByClassName('ui-search-view-options__container')[0];

      var header = document.head;

      var url_atual = document.URL;

      var CriadoValue = document.createElement('div');
      CriadoValue.className = 'subtitleData'
      //CriadoValue.innerHTML = `<button style="background-color: gray" class="botaoCriadosHoje" onclick="alert('Atenção, esse recurso esta temporariamente desativado.')"> Veja os anúncios criados nas Últimas 24h para essa pesquisa</button>`;
      //CriadoValue.innerHTML = `<button class="botaoCriadosHoje" onclick="criadoshoje('${url_atual}')"> Veja os anúncios criados nas Últimas 24h para essa pesquisa</button>`;
      Cabecalho.prepend(CriadoValue);
    } else {
      if (!ultra) {
        var Cabecalho = document.getElementsByClassName('ui-search-view-options__container')[0];

        var CriadoValue = document.createElement('div');
        CriadoValue.className = 'subtitleData'
        CriadoValue.innerHTML = `<button class="botaoUltraMenu" onClick="javascript:window.open('https://avantpro.com.br/ml/', '_blank');"> &#128226; Clique aqui e Conheça o Avantpro Ultra  &#128226;</button> </center>`;
        Cabecalho.prepend(CriadoValue);
      }
    }

  }

  static botaoPalavrasChavesMaisVendidos(itemList) {
    var Titulo = document.getElementsByClassName('ui-search-layout--grid__container')[0];

    /* Criando botao  */
    var CriadoValue = document.createElement('div');
    CriadoValue.className = 'subtitleData';
    CriadoValue.innerHTML = `<button style="margin-bottom: 10px !important; width: fit-content" class="botaoPalavrasChaves" onclick="(function(){
     document.dispatchEvent(new CustomEvent('PalavrasChaves',{detail : { teste: '${itemList}' } } ));
     })()      
     "> Veja os termos mais usados nos títulos</button>`;
    Titulo.insertAdjacentElement("beforebegin", CriadoValue);

  }

  static pesquisaPorAnuncio(itemList, email, ultra) {
    // Para cada item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {

        if (document.contains(document.querySelector(".loading"))) {
          document.querySelector('.loading').remove();
        }

        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'medalha-vendedor';
        medalhaVendedor.setAttribute("style", "margin-left: -7px; margin-right: -7px; color: gray");

        let tipoMedalha = '';
        switch (item.seller.seller_reputation.power_seller_status) {
          case 'platinum':
            tipoMedalha = 'Platinum';
            break;
          case 'silver':
            tipoMedalha = 'Líder';
            break;
          case 'gold':
            tipoMedalha = 'Gold';
            break;
          default:
            tipoMedalha = 'Sem Medalha';
            break;
        }

        var data = item.start_time;

        const hoje = new Date();
        const dataCriacao = new Date(data);
        const diferencaDias = Math.abs(hoje.getTime() - dataCriacao.getTime());
        const diasCriacao = Math.ceil(diferencaDias / (1000 * 60 * 60 * 24));
        var reputacao = '';

        switch (item.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="green" />
            </svg>
            </div>`
            break;
          case '4_light_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgreen" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '3_yellow':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="yellow" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '2_orange':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="orange" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '1_red':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="red" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          default:
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`;
            break;
        }


        let supermercado = item.tags.includes('supermarket_eligible');
        item.taxas.sale_fee_amount = supermercado ? (item.taxas.sale_fee_amount > 5 ? item.taxas.sale_fee_amount - 5 : item.taxas.sale_fee_amount) : item.taxas.sale_fee_amount;


        /** BOTÕES RASTREAR E COPIAR TITULO DO ANÚNCIO */

        let botaoRastreio = document.createElement('div');
        if (ultra) {
          botaoRastreio.classList.add("linha");
          botaoRastreio.setAttribute("style", "position: absolute; right: 0; bottom: 0%; margin-bottom: 5px;");
          botaoRastreio.innerHTML = `
          ${document.getElementsByClassName('ui-search-layout__item shops__layout-item')[0] ? `<button class="btn btn-info" style="margin-left: auto; position: relative; border-radius: 50%; width: 26px; padding: 4px; margin-bottom: 0; bottom: 40px; left: 52%;" onclick="navigator.clipboard.writeText('${item.title}')">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.23275 14.7589C6.79704 14.7589 6.42417 14.6039 6.11415 14.2938C5.80361 13.9833 5.64833 13.6102 5.64833 13.1744V3.66792C5.64833 3.2322 5.80361 2.85907 6.11415 2.54852C6.42417 2.23851 6.79704 2.0835 7.23275 2.0835H14.3626C14.7984 2.0835 15.1715 2.23851 15.482 2.54852C15.7921 2.85907 15.9471 3.2322 15.9471 3.66792V13.1744C15.9471 13.6102 15.7921 13.9833 15.482 14.2938C15.1715 14.6039 14.7984 14.7589 14.3626 14.7589H7.23275ZM4.06391 17.9277C3.6282 17.9277 3.25507 17.7727 2.94452 17.4627C2.6345 17.1521 2.47949 16.779 2.47949 16.3433V6.04455C2.47949 5.82009 2.55554 5.63181 2.70765 5.4797C2.85923 5.32813 3.04724 5.25234 3.2717 5.25234C3.49616 5.25234 3.68444 5.32813 3.83655 5.4797C3.98812 5.63181 4.06391 5.82009 4.06391 6.04455V16.3433H11.986C12.2105 16.3433 12.3988 16.4193 12.5509 16.5714C12.7024 16.723 12.7782 16.911 12.7782 17.1355C12.7782 17.36 12.7024 17.548 12.5509 17.6995C12.3988 17.8517 12.2105 17.9277 11.986 17.9277H4.06391Z" fill="currentColor"/></svg><div class="tooltiptext">Copiar tÍtulo do anúncio</div></button>` : `<button class="btn btn-info" style="margin-left: auto; position: relative; border-radius: 50%; width: 26px; padding: 4px; margin-bottom: 0;" onclick="navigator.clipboard.writeText('${item.title}')">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.23275 14.7589C6.79704 14.7589 6.42417 14.6039 6.11415 14.2938C5.80361 13.9833 5.64833 13.6102 5.64833 13.1744V3.66792C5.64833 3.2322 5.80361 2.85907 6.11415 2.54852C6.42417 2.23851 6.79704 2.0835 7.23275 2.0835H14.3626C14.7984 2.0835 15.1715 2.23851 15.482 2.54852C15.7921 2.85907 15.9471 3.2322 15.9471 3.66792V13.1744C15.9471 13.6102 15.7921 13.9833 15.482 14.2938C15.1715 14.6039 14.7984 14.7589 14.3626 14.7589H7.23275ZM4.06391 17.9277C3.6282 17.9277 3.25507 17.7727 2.94452 17.4627C2.6345 17.1521 2.47949 16.779 2.47949 16.3433V6.04455C2.47949 5.82009 2.55554 5.63181 2.70765 5.4797C2.85923 5.32813 3.04724 5.25234 3.2717 5.25234C3.49616 5.25234 3.68444 5.32813 3.83655 5.4797C3.98812 5.63181 4.06391 5.82009 4.06391 6.04455V16.3433H11.986C12.2105 16.3433 12.3988 16.4193 12.5509 16.5714C12.7024 16.723 12.7782 16.911 12.7782 17.1355C12.7782 17.36 12.7024 17.548 12.5509 17.6995C12.3988 17.8517 12.2105 17.9277 11.986 17.9277H4.06391Z" fill="currentColor"/></svg><div class="tooltiptext">Copiar tÍtulo do anúncio</div></button>`}

          
          <button class="btn btn-success" style="position: relative; border-radius: 50%; width: 26px; padding: 4px; margin-bottom: 0;" onclick="AddProdListaAlert('${email}','${item.id}')">
          <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg><div class="tooltiptext">Rastrear anúncio</div></button>`;
        }
        else {
          botaoRastreio.innerHTML = `
          ${document.getElementsByClassName('ui-search-layout__item shops__layout-item')[0] ? `<button class="btn btn-success" style="position: absolute; border-radius: 50%; width: 26px; padding: 4px; right: 10px; bottom: 5%;" onclick="AddProdListaAlert('${email}','${item.id}')" id="anuncioBtnRastrear">
          <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg><div class="tooltiptext">Rastrear anúncio</div></button>` : `<button class="btn btn-success" style="position: relative; border-radius: 50%; width: 26px; padding: 4px; margin-left: auto;" onclick="AddProdListaAlert('${email}','${item.id}')" id="anuncioBtnRastrear">
          <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg><div class="tooltiptext">Rastrear anúncio</div></button>`}
          `;
        }


        try {
          $(this)
            .find(
              '.ui-search-variations-pill'
            )
            .remove()
        } catch (error) {

        }


        try {

          // if ($(this).find('.ui-search-item__group__element.ui-search-link').length) {
          //   // $(this)
          //   //   .find(
          //   //     '.ui-search-result__image.ui-search-link'
          //   //   )
          //   //   .after(botaoRastreio)

          //   var cardImg = document.getElementsByClassName("ui-search-result__image");
          //   for (let index = 0; index < cardImg.length; index++) {

          //     cardImg[index].appendChild(botaoRastreio);

          //   }

          //   // for (let img of cardImg){
          //   //   // console.log(img)

          //   // }

          // } else {
          $(this)
            .find(
              '.ui-search-result__image'
            )
            .append(botaoRastreio)

          // }

        } catch (error) {

        }


        if (ultra) {
          /* Criando botao download */
          var testeBaixar = document.createElement('div');
          testeBaixar.className = 'pesquisa-baixar';
          testeBaixar.innerHTML = `
          <form class="ui-search-bookmark" style="opacity: 100 !important">
            <button type="button" onclick="downloadFotoPesquisa('${id}')" class="btn btn-info" role="switch" style="position: relative; border-radius: 50%; padding: 8px;" aria-checked="false" aria-label="Favorito"><svg width="20" height="19" viewBox="0 0 26 25" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M24.9102 6.54813C24.8017 6.43878 24.6727 6.35199 24.5305 6.29276C24.3884 6.23353 24.2359 6.20303 24.0819 6.20303C23.9279 6.20303 23.7754 6.23353 23.6332 6.29276C23.491 6.35199 23.362 6.43878 23.2535 6.54813L21.7485 8.0648V1.54313C21.7485 1.23371 21.6256 0.936966 21.4068 0.718174C21.188 0.499381 20.8913 0.376465 20.5819 0.376465C20.2724 0.376465 19.9757 0.499381 19.7569 0.718174C19.5381 0.936966 19.4152 1.23371 19.4152 1.54313V8.0648L17.9102 6.54813C17.6905 6.32844 17.3926 6.20502 17.0819 6.20502C16.7712 6.20502 16.4732 6.32844 16.2535 6.54813C16.0338 6.76782 15.9104 7.06578 15.9104 7.37646C15.9104 7.68715 16.0338 7.98511 16.2535 8.2048L19.7535 11.7048C19.8645 11.811 19.9953 11.8943 20.1385 11.9498C20.2782 12.0115 20.4292 12.0434 20.5819 12.0434C20.7346 12.0434 20.8855 12.0115 21.0252 11.9498C21.1684 11.8943 21.2992 11.811 21.4102 11.7048L24.9102 8.2048C25.0196 8.09634 25.1063 7.96731 25.1656 7.82514C25.2248 7.68297 25.2553 7.53048 25.2553 7.37646C25.2553 7.22245 25.2248 7.06996 25.1656 6.92779C25.1063 6.78562 25.0196 6.65659 24.9102 6.54813ZM20.5819 14.3765C20.2724 14.3765 19.9757 14.4994 19.7569 14.7182C19.5381 14.937 19.4152 15.2337 19.4152 15.5431V15.9865L17.6885 14.2598C17.0789 13.6549 16.2548 13.3155 15.396 13.3155C14.5372 13.3155 13.7132 13.6549 13.1035 14.2598L12.2869 15.0765L9.39353 12.1831C8.77534 11.5947 7.95453 11.2665 7.10104 11.2665C6.24754 11.2665 5.42673 11.5947 4.80854 12.1831L3.08187 13.9098V7.37646C3.08187 7.06705 3.20478 6.7703 3.42358 6.55151C3.64237 6.33271 3.93912 6.2098 4.24854 6.2098H13.5819C13.8913 6.2098 14.188 6.08688 14.4068 5.86809C14.6256 5.6493 14.7485 5.35255 14.7485 5.04313C14.7485 4.73371 14.6256 4.43697 14.4068 4.21817C14.188 3.99938 13.8913 3.87646 13.5819 3.87646H4.24854C3.32028 3.87646 2.43004 4.24521 1.77366 4.90159C1.11728 5.55797 0.748535 6.44821 0.748535 7.37646V21.3765C0.748535 22.3047 1.11728 23.195 1.77366 23.8513C2.43004 24.5077 3.32028 24.8765 4.24854 24.8765H18.2485C19.1768 24.8765 20.067 24.5077 20.7234 23.8513C21.3798 23.195 21.7485 22.3047 21.7485 21.3765V15.5431C21.7485 15.2337 21.6256 14.937 21.4068 14.7182C21.188 14.4994 20.8913 14.3765 20.5819 14.3765ZM4.24854 22.5431C3.93912 22.5431 3.64237 22.4202 3.42358 22.2014C3.20478 21.9826 3.08187 21.6859 3.08187 21.3765V17.2115L6.4652 13.8281C6.6366 13.6648 6.86428 13.5737 7.10104 13.5737C7.33779 13.5737 7.56547 13.6648 7.73687 13.8281L11.4352 17.5265L16.4519 22.5431H4.24854ZM19.4152 21.3765C19.4135 21.5998 19.3399 21.8166 19.2052 21.9948L13.9435 16.7098L14.7602 15.8931C14.8438 15.8078 14.9437 15.7399 15.0539 15.6936C15.164 15.6473 15.2824 15.6235 15.4019 15.6235C15.5214 15.6235 15.6397 15.6473 15.7499 15.6936C15.8601 15.7399 15.9599 15.8078 16.0435 15.8931L19.4152 19.2881V21.3765Z" fill="currentColor"/></svg><div class="tooltiptext">Baixar todas as imagens</div></button>
          </form>`

          try {
            $(this)
              .find('.andes-card.ui-search-result.ui-search-result--core')
              .append(testeBaixar) //set
          } catch (error) {

          }
          /** fim botão download */

        }



        let ean = '';
        if (item.ean != null) {
          if (item.ean != 'Sem EAN') {
            ean = item.ean.split(',');
            ean = ean.filter(x => x.trim());
            ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs de variações' : ean[0];
          } else {
            ean = item.ean;
          }
        }


        let lojaoficial = item.seller.tags ? item.seller.tags.includes('brand') : false;

        let marca = item.atributos.find(atributo => atributo.id == 'BRAND')

        let cor = 'var(--success)';
        let txtCriado = '';
        if (diasCriacao < 180) {
          cor = 'var(--success)';
          txtCriado = 'Criado há menos de 180 dias';
        } else if (diasCriacao >= 180 && diasCriacao < 365) {
          cor = 'var(--warning)';
          txtCriado = 'Criado há menos de 365 dias';
        } else {
          cor = 'var(--danger)';
          txtCriado = 'Criado há mais de um ano';
        }




        medalhaVendedor.innerHTML = `
        <div style="justify-content: end; text-align: right;">
          <div class="cardInfos cardBadge" title>
            ${lojaoficial ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="14" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.68059 17.1067L5.29877 14.6686L2.68059 14.0591L2.93514 11.24L1.15332 9.10669L2.93514 6.97336L2.68059 4.15431L5.29877 3.54478L6.68059 1.10669L9.15332 2.21145L11.626 1.10669L13.0079 3.54478L15.626 4.15431L15.3715 6.97336L17.1533 9.10669L15.3715 11.24L15.626 14.0591L13.0079 14.6686L11.626 17.1067L9.15332 16.0019L6.68059 17.1067ZM7.29877 15.1638L9.15332 14.3257L11.0442 15.1638L12.0624 13.3353L14.0624 12.84L13.8806 10.7067L15.226 9.10669L13.8806 7.46859L14.0624 5.33526L12.0624 4.87812L11.0079 3.04955L9.15332 3.88764L7.26241 3.04955L6.24423 4.87812L4.24423 5.33526L4.42605 7.46859L3.08059 9.10669L4.42605 10.7067L4.24423 12.8781L6.24423 13.3353L7.29877 15.1638ZM8.38968 11.8115L12.4988 7.50669L11.4806 6.40193L8.38968 9.64002L6.82605 8.04002L5.80787 9.10669L8.38968 11.8115Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Loja oficial</p></div>' : ''}

            <div class="badgeBorder" style="position: relative;">${item.seller.seller_reputation.power_seller_status == "platinum" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado platinum</p>' : `${item.seller.seller_reputation.power_seller_status == "gold" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado gold</p>' : `${item.seller.seller_reputation.power_seller_status == "silver" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado líder</p>' : '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Sem medalha</p>'}`}`}</div>

            ${item.catalogo ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="11" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.36954 5.90669C1.69656 5.90669 1.15332 6.44269 1.15332 7.10669C1.15332 7.77069 1.69656 8.30669 2.36954 8.30669C3.04251 8.30669 3.58575 7.77069 3.58575 7.10669C3.58575 6.44269 3.04251 5.90669 2.36954 5.90669ZM2.36954 1.10669C1.69656 1.10669 1.15332 1.64269 1.15332 2.30669C1.15332 2.97069 1.69656 3.50669 2.36954 3.50669C3.04251 3.50669 3.58575 2.97069 3.58575 2.30669C3.58575 1.64269 3.04251 1.10669 2.36954 1.10669ZM2.36954 10.7067C1.69656 10.7067 1.15332 11.2507 1.15332 11.9067C1.15332 12.5627 1.70467 13.1067 2.36954 13.1067C3.0344 13.1067 3.58575 12.5627 3.58575 11.9067C3.58575 11.2507 3.04251 10.7067 2.36954 10.7067ZM5.61278 12.7067H15.3425C15.7885 12.7067 16.1533 12.3467 16.1533 11.9067C16.1533 11.4667 15.7885 11.1067 15.3425 11.1067H5.61278C5.16683 11.1067 4.80197 11.4667 4.80197 11.9067C4.80197 12.3467 5.16683 12.7067 5.61278 12.7067ZM5.61278 7.90669H15.3425C15.7885 7.90669 16.1533 7.54669 16.1533 7.10669C16.1533 6.66669 15.7885 6.30669 15.3425 6.30669H5.61278C5.16683 6.30669 4.80197 6.66669 4.80197 7.10669C4.80197 7.54669 5.16683 7.90669 5.61278 7.90669ZM4.80197 2.30669C4.80197 2.74669 5.16683 3.10669 5.61278 3.10669H15.3425C15.7885 3.10669 16.1533 2.74669 16.1533 2.30669C16.1533 1.86669 15.7885 1.50669 15.3425 1.50669H5.61278C5.16683 1.50669 4.80197 1.86669 4.80197 2.30669Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Item catálogo</p></div>' : ''}

            ${item.taxas.listing_type_name == "Premium" ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="15" height="10" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Anúncio premium</p></div>' : ''}
            
            ${item.flex ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Está no flex</p></div>' : ''}

            ${item.video == "Sim" ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#3d3d3d"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Tem video</p></div>' : ''}
          </div>
        </div>

        <div style="display: flex;">
          <div style="text-align: start; width: 50%; position: relative;">
            <p class="nome-vendedor" style="margin-bottom: 5px; font-weight: unset; max-width: 100% !important;"><strong style="color: var(--grey);">Vendedor: </strong>${item.seller.nickname.substring(0, 22)}</p>
            ${document.getElementsByClassName('ui-search-layout__item shops__layout-item')[0] ? '' : `<div class="tooltiptext">${item.seller.nickname.substring(0, 22)}</div>`}
            
            ${ultra ? `<p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Marca: </strong> ${marca ? (marca.value_name == null ? 'Não Informado</p>' : '<strong style="color: var(--secundary);">' + marca.value_name.substring(0, 45)) + '</strong></p>' : 'Não Informado</p>'}` : ''}

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Comissão: </strong>R$ ${item.taxas.sale_fee_amount.toFixed(2)}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Fotos: </strong>${item.fotos}</p>

            <p style="min-width: 135px;"><strong style="color: var(--grey);">Criado em: </strong>${dataCriacao.toLocaleDateString()} <div class="cardInfo cardCriadoHa" style="color: ${cor}; border: 1px solid ${cor}; border-radius: 50px; padding: 2px 4px 2px 4px; display: inline-flex; font-weight: 600;" title>Há ${diasCriacao.toLocaleString('pt-BR', {})} dias<div class="tooltiptext" style="width: 200px;">${txtCriado}</div></div></p>

            <p style="margin-top: 5px;"><strong style="color: var(--grey);">EAN: </strong>${ean == '' ? 'Sem EAN' : ean}</p>
          </div>

          <div style="text-align: start; width: 50%; margin-left: 25px;">
            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Localização: </strong>${item.seller.tags ? (item.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : item.seller.address.city != null ? (item.seller.address.city + ' / ' + item.seller.address.state.replace('BR-', '')) : 'Não Informado') : (item.seller.address.city != null ? (item.seller.address.city + ' / ' + item.seller.address.state.replace('BR-', '')) : 'Não Informado')}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Qualidade: </strong>${(parseFloat(item.health == null ? 1 : item.health) * 100).toFixed(0)}%</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Vendas: </strong>${item.vendas > 0 ? '+ de ' : ''} ${item.vendas}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Visitas: </strong>Acesse o anúncio</p>
          </div>
        </div>`
          //+ `<p id="loadingConversao" class="loadingConversao" style=" font-weight: bold; margin-right: -15px; color: #2E64FE !important">Carregando dados da conversão <img src="https://i.ibb.co/rydvc4W/800.gif"></img></p>`
          // + `<div id="dadosConversao" class="dadosConversao"></div>`
          + `<div class="linha">${reputacao}</div>
          <p style="margin-top: 5px; text-align: -webkit-center; color: var(--grey);">Informações: <strong>Avantpro</strong></p>`

        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(medalhaVendedor);

        let InfoProdutos = document.createElement('span');
        InfoProdutos.style.display = 'none';
        InfoProdutos.className = 'DadosProduto';
        InfoProdutos.innerText = JSON.stringify({
          "dias": diasCriacao,
          "price": item.price,
          "full": item.full,
          "catalogo": item.catalogo,
          "listing_type_id": item.listing_type_id,
          "vendas": item.vendas
        });

        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(InfoProdutos)
      }

      var card = document.getElementsByClassName('cardBadge');

      for (let i = 0; i < card.length; i++) {
        var cardBadge = card[i].getElementsByTagName('div');

        var ultimo = cardBadge[cardBadge.length - 1];

        ultimo.classList.remove('badgeBorder');

      }
    })

  }

  static pesquisaPorAnuncioConversao(itemList, email) {
    // Para cada item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {

        if (document.contains(document.querySelector(".loadingConversao"))) {
          document.querySelector('.loadingConversao').remove();
        }

        // renderiza dados conversão
        let dadosConversao = document.createElement('div')
        dadosConversao.className = 'conversao';
        dadosConversao.setAttribute("style", "color: gray");

        let conversaoporvisita = '';
        if (parseInt(item.visitas) > 0 && item.vendas > 0) {
          conversaoporvisita = `<strong><p style="margin-right: -15px; color: #2E64FE !important">1 Venda a Cada <strong>${(item.visitas / item.vendas).toFixed(0)}</strong> Visitas | Conversão: <strong>${((1 / (item.visitas / item.vendas)) * 100).toFixed(2)}%</strong></p></strong>`
        } else if (item.vendas == 0) {
          //conversaoporvisita = `<strong><p style="margin-right: -15px; color: #2E64FE !important">Produto sem vendas, conversão indisponível</strong></p>`
        } /* else if (item.visitas == 0) {
          conversaoporvisita = `<strong><p style="margin-right: -15px; color: #2E64FE !important">Conversão indisponível, tente novamente</strong></p>`
        } */



        dadosConversao.innerHTML =
          `<p>Vendas: ${item.vendas > 0 ? '+ de ' : ''} ${item.vendas} | Visitas: ${item.visitas == 0 || item.visitas == undefined ? 'Acesse o anúncio' : item.visitas}</p>`
          + `${conversaoporvisita}`
        $(this)
          .find(
            '.dadosConversao'
          )
          .before(dadosConversao)
      }
    })
  }

  static pesquisaPorAnuncioMaisVendidos(itemList, email) {
    // Para cada item editado

    $('.ui-best-seller-content-main-components > .ui-search-layout--grid__container > .ui-search-layout--grid__grid > .ui-recommendations-card').each(function () {
      let id = $(this).find('.ui-recommendations-card__title > .ui-recommendations-card__link').attr('href');

      if (id.includes('produto.mercadolivre')) {
        id = id.split('-')[1];
        id = 'MLB' + id;
      } else {
        id = id.split('/p/')[1];
        id = id.split('?')[0];
      }

      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'p.ui-recommendations-card__title'
        ).length
      ) {

        if (document.contains(document.querySelector(".loading"))) {
          document.querySelector('.loading').remove();
        }

        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'medalha-vendedor';
        medalhaVendedor.setAttribute("style", "margin-left: -7px; margin-right: -7px; color: gray;");

        var boxProduto = document.getElementsByClassName("ui-recommendations-card");

        for (let produto of boxProduto) {
          produto.setAttribute("style", "height: 100% !important");
        }


        let tipoMedalha = '';
        switch (item.seller.seller_reputation.power_seller_status) {
          case 'platinum':
            tipoMedalha = 'Platinum';
            break;
          case 'silver':
            tipoMedalha = 'Líder';
            break;
          case 'gold':
            tipoMedalha = 'Gold';
            break;
          default:
            tipoMedalha = 'Sem Medalha';
            break;
        }

        var data = item.start_time;

        const hoje = new Date();
        const dataCriacao = new Date(data);
        const diferencaDias = Math.abs(hoje.getTime() - dataCriacao.getTime());
        const diasCriacao = Math.ceil(diferencaDias / (1000 * 60 * 60 * 24));
        var reputacao = '';

        switch (item.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="green" />
            </svg>
            </div>`
            break;
          case '4_light_green':
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgreen" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '3_yellow':
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="yellow" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '2_orange':
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="orange" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '1_red':
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="red" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          default:
            reputacao =
              `<div style="line-height: 0.3 !important;">
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`;
            break;
        }


        let supermercado = item.tags.includes('supermarket_eligible');
        item.taxas.sale_fee_amount = supermercado ? (item.taxas.sale_fee_amount > 5 ? item.taxas.sale_fee_amount - 5 : item.taxas.sale_fee_amount) : item.taxas.sale_fee_amount;


        /** BOTAO RASTREIO */

        // renderiza a medalha do vendedor
        /*   let botaoRastreio = document.createElement('div')
  
          botaoRastreio.innerHTML = `<button class="botaoRastrear" style="justify-content: center; align-items: center; text-align: center; display: flex;" onclick="AddProdListaAlert('${email}','${item.id}')">
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px"
          style="margin-right: 5px"
          width="14" height="14"
          viewBox="20 20 140 140"
          style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g fill="#ffffff"><path d="M114.66667,17.2c-2.04901,0.00393 -3.94017,1.10106 -4.96067,2.87786h-0.0112l-25.09453,36.67318l30.6599,30.6599l36.87474,-25.22891l0.0112,-0.0112c1.65341,-1.05281 2.65437,-2.87735 2.65391,-4.8375c-0.0002,-1.53148 -0.6131,-2.99922 -1.70208,-4.07604l-34.24323,-34.23203l-0.0224,-0.0224c-1.0814,-1.14842 -2.58819,-1.80055 -4.16562,-1.80286zM57.96042,63.06667c-8.52547,0 -17.05595,3.24892 -23.56042,9.75339l28.33073,28.34192l-38.11771,38.11771c-1.49776,1.43802 -2.1011,3.57339 -1.57731,5.58258c0.52378,2.00919 2.09283,3.57824 4.10202,4.10202c2.00919,0.52378 4.14456,-0.07955 5.58258,-1.57732l38.11771,-38.11771l28.34192,28.33073c13.00893,-13.00893 13.00893,-34.1007 0,-47.10964l-17.67031,-17.67031c-6.50447,-6.50447 -15.02375,-9.75339 -23.54922,-9.75339z"></path></g></g></svg>
          Rastrear esse Anúncio</button>`
  
          try {
            $(this)
              .find(
                '.ui-search-variations-pill'
              )
              .remove()
          } catch (error) {
  
          }
  
          $(this)
            .find(
              '.ui-search-result__image'
            )
            .append(botaoRastreio) */

        /** FIM BOTAO RASTREIO */

        let ean = '';
        if (item.ean != null) {
          if (item.ean != 'Sem EAN') {
            ean = item.ean.split(',');
            ean = ean.filter(x => x.trim());
            ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs de variações' : ean[0];
          } else {
            ean = item.ean;
          }
        }


        let lojaoficial = item.seller.tags?.includes('brand');
        let marca = item.atributos.find(atributo => atributo.id == 'BRAND');


        let cor = 'var(--success)';
        let txtCriado = '';
        if (diasCriacao < 180) {
          cor = 'var(--success)';
          txtCriado = 'Criado a menos de 180 dias';
        } else if (diasCriacao >= 180 && diasCriacao < 365) {
          cor = 'var(--warning)';
          txtCriado = 'Criado a menos de 365 dias';
        } else {
          cor = 'var(--danger)';
          txtCriado = 'Criado a mais de um ano';
        }


        medalhaVendedor.innerHTML = `
        <div style="justify-content: end; text-align: right; margin-top: 15px;">
          <div class="cardInfos cardBadge" title>
            ${lojaoficial ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="14" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.68059 17.1067L5.29877 14.6686L2.68059 14.0591L2.93514 11.24L1.15332 9.10669L2.93514 6.97336L2.68059 4.15431L5.29877 3.54478L6.68059 1.10669L9.15332 2.21145L11.626 1.10669L13.0079 3.54478L15.626 4.15431L15.3715 6.97336L17.1533 9.10669L15.3715 11.24L15.626 14.0591L13.0079 14.6686L11.626 17.1067L9.15332 16.0019L6.68059 17.1067ZM7.29877 15.1638L9.15332 14.3257L11.0442 15.1638L12.0624 13.3353L14.0624 12.84L13.8806 10.7067L15.226 9.10669L13.8806 7.46859L14.0624 5.33526L12.0624 4.87812L11.0079 3.04955L9.15332 3.88764L7.26241 3.04955L6.24423 4.87812L4.24423 5.33526L4.42605 7.46859L3.08059 9.10669L4.42605 10.7067L4.24423 12.8781L6.24423 13.3353L7.29877 15.1638ZM8.38968 11.8115L12.4988 7.50669L11.4806 6.40193L8.38968 9.64002L6.82605 8.04002L5.80787 9.10669L8.38968 11.8115Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Loja oficial</p></div>' : ''}

            <div class="badgeBorder" style="position: relative;">${item.seller.seller_reputation.power_seller_status == "platinum" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado platinum</p>' : `${item.seller.seller_reputation.power_seller_status == "gold" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado gold</p>' : `${item.seller.seller_reputation.power_seller_status == "silver" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado líder</p>' : '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Sem medalha</p>'}`}`}</div>

            ${item.catalogo ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="11" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.36954 5.90669C1.69656 5.90669 1.15332 6.44269 1.15332 7.10669C1.15332 7.77069 1.69656 8.30669 2.36954 8.30669C3.04251 8.30669 3.58575 7.77069 3.58575 7.10669C3.58575 6.44269 3.04251 5.90669 2.36954 5.90669ZM2.36954 1.10669C1.69656 1.10669 1.15332 1.64269 1.15332 2.30669C1.15332 2.97069 1.69656 3.50669 2.36954 3.50669C3.04251 3.50669 3.58575 2.97069 3.58575 2.30669C3.58575 1.64269 3.04251 1.10669 2.36954 1.10669ZM2.36954 10.7067C1.69656 10.7067 1.15332 11.2507 1.15332 11.9067C1.15332 12.5627 1.70467 13.1067 2.36954 13.1067C3.0344 13.1067 3.58575 12.5627 3.58575 11.9067C3.58575 11.2507 3.04251 10.7067 2.36954 10.7067ZM5.61278 12.7067H15.3425C15.7885 12.7067 16.1533 12.3467 16.1533 11.9067C16.1533 11.4667 15.7885 11.1067 15.3425 11.1067H5.61278C5.16683 11.1067 4.80197 11.4667 4.80197 11.9067C4.80197 12.3467 5.16683 12.7067 5.61278 12.7067ZM5.61278 7.90669H15.3425C15.7885 7.90669 16.1533 7.54669 16.1533 7.10669C16.1533 6.66669 15.7885 6.30669 15.3425 6.30669H5.61278C5.16683 6.30669 4.80197 6.66669 4.80197 7.10669C4.80197 7.54669 5.16683 7.90669 5.61278 7.90669ZM4.80197 2.30669C4.80197 2.74669 5.16683 3.10669 5.61278 3.10669H15.3425C15.7885 3.10669 16.1533 2.74669 16.1533 2.30669C16.1533 1.86669 15.7885 1.50669 15.3425 1.50669H5.61278C5.16683 1.50669 4.80197 1.86669 4.80197 2.30669Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Item catálogo</p></div>' : ''}

            ${item.taxas.listing_type_name == "Premium" ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="15" height="10" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Anúncio premium</p></div>' : ''}
            
            ${item.flex ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Está no flex</p></div>' : ''}

            ${item.video == "Sim" ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#3d3d3d"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Tem video</p></div>' : ''}
          </div>
        </div>

        <div style="display: flex;">
          <div style="text-align: start; width: 50%; position: relative;">
            <p class="nome-vendedor" style="margin-bottom: 5px; font-weight: unset; max-width: 100% !important;"><strong style="color: var(--grey);">Vendedor: </strong>${item.seller.nickname.substring(0, 22)}</p>
            <div class="tooltiptext">${item.seller.nickname.substring(0, 22)}</div>
            
            ${ultra ? `<p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Marca: </strong> ${marca ? (marca.value_name == null ? 'Não Informado</p>' : '<strong style="color: var(--secundary);">' + marca.value_name.substring(0, 45)) + '</strong></p>' : 'Não Informado</p>'}` : ''}

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Comissão: </strong>R$ ${item.taxas.sale_fee_amount.toFixed(2)}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Fotos: </strong>${item.fotos}</p>

            <p style="min-width: 135px;"><strong style="color: var(--grey);">Criado em: </strong>${dataCriacao.toLocaleDateString()} <div class="cardInfo cardCriadoHa" style="color: ${cor}; border: 1px solid ${cor}; border-radius: 50px; padding: 2px 4px 2px 4px; display: inline-flex; font-weight: 600;" title>Há ${diasCriacao} dias<div class="tooltiptext" style="width: 200px;">${txtCriado}</div></div></p>

            <p style="margin-top: 5px;"><strong style="color: var(--grey);">EAN: </strong>${ean == '' ? 'Sem EAN' : ean}</p>
          </div>

          <div style="text-align: start; width: 50%; margin-left: 25px;">
            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Localização: </strong>${item.seller.tags ? (item.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : item.seller.address.city != null ? (item.seller.address.city + ' / ' + item.seller.address.state.replace('BR-', '')) : 'Não Informado') : 'Não Informado'}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Qualidade: </strong>${(parseFloat(item.health == null ? 1 : item.health) * 100).toFixed(0)}%</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Vendas: </strong>${item.vendas > 0 ? '+ de ' : ''} ${item.vendas}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Visitas: </strong>Acesse o anúncio</p>
          </div>
        </div>`
          //+ `<p id="loadingConversao" class="loadingConversao" style=" font-weight: bold; margin-right: -15px; color: #2E64FE !important">Carregando dados da conversão <img src="https://i.ibb.co/rydvc4W/800.gif"></img></p>`
          // + `<div id="dadosConversao" class="dadosConversao"></div>`
          + `<div class="linha">${reputacao}</div>
          <p style="margin-top: 5px; text-align: -webkit-center; color: var(--grey);">Informações: <strong>Avantpro</strong></p>`
        $(this)
          .find(
            '.ui-recommendations-card__title'
          )
          .after(medalhaVendedor)

        var card = document.getElementsByClassName('cardBadge');

        for (let i = 0; i < card.length; i++) {
          var cardBadge = card[i].getElementsByTagName('div');

          var ultimo = cardBadge[cardBadge.length - 1];

          ultimo.classList.remove('badgeBorder');

        }
      }
    })
  }

  static pesquisaPorAnuncioMaisVendidosConversao(itemList, email) {
    // Para cada item
    $('.items_container > .promotion-item').each(function () {
      let id = $(this).find('.promotion-item__link-container').attr('href');
      id = id.split('-')[1];
      id = 'MLB' + id;
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'p.promotion-item__title'
        ).length
      ) {


        if (document.contains(document.querySelector(".loadingConversao"))) {
          document.querySelector('.loadingConversao').remove();
        }

        // renderiza dados conversão
        let dadosConversao = document.createElement('div')
        dadosConversao.className = 'conversao';
        dadosConversao.setAttribute("style", "color: gray");

        let conversaoporvisita = '';
        if (parseInt(item.visitas) > 0 && item.vendas > 0) {
          conversaoporvisita = `<strong><p style="line-height: 0.3 !important; margin-right: -15px; color: #2E64FE !important">1 Venda a Cada <strong>${(item.visitas / item.vendas).toFixed(0)}</strong> Visitas | Conversão: <strong>${((1 / (item.visitas / item.vendas)) * 100).toFixed(2)}%</strong></p></strong>`
        } else if (item.vendas == 0) {
          //conversaoporvisita = `<strong><p style="line-height: 0.3 !important; margin-right: -15px; color: #2E64FE !important">Produto sem vendas, conversão indisponível</strong></p>`
        }/*  else if (item.visitas == 0) {
          conversaoporvisita = `<strong><p style="line-height: 0.3 !important; margin-right: -15px; color: #2E64FE !important">Conversão indisponível, tente novamente</strong></p>`
        } */



        dadosConversao.innerHTML =
          `<p style="line-height: 0.3 !important;">Vendas: ${item.vendas > 0 ? '+ de ' : ''} ${item.vendas} | Visitas: ${item.visitas == 0 || item.visitas == undefined ? 'Acesse o anúncio' : item.visitas}</p>`
          + `${conversaoporvisita}`
        $(this)
          .find(
            '.dadosConversao'
          )
          .before(dadosConversao)
      }
    })
  }

  static pesquisaLoadingMaisVendidos(itemList) {
    $('.items_container > .promotion-item').each(function () {
      let id = $(this).find('.promotion-item__link-container').attr('href');
      if (id.includes('produto.mercadolivre')) {
        id = id.split('-')[1];
        id = 'MLB' + id;
      } else {
        id = id.split('/p/')[1];
        id = id.split('?')[0];
      }
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'p.promotion-item__title'
        ).length
      ) {
        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'loading'
        medalhaVendedor.setAttribute("style", "margin-bottom: 10px;")

        medalhaVendedor.innerHTML =
          `<center><div class="loader"><svg width="37" height="50" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <defs>
          <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
          <stop offset="0.139315" stop-color="#271BEF"/>
          <stop offset="0.942129" stop-color="#00C2FF"/>
          </linearGradient>
          <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
          <stop offset="0.0921191" stop-color="#00C2FF"/>
          <stop offset="0.970863" stop-color="#271BEF"/>
          </linearGradient>
          </defs>
          </svg>
          <p>Carregando dados Avantpro...</p>
          </div>
          </center>`
        $(this)
          .find(
            '.promotion-item__title'
          )
          .after(medalhaVendedor)
      }
    })
  }



  static vendasVendedor(itemList) {
    // Para cada item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let vendasVendedor = document.createElement('span')
        vendasVendedor.className = 'vendas-vendedor'
        vendasVendedor.setAttribute("style", "color: black; font-size:11px;");

        vendasVendedor.innerHTML = 'Concluidas: ' + item.seller.seller_reputation.transactions.completed + ' Canceladas:  ' + item.seller.seller_reputation.transactions.canceled + ' Total: ' + item.seller.seller_reputation.transactions.total
        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(vendasVendedor)
      }
    })
  }


  static anuncioCriado(itemList) {
    // Para cada item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let vendasVendedor = document.createElement('span')
        vendasVendedor.className = 'anuncio-criado'
        vendasVendedor.setAttribute("style", "color: black; font-size:11px; margin-top:-10px;");

        vendasVendedor.innerHTML = 'Anúncio Criado em: ' + item.start_time
        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(vendasVendedor)
      }
    })
  }

  static menuMeliPRO(validacao, ultra) {
    var body = document.body;
    let atalhoRastreio = document.createElement('div');
    atalhoRastreio.className = 'atalhoRastreio';
    if (validacao) {
      atalhoRastreio.setAttribute('onclick', `document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;');`);
    } else {
      atalhoRastreio.setAttribute('onclick', `document.getElementsByClassName('bodyRastreio')[0].style.display = 'block';`);
    }
    atalhoRastreio.innerHTML = `
         <svg width="0" height="38" viewBox="0 0 450 450" fill="none" xmlns="http://www.w3.org/2000/svg">
         <img src="https://img.icons8.com/android/30/FFFFFF/chevron-left.png"/>
         </svg>
        `;
    body.appendChild(atalhoRastreio);


    let menu = document.createElement('div');
    menu.className = 'dropdown';
    if (document.URL.includes('/MLB')) {
      menu.setAttribute('style', 'left: 10%; top: 20%;');
    } else {
      menu.setAttribute('style', 'left: 150%; top: 15%;');
    }

    if (validacao) {
      menu.innerHTML = `
    <button class="dropbtn">
      <svg width="16" height="42" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
      <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
      <defs>
      <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
      <stop offset="0.380208" stop-color="#F2A008"/>
      <stop offset="0.792994" stop-color="#F9D043"/>
      </linearGradient>
      <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
      <stop stop-color="#1B22B8"/>
      <stop offset="1" stop-color="#4D43FA"/>
      </linearGradient>
      </defs>
      </svg>  
    </button>
    <div class="dropdown-content" style="border-radius: 6px;">
      <a onclick="(function(){
        document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;');
        })()">Fazer Login</a>
      <a href="https://www.youtube.com/@avantprooficial" target="_blank">Conteúdo no Youtube</a>
      <a href="https://api.whatsapp.com/send?phone=5519997514469" target="_blank">Whatsapp Suporte</a>
      <a onclick="abrirSobre()">Sobre Nós</a>
      <center><small style="color: gray; font-size: 12px;">Versão ${chrome.runtime.getManifest().version}</small></center>
    </div>
    `;
    } else {
      menu.innerHTML = `
    <button class="dropbtn">
      <svg width="16" height="42" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
      <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
      <defs>
      <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
      <stop offset="0.380208" stop-color="#F2A008"/>
      <stop offset="0.792994" stop-color="#F9D043"/>
      </linearGradient>
      <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
      <stop stop-color="#1B22B8"/>
      <stop offset="1" stop-color="#4D43FA"/>
      </linearGradient>
      </defs>
      </svg>    
    </button>
    <div class="dropdown-content" style="border-radius: 6px;">`+
        `${ultra ? `<a onclick="gerar100ean()">Gerador de EANs</a>` : ''}` +
        `${ultra ? `<a onclick="editarfotos()">Editor de Fotos</a>` : ''}` +
        `<a href="https://www.youtube.com/@avantprooficial" target="_blank">Conteúdo no Youtube</a>` +
        `<a href="https://api.whatsapp.com/send?phone=5519997514469" target="_blank">Whatsapp Suporte Avantpro</a>` +
        `<a onclick="abrirSobre()">Sobre Nós</a>` +
        `<a id="sairmlpromenu">Sair do Avantpro</a>` +
        `<center><small style="color: gray; font-size: 12px;">${ultra ? `Ultra` : `Premium`} | Versão ${chrome.runtime.getManifest().version}</small></center>` +
        `</div>`;
    }

    if (document.URL.includes('/anuncie')) {
      document.getElementsByClassName('nav-header-user')[0].insertAdjacentElement("beforebegin", menu);
      document.getElementsByClassName('dropdown-content')[0].style.right = "-9px"
    } else if (document.URL.includes('/MLB')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginRight = "40em"
    } else if (document.URL.includes('/anuncios')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/cupons')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/credits')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/hub-engine')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-16px"
    }

    $('#sairmlpromenu').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });
  }

  /** MENU GRATIS */
  static menuMeliPROGratis(validacao) {
    let menu = document.createElement('div');
    menu.className = 'dropdown';
    if (document.URL.includes('/MLB')) {
      menu.setAttribute('style', 'left: 10%; top: 20%;');
    } else {
      menu.setAttribute('style', 'left: 150%; top: 15%;');
    }

    menu.innerHTML = `
      <button class="dropbtn">
        <svg width="16" height="42" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
        <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
        <defs>
        <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
        <stop offset="0.380208" stop-color="#F2A008"/>
        <stop offset="0.792994" stop-color="#F9D043"/>
        </linearGradient>
        <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
        <stop stop-color="#1B22B8"/>
        <stop offset="1" stop-color="#4D43FA"/>
        </linearGradient>
        </defs>
        </svg> 
      </button>
      <div class="dropdown-content" style="border-radius: 6px;">`+
      `<a href="https://avantpro.com.br/ml/" target="_blank">Migre para o Ultra</a>` +
      `<a href="https://www.youtube.com/@avantprooficial" target="_blank">Conteúdo no Youtube</a>` +
      `<a onclick="abrirSobre()">Sobre Nós</a>` +
      `<a id="sairmlpromenu">Sair do Avantpro</a>` +
      `<center><small style="color: gray; font-size: 12px;">Grátis | Versão ${chrome.runtime.getManifest().version}</small></center>` +
      `</div>`;

    if (document.URL.includes('/anuncie')) {
      document.getElementsByClassName('nav-header-user')[0].insertAdjacentElement("beforebegin", menu);
      document.getElementsByClassName('dropdown-content')[0].style.right = "-9px"
    } else if (document.URL.includes('/MLB')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginRight = "40em"
    } else if (document.URL.includes('/anuncios')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/cupons')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/credits')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else if (document.URL.includes('/hub-engine')) {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-27px"
    } else {
      document.getElementsByClassName('nav-menu-list')[0].insertAdjacentElement("afterend", menu);
      document.getElementsByClassName('dropdown')[0].style.marginLeft = "-16px"
    }

    $('#sairmlpromenu').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });
  }

  static menuLateral(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, rawVendedoresCompleto, qtdSupermercado, qtdOferta, qtdInternacional, maiorVenda, menorVenda, totalVendas, ultra, qtdFlex, linkMenuUltra, linkMenuPremium, classificacao, classificacaotxt, classicoTx, premiumTx, pesquisaSemelhante, patrocinados, links) {

    if (ultra) {

      try {
        //Taxa Categoria
        let taxaCategoria = document.createElement('p')
        taxaCategoria.className = 'taxa-pesquisa';


        if (classicoTx > 0 && premiumTx > 0) {
          taxaCategoria.innerHTML = `Nessa categoria você paga: <br> Clássico: ${classicoTx}% | Premium: ${premiumTx}%`;
        } else {
          taxaCategoria.innerHTML = `Taxa da Categoria indisponível no momento. Tente novamente mais tarde!`;
        }

        document.getElementsByClassName('andes-breadcrumb')[0].insertAdjacentElement("beforeEnd", taxaCategoria);
      } catch (error) {

      }

      try {
        //Pesquisas Relacionadas
        let termos = document.createElement('p')
        termos.className = 'pesquisa-semelhante';
        let termosHtml = ``;

        for (let i = 0; i < pesquisaSemelhante.length; i++) {
          termosHtml += `<li class="termos-relacionados">- ${pesquisaSemelhante[i].q}</li>`;
        }

        termos.innerHTML = `<p style="font-weight: bold; margin-bottom: 5px">Clientes pesquisaram também: </p><ul>` + termosHtml + `</ul>`;


        if (pesquisaSemelhante.length > 0) {
          document.getElementsByClassName('ui-search-filter-groups')[0].insertAdjacentElement("beforeBegin", termos); //set
        }


      } catch (error) {

      }

      try {
        //Concorrência
        let concorrencia = document.createElement('span')
        concorrencia.className = 'concorrencia-pesquisa';
        concorrencia.setAttribute("style", `background: ${classificacao};`);
        concorrencia.innerHTML = `${classificacaotxt}`;
        //document.getElementsByClassName('ui-search-search-result')[0].insertAdjacentElement("beforeEnd", concorrencia); //set

        /** Sair do Avantpro, excel e análise de mercado */
        let btnLinha = document.createElement('div');
        btnLinha.className = 'linha';
        btnLinha.style.marginTop = '30px';
        btnLinha.innerHTML = `
        <button class="btn btn-danger" id="sairmlpro" style="margin-right: auto; position: relative;" title="Sair do Avantpro" role="button"><svg style="margin-right: 5px;" width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.30314 0.919189H9.80314C10.2452 0.919189 10.6691 1.09478 10.9817 1.40734C11.2942 1.71991 11.4698 2.14383 11.4698 2.58586V3.41919C11.4698 3.6402 11.382 3.85216 11.2257 4.00844C11.0695 4.16473 10.8575 4.25252 10.6365 4.25252C10.4155 4.25252 10.2035 4.16473 10.0472 4.00844C9.89094 3.85216 9.80314 3.6402 9.80314 3.41919V2.58586H2.30314V15.9192H9.80314V15.0859C9.80314 14.8648 9.89094 14.6529 10.0472 14.4966C10.2035 14.3403 10.4155 14.2525 10.6365 14.2525C10.8575 14.2525 11.0695 14.3403 11.2257 14.4966C11.382 14.6529 11.4698 14.8648 11.4698 15.0859V15.9192C11.4698 16.3612 11.2942 16.7851 10.9817 17.0977C10.6691 17.4103 10.2452 17.5859 9.80314 17.5859H2.30314C1.86111 17.5859 1.43719 17.4103 1.12463 17.0977C0.812069 16.7851 0.636475 16.3612 0.636475 15.9192V2.58586C0.636475 2.14383 0.812069 1.71991 1.12463 1.40734C1.43719 1.09478 1.86111 0.919189 2.30314 0.919189Z" fill="currentColor"/><path d="M11.2991 12.8317C11.6241 13.1567 12.1491 13.1567 12.4741 12.8317L15.4641 9.84171C15.6203 9.68544 15.708 9.47352 15.708 9.25255C15.708 9.03158 15.6203 8.81965 15.4641 8.66338L12.4741 5.67338C12.3156 5.53021 12.1083 5.45337 11.8948 5.45876C11.6814 5.46415 11.4782 5.55135 11.3272 5.70233C11.1762 5.85331 11.089 6.05654 11.0836 6.26999C11.0782 6.48344 11.1551 6.69081 11.2982 6.84921L12.8616 8.41921H5.63656C5.41554 8.41921 5.20358 8.50701 5.0473 8.66329C4.89102 8.81957 4.80322 9.03153 4.80322 9.25255C4.80322 9.47356 4.89102 9.68552 5.0473 9.8418C5.20358 9.99808 5.41554 10.0859 5.63656 10.0859H12.8616L11.2982 11.6559C11.1427 11.8121 11.0554 12.0235 11.0556 12.244C11.0557 12.4644 11.1433 12.6758 11.2991 12.8317Z" fill="currentColor"/></svg>
        Sair<div class="tooltiptext">Sair do Avantpro</div></button>
        
        <button class="btn btn-info" style="position: relative;" title="Planilha de lucratividade" onclick="abrirExcelPesquisa()" role="button"><svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.04074 0.418945H11.3265C11.819 0.418945 12.2914 0.619123 12.6396 0.975442C12.9879 1.33176 13.1836 1.81503 13.1836 2.31895V17.5189C13.1836 18.0229 12.9879 18.5061 12.6396 18.8624C12.2914 19.2188 11.819 19.4189 11.3265 19.4189H2.04074C1.54819 19.4189 1.07582 19.2188 0.727538 18.8624C0.379256 18.5061 0.183594 18.0229 0.183594 17.5189V2.31895C0.183594 1.81503 0.379256 1.33176 0.727538 0.975442C1.07582 0.619123 1.54819 0.418945 2.04074 0.418945ZM2.04074 2.31895V6.11895H11.3265V2.31895H2.04074ZM2.04074 8.01895V9.91895H3.89788V8.01895H2.04074ZM5.75502 8.01895V9.91895H7.61216V8.01895H5.75502ZM9.46931 8.01895V9.91895H11.3265V8.01895H9.46931ZM2.04074 11.8189V13.7189H3.89788V11.8189H2.04074ZM5.75502 11.8189V13.7189H7.61216V11.8189H5.75502ZM9.46931 11.8189V13.7189H11.3265V11.8189H9.46931ZM2.04074 15.6189V17.5189H3.89788V15.6189H2.04074ZM5.75502 15.6189V17.5189H7.61216V15.6189H5.75502ZM9.46931 15.6189V17.5189H11.3265V15.6189H9.46931Z" fill="currentColor"/></svg><div class="tooltiptext" style="width: 180px">Clique para fazer uma planilha de lucratividade</div>
        </button>
        
        <button class="btn ${classificacao}" style="position: relative;" title="Análise de mercado" onclick="abrirAnaliseMercado(${JSON.stringify(links).replace(/'/g, '&apos;').replace(/"/g, '&quot;')})" role="button"><svg width="16" height="20" viewBox="0 0 197 232" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.160156" y="121.496" width="40" height="110" fill="currentColor"/><rect x="52.2922" y="81.4956" width="40" height="150" fill="currentColor"/><rect x="104.424" y="101.496" width="40" height="130" fill="currentColor"/><rect x="156.556" y="66.6699" width="40" height="165" fill="currentColor"/><circle cx="20.1602" cy="71.6655" r="15" fill="currentColor"/><circle cx="72.2922" cy="31.6655" r="15" fill="currentColor"/><circle cx="124.424" cy="51.6699" r="15" fill="currentColor"/><circle cx="176.556" cy="15.0698" r="15" fill="currentColor"/><path d="M19.2476 74.2711L72.4429 31.2452L124.465 53.5404L177.269 15.5996" stroke="currentColor" stroke-width="13"/></svg><div class="tooltiptext" style="width: 180px">Clique para ver uma análise do mercado</div>
        </button>
        `;
        try {
          document.getElementsByClassName('pesquisa-semelhante')[0].insertAdjacentElement("afterEnd", btnLinha);
        } catch (err) {
          document.getElementsByClassName('ui-search-search-result shops__result')[0].insertAdjacentElement("afterEnd", btnLinha);
        }
      } catch (error) {

      }

    }

    // renderiza a medalha do vendedor
    let medalhaVendedor = document.createElement('div')
    medalhaVendedor.className = 'ui-menu-lateral'

    let anunciosPorVendas = '';

    try {

      for (let i = 0; i < rawVendedoresCompleto.length; i++) {

        var testeVendedor = rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status;

        let full = '';
        let gratis = '';
        let reputacao = '';
        let estado = '';
        for (let x = 0; x < rawVendedoresCompleto[i].val.available_filters.length; x++) {
          if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping") full = rawVendedoresCompleto[i].val.available_filters[x].values.length == 2 ? rawVendedoresCompleto[i].val.available_filters[x].values[1].results : 0;
          if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping_cost") gratis = rawVendedoresCompleto[i].val.available_filters[x].values[0].results
        }

        // Reputação
        switch (rawVendedoresCompleto[i].val.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="green" />
          </svg>
          `
            break;
          case '4_light_green':
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgreen" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
            break;
          case '3_yellow':
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="yellow" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
            break;
          case '2_orange':
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="orange" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
            break;
          case '1_red':
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="red" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
         `
            break;
          default:
            reputacao =
              `
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect  width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
              <svg class="svg-termometro-menu" width="40" height="8">
              <rect width="40" height="8" fill="lightgray" />
          </svg>
          `;
            break;
        }

        // Vendedores
        if (rawVendedoresCompleto[i].val.results.length > 0) {
          anunciosPorVendas += `
          <div class="vendedores">
            <button class="btn btn-success rastrearConcorrente" style="position: absolute; right: 0; margin-top: -5px; border-radius: 50%; width: 23.5px; padding: 3px; display: none;">
                <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg>
                <div class="tooltiptext">Rastrear concorrente</div>
            </button>

            <div style="display: flex; align-items: baseline; margin-bottom: 5px;">
              <h4 class="nome-vendedor">${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "platinum" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-platinum><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "gold" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-gold><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "silver" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-silver><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-sem><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}`}`}
              ${ultra ? `<a href="https://lista.mercadolivre.com.br/_CustId_${rawVendedoresCompleto[i].val.seller.id}" target="_blank" data-vendedor-nome>${rawVendedoresCompleto[i].val.seller.nickname}</a></h4>` : rawVendedoresCompleto[i].val.seller.nickname}</h4>` +
            '<p class="tituloCard" style="margin-bottom: 0px;">: ' + rawVendedoresCompleto[i].val.qtdAnuncio + ' anúncio(s)</p> </div> '

            + `${ultra ? (rawVendedoresCompleto[i].val.hoje.total > 0 ? `<p style="font-size: 13px; text-align: center; margin-bottom: 10px;"><a href="https://lista.mercadolivre.com.br/_CustId_${rawVendedoresCompleto[i].val.seller.id}_PublishedToday_YES" target="_blank">Criou <strong>${rawVendedoresCompleto[i].val.hoje.total}</strong> Anúncios nas Últimas 24h</a></p>` : `<p style="font-size: 13px; text-align: center; margin-bottom: 10px;">Não Criou Anúncios nas Últimas 24h</p>`) : ''}
              
            <div class="linha-2" style="text-align: start; align-items: start;">
              <div>
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="10" height="13" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
                <ul>
                  <li>Concluidas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.completed}</strong></li>
                  <li>Canceladas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.canceled}</strong></li>
                  <li>Total: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.total}</strong></li>
                </ul>
              </div>

              <div style="margin-left: 10px;">
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="12" height="13" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.2211 2.06592H12.4433V0.565918H10.8877V2.06592H4.6655V0.565918H3.10994V2.06592H2.33217C1.46883 2.06592 0.784389 2.74092 0.784389 3.56592L0.776611 14.0659C0.776611 14.4637 0.9405 14.8453 1.23222 15.1266C1.52395 15.4079 1.91961 15.5659 2.33217 15.5659H13.2211C14.0766 15.5659 14.7766 14.8909 14.7766 14.0659V3.56592C14.7766 2.74092 14.0766 2.06592 13.2211 2.06592ZM13.2211 14.0659H2.33217V6.56592H13.2211V14.0659ZM5.44328 9.56592H3.88772V8.06592H5.44328V9.56592ZM8.55439 9.56592H6.99883V8.06592H8.55439V9.56592ZM11.6655 9.56592H10.1099V8.06592H11.6655V9.56592ZM5.44328 12.5659H3.88772V11.0659H5.44328V12.5659ZM8.55439 12.5659H6.99883V11.0659H8.55439V12.5659ZM11.6655 12.5659H10.1099V11.0659H11.6655V12.5659Z" fill="#3d3d3d"/></svg>Últimos 60 dias</p>
                <ul>
                  <li>Vendas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.metrics.sales.completed}</strong></li>
                  <li>Reclamações: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.claims.value}</strong></li>
                  <li>Atrasos: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.delayed_handling_time.value}</strong></li>
                </ul>
              </div>
            </div>

            <div class="linha-2" style="text-align: start; margin-top: 10px; align-items: start;">
              <div>
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="15" height="13" viewBox="0 0 15 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.42598 6.99829H9.72598V5.49829H3.42598V6.99829ZM3.42598 4.74829H9.72598V3.24829H3.42598V4.74829ZM2.02598 12.2483C1.64098 12.2483 1.31151 12.1015 1.03758 11.808C0.763177 11.514 0.625977 11.1608 0.625977 10.7483V1.74829C0.625977 1.33579 0.763177 0.982791 1.03758 0.689291C1.31151 0.395291 1.64098 0.248291 2.02598 0.248291H13.226C13.611 0.248291 13.9407 0.395291 14.2151 0.689291C14.489 0.982791 14.626 1.33579 14.626 1.74829V10.7483C14.626 11.1608 14.489 11.514 14.2151 11.808C13.9407 12.1015 13.611 12.2483 13.226 12.2483H2.02598ZM2.02598 10.7483H13.226V1.74829H2.02598V10.7483ZM2.02598 10.7483V1.74829V10.7483Z" fill="#3D3D3D"/></svg>Anúncios</p>
                <ul>
                  <li>Total: <strong>${rawVendedoresCompleto[i].val.paging.total}</strong></li>
                  <li>No full: <strong>${full}</strong></li>
                  <li>Frete grátis: <strong>${gratis}</strong></li>
                </ul>
              </div>

              <div style="margin-left: 10px;">
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="9" height="13" viewBox="0 0 11 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.7771 7.06748C5.3035 7.06748 4.8493 6.88311 4.51441 6.55492C4.17952 6.22673 3.99139 5.78161 3.99139 5.31748C3.99139 4.85335 4.17952 4.40823 4.51441 4.08004C4.8493 3.75185 5.3035 3.56748 5.7771 3.56748C6.2507 3.56748 6.7049 3.75185 7.03979 4.08004C7.37468 4.40823 7.56281 4.85335 7.56281 5.31748C7.56281 5.54729 7.51663 5.77486 7.42688 5.98718C7.33714 6.1995 7.20561 6.39241 7.03979 6.55492C6.87397 6.71742 6.67712 6.84632 6.46046 6.93427C6.24381 7.02222 6.0116 7.06748 5.7771 7.06748ZM5.7771 0.41748C4.45102 0.41748 3.17925 0.933729 2.24157 1.85266C1.30388 2.77159 0.7771 4.01792 0.7771 5.31748C0.7771 8.99248 5.7771 14.4175 5.7771 14.4175C5.7771 14.4175 10.7771 8.99248 10.7771 5.31748C10.7771 4.01792 10.2503 2.77159 9.31263 1.85266C8.37495 0.933729 7.10318 0.41748 5.7771 0.41748Z" fill="#3D3D3D"/></svg>Localização</p>
                <ul>
                  <li>${rawVendedoresCompleto[i].val.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : (rawVendedoresCompleto[i].val.cidade != null ? (rawVendedoresCompleto[i].val.cidade + ' / ' + rawVendedoresCompleto[i].val.uf.replace('BR-', '')) : 'Não Informado')}</li>
                </ul>

                ${rawVendedoresCompleto[i].val.seller.tags[0] == 'brand' ? '<p style="color: #2AC568; font-weight: bold; font-size: 13px; display: flex; align-items: center; margin-top: 10px;" data-vendedor-oficial><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg>Loja Oficial</p>' : ''}
              </div>
            </div>

            <div class="linha" style="margin-top: 10px; margin-bottom: 10px;">
              ${reputacao}
            </div>
          </div>
          `
        } else {

        }

      }
    } catch (error) {

    }

    if (!ultra) {

      /** Linha de botões premium - excel e análise de mercado*/
      let btnLinha = document.createElement('div');
      btnLinha.className = 'linha';
      btnLinha.style.marginTop = '20px';
      btnLinha.innerHTML = `
        <button class="btn btn-danger" id="sairmlpro" style="margin-right: auto; position: relative;" title="Sair do Avantpro" role="button"><svg style="margin-right: 5px;" width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.30314 0.919189H9.80314C10.2452 0.919189 10.6691 1.09478 10.9817 1.40734C11.2942 1.71991 11.4698 2.14383 11.4698 2.58586V3.41919C11.4698 3.6402 11.382 3.85216 11.2257 4.00844C11.0695 4.16473 10.8575 4.25252 10.6365 4.25252C10.4155 4.25252 10.2035 4.16473 10.0472 4.00844C9.89094 3.85216 9.80314 3.6402 9.80314 3.41919V2.58586H2.30314V15.9192H9.80314V15.0859C9.80314 14.8648 9.89094 14.6529 10.0472 14.4966C10.2035 14.3403 10.4155 14.2525 10.6365 14.2525C10.8575 14.2525 11.0695 14.3403 11.2257 14.4966C11.382 14.6529 11.4698 14.8648 11.4698 15.0859V15.9192C11.4698 16.3612 11.2942 16.7851 10.9817 17.0977C10.6691 17.4103 10.2452 17.5859 9.80314 17.5859H2.30314C1.86111 17.5859 1.43719 17.4103 1.12463 17.0977C0.812069 16.7851 0.636475 16.3612 0.636475 15.9192V2.58586C0.636475 2.14383 0.812069 1.71991 1.12463 1.40734C1.43719 1.09478 1.86111 0.919189 2.30314 0.919189Z" fill="currentColor"/><path d="M11.2991 12.8317C11.6241 13.1567 12.1491 13.1567 12.4741 12.8317L15.4641 9.84171C15.6203 9.68544 15.708 9.47352 15.708 9.25255C15.708 9.03158 15.6203 8.81965 15.4641 8.66338L12.4741 5.67338C12.3156 5.53021 12.1083 5.45337 11.8948 5.45876C11.6814 5.46415 11.4782 5.55135 11.3272 5.70233C11.1762 5.85331 11.089 6.05654 11.0836 6.26999C11.0782 6.48344 11.1551 6.69081 11.2982 6.84921L12.8616 8.41921H5.63656C5.41554 8.41921 5.20358 8.50701 5.0473 8.66329C4.89102 8.81957 4.80322 9.03153 4.80322 9.25255C4.80322 9.47356 4.89102 9.68552 5.0473 9.8418C5.20358 9.99808 5.41554 10.0859 5.63656 10.0859H12.8616L11.2982 11.6559C11.1427 11.8121 11.0554 12.0235 11.0556 12.244C11.0557 12.4644 11.1433 12.6758 11.2991 12.8317Z" fill="currentColor"/></svg>
        Sair<div class="tooltiptext">Sair do Avantpro</div></button>

        <button class="btn btn-disabled" style="cursor: pointer;" onclick="abrirExcelPesquisa()"><svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.04074 0.418945H11.3265C11.819 0.418945 12.2914 0.619123 12.6396 0.975442C12.9879 1.33176 13.1836 1.81503 13.1836 2.31895V17.5189C13.1836 18.0229 12.9879 18.5061 12.6396 18.8624C12.2914 19.2188 11.819 19.4189 11.3265 19.4189H2.04074C1.54819 19.4189 1.07582 19.2188 0.727538 18.8624C0.379256 18.5061 0.183594 18.0229 0.183594 17.5189V2.31895C0.183594 1.81503 0.379256 1.33176 0.727538 0.975442C1.07582 0.619123 1.54819 0.418945 2.04074 0.418945ZM2.04074 2.31895V6.11895H11.3265V2.31895H2.04074ZM2.04074 8.01895V9.91895H3.89788V8.01895H2.04074ZM5.75502 8.01895V9.91895H7.61216V8.01895H5.75502ZM9.46931 8.01895V9.91895H11.3265V8.01895H9.46931ZM2.04074 11.8189V13.7189H3.89788V11.8189H2.04074ZM5.75502 11.8189V13.7189H7.61216V11.8189H5.75502ZM9.46931 11.8189V13.7189H11.3265V11.8189H9.46931ZM2.04074 15.6189V17.5189H3.89788V15.6189H2.04074ZM5.75502 15.6189V17.5189H7.61216V15.6189H5.75502ZM9.46931 15.6189V17.5189H11.3265V15.6189H9.46931Z" fill="currentColor"/></svg><div class="tooltiptext" style="width: 200px;">Recurso disponível para assinantes Ultra</div></button>

        <button class="btn btn-disabled" style="cursor: pointer;" onclick="abrirAnaliseMercadoPremium()"><svg width="16" height="20" viewBox="0 0 197 232" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.160156" y="121.496" width="40" height="110" fill="currentColor"/><rect x="52.2922" y="81.4956" width="40" height="150" fill="currentColor"/><rect x="104.424" y="101.496" width="40" height="130" fill="currentColor"/><rect x="156.556" y="66.6699" width="40" height="165" fill="currentColor"/><circle cx="20.1602" cy="71.6655" r="15" fill="currentColor"/><circle cx="72.2922" cy="31.6655" r="15" fill="currentColor"/><circle cx="124.424" cy="51.6699" r="15" fill="currentColor"/><circle cx="176.556" cy="15.0698" r="15" fill="currentColor"/><path d="M19.2476 74.2711L72.4429 31.2452L124.465 53.5404L177.269 15.5996" stroke="currentColor" stroke-width="13"/></svg><div class="tooltiptext" style="width: 200px;">Recurso disponível para assinantes Ultra</div></button>`;

      try {
        document.getElementsByClassName('pesquisa-semelhante')[0].insertAdjacentElement("afterEnd", btnLinha);
      } catch (err) {
        document.getElementsByClassName('ui-search-search-result shops__result')[0].insertAdjacentElement("afterEnd", btnLinha);
      }
    }

    medalhaVendedor.innerHTML = //`${ultra ? `<center><span class="baixeApp">Baixe o aplicativo Avantpro Ultra</span></center>` : ``}`
      //+ `<center>${ultra ? `<a href="https://linktr.ee/meliproapp" target="_blank"><img width="250px" src="https://ramcloud.com.br/img/qrcode.png?time=${new Date().getTime()}" /></a> ` : ``}</center>`
      /* html */
      `<center>${ultra ? `<a href="${linkMenuUltra.MENSAGEM}" target="_blank"><img width="200px" src="https://ramcloud.com.br/img/logomeliproMenuExtUltra.png?time=${new Date().getTime()}" /></a> ` : `<a href="${linkMenuPremium.MENSAGEM}" target="_blank"><img width="200px" src="https://ramcloud.com.br/img/logomeliproMenuExtPremium.png?time=${new Date().getTime()}" /></a>`}</center>
      <center><small style="color: gray; font-size: 12px; margin-top: -10px">${ultra ? `Assinatura Ultra` : `Assinatura Premium`}</small></center>
      <center><p style="font-size: 13px; font-weight: 600; color: var(--grey);">Fique por dentro das novidades!</p></center>
      <div class="linha-2">
        <button class="btn btn-success" onClick="javascript:window.open('https://linktr.ee/grupoavantpro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.4389 3.74208C16.5175 2.81601 15.42 2.08175 14.2104 1.58214C13.0008 1.08252 11.7034 0.827551 10.3937 0.832091C4.90628 0.832091 0.433918 5.28208 0.433918 10.7421C0.433918 12.4921 0.896229 14.1921 1.76055 15.692L0.353516 20.832L5.6299 19.452C7.08718 20.242 8.72537 20.662 10.3937 20.662C15.8812 20.662 20.3535 16.212 20.3535 10.7521C20.3535 8.10207 19.3183 5.61208 17.4389 3.74208ZM10.3937 18.982C8.90628 18.982 7.44899 18.582 6.17261 17.832L5.8711 17.652L2.73542 18.472L3.5696 15.432L3.36859 15.122C2.54221 13.809 2.1034 12.2913 2.10226 10.7421C2.10226 6.20207 5.82085 2.50209 10.3837 2.50209C12.5947 2.50209 14.6751 3.36208 16.2329 4.92208C17.0042 5.68604 17.6155 6.59474 18.0313 7.5955C18.4471 8.59626 18.6591 9.66917 18.655 10.7521C18.6751 15.292 14.9565 18.982 10.3937 18.982ZM14.9364 12.8221C14.6852 12.7021 13.459 12.1021 13.2379 12.0121C13.0068 11.9321 12.846 11.8921 12.6751 12.1321C12.5043 12.3821 12.0319 12.9421 11.8912 13.1021C11.7505 13.2721 11.5997 13.2921 11.3485 13.1621C11.0972 13.0421 10.2932 12.7721 9.34849 11.9321C8.60477 11.2721 8.11231 10.4621 7.96156 10.2121C7.82085 9.96206 7.94145 9.83206 8.07211 9.70206C8.18266 9.59206 8.32336 9.41206 8.44397 9.27207C8.56457 9.13206 8.61482 9.02207 8.69522 8.86207C8.77563 8.69207 8.73542 8.55207 8.67512 8.43207C8.61482 8.31207 8.11231 7.09207 7.9113 6.59207C7.7103 6.11208 7.49924 6.17207 7.34849 6.16208H6.86608C6.69522 6.16208 6.43392 6.22207 6.20276 6.47207C5.98166 6.72207 5.33844 7.32207 5.33844 8.54207C5.33844 9.76206 6.23291 10.9421 6.35352 11.1021C6.47412 11.2721 8.11231 13.7721 10.6048 14.842C11.1977 15.102 11.66 15.252 12.0219 15.362C12.6148 15.552 13.1575 15.522 13.5897 15.462C14.0721 15.392 15.0671 14.862 15.2681 14.2821C15.4791 13.7021 15.4791 13.2121 15.4088 13.1021C15.3384 12.9921 15.1877 12.9421 14.9364 12.8221Z" fill="currentColor"/></svg>WHATSAPP</button>
        <button class="btn btn-info" onClick="javascript:window.open('https://t.me/mercadolivrepro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.3444 1.22126C20.1394 1.02947 19.8912 0.902585 19.6262 0.854103C19.3612 0.805621 19.0892 0.83735 18.8392 0.945917L1.79307 8.33936C1.49408 8.46516 1.24083 8.69601 1.0723 8.99637C0.90378 9.29673 0.829332 9.64994 0.860422 10.0016C0.888159 10.3531 1.01834 10.6853 1.23144 10.9482C1.44454 11.2111 1.72908 11.3907 2.04239 11.4599L6.37318 12.4083V18.3842C6.37302 18.7075 6.45983 19.0236 6.62259 19.2923C6.78535 19.561 7.01673 19.7703 7.28735 19.8935C7.46646 19.9731 7.65757 20.0146 7.85063 20.0159C8.04468 20.0167 8.23692 19.9747 8.41609 19.8924C8.59526 19.8101 8.75776 19.6891 8.89409 19.5366L11.295 16.8954L14.924 20.4238C15.1919 20.6848 15.5363 20.8297 15.8935 20.8317C16.0506 20.8353 16.207 20.8077 16.3552 20.7501C16.5989 20.665 16.8182 20.5111 16.9915 20.3036C17.1648 20.0961 17.2861 19.8423 17.3433 19.5672L20.8153 2.82232C20.876 2.53338 20.8642 2.23164 20.7812 1.94954C20.6983 1.66744 20.5472 1.41565 20.3444 1.22126ZM6.93646 10.8684L2.33788 9.85884L15.2287 4.26022L6.93646 10.8684ZM7.85063 18.3842V13.5505L10.1776 15.8144L7.85063 18.3842ZM15.9028 19.2001L8.29387 11.8066L19.2547 3.06707L15.9028 19.2001Z" fill="currentColor"/></svg>TELEGRAM</button>
      </div>
      <center><p style="margin-top: 10px; margin-bottom: 15px; font-size: 13px; font-weight: 500; color: var(--grey);">Precisa de Ajuda? Mande um Email: <strong style="font-weight: 600;">mlpro@ramsolution.com.br</strong></p></center>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#3D3D3D"/></svg>Concorrência</p>
      <div class="linha">
        <div class="cardInfos" style="border-radius: 50px; min-height: auto !important; width: 100%; display: flex; margin: 2px 0 5px 0;">
          <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Sem</p><p style="font-size: 16px;"><strong>${qtdSemMedalha}</strong></p></div>
          <div class="medalhaLider" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Líder</p><p style="font-size: 16px;"><strong>${qtdLider}</strong></p></div>
          <div class="medalhaGold" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Gold</p><p style="font-size: 16px;"><strong>${qtdGold}</strong></p></div>
          <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Platinum</p><p style="font-size: 16px;"><strong>${qtdPlatinum}</strong></p></div>
        </div>
      </div>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
      <div class="linha">
        <div class="cardInfos cardApendice" style="width: 100%; padding-right: 8px; padding-left: 8px; margin-top: 2px;">
          <div style="display: flex; align-items: center; justify-content: center;">
            <div style="margin-right: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="6" height="10" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.78274 1.43042L4.78274 11.6152M4.78274 11.6152L7.87524 8.643M4.78274 11.6152L1.4193 8.643" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Menor qtd.</p><p><strong>${menorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
            <div class="divMenorVendas" style="position: relative;"><p class="tituloCard"><svg style="margin-right: 4px;" width="7" height="10" viewBox="0 0 10 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.74973 11.615V1.43018M4.74973 1.43018L1.65723 4.40241M4.74973 1.43018L8.11317 4.40241" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Maior qtd.</p><p><strong>${maiorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
            <div style="margin-left: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="7" viewBox="0 0 13 7" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.86401 1.64771H11.1973M1.86401 5.39771H11.1973" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Total</p><p><strong>+ de ${totalVendas.toLocaleString('pt-BR', {})}</strong></p></div>
          </div>
          <span><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="#3166FE" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="#3166FE"/></svg></span>
          <div class="tooltiptext" style="color: white;">
            <p>Quantidade de vendas aproximada conforme tabela de range ML.</p>
            <p style="text-decoration: underline; margin-top: 8px; cursor: pointer; width: fit-content; margin-left: auto; margin-right: 8px" id="btnModalRange">Saiba mais.</p>
          </div>
        </div>
      </div>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important; margin-top: 2px;"><svg style="margin-right: 4px" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 2C4 2.53043 3.78929 3.03914 3.41421 3.41421C3.03914 3.78929 2.53043 4 2 4C1.46957 4 0.960859 3.78929 0.585786 3.41421C0.210714 3.03914 0 2.53043 0 2C0 1.46957 0.210714 0.960859 0.585786 0.585786C0.960859 0.210714 1.46957 0 2 0C2.53043 0 3.03914 0.210714 3.41421 0.585786C3.78929 0.960859 4 1.46957 4 2ZM4 8C4 8.53043 3.78929 9.03914 3.41421 9.41421C3.03914 9.78929 2.53043 10 2 10C1.46957 10 0.960859 9.78929 0.585786 9.41421C0.210714 9.03914 0 8.53043 0 8C0 7.46957 0.210714 6.96086 0.585786 6.58579C0.960859 6.21071 1.46957 6 2 6C2.53043 6 3.03914 6.21071 3.41421 6.58579C3.78929 6.96086 4 7.46957 4 8ZM2 16C2.53043 16 3.03914 15.7893 3.41421 15.4142C3.78929 15.0391 4 14.5304 4 14C4 13.4696 3.78929 12.9609 3.41421 12.5858C3.03914 12.2107 2.53043 12 2 12C1.46957 12 0.960859 12.2107 0.585786 12.5858C0.210714 12.9609 0 13.4696 0 14C0 14.5304 0.210714 15.0391 0.585786 15.4142C0.960859 15.7893 1.46957 16 2 16ZM10 2C10 2.53043 9.78929 3.03914 9.41421 3.41421C9.03914 3.78929 8.53043 4 8 4C7.46957 4 6.96086 3.78929 6.58579 3.41421C6.21071 3.03914 6 2.53043 6 2C6 1.46957 6.21071 0.960859 6.58579 0.585786C6.96086 0.210714 7.46957 0 8 0C8.53043 0 9.03914 0.210714 9.41421 0.585786C9.78929 0.960859 10 1.46957 10 2ZM8 10C8.53043 10 9.03914 9.78929 9.41421 9.41421C9.78929 9.03914 10 8.53043 10 8C10 7.46957 9.78929 6.96086 9.41421 6.58579C9.03914 6.21071 8.53043 6 8 6C7.46957 6 6.96086 6.21071 6.58579 6.58579C6.21071 6.96086 6 7.46957 6 8C6 8.53043 6.21071 9.03914 6.58579 9.41421C6.96086 9.78929 7.46957 10 8 10ZM10 14C10 14.5304 9.78929 15.0391 9.41421 15.4142C9.03914 15.7893 8.53043 16 8 16C7.46957 16 6.96086 15.7893 6.58579 15.4142C6.21071 15.0391 6 14.5304 6 14C6 13.4696 6.21071 12.9609 6.58579 12.5858C6.96086 12.2107 7.46957 12 8 12C8.53043 12 9.03914 12.2107 9.41421 12.5858C9.78929 12.9609 10 13.4696 10 14ZM14 4C14.5304 4 15.0391 3.78929 15.4142 3.41421C15.7893 3.03914 16 2.53043 16 2C16 1.46957 15.7893 0.960859 15.4142 0.585786C15.0391 0.210714 14.5304 0 14 0C13.4696 0 12.9609 0.210714 12.5858 0.585786C12.2107 0.960859 12 1.46957 12 2C12 2.53043 12.2107 3.03914 12.5858 3.41421C12.9609 3.78929 13.4696 4 14 4ZM16 8C16 8.53043 15.7893 9.03914 15.4142 9.41421C15.0391 9.78929 14.5304 10 14 10C13.4696 10 12.9609 9.78929 12.5858 9.41421C12.2107 9.03914 12 8.53043 12 8C12 7.46957 12.2107 6.96086 12.5858 6.58579C12.9609 6.21071 13.4696 6 14 6C14.5304 6 15.0391 6.21071 15.4142 6.58579C15.7893 6.96086 16 7.46957 16 8ZM14 16C14.5304 16 15.0391 15.7893 15.4142 15.4142C15.7893 15.0391 16 14.5304 16 14C16 13.4696 15.7893 12.9609 15.4142 12.5858C15.0391 12.2107 14.5304 12 14 12C13.4696 12 12.9609 12.2107 12.5858 12.5858C12.2107 12.9609 12 13.4696 12 14C12 14.5304 12.2107 15.0391 12.5858 15.4142C12.9609 15.7893 13.4696 16 14 16Z" fill="#3D3D3D"/></svg>Outras informações</p>
      <div class="linha-3">
        <div class="cardInfos" style="width: 80px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.49334 15.4688L5.19789 13.183L2.74334 12.6116L2.98198 9.96875L1.31152 7.96875L2.98198 5.96875L2.74334 3.32589L5.19789 2.75446L6.49334 0.46875L8.81152 1.50446L11.1297 0.46875L12.4252 2.75446L14.8797 3.32589L14.6411 5.96875L16.3115 7.96875L14.6411 9.96875L14.8797 12.6116L12.4252 13.183L11.1297 15.4688L8.81152 14.433L6.49334 15.4688ZM7.07289 13.6473L8.81152 12.8616L10.5843 13.6473L11.5388 11.933L13.4138 11.4688L13.2433 9.46875L14.5047 7.96875L13.2433 6.43304L13.4138 4.43304L11.5388 4.00446L10.5502 2.29018L8.81152 3.07589L7.0388 2.29018L6.08425 4.00446L4.20925 4.43304L4.37971 6.43304L3.11834 7.96875L4.37971 9.46875L4.20925 11.5045L6.08425 11.933L7.07289 13.6473ZM8.09561 10.5045L11.9479 6.46875L10.9933 5.43304L8.09561 8.46875L6.62971 6.96875L5.67516 7.96875L8.09561 10.5045Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg>Oficiais</p><p><strong>${qtdLojasOficiais}</strong></p></div>
        <div class="cardInfos" style="width: 85px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="12" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.79724 12.024L13.4372 6.38399L12.3172 5.26399L7.79724 9.78399L5.51724 7.50399L4.39724 8.62399L7.79724 12.024ZM8.91724 16.344C7.81057 16.344 6.77057 16.1339 5.79724 15.7136C4.8239 15.2939 3.97724 14.724 3.25724 14.004C2.53724 13.284 1.96737 12.4373 1.54764 11.464C1.12737 10.4907 0.917236 9.45066 0.917236 8.34399C0.917236 7.23733 1.12737 6.19733 1.54764 5.22399C1.96737 4.25066 2.53724 3.40399 3.25724 2.68399C3.97724 1.96399 4.8239 1.39386 5.79724 0.973594C6.77057 0.553861 7.81057 0.343994 8.91724 0.343994C10.0239 0.343994 11.0639 0.553861 12.0372 0.973594C13.0106 1.39386 13.8572 1.96399 14.5772 2.68399C15.2972 3.40399 15.8671 4.25066 16.2868 5.22399C16.7071 6.19733 16.9172 7.23733 16.9172 8.34399C16.9172 9.45066 16.7071 10.4907 16.2868 11.464C15.8671 12.4373 15.2972 13.284 14.5772 14.004C13.8572 14.724 13.0106 15.2939 12.0372 15.7136C11.0639 16.1339 10.0239 16.344 8.91724 16.344ZM8.91724 14.744C10.7039 14.744 12.2172 14.124 13.4572 12.884C14.6972 11.644 15.3172 10.1307 15.3172 8.34399C15.3172 6.55733 14.6972 5.04399 13.4572 3.80399C12.2172 2.56399 10.7039 1.94399 8.91724 1.94399C7.13057 1.94399 5.61724 2.56399 4.37724 3.80399C3.13724 5.04399 2.51724 6.55733 2.51724 8.34399C2.51724 10.1307 3.13724 11.644 4.37724 12.884C5.61724 14.124 7.13057 14.744 8.91724 14.744Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Clássicos</p><p><strong>${qtdClassico}</strong></p></div>
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="13.2" height="8.2" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Premium</p><p><strong>${qtdPremium}</strong></p></div>  
      </div>

      <div class="linha-3">
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="9" height="12" viewBox="0 0 11 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.02363 0.674853L0.233168 6.75717C-0.18632 7.13732 0.0496419 7.83862 0.613329 7.89105L5.91592 8.40228L2.73699 12.8329C2.59279 13.0361 2.61245 13.318 2.78942 13.4949C2.98606 13.6915 3.29412 13.6981 3.49731 13.508L10.2878 7.4257C10.7073 7.04556 10.4713 6.34426 9.90761 6.29182L4.60502 5.78059L7.78395 1.34994C7.92815 1.14676 7.90849 0.864925 7.73152 0.687961C7.63885 0.593328 7.51269 0.538916 7.38026 0.536464C7.24783 0.534011 7.11974 0.583715 7.02363 0.674853Z" fill="#3D3D3D"/></svg>FULL</p><p><strong>${qtdFull}</strong></p></div>
        <div class="cardInfos" style="width: 100px;"><p class="tituloCard" style="display: flex; align-items: center;"><svg style="margin-right: 4px;" width="12" height="11" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.60074 1.19312C2.08399 1.19312 1.58841 1.39563 1.22302 1.75611C0.857621 2.11659 0.652344 2.6055 0.652344 3.1153V13.3669C0.652382 13.8457 0.833483 14.3071 1.16021 14.661C1.48693 15.015 1.93577 15.2359 2.41889 15.2806C2.51861 15.8795 2.83057 16.4241 3.29921 16.8174C3.76786 17.2106 4.36277 17.4271 4.97801 17.4281C5.59326 17.4291 6.18891 17.2147 6.6589 16.823C7.12888 16.4313 7.4427 15.8877 7.54448 15.2891H9.34739C9.44869 15.8874 9.76175 16.4308 10.2309 16.8227C10.7001 17.2147 11.295 17.4298 11.9098 17.4298C12.5245 17.4298 13.1194 17.2147 13.5886 16.8227C14.0578 16.4308 14.3708 15.8874 14.4721 15.2891H16.023C16.2789 15.2891 16.5323 15.2394 16.7687 15.1428C17.005 15.0462 17.2198 14.9046 17.4008 14.7261C17.5817 14.5476 17.7252 14.3357 17.8231 14.1025C17.921 13.8693 17.9714 13.6194 17.9714 13.3669V8.7426C17.9713 8.45802 17.9071 8.17703 17.7835 7.9199L16.3123 4.85551C16.1544 4.52665 15.9052 4.24874 15.5935 4.05411C15.2819 3.85947 14.9206 3.75611 14.5518 3.75603H13.2087V3.1153C13.2087 2.6055 13.0034 2.11659 12.638 1.75611C12.2726 1.39563 11.777 1.19312 11.2603 1.19312H2.60074ZM14.3604 14.0077C14.1532 13.4318 13.7449 12.9475 13.2087 12.6416V9.309H16.6725V11.8719H15.5901C15.4178 11.8719 15.2526 11.9394 15.1308 12.0596C15.009 12.1797 14.9406 12.3427 14.9406 12.5126C14.9406 12.6826 15.009 12.8455 15.1308 12.9657C15.2526 13.0859 15.4178 13.1534 15.5901 13.1534H16.6725V13.3669C16.6725 13.5369 16.6041 13.6998 16.4823 13.82C16.3605 13.9402 16.1953 14.0077 16.023 14.0077H14.3604ZM11.9098 12.2991C11.3723 12.2989 10.8481 12.4631 10.4092 12.7691C9.97029 13.0751 9.63836 13.5078 9.4591 14.0077H7.43277C7.25386 13.5079 6.92235 13.0751 6.48386 12.7689C6.04536 12.4627 5.52145 12.298 4.98421 12.2977C4.44697 12.2973 3.92281 12.4612 3.48388 12.7668C3.04495 13.0724 2.71282 13.5047 2.5332 14.0043C2.3735 13.9878 2.22566 13.9135 2.11819 13.7958C2.01073 13.6781 1.95126 13.5253 1.95128 13.3669V3.1153C1.95128 2.94537 2.0197 2.7824 2.1415 2.66224C2.2633 2.54208 2.42849 2.47457 2.60074 2.47457H11.2603C11.4325 2.47457 11.5977 2.54208 11.7195 2.66224C11.8413 2.7824 11.9098 2.94537 11.9098 3.1153V12.2991ZM13.2087 5.03748H14.5509C14.6741 5.03729 14.7947 5.07165 14.8988 5.13654C15.0029 5.20143 15.0862 5.29418 15.1389 5.40398L16.398 8.02754H13.2087V5.03748ZM4.98212 16.1434C4.63762 16.1434 4.30723 16.0084 4.06363 15.7681C3.82004 15.5278 3.68318 15.2018 3.68318 14.862C3.68318 14.5221 3.82004 14.1962 4.06363 13.9558C4.30723 13.7155 4.63762 13.5805 4.98212 13.5805C5.32661 13.5805 5.657 13.7155 5.9006 13.9558C6.1442 14.1962 6.28105 14.5221 6.28105 14.862C6.28105 15.2018 6.1442 15.5278 5.9006 15.7681C5.657 16.0084 5.32661 16.1434 4.98212 16.1434ZM13.2087 14.862C13.2087 15.2018 13.0718 15.5278 12.8282 15.7681C12.5846 16.0084 12.2543 16.1434 11.9098 16.1434C11.5653 16.1434 11.2349 16.0084 10.9913 15.7681C10.7477 15.5278 10.6108 15.2018 10.6108 14.862C10.6108 14.5221 10.7477 14.1962 10.9913 13.9558C11.2349 13.7155 11.5653 13.5805 11.9098 13.5805C12.2543 13.5805 12.5846 13.7155 12.8282 13.9558C13.0718 14.1962 13.2087 14.5221 13.2087 14.862Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Frete grátis</p><p><strong>${qtdFreteGratis}</strong></p></div>
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg>
        Flex</p><p><strong>${qtdFlex}</strong></p></div>  
      </div>

      <div class="linha-3">
        <div class="cardInfos" style="width: 100px; padding-left: 2px; padding-right: 2px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 12 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.76363 20.8397C5.44101 20.8397 5.17039 20.7304 4.95177 20.5118C4.73391 20.2939 4.62498 20.0237 4.62498 19.701V18.3916C3.77099 18.2018 3.02138 17.8697 2.37615 17.3953C1.73091 16.9208 1.20903 16.2566 0.810506 15.4026C0.677664 15.1369 0.67273 14.8572 0.795704 14.5634C0.919437 14.2689 1.14261 14.0552 1.46523 13.9224C1.73091 13.8085 2.00609 13.8135 2.29075 13.9372C2.57541 14.0602 2.79365 14.264 2.94547 14.5486C3.26809 15.118 3.67611 15.5499 4.16952 15.8444C4.66294 16.1382 5.27022 16.2851 5.99136 16.2851C6.76944 16.2851 7.4291 16.1097 7.97033 15.759C8.51081 15.4076 8.78105 14.8618 8.78105 14.1217C8.78105 13.4574 8.5723 12.9306 8.15479 12.5412C7.73729 12.1525 6.76944 11.7115 5.25124 11.2181C3.61917 10.7057 2.4995 10.0939 1.89222 9.38259C1.28494 8.67056 0.981303 7.80215 0.981303 6.77736C0.981303 5.54383 1.37983 4.58546 2.17689 3.90227C2.97394 3.21908 3.78997 2.83004 4.62498 2.73516V1.48264C4.62498 1.16003 4.73391 0.889407 4.95177 0.670786C5.17039 0.452925 5.44101 0.343994 5.76363 0.343994C6.08625 0.343994 6.35687 0.452925 6.57549 0.670786C6.79335 0.889407 6.90228 1.16003 6.90228 1.48264V2.73516C7.62342 2.84902 8.24968 3.08169 8.78105 3.43315C9.31242 3.78385 9.7489 4.2154 10.0905 4.72779C10.2613 4.9745 10.2947 5.24967 10.1907 5.55331C10.0859 5.85695 9.87226 6.0752 9.54964 6.20804C9.28396 6.3219 9.00878 6.32646 8.72412 6.2217C8.43946 6.1177 8.17377 5.93286 7.92706 5.66718C7.68036 5.40149 7.39114 5.1973 7.05941 5.05459C6.72693 4.91263 6.31398 4.84166 5.82056 4.84166C4.98555 4.84166 4.34981 5.02688 3.91333 5.39732C3.47684 5.767 3.2586 6.22702 3.2586 6.77736C3.2586 7.40362 3.54326 7.89703 4.11259 8.25761C4.68191 8.61818 5.66874 8.99773 7.07308 9.39626C8.38252 9.77581 9.37429 10.3782 10.0484 11.2033C10.7217 12.0292 11.0583 12.983 11.0583 14.0647C11.0583 15.4121 10.6598 16.4369 9.86277 17.1391C9.06571 17.8412 8.07888 18.2777 6.90228 18.4485V19.701C6.90228 20.0237 6.79335 20.2939 6.57549 20.5118C6.35687 20.7304 6.08625 20.8397 5.76363 20.8397Z" fill="#303030" stroke="#303030" stroke-width="0.5"/></svg>Patrocinados</p><p><strong>${ultra ? `${patrocinados.length}` : `<button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button>`}</strong></p></div>

        <div class="cardInfos" style="width: 85px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="10" viewBox="0 0 17 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78094 6.19487C1.0631 6.19487 0.483643 6.77554 0.483643 7.49487C0.483643 8.21421 1.0631 8.79487 1.78094 8.79487C2.49878 8.79487 3.07824 8.21421 3.07824 7.49487C3.07824 6.77554 2.49878 6.19487 1.78094 6.19487ZM1.78094 0.994873C1.0631 0.994873 0.483643 1.57554 0.483643 2.29487C0.483643 3.01421 1.0631 3.59487 1.78094 3.59487C2.49878 3.59487 3.07824 3.01421 3.07824 2.29487C3.07824 1.57554 2.49878 0.994873 1.78094 0.994873ZM1.78094 11.3949C1.0631 11.3949 0.483643 11.9842 0.483643 12.6949C0.483643 13.4055 1.07175 13.9949 1.78094 13.9949C2.49013 13.9949 3.07824 13.4055 3.07824 12.6949C3.07824 11.9842 2.49878 11.3949 1.78094 11.3949ZM5.2404 13.5615H15.6188C16.0945 13.5615 16.4836 13.1715 16.4836 12.6949C16.4836 12.2182 16.0945 11.8282 15.6188 11.8282H5.2404C4.76472 11.8282 4.37553 12.2182 4.37553 12.6949C4.37553 13.1715 4.76472 13.5615 5.2404 13.5615ZM5.2404 8.36154H15.6188C16.0945 8.36154 16.4836 7.97154 16.4836 7.49487C16.4836 7.01821 16.0945 6.62821 15.6188 6.62821H5.2404C4.76472 6.62821 4.37553 7.01821 4.37553 7.49487C4.37553 7.97154 4.76472 8.36154 5.2404 8.36154ZM4.37553 2.29487C4.37553 2.77154 4.76472 3.16154 5.2404 3.16154H15.6188C16.0945 3.16154 16.4836 2.77154 16.4836 2.29487C16.4836 1.81821 16.0945 1.42821 15.6188 1.42821H5.2404C4.76472 1.42821 4.37553 1.81821 4.37553 2.29487Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Catálogo</p><p><strong>${qtdCatalogo}</strong></p></div>
        <div class="cardInfos" style="width: 70px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="11" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.7439 8.16L8.56811 0.984171C8.28108 0.697138 7.88242 0.521729 7.4439 0.521729H1.8627C0.985649 0.521729 0.268066 1.23931 0.268066 2.11636V7.69756C0.268066 8.13608 0.443476 8.53474 0.738482 8.82975L7.91431 16.0056C8.20135 16.2926 8.6 16.468 9.03853 16.468C9.47705 16.468 9.87571 16.2926 10.1627 15.9976L15.7439 10.4164C16.0389 10.1294 16.2144 9.73071 16.2144 9.29219C16.2144 8.85366 16.031 8.44703 15.7439 8.16ZM9.03853 14.8814L1.8627 7.69756V2.11636H7.4439V2.10838L14.6197 9.28421L9.03853 14.8814Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.56633 6.01597C5.22685 6.01597 5.7623 5.48051 5.7623 4.82C5.7623 4.15948 5.22685 3.62402 4.56633 3.62402C3.90582 3.62402 3.37036 4.15948 3.37036 4.82C3.37036 5.48051 3.90582 6.01597 4.56633 6.01597Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Oferta</p><p><strong>${qtdOferta}</strong></p></div>
      </div>

      <div class="linha-2">
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="10" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.2226 12.6463L10.3883 5.55484L13.4642 2.4789C13.9284 2.01471 13.9284 1.2653 13.4642 0.801112C13 0.336925 12.2506 0.336925 11.7864 0.801112L8.71047 3.87705L1.61904 2.04267C1.33941 1.96438 1.03181 2.04827 0.824886 2.25519C0.433403 2.64668 0.528478 3.30101 1.00944 3.56946L6.1882 6.39932L3.11786 9.46967L1.09892 8.96074C0.964701 8.92718 0.819293 8.97192 0.724219 9.067L0.399847 9.39137C0.215291 9.57593 0.254439 9.88352 0.472551 10.0121L2.51386 11.2369L2.83823 11.4271L3.00041 11.6899L3.17378 11.9863L3.96794 13.3174L4.24757 13.7872C4.38179 14.0109 4.68379 14.0444 4.86835 13.8599L5.19272 13.5355C5.29339 13.4348 5.33253 13.295 5.29898 13.1608L4.79564 11.1475L7.87158 8.07151L10.7014 13.2503C10.9643 13.7368 11.6186 13.8319 12.0101 13.4404C12.217 13.2335 12.3009 12.9259 12.2226 12.6463Z" fill="var(--grey)"/></svg>Internacional</p><p><strong>${qtdInternacional}</strong></p></div>

        <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="12" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.8427 10.1738C14.5025 10.1738 15.0831 9.81303 15.3821 9.26749L18.5313 3.55693C18.6055 3.42356 18.6435 3.27314 18.6417 3.12055C18.6398 2.96796 18.5982 2.81849 18.5209 2.68694C18.4436 2.55538 18.3333 2.4463 18.2009 2.37049C18.0685 2.29467 17.9186 2.25475 17.766 2.25468H4.74707L3.92019 0.494873H1.0437V2.25468H2.80302L5.96979 8.93312L4.78225 11.0801C4.1401 12.2592 4.98457 13.6934 6.32165 13.6934H16.8776V11.9336H6.32165L7.28928 10.1738H13.8427ZM5.58274 4.01448H16.2706L13.8427 8.41398H7.66753L5.58274 4.01448ZM6.32165 14.5733C5.35403 14.5733 4.57113 15.3652 4.57113 16.3331C4.57113 17.301 5.35403 18.0929 6.32165 18.0929C7.28928 18.0929 8.08097 17.301 8.08097 16.3331C8.08097 15.3652 7.28928 14.5733 6.32165 14.5733ZM15.1182 14.5733C14.1506 14.5733 13.3677 15.3652 13.3677 16.3331C13.3677 17.301 14.1506 18.0929 15.1182 18.0929C16.0859 18.0929 16.8776 17.301 16.8776 16.3331C16.8776 15.3652 16.0859 14.5733 15.1182 14.5733Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Supermercado</p><p><strong>${qtdSupermercado}</strong></p></div>  
      </div>

      <div class="linha-2">
        <div class="cardInfos">
          <p class="tituloCard">
            <svg style="margin-right: 4px;" width="19" height="11" viewBox="0 0 29 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.0166 11.8958C21.2041 11.8961 21.3848 11.8263 21.5233 11.7C21.6618 11.5737 21.748 11.4002 21.765 11.2135C21.7819 11.0269 21.7283 10.8406 21.6148 10.6915C21.5013 10.5424 21.3361 10.4411 21.1516 10.4078L21.1405 10.4057L21.1292 10.4047L21.0392 10.3967L21.0282 10.3958H21.0171H20.0171H19.7671V10.6458V11.6458V11.8958H20.0171H21.0166ZM21.0166 11.8958L21.0171 11.6458M21.0166 11.8958H21.0171V11.6458M21.0171 11.6458H20.2671H20.0171V11.3958V10.8958V10.6458H20.2671H21.0171L21.1071 10.6538C21.2301 10.676 21.3402 10.7435 21.4159 10.8429C21.4916 10.9423 21.5273 11.0665 21.516 11.1909C21.5047 11.3154 21.4472 11.4311 21.3549 11.5152C21.2626 11.5994 21.142 11.646 21.0171 11.6458ZM18.2671 7.39575V7.64575V8.64575V8.89575H18.0171H17.0171H17.006L16.995 8.89477L16.905 8.88677L16.8937 8.88577L16.8826 8.88375C16.6981 8.85036 16.5329 8.74913 16.4194 8.6C16.3059 8.45087 16.2523 8.26464 16.2693 8.07798C16.2862 7.89133 16.3724 7.71778 16.5109 7.59152C16.6493 7.46531 16.83 7.39548 17.0173 7.39575H17.0171H18.2671ZM18.2671 7.39575H18.0171M18.2671 7.39575H18.0171M18.0171 7.39575L17.0176 7.39575L18.0171 7.39575ZM27.7009 16.9583C27.6318 17.109 27.5147 17.2326 27.368 17.3097L27.2748 17.3497L19.2803 20.3477L19.2802 20.3477C19.1476 20.3975 19.0036 20.4087 18.8649 20.3801L18.7449 20.3453L10.7539 17.3487L10.7534 17.3485C10.5958 17.2898 10.4625 17.1798 10.3749 17.0363C10.2873 16.8927 10.2505 16.7239 10.2704 16.5569C10.2903 16.3899 10.3658 16.2345 10.4846 16.1155C10.6018 15.9982 10.7545 15.9231 10.9188 15.9019L11.0315 15.8953L11.2671 15.8817V15.6458V3.64575V3.64574C11.2671 2.94429 11.5351 2.26935 12.0163 1.759C12.4966 1.24955 13.1532 0.942555 13.8521 0.900541L14.0207 0.895752H24.0171C24.7186 0.895713 25.3935 1.16372 25.9039 1.64493C26.4133 2.12529 26.7203 2.78186 26.7623 3.48071L26.7671 3.64929V15.6458V15.8963L27.0176 15.8958C27.1861 15.8954 27.3497 15.9518 27.4822 16.0558C27.6147 16.1598 27.7084 16.3054 27.7481 16.4691C27.7877 16.6328 27.7711 16.8051 27.7009 16.9583ZM12.7671 16.3278V16.501L12.9293 16.5618L18.9293 18.8118L19.0171 18.8448L19.1049 18.8118L25.1049 16.5618L25.2671 16.501V16.3278V3.64575C25.2671 3.31423 25.1354 2.99629 24.901 2.76187C24.6666 2.52745 24.3486 2.39575 24.0171 2.39575H14.0171C13.6856 2.39575 13.3676 2.52745 13.1332 2.76187C12.8988 2.99629 12.7671 3.31423 12.7671 3.64575V16.3278ZM19.7671 5.64575V5.89575H20.0171H22.0171C22.216 5.89575 22.4068 5.97477 22.5474 6.11542C22.6881 6.25607 22.7671 6.44684 22.7671 6.64575C22.7671 6.84466 22.6881 7.03543 22.5474 7.17608C22.4068 7.31673 22.216 7.39575 22.0171 7.39575H20.0171H19.7671V7.64575V8.64575V8.89575H20.0171H21.0171C21.6138 8.89575 22.1861 9.1328 22.6081 9.55476C23.0301 9.97672 23.2671 10.549 23.2671 11.1458C23.2671 11.7425 23.0301 12.3148 22.6081 12.7367C22.1861 13.1587 21.6138 13.3958 21.0171 13.3958H20.0171H19.7671V13.6458V14.6458C19.7671 14.8447 19.6881 15.0354 19.5474 15.1761C19.4068 15.3167 19.216 15.3958 19.0171 15.3958C18.8182 15.3958 18.6274 15.3167 18.4868 15.1761C18.3461 15.0354 18.2671 14.8447 18.2671 14.6458V13.6458V13.3958H18.0171H16.0171C15.8182 13.3958 15.6274 13.3167 15.4868 13.1761C15.3461 13.0354 15.2671 12.8447 15.2671 12.6458C15.2671 12.4468 15.3461 12.2561 15.4868 12.1154C15.6274 11.9748 15.8182 11.8958 16.0171 11.8958H18.0171H18.2671V11.6458V10.6458V10.3958H18.0171H17.0171C16.4204 10.3958 15.8481 10.1587 15.4261 9.73674C15.0042 9.31479 14.7671 8.74249 14.7671 8.14575C14.7671 7.54902 15.0042 6.97672 15.4261 6.55476C15.8481 6.1328 16.4204 5.89575 17.0171 5.89575H18.0171H18.2671V5.64575V4.64575C18.2671 4.44684 18.3461 4.25607 18.4868 4.11542C18.6274 3.97477 18.8182 3.89575 19.0171 3.89575C19.216 3.89575 19.4068 3.97477 19.5474 4.11542C19.6881 4.25607 19.7671 4.44684 19.7671 4.64575V5.64575Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.82644 4.68677L4.82644 14.8716M4.82644 14.8716L7.91895 11.8993M4.82644 14.8716L1.463 11.8993" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Menor preço
          </p>
          <p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(menorPreco)}</strong></p>
        </div>
        <div class="cardInfos">
          <p class="tituloCard">
            <svg style="margin-right: 4px;" width="21" height="13" viewBox="0 0 28 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M23.6809 0.645752C24.4461 0.645709 25.1824 0.938077 25.7392 1.46304C26.2959 1.98799 26.631 2.70586 26.6759 3.46975L26.6809 3.64575V15.6458C26.9055 15.6453 27.1237 15.7205 27.3004 15.8591C27.4771 15.9978 27.6019 16.192 27.6548 16.4102C27.7077 16.6285 27.6856 16.8583 27.592 17.0624C27.4984 17.2666 27.3388 17.4333 27.1389 17.5358L27.0319 17.5818L19.0319 20.5818C18.8518 20.6494 18.656 20.6636 18.4679 20.6228L18.3299 20.5828L10.3299 17.5828C10.1198 17.5045 9.94208 17.3579 9.8253 17.1665C9.70851 16.9751 9.65945 16.75 9.68598 16.5273C9.71252 16.3047 9.81311 16.0974 9.9716 15.9388C10.1301 15.7802 10.3373 15.6794 10.5599 15.6528L10.6809 15.6458V3.64575C10.6809 2.88054 10.9732 2.14424 11.4982 1.58749C12.0232 1.03075 12.741 0.695644 13.5049 0.650752L13.6809 0.645752H23.6809ZM23.6809 2.64575H13.6809C13.4157 2.64575 13.1614 2.75111 12.9738 2.93865C12.7863 3.12618 12.6809 3.38054 12.6809 3.64575V16.3278L18.6809 18.5778L24.6809 16.3278V3.64575C24.6809 3.38054 24.5756 3.12618 24.388 2.93865C24.2005 2.75111 23.9461 2.64575 23.6809 2.64575ZM18.6809 3.64575C18.9461 3.64575 19.2005 3.75111 19.388 3.93865C19.5756 4.12618 19.6809 4.38054 19.6809 4.64575V5.64575H21.6809C21.9461 5.64575 22.2005 5.75111 22.388 5.93865C22.5756 6.12618 22.6809 6.38054 22.6809 6.64575C22.6809 6.91097 22.5756 7.16532 22.388 7.35286C22.2005 7.54039 21.9461 7.64575 21.6809 7.64575H19.6809V8.64575H20.6809C21.344 8.64575 21.9798 8.90914 22.4487 9.37799C22.9175 9.84683 23.1809 10.4827 23.1809 11.1458C23.1809 11.8088 22.9175 12.4447 22.4487 12.9135C21.9798 13.3824 21.344 13.6458 20.6809 13.6458H19.6809V14.6458C19.6809 14.911 19.5756 15.1653 19.388 15.3529C19.2005 15.5404 18.9461 15.6458 18.6809 15.6458C18.4157 15.6458 18.1614 15.5404 17.9738 15.3529C17.7863 15.1653 17.6809 14.911 17.6809 14.6458V13.6458H15.6809C15.4157 13.6458 15.1614 13.5404 14.9738 13.3529C14.7863 13.1653 14.6809 12.911 14.6809 12.6458C14.6809 12.3805 14.7863 12.1262 14.9738 11.9386C15.1614 11.7511 15.4157 11.6458 15.6809 11.6458H17.6809V10.6458H16.6809C16.0179 10.6458 15.382 10.3824 14.9132 9.91352C14.4443 9.44468 14.1809 8.80879 14.1809 8.14575C14.1809 7.48271 14.4443 6.84683 14.9132 6.37799C15.382 5.90914 16.0179 5.64575 16.6809 5.64575H17.6809V4.64575C17.6809 4.38054 17.7863 4.12618 17.9738 3.93865C18.1614 3.75111 18.4157 3.64575 18.6809 3.64575ZM20.6809 10.6458H19.6809V11.6458H20.6809C20.8059 11.646 20.9264 11.5994 21.0187 11.5152C21.111 11.4311 21.1685 11.3154 21.1798 11.1909C21.1911 11.0665 21.1554 10.9423 21.0797 10.8429C21.004 10.7435 20.8939 10.676 20.7709 10.6538L20.6809 10.6458ZM17.6809 7.64575H16.6809C16.556 7.64552 16.4355 7.69208 16.3431 7.77626C16.2508 7.86044 16.1933 7.97614 16.182 8.10057C16.1708 8.22501 16.2065 8.34916 16.2821 8.44858C16.3578 8.54801 16.468 8.61549 16.5909 8.63775L16.6809 8.64575H17.6809V7.64575Z" fill="#3D3D3D"/><path d="M4.89207 14.8713V4.68652M4.89207 4.68652L1.79956 7.65876M4.89207 4.68652L7.83802 7.65876" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Maior preço
          </p>
          <p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(maiorPreco)}</strong></p></div>
      </div>

      
      <center><p style="margin-top: 10px; font-size: 12px">Informações: <strong>Avantpro</strong></p></center>
      <button style="margin-left: auto; margin-right: auto;" class="btn btn-info" onClick="javascript:window.open('https://avantpro.com.br/', '_blank');">Conheça outras ferramentas</button>
      ${rawVendedoresCompleto == undefined ? '' : `<div style="display: flex; align-items: center; margin: 25px 5px 10px 5px;"><p style="font-size: 15px; font-weight: 700; color: var(--grey); margin-right: auto;"><svg width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.41895 0.593018C9.47981 0.593018 10.4972 1.01444 11.2474 1.76459C11.9975 2.51474 12.4189 3.53215 12.4189 4.59302C12.4189 5.65388 11.9975 6.6713 11.2474 7.42144C10.4972 8.17159 9.47981 8.59302 8.41895 8.59302C7.35808 8.59302 6.34066 8.17159 5.59052 7.42144C4.84037 6.6713 4.41895 5.65388 4.41895 4.59302C4.41895 3.53215 4.84037 2.51474 5.59052 1.76459C6.34066 1.01444 7.35808 0.593018 8.41895 0.593018ZM8.41895 10.593C12.8389 10.593 16.4189 12.383 16.4189 14.593V16.593H0.418945V14.593C0.418945 12.383 3.99895 10.593 8.41895 10.593Z" fill="#3D3D3D"/></svg> Vendedores nessa página (${rawVendedoresCompleto.length})</p>

      <button class="btnMostraVendedor" id="btnMostrarVendedor"><svg style="transform: rotate(180deg);" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
      </div>

      <div class="infoEscondida escondeInfo">
        <div class="linha" style="margin-bottom: 15px;">
          ${ultra ? `<div class="searchBar">
            <input style="height: 35px;" placeholder="Procure por uma loja" type="search" id="searchVendedor"></input>
            <button style="height: 35px;" class="btn-searchbar">
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
            </button>
          </div>

          <div style="position: relative;">
            <button class="btn btn-light" data-dropdown-btn><svg style="margin-right: 4px;" width="13" height="9" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.10199 9.1978C9.29153 9.19801 9.47384 9.27059 9.61166 9.40069C9.74949 9.5308 9.83243 9.70863 9.84353 9.89784C9.85464 10.087 9.79308 10.2734 9.67143 10.4187C9.54977 10.564 9.37721 10.6574 9.189 10.6798L9.10199 10.685H6.1274C5.93786 10.6848 5.75556 10.6122 5.61773 10.4821C5.47991 10.352 5.39697 10.1742 5.38586 9.985C5.37475 9.79579 5.43631 9.60948 5.55797 9.46414C5.67962 9.3188 5.85218 9.22539 6.0404 9.20301L6.1274 9.1978H9.10199ZM11.3329 4.73611C11.5302 4.73611 11.7193 4.81445 11.8588 4.95391C11.9982 5.09336 12.0766 5.2825 12.0766 5.47972C12.0766 5.67694 11.9982 5.86608 11.8588 6.00554C11.7193 6.14499 11.5302 6.22334 11.3329 6.22334H3.89646C3.69924 6.22334 3.51009 6.14499 3.37062 6.00554C3.23116 5.86608 3.15282 5.67694 3.15282 5.47972C3.15282 5.2825 3.23116 5.09336 3.37062 4.95391C3.51009 4.81445 3.69924 4.73611 3.89646 4.73611H11.3329ZM13.5639 0.274414C13.7611 0.274414 13.9502 0.352759 14.0897 0.492214C14.2292 0.631669 14.3075 0.820811 14.3075 1.01803C14.3075 1.21525 14.2292 1.40439 14.0897 1.54385C13.9502 1.6833 13.7611 1.76165 13.5639 1.76165H1.66552C1.46829 1.76165 1.27914 1.6833 1.13968 1.54385C1.00022 1.40439 0.921875 1.21525 0.921875 1.01803C0.921875 0.820811 1.00022 0.631669 1.13968 0.492214C1.27914 0.352759 1.46829 0.274414 1.66552 0.274414H13.5639Z" fill="#3D3D3D"/></svg>Filtrar</button>
            <div class="dropdown-content" data-dropdown-content>
              <ul style="font-size: 13px; color: var(--grey);">
                <li><a class="filtro-vendedor active">Todos</a></li>
                <li><a class="filtro-vendedor">Sem medalha</a></li>
                <li><a class="filtro-vendedor">Mercado Líder</a></li>
                <li><a class="filtro-vendedor">Mercado Gold</a></li>
                <li><a class="filtro-vendedor">Mercado Platinum</a></li>
                <li><a class="filtro-vendedor">Lojas oficiais</a></li>
              </ul>
            </div>
          </div>
          ` : `
          <div class="searchBar" style="position: relative;">
            <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
            <input style="height: 35px;" placeholder="Procure por uma loja" type="search" disabled></input>
            <button style="height: 35px;" class="btn-searchbar" disabled>
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
            </button>
          </div>
          
          <div>
            <button class="btn btn-light" data-dropdown-btn disabled><svg style="margin-right: 4px;" width="13" height="9" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.10199 9.1978C9.29153 9.19801 9.47384 9.27059 9.61166 9.40069C9.74949 9.5308 9.83243 9.70863 9.84353 9.89784C9.85464 10.087 9.79308 10.2734 9.67143 10.4187C9.54977 10.564 9.37721 10.6574 9.189 10.6798L9.10199 10.685H6.1274C5.93786 10.6848 5.75556 10.6122 5.61773 10.4821C5.47991 10.352 5.39697 10.1742 5.38586 9.985C5.37475 9.79579 5.43631 9.60948 5.55797 9.46414C5.67962 9.3188 5.85218 9.22539 6.0404 9.20301L6.1274 9.1978H9.10199ZM11.3329 4.73611C11.5302 4.73611 11.7193 4.81445 11.8588 4.95391C11.9982 5.09336 12.0766 5.2825 12.0766 5.47972C12.0766 5.67694 11.9982 5.86608 11.8588 6.00554C11.7193 6.14499 11.5302 6.22334 11.3329 6.22334H3.89646C3.69924 6.22334 3.51009 6.14499 3.37062 6.00554C3.23116 5.86608 3.15282 5.67694 3.15282 5.47972C3.15282 5.2825 3.23116 5.09336 3.37062 4.95391C3.51009 4.81445 3.69924 4.73611 3.89646 4.73611H11.3329ZM13.5639 0.274414C13.7611 0.274414 13.9502 0.352759 14.0897 0.492214C14.2292 0.631669 14.3075 0.820811 14.3075 1.01803C14.3075 1.21525 14.2292 1.40439 14.0897 1.54385C13.9502 1.6833 13.7611 1.76165 13.5639 1.76165H1.66552C1.46829 1.76165 1.27914 1.6833 1.13968 1.54385C1.00022 1.40439 0.921875 1.21525 0.921875 1.01803C0.921875 0.820811 1.00022 0.631669 1.13968 0.492214C1.27914 0.352759 1.46829 0.274414 1.66552 0.274414H13.5639Z" fill="#3D3D3D"/></svg>Filtrar
            <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
            </button>
          </div>`}
          
        </div>
        `
        + anunciosPorVendas + `
        
        <button class="btn btn-light" id="btnFechaVendedor" style="margin: 5px auto 5px auto;">Ocultar vendedores<svg style="margin-left: 4px;" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
        </div>`

      }
      
      <div id="modalRange" class="modalFaturamento">
        <div class="modalBody">
            <div class="closeModal" id="closeMdlFaturamento"><svg width="13" height="13" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></div>
            <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 25px; color: var(--grey);">
            <h2 style="font-weight: 900;">Range de vendas ML</h2></div>
            
            <div style="display: flex; justify-content: center;">
              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>1 venda</p>
                    <p>1 vendido</p>
                  </div>
                  <div class="row-tabela">
                    <p>2 vendas</p>
                    <p>2 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>3 vendas</p>
                    <p>3 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>4 vendas</p>
                    <p>4 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>5 vendas</p>
                    <p>5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 6 a 25 vendas</p>
                    <p>+5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 26 a 50 vendas</p>
                    <p>+25 vendidos</p>
                  </div>
                </div>
              </div>

              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>De 51 a 100 vendas</p>
                    <p>+50 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 101 a 150 vendas</p>
                    <p>+100 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 151 a 200 vendas</p>
                    <p>+150 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 201 a 250 vendas</p>
                    <p>+200 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 251 a 500 vendas</p>
                    <p>+250 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 501 a 5.000 vendas</p>
                    <p>+500 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 5.001 a 50.000 vendas</p>
                    <p>+5.000 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 50.001 a 500.000 vendas</p>
                    <p>+50.000 vendidos</p>
                  </div>
                </div>
              </div>
            </div>

            <div style="text-align: center; margin-top: 16px;"><p>Informações oficiais oferecidas pelo ML. <a href="https://developers.mercadolivre.com.br/pt_br/itens-e-buscas#Valores-nos-campos-sold-quantity-e-available-quantity" target="_blank">Leia aqui.</a></p></div>

        </div>
            
      </div>
      
      `

    // + `${ultra ? `<p class="p-ads">Anúncios Patrocinados: <strong>${patrocinados.length}</strong> </p>` : ''}`

    document.getElementsByClassName('ui-search-filter-groups')[0].insertAdjacentElement("afterbegin", medalhaVendedor);

    /* Sair do Avantpro */
    $('#sairmlpro').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });

    /* Mostrar vendedores */
    var bntMostrarVendedor = document.getElementById("btnMostrarVendedor");
    var btnFechaVendedor = document.getElementById("btnFechaVendedor");
    var infoEscondida = document.getElementsByClassName("infoEscondida")[0];

    bntMostrarVendedor.addEventListener("click", function () {

      if (infoEscondida.classList.contains("escondeInfo")) {
        bntMostrarVendedor.style.transform = "rotate(-180deg)";
        infoEscondida.classList.add("mostraInfo");
        infoEscondida.classList.remove("escondeInfo");
        document.getElementsByClassName("mostraInfo")[0].style.animation = "downInformation .3s";
      }

      else {
        bntMostrarVendedor.style.transform = "rotate(0deg)";
        document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
        setTimeout(function () {
          infoEscondida.classList.add("escondeInfo");
          infoEscondida.classList.remove("mostraInfo");
        }, 305);
      }
    });

    btnFechaVendedor.addEventListener("click", function () {
      bntMostrarVendedor.style.transform = "rotate(0deg)";
      document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
      setTimeout(function () {
        infoEscondida.classList.add("escondeInfo");
        infoEscondida.classList.remove("mostraInfo");
      }, 299);

    });
    /* Fim do mostrar vendedores */


    /* Searchbar vendedores */
    var searchBar = document.getElementById("searchVendedor");

    searchBar?.addEventListener("keyup", e => {
      const texto = e.target.value.toUpperCase();
      var vendedores = [].slice.call(document.getElementsByClassName("vendedores"));

      for (let i = 0; i < vendedores.length; i++) {

        const vendedorVisivel = vendedores[i].querySelector('[data-vendedor-nome]').innerHTML.includes(texto);
        vendedores[i].classList.toggle("vendedorEscondido", !vendedorVisivel);

      }
    })
    /* Fim Searchbar vendedores */


    /* Filtrar vendedores */
    const btnDropdown = document.querySelector("[data-dropdown-btn]"); //Botão do dropdown
    const contentDropdown = document.querySelector("[data-dropdown-content]");

    btnDropdown.addEventListener("click", () => {
      contentDropdown.classList.toggle("show-dropdown");
    })

    window.onclick = function (event) { //Fechar dropdown quando clicar fora da tela
      if (event.target != btnDropdown) {
        if (contentDropdown.classList.contains('show-dropdown')) {
          contentDropdown.classList.remove('show-dropdown');
        }
      }
    }


    var filtro = [].slice.call(document.getElementsByClassName("filtro-vendedor"));
    var vendedores = [].slice.call(document.getElementsByClassName("vendedores"));
    for (let i = 0; i < filtro.length; i++) {
      filtro[i].addEventListener('click', () => {
        vendedores.forEach(vendedor => {
          switch (i) {
            case 0:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[0].classList.add('active');

              break
            case 1:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';
              !vendedor.querySelector('[data-vendedor-sem]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[1].classList.add('active');

              break;

            case 2:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-silver]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[2].classList.add('active');

              break;

            case 3:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-gold]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[3].classList.add('active');

              break;

            case 4:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-platinum]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[4].classList.add('active');

              break;

            case 5:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-oficial]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[5].classList.add('active');

              break;

            default:
              break;
          }
        });
      })
    }
    /* Fim filtrar vendedores */


    var modalRange = document.getElementById("modalRange");
    var btnModalRange = document.getElementById("btnModalRange");

    var closeMdl = document.getElementsByClassName("closeModal");

    // var infoSobeModal = document.getElementsByClassName("ui-pdp-container__col col-2 ui-pdp-container--column-left pb-40")[0];
    // var containerMl = document.getElementsByClassName('shops__ui-main')[0]

    function abreModalRange() {
      modalRange.classList.toggle("openModal");
    }

    function unloadScrollBars() { //Desativa scroll da pagina
      // containerMl.style.zIndex = 20
      // infoSobeModal.style.zIndex = -1;
      document.documentElement.style.overflow = 'hidden';
      document.body.scroll = "no";
    }

    function reloadScrollBars() { //Ativa scroll da pagina
      // setTimeout(() => {
      //   infoSobeModal.style.zIndex = '';
      //   containerMl.style.zIndex = '';
      // }, 200);
      document.documentElement.style.overflow = 'auto';
      document.body.scroll = "yes";
    }

    btnModalRange.addEventListener("click", abreModalRange);
    btnModalRange.addEventListener("click", unloadScrollBars);

    for (let i = 0; i <= closeMdl.length; i++) {
      if (closeMdl[i]) {
        closeMdl[i].addEventListener("click", () => {
          reloadScrollBars();

          if (modalRange.classList.contains('openModal')) {
            abreModalRange();
          }
        });
      }
    };


  }

  static menuLateralMaisVendidos(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, rawVendedoresCompleto, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdOferta, qtdInternacional, ultra, qtdFlex) {


    /**Linha para o botão sair Avantpro */
    var btnLinha = document.createElement("div");
    btnLinha.className = "linha";
    btnLinha.style.marginTop = "20px";
    btnLinha.style.marginBottom = "30px";

    btnLinha.innerHTML = /* html */`
      <button class="btn btn-danger" id="sairmlpro" style="margin-right: auto; position: relative; font-weight: 500" title="Sair do Avantpro" role="button"><svg style="margin-right: 5px;" width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.30314 0.919189H9.80314C10.2452 0.919189 10.6691 1.09478 10.9817 1.40734C11.2942 1.71991 11.4698 2.14383 11.4698 2.58586V3.41919C11.4698 3.6402 11.382 3.85216 11.2257 4.00844C11.0695 4.16473 10.8575 4.25252 10.6365 4.25252C10.4155 4.25252 10.2035 4.16473 10.0472 4.00844C9.89094 3.85216 9.80314 3.6402 9.80314 3.41919V2.58586H2.30314V15.9192H9.80314V15.0859C9.80314 14.8648 9.89094 14.6529 10.0472 14.4966C10.2035 14.3403 10.4155 14.2525 10.6365 14.2525C10.8575 14.2525 11.0695 14.3403 11.2257 14.4966C11.382 14.6529 11.4698 14.8648 11.4698 15.0859V15.9192C11.4698 16.3612 11.2942 16.7851 10.9817 17.0977C10.6691 17.4103 10.2452 17.5859 9.80314 17.5859H2.30314C1.86111 17.5859 1.43719 17.4103 1.12463 17.0977C0.812069 16.7851 0.636475 16.3612 0.636475 15.9192V2.58586C0.636475 2.14383 0.812069 1.71991 1.12463 1.40734C1.43719 1.09478 1.86111 0.919189 2.30314 0.919189Z" fill="currentColor"/><path d="M11.2991 12.8317C11.6241 13.1567 12.1491 13.1567 12.4741 12.8317L15.4641 9.84171C15.6203 9.68544 15.708 9.47352 15.708 9.25255C15.708 9.03158 15.6203 8.81965 15.4641 8.66338L12.4741 5.67338C12.3156 5.53021 12.1083 5.45337 11.8948 5.45876C11.6814 5.46415 11.4782 5.55135 11.3272 5.70233C11.1762 5.85331 11.089 6.05654 11.0836 6.26999C11.0782 6.48344 11.1551 6.69081 11.2982 6.84921L12.8616 8.41921H5.63656C5.41554 8.41921 5.20358 8.50701 5.0473 8.66329C4.89102 8.81957 4.80322 9.03153 4.80322 9.25255C4.80322 9.47356 4.89102 9.68552 5.0473 9.8418C5.20358 9.99808 5.41554 10.0859 5.63656 10.0859H12.8616L11.2982 11.6559C11.1427 11.8121 11.0554 12.0235 11.0556 12.244C11.0557 12.4644 11.1433 12.6758 11.2991 12.8317Z" fill="currentColor"/></svg>Sair<div class="tooltiptext">Sair do Avantpro</div></button>
    `;

    document.getElementsByClassName('ui-search-breadcrumb__title shops-custom-primary-font')[0].insertBefore(btnLinha, document.getElementsByClassName('seller-subtitle')[0]);

    // document.getElementsByClassName('seller-title')[0].insertAdjacentElement("beforeend", btnLinha);


    // renderiza a medalha do vendedor
    let medalhaVendedor = document.createElement('div')
    medalhaVendedor.className = 'ui-menu-lateral'
    medalhaVendedor.style.fontWeight = '500'

    let anunciosPorVendas = '';

    for (let i = 0; i < rawVendedoresCompleto.length; i++) {
      let full = '';
      let gratis = '';
      let reputacao = '';
      let estado = '';
      for (let x = 0; x < rawVendedoresCompleto[i].val.available_filters.length; x++) {
        if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping") full = rawVendedoresCompleto[i].val.available_filters[x].values.length == 2 ? rawVendedoresCompleto[i].val.available_filters[x].values[1].results : 0;
        if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping_cost") gratis = rawVendedoresCompleto[i].val.available_filters[x].values[0].results
      }

      // Reputação
      switch (rawVendedoresCompleto[i].val.seller.seller_reputation.level_id) {
        case '5_green':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="green" />
          </svg>
          `
          break;
        case '4_light_green':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgreen" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
          break;
        case '3_yellow':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="yellow" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
          break;
        case '2_orange':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="orange" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
          `
          break;
        case '1_red':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="red" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
         `
          break;
        default:
          reputacao =
            `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
          </svg>
          `;
          break;
      }

      // Vendedores
      if (rawVendedoresCompleto[i].val.results.length > 0) {
        anunciosPorVendas += /* html */`
    <div class="vendedores">
      <button class="btn btn-success" style="position: absolute; right: 0; margin-top: -5px; border-radius: 50%; width: 23.5px; padding: 3px; display: none;">
          <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg>
      </button>

      <div style="display: flex; align-items: baseline; margin-bottom: 5px;">
        <h4 class="nome-vendedor" style="font-size: initial; margin: initial;">${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "platinum" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-platinum><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "gold" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-gold><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "silver" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-silver><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg" data-vendedor-sem><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}`}`}
        ${ultra ? `<a href="https://lista.mercadolivre.com.br/_CustId_${rawVendedoresCompleto[i].val.seller.id}" target="_blank" data-vendedor-nome>${rawVendedoresCompleto[i].val.seller.nickname}</a></h4>` : rawVendedoresCompleto[i].val.seller.nickname} </h4>` +
          '<p class="tituloCard" style="margin-bottom: 0px; margin-left: 4px;">: ' + rawVendedoresCompleto[i].val.qtdAnuncio + ' anúncio(s)</p> </div>'

          + `${ultra ? `<p style="font-size: 13px; text-align: center; margin-bottom: 10px;"><a href="https://lista.mercadolivre.com.br/_CustId_${rawVendedoresCompleto[i].val.seller.id}_PublishedToday_YES" target="_blank">Verificar se Criou Anúncios nas Últimas 24h</a></p>` : ''}
        
      <div class="linha-2" style="text-align: start; align-items: start;">
        <div>
          <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="10" height="13" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
          <ul style="padding-left: 0; margin-top: initial; margin-bottom: initial;">
            <li style="list-style: none">Concluidas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.completed}</strong></li>
            <li style="list-style: none">Canceladas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.canceled}</strong></li>
            <li style="list-style: none">Total: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.total}</strong></li>
          </ul>
        </div>

        <div style="margin-left: 10px;">
          <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="12" height="13" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.2211 2.06592H12.4433V0.565918H10.8877V2.06592H4.6655V0.565918H3.10994V2.06592H2.33217C1.46883 2.06592 0.784389 2.74092 0.784389 3.56592L0.776611 14.0659C0.776611 14.4637 0.9405 14.8453 1.23222 15.1266C1.52395 15.4079 1.91961 15.5659 2.33217 15.5659H13.2211C14.0766 15.5659 14.7766 14.8909 14.7766 14.0659V3.56592C14.7766 2.74092 14.0766 2.06592 13.2211 2.06592ZM13.2211 14.0659H2.33217V6.56592H13.2211V14.0659ZM5.44328 9.56592H3.88772V8.06592H5.44328V9.56592ZM8.55439 9.56592H6.99883V8.06592H8.55439V9.56592ZM11.6655 9.56592H10.1099V8.06592H11.6655V9.56592ZM5.44328 12.5659H3.88772V11.0659H5.44328V12.5659ZM8.55439 12.5659H6.99883V11.0659H8.55439V12.5659ZM11.6655 12.5659H10.1099V11.0659H11.6655V12.5659Z" fill="#3d3d3d"/></svg>Últimos 60 dias</p>
          <ul style="padding-left: 0; margin-top: initial; margin-bottom: initial;">
            <li style="list-style: none">Vendas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.metrics.sales.completed}</strong></li>
            <li style="list-style: none">Reclamações: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.claims.value}</strong></li>
            <li style="list-style: none">Atrasos: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.delayed_handling_time.value}</strong></li>
          </ul>
        </div>
      </div>

      <div class="linha-2" style="text-align: start; margin-top: 10px; align-items: start;">
        <div>
          <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="15" height="13" viewBox="0 0 15 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.42598 6.99829H9.72598V5.49829H3.42598V6.99829ZM3.42598 4.74829H9.72598V3.24829H3.42598V4.74829ZM2.02598 12.2483C1.64098 12.2483 1.31151 12.1015 1.03758 11.808C0.763177 11.514 0.625977 11.1608 0.625977 10.7483V1.74829C0.625977 1.33579 0.763177 0.982791 1.03758 0.689291C1.31151 0.395291 1.64098 0.248291 2.02598 0.248291H13.226C13.611 0.248291 13.9407 0.395291 14.2151 0.689291C14.489 0.982791 14.626 1.33579 14.626 1.74829V10.7483C14.626 11.1608 14.489 11.514 14.2151 11.808C13.9407 12.1015 13.611 12.2483 13.226 12.2483H2.02598ZM2.02598 10.7483H13.226V1.74829H2.02598V10.7483ZM2.02598 10.7483V1.74829V10.7483Z" fill="#3D3D3D"/></svg>Anúncios</p>
          <ul style="padding-left: 0; margin-top: initial; margin-bottom: initial;">
            <li style="list-style: none">Total: <strong>${rawVendedoresCompleto[i].val.paging.total}</strong></li>
            <li style="list-style: none">No full: <strong>${full}</strong></li>
            <li style="list-style: none">Frete grátis: <strong>${gratis}</strong></li>
          </ul>
        </div>

        <div style="margin-left: 10px;">
          <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="9" height="13" viewBox="0 0 11 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.7771 7.06748C5.3035 7.06748 4.8493 6.88311 4.51441 6.55492C4.17952 6.22673 3.99139 5.78161 3.99139 5.31748C3.99139 4.85335 4.17952 4.40823 4.51441 4.08004C4.8493 3.75185 5.3035 3.56748 5.7771 3.56748C6.2507 3.56748 6.7049 3.75185 7.03979 4.08004C7.37468 4.40823 7.56281 4.85335 7.56281 5.31748C7.56281 5.54729 7.51663 5.77486 7.42688 5.98718C7.33714 6.1995 7.20561 6.39241 7.03979 6.55492C6.87397 6.71742 6.67712 6.84632 6.46046 6.93427C6.24381 7.02222 6.0116 7.06748 5.7771 7.06748ZM5.7771 0.41748C4.45102 0.41748 3.17925 0.933729 2.24157 1.85266C1.30388 2.77159 0.7771 4.01792 0.7771 5.31748C0.7771 8.99248 5.7771 14.4175 5.7771 14.4175C5.7771 14.4175 10.7771 8.99248 10.7771 5.31748C10.7771 4.01792 10.2503 2.77159 9.31263 1.85266C8.37495 0.933729 7.10318 0.41748 5.7771 0.41748Z" fill="#3D3D3D"/></svg>Localização</p>
          <ul style="padding-left: 0; margin-top: initial; margin-bottom: initial;">
            <li style="list-style: none">${rawVendedoresCompleto[i].val.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : (rawVendedoresCompleto[i].val.cidade != null ? (rawVendedoresCompleto[i].val.cidade + ' / ' + rawVendedoresCompleto[i].val.uf.replace('BR-', '')) : 'Não Informado')}</li>
          </ul>

          ${rawVendedoresCompleto[i].val.seller.tags[0] == 'brand' ? '<p style="color: #2AC568 !important; font-weight: bold; font-size: 13px; display: flex; align-items: center; margin-top: 10px;"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg>Loja Oficial</p>' : ''}
        </div>
      </div>

      <div class="linha" style="margin-top: 10px; margin-bottom: 10px;">
        ${reputacao}
      </div>
    </div>
    `
      } else {

      }
    }


    medalhaVendedor.innerHTML = /* html */`<center><img width="150px" src="https://ramcloud.com.br/img/logomelipro.png?time=${new Date().getTime()}" /></center>
  <center style="margin-top: -5px !important; margin-bottom: 5px !important"><small style="color: gray !important; font-size: 12px;">Versão ${chrome.runtime.getManifest().version}</small></center>
  <center><p style="font-size: 13px; font-weight: 600; color: var(--grey) !important;">Fique por dentro das novidades!</p></center>

  <div class="linha-2">
    <button class="btn btn-success" style="font-weight: 500" onClick="javascript:window.open('https://linktr.ee/grupoavantpro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.4389 3.74208C16.5175 2.81601 15.42 2.08175 14.2104 1.58214C13.0008 1.08252 11.7034 0.827551 10.3937 0.832091C4.90628 0.832091 0.433918 5.28208 0.433918 10.7421C0.433918 12.4921 0.896229 14.1921 1.76055 15.692L0.353516 20.832L5.6299 19.452C7.08718 20.242 8.72537 20.662 10.3937 20.662C15.8812 20.662 20.3535 16.212 20.3535 10.7521C20.3535 8.10207 19.3183 5.61208 17.4389 3.74208ZM10.3937 18.982C8.90628 18.982 7.44899 18.582 6.17261 17.832L5.8711 17.652L2.73542 18.472L3.5696 15.432L3.36859 15.122C2.54221 13.809 2.1034 12.2913 2.10226 10.7421C2.10226 6.20207 5.82085 2.50209 10.3837 2.50209C12.5947 2.50209 14.6751 3.36208 16.2329 4.92208C17.0042 5.68604 17.6155 6.59474 18.0313 7.5955C18.4471 8.59626 18.6591 9.66917 18.655 10.7521C18.6751 15.292 14.9565 18.982 10.3937 18.982ZM14.9364 12.8221C14.6852 12.7021 13.459 12.1021 13.2379 12.0121C13.0068 11.9321 12.846 11.8921 12.6751 12.1321C12.5043 12.3821 12.0319 12.9421 11.8912 13.1021C11.7505 13.2721 11.5997 13.2921 11.3485 13.1621C11.0972 13.0421 10.2932 12.7721 9.34849 11.9321C8.60477 11.2721 8.11231 10.4621 7.96156 10.2121C7.82085 9.96206 7.94145 9.83206 8.07211 9.70206C8.18266 9.59206 8.32336 9.41206 8.44397 9.27207C8.56457 9.13206 8.61482 9.02207 8.69522 8.86207C8.77563 8.69207 8.73542 8.55207 8.67512 8.43207C8.61482 8.31207 8.11231 7.09207 7.9113 6.59207C7.7103 6.11208 7.49924 6.17207 7.34849 6.16208H6.86608C6.69522 6.16208 6.43392 6.22207 6.20276 6.47207C5.98166 6.72207 5.33844 7.32207 5.33844 8.54207C5.33844 9.76206 6.23291 10.9421 6.35352 11.1021C6.47412 11.2721 8.11231 13.7721 10.6048 14.842C11.1977 15.102 11.66 15.252 12.0219 15.362C12.6148 15.552 13.1575 15.522 13.5897 15.462C14.0721 15.392 15.0671 14.862 15.2681 14.2821C15.4791 13.7021 15.4791 13.2121 15.4088 13.1021C15.3384 12.9921 15.1877 12.9421 14.9364 12.8221Z" fill="currentColor"/></svg>WHATSAPP</button>
    <button class="btn btn-info" style="font-weight: 500" onClick="javascript:window.open('https://t.me/mercadolivrepro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.3444 1.22126C20.1394 1.02947 19.8912 0.902585 19.6262 0.854103C19.3612 0.805621 19.0892 0.83735 18.8392 0.945917L1.79307 8.33936C1.49408 8.46516 1.24083 8.69601 1.0723 8.99637C0.90378 9.29673 0.829332 9.64994 0.860422 10.0016C0.888159 10.3531 1.01834 10.6853 1.23144 10.9482C1.44454 11.2111 1.72908 11.3907 2.04239 11.4599L6.37318 12.4083V18.3842C6.37302 18.7075 6.45983 19.0236 6.62259 19.2923C6.78535 19.561 7.01673 19.7703 7.28735 19.8935C7.46646 19.9731 7.65757 20.0146 7.85063 20.0159C8.04468 20.0167 8.23692 19.9747 8.41609 19.8924C8.59526 19.8101 8.75776 19.6891 8.89409 19.5366L11.295 16.8954L14.924 20.4238C15.1919 20.6848 15.5363 20.8297 15.8935 20.8317C16.0506 20.8353 16.207 20.8077 16.3552 20.7501C16.5989 20.665 16.8182 20.5111 16.9915 20.3036C17.1648 20.0961 17.2861 19.8423 17.3433 19.5672L20.8153 2.82232C20.876 2.53338 20.8642 2.23164 20.7812 1.94954C20.6983 1.66744 20.5472 1.41565 20.3444 1.22126ZM6.93646 10.8684L2.33788 9.85884L15.2287 4.26022L6.93646 10.8684ZM7.85063 18.3842V13.5505L10.1776 15.8144L7.85063 18.3842ZM15.9028 19.2001L8.29387 11.8066L19.2547 3.06707L15.9028 19.2001Z" fill="currentColor"/></svg>TELEGRAM</button>
  </div>
  <center><p style="margin-top: 10px; margin-bottom: 15px; font-size: 13px; font-weight: 500; color: var(--grey) !important;">Precisa de Ajuda? Mande um Email: <strong style="font-weight: 600;">mlpro@ramsolution.com.br</strong></p></center>

  <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#3D3D3D"/></svg>Concorrência</p>
  <div class="linha">
    <div class="cardInfos" style="border-radius: 50px; min-height: auto !important; width: 100%; display: flex; margin: 5px 0 5px 0;">
      <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Sem</p><p style="font-size: 16px;"><strong>${qtdSemMedalha}</strong></p></div>
      <div class="medalhaLider" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Líder</p><p style="font-size: 16px;"><strong>${qtdLider}</strong></p></div>
      <div class="medalhaGold" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Gold</p><p style="font-size: 16px;"><strong>${qtdGold}</strong></p></div>
      <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Platinum</p><p style="font-size: 16px;"><strong>${qtdPlatinum}</strong></p></div>
    </div>
  </div>

  <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
  <div class="linha">
    <div class="cardInfos cardApendice" style="width: 100%; padding-right: 8px; padding-left: 8px;">
      <div style="display: flex; align-items: center; justify-content: center;">
        <div style="margin-right: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="6" height="10" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.78274 1.43042L4.78274 11.6152M4.78274 11.6152L7.87524 8.643M4.78274 11.6152L1.4193 8.643" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Menor qtd.</p><p><strong>${menorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
        <div class="divMenorVendas" style="position: relative;"><p class="tituloCard"><svg style="margin-right: 4px;" width="7" height="10" viewBox="0 0 10 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.74973 11.615V1.43018M4.74973 1.43018L1.65723 4.40241M4.74973 1.43018L8.11317 4.40241" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Maior qtd.</p><p><strong>${maiorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
        <div style="margin-left: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="7" viewBox="0 0 13 7" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.86401 1.64771H11.1973M1.86401 5.39771H11.1973" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Total</p><p><strong>+ de ${totalVendas.toLocaleString('pt-BR', {})}</strong></p></div>
      </div>
      <span><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="#3166FE" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="#3166FE"/></svg></span>
      <div class="tooltiptext" style="color: white;">
        <p>Quantidade de vendas aproximada conforme tabela de range ML.</p>
        <p style="text-decoration: underline; margin-top: 8px; cursor: pointer; width: fit-content; margin-left: auto; margin-right: 8px" id="btnModalRange">Saiba mais.</p>
      </div>
    </div>
  </div>

  <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important; margin-top: 2px;"><svg style="margin-right: 4px" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 2C4 2.53043 3.78929 3.03914 3.41421 3.41421C3.03914 3.78929 2.53043 4 2 4C1.46957 4 0.960859 3.78929 0.585786 3.41421C0.210714 3.03914 0 2.53043 0 2C0 1.46957 0.210714 0.960859 0.585786 0.585786C0.960859 0.210714 1.46957 0 2 0C2.53043 0 3.03914 0.210714 3.41421 0.585786C3.78929 0.960859 4 1.46957 4 2ZM4 8C4 8.53043 3.78929 9.03914 3.41421 9.41421C3.03914 9.78929 2.53043 10 2 10C1.46957 10 0.960859 9.78929 0.585786 9.41421C0.210714 9.03914 0 8.53043 0 8C0 7.46957 0.210714 6.96086 0.585786 6.58579C0.960859 6.21071 1.46957 6 2 6C2.53043 6 3.03914 6.21071 3.41421 6.58579C3.78929 6.96086 4 7.46957 4 8ZM2 16C2.53043 16 3.03914 15.7893 3.41421 15.4142C3.78929 15.0391 4 14.5304 4 14C4 13.4696 3.78929 12.9609 3.41421 12.5858C3.03914 12.2107 2.53043 12 2 12C1.46957 12 0.960859 12.2107 0.585786 12.5858C0.210714 12.9609 0 13.4696 0 14C0 14.5304 0.210714 15.0391 0.585786 15.4142C0.960859 15.7893 1.46957 16 2 16ZM10 2C10 2.53043 9.78929 3.03914 9.41421 3.41421C9.03914 3.78929 8.53043 4 8 4C7.46957 4 6.96086 3.78929 6.58579 3.41421C6.21071 3.03914 6 2.53043 6 2C6 1.46957 6.21071 0.960859 6.58579 0.585786C6.96086 0.210714 7.46957 0 8 0C8.53043 0 9.03914 0.210714 9.41421 0.585786C9.78929 0.960859 10 1.46957 10 2ZM8 10C8.53043 10 9.03914 9.78929 9.41421 9.41421C9.78929 9.03914 10 8.53043 10 8C10 7.46957 9.78929 6.96086 9.41421 6.58579C9.03914 6.21071 8.53043 6 8 6C7.46957 6 6.96086 6.21071 6.58579 6.58579C6.21071 6.96086 6 7.46957 6 8C6 8.53043 6.21071 9.03914 6.58579 9.41421C6.96086 9.78929 7.46957 10 8 10ZM10 14C10 14.5304 9.78929 15.0391 9.41421 15.4142C9.03914 15.7893 8.53043 16 8 16C7.46957 16 6.96086 15.7893 6.58579 15.4142C6.21071 15.0391 6 14.5304 6 14C6 13.4696 6.21071 12.9609 6.58579 12.5858C6.96086 12.2107 7.46957 12 8 12C8.53043 12 9.03914 12.2107 9.41421 12.5858C9.78929 12.9609 10 13.4696 10 14ZM14 4C14.5304 4 15.0391 3.78929 15.4142 3.41421C15.7893 3.03914 16 2.53043 16 2C16 1.46957 15.7893 0.960859 15.4142 0.585786C15.0391 0.210714 14.5304 0 14 0C13.4696 0 12.9609 0.210714 12.5858 0.585786C12.2107 0.960859 12 1.46957 12 2C12 2.53043 12.2107 3.03914 12.5858 3.41421C12.9609 3.78929 13.4696 4 14 4ZM16 8C16 8.53043 15.7893 9.03914 15.4142 9.41421C15.0391 9.78929 14.5304 10 14 10C13.4696 10 12.9609 9.78929 12.5858 9.41421C12.2107 9.03914 12 8.53043 12 8C12 7.46957 12.2107 6.96086 12.5858 6.58579C12.9609 6.21071 13.4696 6 14 6C14.5304 6 15.0391 6.21071 15.4142 6.58579C15.7893 6.96086 16 7.46957 16 8ZM14 16C14.5304 16 15.0391 15.7893 15.4142 15.4142C15.7893 15.0391 16 14.5304 16 14C16 13.4696 15.7893 12.9609 15.4142 12.5858C15.0391 12.2107 14.5304 12 14 12C13.4696 12 12.9609 12.2107 12.5858 12.5858C12.2107 12.9609 12 13.4696 12 14C12 14.5304 12.2107 15.0391 12.5858 15.4142C12.9609 15.7893 13.4696 16 14 16Z" fill="#3D3D3D"/></svg>Outras informações</p>
  <div class="linha-3">
    <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.49334 15.4688L5.19789 13.183L2.74334 12.6116L2.98198 9.96875L1.31152 7.96875L2.98198 5.96875L2.74334 3.32589L5.19789 2.75446L6.49334 0.46875L8.81152 1.50446L11.1297 0.46875L12.4252 2.75446L14.8797 3.32589L14.6411 5.96875L16.3115 7.96875L14.6411 9.96875L14.8797 12.6116L12.4252 13.183L11.1297 15.4688L8.81152 14.433L6.49334 15.4688ZM7.07289 13.6473L8.81152 12.8616L10.5843 13.6473L11.5388 11.933L13.4138 11.4688L13.2433 9.46875L14.5047 7.96875L13.2433 6.43304L13.4138 4.43304L11.5388 4.00446L10.5502 2.29018L8.81152 3.07589L7.0388 2.29018L6.08425 4.00446L4.20925 4.43304L4.37971 6.43304L3.11834 7.96875L4.37971 9.46875L4.20925 11.5045L6.08425 11.933L7.07289 13.6473ZM8.09561 10.5045L11.9479 6.46875L10.9933 5.43304L8.09561 8.46875L6.62971 6.96875L5.67516 7.96875L8.09561 10.5045Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg>Oficiais</p><p><strong>${qtdLojasOficiais}</strong></p></div>
    <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="11" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.79724 12.024L13.4372 6.38399L12.3172 5.26399L7.79724 9.78399L5.51724 7.50399L4.39724 8.62399L7.79724 12.024ZM8.91724 16.344C7.81057 16.344 6.77057 16.1339 5.79724 15.7136C4.8239 15.2939 3.97724 14.724 3.25724 14.004C2.53724 13.284 1.96737 12.4373 1.54764 11.464C1.12737 10.4907 0.917236 9.45066 0.917236 8.34399C0.917236 7.23733 1.12737 6.19733 1.54764 5.22399C1.96737 4.25066 2.53724 3.40399 3.25724 2.68399C3.97724 1.96399 4.8239 1.39386 5.79724 0.973594C6.77057 0.553861 7.81057 0.343994 8.91724 0.343994C10.0239 0.343994 11.0639 0.553861 12.0372 0.973594C13.0106 1.39386 13.8572 1.96399 14.5772 2.68399C15.2972 3.40399 15.8671 4.25066 16.2868 5.22399C16.7071 6.19733 16.9172 7.23733 16.9172 8.34399C16.9172 9.45066 16.7071 10.4907 16.2868 11.464C15.8671 12.4373 15.2972 13.284 14.5772 14.004C13.8572 14.724 13.0106 15.2939 12.0372 15.7136C11.0639 16.1339 10.0239 16.344 8.91724 16.344ZM8.91724 14.744C10.7039 14.744 12.2172 14.124 13.4572 12.884C14.6972 11.644 15.3172 10.1307 15.3172 8.34399C15.3172 6.55733 14.6972 5.04399 13.4572 3.80399C12.2172 2.56399 10.7039 1.94399 8.91724 1.94399C7.13057 1.94399 5.61724 2.56399 4.37724 3.80399C3.13724 5.04399 2.51724 6.55733 2.51724 8.34399C2.51724 10.1307 3.13724 11.644 4.37724 12.884C5.61724 14.124 7.13057 14.744 8.91724 14.744Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Clássicos</p><p><strong>${qtdClassico}</strong></p></div>
    <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="13.2" height="8.2" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Premium</p><p><strong>${qtdPremium}</strong></p></div>  
  </div>

  <div class="linha-3">
    <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="9" height="12" viewBox="0 0 11 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.02363 0.674853L0.233168 6.75717C-0.18632 7.13732 0.0496419 7.83862 0.613329 7.89105L5.91592 8.40228L2.73699 12.8329C2.59279 13.0361 2.61245 13.318 2.78942 13.4949C2.98606 13.6915 3.29412 13.6981 3.49731 13.508L10.2878 7.4257C10.7073 7.04556 10.4713 6.34426 9.90761 6.29182L4.60502 5.78059L7.78395 1.34994C7.92815 1.14676 7.90849 0.864925 7.73152 0.687961C7.63885 0.593328 7.51269 0.538916 7.38026 0.536464C7.24783 0.534011 7.11974 0.583715 7.02363 0.674853Z" fill="#3D3D3D"/></svg>FULL</p><p><strong>${qtdFull}</strong></p></div>
    <div class="cardInfos" style="width: 100px;"><p class="tituloCard" style="display: flex; align-items: center;"><svg style="margin-right: 4px;" width="12" height="11" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.60074 1.19312C2.08399 1.19312 1.58841 1.39563 1.22302 1.75611C0.857621 2.11659 0.652344 2.6055 0.652344 3.1153V13.3669C0.652382 13.8457 0.833483 14.3071 1.16021 14.661C1.48693 15.015 1.93577 15.2359 2.41889 15.2806C2.51861 15.8795 2.83057 16.4241 3.29921 16.8174C3.76786 17.2106 4.36277 17.4271 4.97801 17.4281C5.59326 17.4291 6.18891 17.2147 6.6589 16.823C7.12888 16.4313 7.4427 15.8877 7.54448 15.2891H9.34739C9.44869 15.8874 9.76175 16.4308 10.2309 16.8227C10.7001 17.2147 11.295 17.4298 11.9098 17.4298C12.5245 17.4298 13.1194 17.2147 13.5886 16.8227C14.0578 16.4308 14.3708 15.8874 14.4721 15.2891H16.023C16.2789 15.2891 16.5323 15.2394 16.7687 15.1428C17.005 15.0462 17.2198 14.9046 17.4008 14.7261C17.5817 14.5476 17.7252 14.3357 17.8231 14.1025C17.921 13.8693 17.9714 13.6194 17.9714 13.3669V8.7426C17.9713 8.45802 17.9071 8.17703 17.7835 7.9199L16.3123 4.85551C16.1544 4.52665 15.9052 4.24874 15.5935 4.05411C15.2819 3.85947 14.9206 3.75611 14.5518 3.75603H13.2087V3.1153C13.2087 2.6055 13.0034 2.11659 12.638 1.75611C12.2726 1.39563 11.777 1.19312 11.2603 1.19312H2.60074ZM14.3604 14.0077C14.1532 13.4318 13.7449 12.9475 13.2087 12.6416V9.309H16.6725V11.8719H15.5901C15.4178 11.8719 15.2526 11.9394 15.1308 12.0596C15.009 12.1797 14.9406 12.3427 14.9406 12.5126C14.9406 12.6826 15.009 12.8455 15.1308 12.9657C15.2526 13.0859 15.4178 13.1534 15.5901 13.1534H16.6725V13.3669C16.6725 13.5369 16.6041 13.6998 16.4823 13.82C16.3605 13.9402 16.1953 14.0077 16.023 14.0077H14.3604ZM11.9098 12.2991C11.3723 12.2989 10.8481 12.4631 10.4092 12.7691C9.97029 13.0751 9.63836 13.5078 9.4591 14.0077H7.43277C7.25386 13.5079 6.92235 13.0751 6.48386 12.7689C6.04536 12.4627 5.52145 12.298 4.98421 12.2977C4.44697 12.2973 3.92281 12.4612 3.48388 12.7668C3.04495 13.0724 2.71282 13.5047 2.5332 14.0043C2.3735 13.9878 2.22566 13.9135 2.11819 13.7958C2.01073 13.6781 1.95126 13.5253 1.95128 13.3669V3.1153C1.95128 2.94537 2.0197 2.7824 2.1415 2.66224C2.2633 2.54208 2.42849 2.47457 2.60074 2.47457H11.2603C11.4325 2.47457 11.5977 2.54208 11.7195 2.66224C11.8413 2.7824 11.9098 2.94537 11.9098 3.1153V12.2991ZM13.2087 5.03748H14.5509C14.6741 5.03729 14.7947 5.07165 14.8988 5.13654C15.0029 5.20143 15.0862 5.29418 15.1389 5.40398L16.398 8.02754H13.2087V5.03748ZM4.98212 16.1434C4.63762 16.1434 4.30723 16.0084 4.06363 15.7681C3.82004 15.5278 3.68318 15.2018 3.68318 14.862C3.68318 14.5221 3.82004 14.1962 4.06363 13.9558C4.30723 13.7155 4.63762 13.5805 4.98212 13.5805C5.32661 13.5805 5.657 13.7155 5.9006 13.9558C6.1442 14.1962 6.28105 14.5221 6.28105 14.862C6.28105 15.2018 6.1442 15.5278 5.9006 15.7681C5.657 16.0084 5.32661 16.1434 4.98212 16.1434ZM13.2087 14.862C13.2087 15.2018 13.0718 15.5278 12.8282 15.7681C12.5846 16.0084 12.2543 16.1434 11.9098 16.1434C11.5653 16.1434 11.2349 16.0084 10.9913 15.7681C10.7477 15.5278 10.6108 15.2018 10.6108 14.862C10.6108 14.5221 10.7477 14.1962 10.9913 13.9558C11.2349 13.7155 11.5653 13.5805 11.9098 13.5805C12.2543 13.5805 12.5846 13.7155 12.8282 13.9558C13.0718 14.1962 13.2087 14.5221 13.2087 14.862Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Frete grátis</p><p><strong>${qtdFreteGratis}</strong></p></div>
    <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg>
    Flex</p><p><strong>${qtdFlex}</strong></p></div>  
  </div>

  <div class="linha-3">
    <div class="cardInfos" style="width: 100px; padding-left: 2px; padding-right: 2px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 12 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.76363 20.8397C5.44101 20.8397 5.17039 20.7304 4.95177 20.5118C4.73391 20.2939 4.62498 20.0237 4.62498 19.701V18.3916C3.77099 18.2018 3.02138 17.8697 2.37615 17.3953C1.73091 16.9208 1.20903 16.2566 0.810506 15.4026C0.677664 15.1369 0.67273 14.8572 0.795704 14.5634C0.919437 14.2689 1.14261 14.0552 1.46523 13.9224C1.73091 13.8085 2.00609 13.8135 2.29075 13.9372C2.57541 14.0602 2.79365 14.264 2.94547 14.5486C3.26809 15.118 3.67611 15.5499 4.16952 15.8444C4.66294 16.1382 5.27022 16.2851 5.99136 16.2851C6.76944 16.2851 7.4291 16.1097 7.97033 15.759C8.51081 15.4076 8.78105 14.8618 8.78105 14.1217C8.78105 13.4574 8.5723 12.9306 8.15479 12.5412C7.73729 12.1525 6.76944 11.7115 5.25124 11.2181C3.61917 10.7057 2.4995 10.0939 1.89222 9.38259C1.28494 8.67056 0.981303 7.80215 0.981303 6.77736C0.981303 5.54383 1.37983 4.58546 2.17689 3.90227C2.97394 3.21908 3.78997 2.83004 4.62498 2.73516V1.48264C4.62498 1.16003 4.73391 0.889407 4.95177 0.670786C5.17039 0.452925 5.44101 0.343994 5.76363 0.343994C6.08625 0.343994 6.35687 0.452925 6.57549 0.670786C6.79335 0.889407 6.90228 1.16003 6.90228 1.48264V2.73516C7.62342 2.84902 8.24968 3.08169 8.78105 3.43315C9.31242 3.78385 9.7489 4.2154 10.0905 4.72779C10.2613 4.9745 10.2947 5.24967 10.1907 5.55331C10.0859 5.85695 9.87226 6.0752 9.54964 6.20804C9.28396 6.3219 9.00878 6.32646 8.72412 6.2217C8.43946 6.1177 8.17377 5.93286 7.92706 5.66718C7.68036 5.40149 7.39114 5.1973 7.05941 5.05459C6.72693 4.91263 6.31398 4.84166 5.82056 4.84166C4.98555 4.84166 4.34981 5.02688 3.91333 5.39732C3.47684 5.767 3.2586 6.22702 3.2586 6.77736C3.2586 7.40362 3.54326 7.89703 4.11259 8.25761C4.68191 8.61818 5.66874 8.99773 7.07308 9.39626C8.38252 9.77581 9.37429 10.3782 10.0484 11.2033C10.7217 12.0292 11.0583 12.983 11.0583 14.0647C11.0583 15.4121 10.6598 16.4369 9.86277 17.1391C9.06571 17.8412 8.07888 18.2777 6.90228 18.4485V19.701C6.90228 20.0237 6.79335 20.2939 6.57549 20.5118C6.35687 20.7304 6.08625 20.8397 5.76363 20.8397Z" fill="#303030" stroke="#303030" stroke-width="0.5"/></svg>Patrocinados</p><p style="font-size: 13px !important"><strong>Informação indisponível</strong></p></div>

    <div class="cardInfos" style="width: 85px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="10" viewBox="0 0 17 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78094 6.19487C1.0631 6.19487 0.483643 6.77554 0.483643 7.49487C0.483643 8.21421 1.0631 8.79487 1.78094 8.79487C2.49878 8.79487 3.07824 8.21421 3.07824 7.49487C3.07824 6.77554 2.49878 6.19487 1.78094 6.19487ZM1.78094 0.994873C1.0631 0.994873 0.483643 1.57554 0.483643 2.29487C0.483643 3.01421 1.0631 3.59487 1.78094 3.59487C2.49878 3.59487 3.07824 3.01421 3.07824 2.29487C3.07824 1.57554 2.49878 0.994873 1.78094 0.994873ZM1.78094 11.3949C1.0631 11.3949 0.483643 11.9842 0.483643 12.6949C0.483643 13.4055 1.07175 13.9949 1.78094 13.9949C2.49013 13.9949 3.07824 13.4055 3.07824 12.6949C3.07824 11.9842 2.49878 11.3949 1.78094 11.3949ZM5.2404 13.5615H15.6188C16.0945 13.5615 16.4836 13.1715 16.4836 12.6949C16.4836 12.2182 16.0945 11.8282 15.6188 11.8282H5.2404C4.76472 11.8282 4.37553 12.2182 4.37553 12.6949C4.37553 13.1715 4.76472 13.5615 5.2404 13.5615ZM5.2404 8.36154H15.6188C16.0945 8.36154 16.4836 7.97154 16.4836 7.49487C16.4836 7.01821 16.0945 6.62821 15.6188 6.62821H5.2404C4.76472 6.62821 4.37553 7.01821 4.37553 7.49487C4.37553 7.97154 4.76472 8.36154 5.2404 8.36154ZM4.37553 2.29487C4.37553 2.77154 4.76472 3.16154 5.2404 3.16154H15.6188C16.0945 3.16154 16.4836 2.77154 16.4836 2.29487C16.4836 1.81821 16.0945 1.42821 15.6188 1.42821H5.2404C4.76472 1.42821 4.37553 1.81821 4.37553 2.29487Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Catálogo</p><p><strong>${qtdCatalogo}</strong></p></div>
    <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="11" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.7439 8.16L8.56811 0.984171C8.28108 0.697138 7.88242 0.521729 7.4439 0.521729H1.8627C0.985649 0.521729 0.268066 1.23931 0.268066 2.11636V7.69756C0.268066 8.13608 0.443476 8.53474 0.738482 8.82975L7.91431 16.0056C8.20135 16.2926 8.6 16.468 9.03853 16.468C9.47705 16.468 9.87571 16.2926 10.1627 15.9976L15.7439 10.4164C16.0389 10.1294 16.2144 9.73071 16.2144 9.29219C16.2144 8.85366 16.031 8.44703 15.7439 8.16ZM9.03853 14.8814L1.8627 7.69756V2.11636H7.4439V2.10838L14.6197 9.28421L9.03853 14.8814Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.56633 6.01597C5.22685 6.01597 5.7623 5.48051 5.7623 4.82C5.7623 4.15948 5.22685 3.62402 4.56633 3.62402C3.90582 3.62402 3.37036 4.15948 3.37036 4.82C3.37036 5.48051 3.90582 6.01597 4.56633 6.01597Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Oferta</p><p><strong>${qtdOferta}</strong></p></div>
  </div>

  <div class="linha-2">
    <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="10" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.2226 12.6463L10.3883 5.55484L13.4642 2.4789C13.9284 2.01471 13.9284 1.2653 13.4642 0.801112C13 0.336925 12.2506 0.336925 11.7864 0.801112L8.71047 3.87705L1.61904 2.04267C1.33941 1.96438 1.03181 2.04827 0.824886 2.25519C0.433403 2.64668 0.528478 3.30101 1.00944 3.56946L6.1882 6.39932L3.11786 9.46967L1.09892 8.96074C0.964701 8.92718 0.819293 8.97192 0.724219 9.067L0.399847 9.39137C0.215291 9.57593 0.254439 9.88352 0.472551 10.0121L2.51386 11.2369L2.83823 11.4271L3.00041 11.6899L3.17378 11.9863L3.96794 13.3174L4.24757 13.7872C4.38179 14.0109 4.68379 14.0444 4.86835 13.8599L5.19272 13.5355C5.29339 13.4348 5.33253 13.295 5.29898 13.1608L4.79564 11.1475L7.87158 8.07151L10.7014 13.2503C10.9643 13.7368 11.6186 13.8319 12.0101 13.4404C12.217 13.2335 12.3009 12.9259 12.2226 12.6463Z" fill="black"/></svg>Internacional</p><p><strong>${qtdInternacional}</strong></p></div>

    <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="12" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.8427 10.1738C14.5025 10.1738 15.0831 9.81303 15.3821 9.26749L18.5313 3.55693C18.6055 3.42356 18.6435 3.27314 18.6417 3.12055C18.6398 2.96796 18.5982 2.81849 18.5209 2.68694C18.4436 2.55538 18.3333 2.4463 18.2009 2.37049C18.0685 2.29467 17.9186 2.25475 17.766 2.25468H4.74707L3.92019 0.494873H1.0437V2.25468H2.80302L5.96979 8.93312L4.78225 11.0801C4.1401 12.2592 4.98457 13.6934 6.32165 13.6934H16.8776V11.9336H6.32165L7.28928 10.1738H13.8427ZM5.58274 4.01448H16.2706L13.8427 8.41398H7.66753L5.58274 4.01448ZM6.32165 14.5733C5.35403 14.5733 4.57113 15.3652 4.57113 16.3331C4.57113 17.301 5.35403 18.0929 6.32165 18.0929C7.28928 18.0929 8.08097 17.301 8.08097 16.3331C8.08097 15.3652 7.28928 14.5733 6.32165 14.5733ZM15.1182 14.5733C14.1506 14.5733 13.3677 15.3652 13.3677 16.3331C13.3677 17.301 14.1506 18.0929 15.1182 18.0929C16.0859 18.0929 16.8776 17.301 16.8776 16.3331C16.8776 15.3652 16.0859 14.5733 15.1182 14.5733Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Supermercado</p><p><strong>${qtdSupermercado}</strong></p></div>  
  </div>

  <div class="linha-2">
    <div class="cardInfos">
      <p class="tituloCard">
        <svg style="margin-right: 4px;" width="19" height="11" viewBox="0 0 29 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.0166 11.8958C21.2041 11.8961 21.3848 11.8263 21.5233 11.7C21.6618 11.5737 21.748 11.4002 21.765 11.2135C21.7819 11.0269 21.7283 10.8406 21.6148 10.6915C21.5013 10.5424 21.3361 10.4411 21.1516 10.4078L21.1405 10.4057L21.1292 10.4047L21.0392 10.3967L21.0282 10.3958H21.0171H20.0171H19.7671V10.6458V11.6458V11.8958H20.0171H21.0166ZM21.0166 11.8958L21.0171 11.6458M21.0166 11.8958H21.0171V11.6458M21.0171 11.6458H20.2671H20.0171V11.3958V10.8958V10.6458H20.2671H21.0171L21.1071 10.6538C21.2301 10.676 21.3402 10.7435 21.4159 10.8429C21.4916 10.9423 21.5273 11.0665 21.516 11.1909C21.5047 11.3154 21.4472 11.4311 21.3549 11.5152C21.2626 11.5994 21.142 11.646 21.0171 11.6458ZM18.2671 7.39575V7.64575V8.64575V8.89575H18.0171H17.0171H17.006L16.995 8.89477L16.905 8.88677L16.8937 8.88577L16.8826 8.88375C16.6981 8.85036 16.5329 8.74913 16.4194 8.6C16.3059 8.45087 16.2523 8.26464 16.2693 8.07798C16.2862 7.89133 16.3724 7.71778 16.5109 7.59152C16.6493 7.46531 16.83 7.39548 17.0173 7.39575H17.0171H18.2671ZM18.2671 7.39575H18.0171M18.2671 7.39575H18.0171M18.0171 7.39575L17.0176 7.39575L18.0171 7.39575ZM27.7009 16.9583C27.6318 17.109 27.5147 17.2326 27.368 17.3097L27.2748 17.3497L19.2803 20.3477L19.2802 20.3477C19.1476 20.3975 19.0036 20.4087 18.8649 20.3801L18.7449 20.3453L10.7539 17.3487L10.7534 17.3485C10.5958 17.2898 10.4625 17.1798 10.3749 17.0363C10.2873 16.8927 10.2505 16.7239 10.2704 16.5569C10.2903 16.3899 10.3658 16.2345 10.4846 16.1155C10.6018 15.9982 10.7545 15.9231 10.9188 15.9019L11.0315 15.8953L11.2671 15.8817V15.6458V3.64575V3.64574C11.2671 2.94429 11.5351 2.26935 12.0163 1.759C12.4966 1.24955 13.1532 0.942555 13.8521 0.900541L14.0207 0.895752H24.0171C24.7186 0.895713 25.3935 1.16372 25.9039 1.64493C26.4133 2.12529 26.7203 2.78186 26.7623 3.48071L26.7671 3.64929V15.6458V15.8963L27.0176 15.8958C27.1861 15.8954 27.3497 15.9518 27.4822 16.0558C27.6147 16.1598 27.7084 16.3054 27.7481 16.4691C27.7877 16.6328 27.7711 16.8051 27.7009 16.9583ZM12.7671 16.3278V16.501L12.9293 16.5618L18.9293 18.8118L19.0171 18.8448L19.1049 18.8118L25.1049 16.5618L25.2671 16.501V16.3278V3.64575C25.2671 3.31423 25.1354 2.99629 24.901 2.76187C24.6666 2.52745 24.3486 2.39575 24.0171 2.39575H14.0171C13.6856 2.39575 13.3676 2.52745 13.1332 2.76187C12.8988 2.99629 12.7671 3.31423 12.7671 3.64575V16.3278ZM19.7671 5.64575V5.89575H20.0171H22.0171C22.216 5.89575 22.4068 5.97477 22.5474 6.11542C22.6881 6.25607 22.7671 6.44684 22.7671 6.64575C22.7671 6.84466 22.6881 7.03543 22.5474 7.17608C22.4068 7.31673 22.216 7.39575 22.0171 7.39575H20.0171H19.7671V7.64575V8.64575V8.89575H20.0171H21.0171C21.6138 8.89575 22.1861 9.1328 22.6081 9.55476C23.0301 9.97672 23.2671 10.549 23.2671 11.1458C23.2671 11.7425 23.0301 12.3148 22.6081 12.7367C22.1861 13.1587 21.6138 13.3958 21.0171 13.3958H20.0171H19.7671V13.6458V14.6458C19.7671 14.8447 19.6881 15.0354 19.5474 15.1761C19.4068 15.3167 19.216 15.3958 19.0171 15.3958C18.8182 15.3958 18.6274 15.3167 18.4868 15.1761C18.3461 15.0354 18.2671 14.8447 18.2671 14.6458V13.6458V13.3958H18.0171H16.0171C15.8182 13.3958 15.6274 13.3167 15.4868 13.1761C15.3461 13.0354 15.2671 12.8447 15.2671 12.6458C15.2671 12.4468 15.3461 12.2561 15.4868 12.1154C15.6274 11.9748 15.8182 11.8958 16.0171 11.8958H18.0171H18.2671V11.6458V10.6458V10.3958H18.0171H17.0171C16.4204 10.3958 15.8481 10.1587 15.4261 9.73674C15.0042 9.31479 14.7671 8.74249 14.7671 8.14575C14.7671 7.54902 15.0042 6.97672 15.4261 6.55476C15.8481 6.1328 16.4204 5.89575 17.0171 5.89575H18.0171H18.2671V5.64575V4.64575C18.2671 4.44684 18.3461 4.25607 18.4868 4.11542C18.6274 3.97477 18.8182 3.89575 19.0171 3.89575C19.216 3.89575 19.4068 3.97477 19.5474 4.11542C19.6881 4.25607 19.7671 4.44684 19.7671 4.64575V5.64575Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.82644 4.68677L4.82644 14.8716M4.82644 14.8716L7.91895 11.8993M4.82644 14.8716L1.463 11.8993" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        Menor preço
      </p>
      <p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(menorPreco)}</strong></p>
    </div>
    <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="21" height="13" viewBox="0 0 28 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M23.6809 0.645752C24.4461 0.645709 25.1824 0.938077 25.7392 1.46304C26.2959 1.98799 26.631 2.70586 26.6759 3.46975L26.6809 3.64575V15.6458C26.9055 15.6453 27.1237 15.7205 27.3004 15.8591C27.4771 15.9978 27.6019 16.192 27.6548 16.4102C27.7077 16.6285 27.6856 16.8583 27.592 17.0624C27.4984 17.2666 27.3388 17.4333 27.1389 17.5358L27.0319 17.5818L19.0319 20.5818C18.8518 20.6494 18.656 20.6636 18.4679 20.6228L18.3299 20.5828L10.3299 17.5828C10.1198 17.5045 9.94208 17.3579 9.8253 17.1665C9.70851 16.9751 9.65945 16.75 9.68598 16.5273C9.71252 16.3047 9.81311 16.0974 9.9716 15.9388C10.1301 15.7802 10.3373 15.6794 10.5599 15.6528L10.6809 15.6458V3.64575C10.6809 2.88054 10.9732 2.14424 11.4982 1.58749C12.0232 1.03075 12.741 0.695644 13.5049 0.650752L13.6809 0.645752H23.6809ZM23.6809 2.64575H13.6809C13.4157 2.64575 13.1614 2.75111 12.9738 2.93865C12.7863 3.12618 12.6809 3.38054 12.6809 3.64575V16.3278L18.6809 18.5778L24.6809 16.3278V3.64575C24.6809 3.38054 24.5756 3.12618 24.388 2.93865C24.2005 2.75111 23.9461 2.64575 23.6809 2.64575ZM18.6809 3.64575C18.9461 3.64575 19.2005 3.75111 19.388 3.93865C19.5756 4.12618 19.6809 4.38054 19.6809 4.64575V5.64575H21.6809C21.9461 5.64575 22.2005 5.75111 22.388 5.93865C22.5756 6.12618 22.6809 6.38054 22.6809 6.64575C22.6809 6.91097 22.5756 7.16532 22.388 7.35286C22.2005 7.54039 21.9461 7.64575 21.6809 7.64575H19.6809V8.64575H20.6809C21.344 8.64575 21.9798 8.90914 22.4487 9.37799C22.9175 9.84683 23.1809 10.4827 23.1809 11.1458C23.1809 11.8088 22.9175 12.4447 22.4487 12.9135C21.9798 13.3824 21.344 13.6458 20.6809 13.6458H19.6809V14.6458C19.6809 14.911 19.5756 15.1653 19.388 15.3529C19.2005 15.5404 18.9461 15.6458 18.6809 15.6458C18.4157 15.6458 18.1614 15.5404 17.9738 15.3529C17.7863 15.1653 17.6809 14.911 17.6809 14.6458V13.6458H15.6809C15.4157 13.6458 15.1614 13.5404 14.9738 13.3529C14.7863 13.1653 14.6809 12.911 14.6809 12.6458C14.6809 12.3805 14.7863 12.1262 14.9738 11.9386C15.1614 11.7511 15.4157 11.6458 15.6809 11.6458H17.6809V10.6458H16.6809C16.0179 10.6458 15.382 10.3824 14.9132 9.91352C14.4443 9.44468 14.1809 8.80879 14.1809 8.14575C14.1809 7.48271 14.4443 6.84683 14.9132 6.37799C15.382 5.90914 16.0179 5.64575 16.6809 5.64575H17.6809V4.64575C17.6809 4.38054 17.7863 4.12618 17.9738 3.93865C18.1614 3.75111 18.4157 3.64575 18.6809 3.64575ZM20.6809 10.6458H19.6809V11.6458H20.6809C20.8059 11.646 20.9264 11.5994 21.0187 11.5152C21.111 11.4311 21.1685 11.3154 21.1798 11.1909C21.1911 11.0665 21.1554 10.9423 21.0797 10.8429C21.004 10.7435 20.8939 10.676 20.7709 10.6538L20.6809 10.6458ZM17.6809 7.64575H16.6809C16.556 7.64552 16.4355 7.69208 16.3431 7.77626C16.2508 7.86044 16.1933 7.97614 16.182 8.10057C16.1708 8.22501 16.2065 8.34916 16.2821 8.44858C16.3578 8.54801 16.468 8.61549 16.5909 8.63775L16.6809 8.64575H17.6809V7.64575Z" fill="#3D3D3D"/><path d="M4.89207 14.8713V4.68652M4.89207 4.68652L1.79956 7.65876M4.89207 4.68652L7.83802 7.65876" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Maior preço</p><p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(maiorPreco)}</strong></p></div>
  </div>

  <center><p style="margin-top: 10px; font-size: 12px">Informações: <strong>Avantpro</strong></p></center>
  <button style="margin-left: auto; margin-right: auto; font-weight: 500;" class="btn btn-info" onClick="javascript:window.open('https://avantpro.com.br/', '_blank');">Conheça outras ferramentas</button>
  ${rawVendedoresCompleto == undefined ? '' : `<div style="display: flex; align-items: center; margin: 25px 5px 10px 5px;"><p style="font-size: 15px; font-weight: 700; color: var(--grey) !important; margin-right: auto;"><svg width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.41895 0.593018C9.47981 0.593018 10.4972 1.01444 11.2474 1.76459C11.9975 2.51474 12.4189 3.53215 12.4189 4.59302C12.4189 5.65388 11.9975 6.6713 11.2474 7.42144C10.4972 8.17159 9.47981 8.59302 8.41895 8.59302C7.35808 8.59302 6.34066 8.17159 5.59052 7.42144C4.84037 6.6713 4.41895 5.65388 4.41895 4.59302C4.41895 3.53215 4.84037 2.51474 5.59052 1.76459C6.34066 1.01444 7.35808 0.593018 8.41895 0.593018ZM8.41895 10.593C12.8389 10.593 16.4189 12.383 16.4189 14.593V16.593H0.418945V14.593C0.418945 12.383 3.99895 10.593 8.41895 10.593Z" fill="#3D3D3D"/></svg> Vendedores nessa página (${rawVendedoresCompleto.length})</p>
  
  <button class="btnMostraVendedor" id="btnMostrarVendedor"><svg style="transform: rotate(180deg);" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
  </div>

  <div class="infoEscondida escondeInfo">
    <div class="linha" style="margin-bottom: 15px;">
      ${ultra ? `<div class="searchBar">
        <input style="height: 35px;" placeholder="Procure por uma loja" type="search" id="searchVendedor"></input>
        <button style="height: 35px;" class="btn-searchbar">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
        </button>
      </div>
    
      <div style="position: relative;">
        <button class="btn btn-light" style="font-weight: 500;" data-dropdown-btn><svg style="margin-right: 4px;" width="13" height="9" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.10199 9.1978C9.29153 9.19801 9.47384 9.27059 9.61166 9.40069C9.74949 9.5308 9.83243 9.70863 9.84353 9.89784C9.85464 10.087 9.79308 10.2734 9.67143 10.4187C9.54977 10.564 9.37721 10.6574 9.189 10.6798L9.10199 10.685H6.1274C5.93786 10.6848 5.75556 10.6122 5.61773 10.4821C5.47991 10.352 5.39697 10.1742 5.38586 9.985C5.37475 9.79579 5.43631 9.60948 5.55797 9.46414C5.67962 9.3188 5.85218 9.22539 6.0404 9.20301L6.1274 9.1978H9.10199ZM11.3329 4.73611C11.5302 4.73611 11.7193 4.81445 11.8588 4.95391C11.9982 5.09336 12.0766 5.2825 12.0766 5.47972C12.0766 5.67694 11.9982 5.86608 11.8588 6.00554C11.7193 6.14499 11.5302 6.22334 11.3329 6.22334H3.89646C3.69924 6.22334 3.51009 6.14499 3.37062 6.00554C3.23116 5.86608 3.15282 5.67694 3.15282 5.47972C3.15282 5.2825 3.23116 5.09336 3.37062 4.95391C3.51009 4.81445 3.69924 4.73611 3.89646 4.73611H11.3329ZM13.5639 0.274414C13.7611 0.274414 13.9502 0.352759 14.0897 0.492214C14.2292 0.631669 14.3075 0.820811 14.3075 1.01803C14.3075 1.21525 14.2292 1.40439 14.0897 1.54385C13.9502 1.6833 13.7611 1.76165 13.5639 1.76165H1.66552C1.46829 1.76165 1.27914 1.6833 1.13968 1.54385C1.00022 1.40439 0.921875 1.21525 0.921875 1.01803C0.921875 0.820811 1.00022 0.631669 1.13968 0.492214C1.27914 0.352759 1.46829 0.274414 1.66552 0.274414H13.5639Z" fill="#3D3D3D"/></svg>Filtrar</button>
        <ul class="dropdown-content" style="font-size: 13px; color: var(--grey); list-style: none !important; padding-left: 0;" data-dropdown-content>
          <li><a class="filtro-vendedor active" style="cursor: pointer;">Todos</a></li>
          <li><a class="filtro-vendedor" style="cursor: pointer;">Sem medalha</a></li>
          <li><a class="filtro-vendedor" style="cursor: pointer;">Mercado Líder</a></li>
          <li><a class="filtro-vendedor" style="cursor: pointer;">Mercado Gold</a></li>
          <li><a class="filtro-vendedor" style="cursor: pointer;">Mercado Platinum</a></li>
          <li><a class="filtro-vendedor" style="cursor: pointer;">Lojas oficiais</a></li>
        </ul>
      </div>` : `
      <div class="searchBar" style="position: relative;">
        <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
        <input style="height: 35px;" placeholder="Procure por uma loja" type="search" disabled></input>
        <button style="height: 35px;" class="btn-searchbar" disabled>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
        </button>
      </div>

      <div>
        <button class="btn btn-light" style="font-weight: 500;" data-dropdown-btn disabled><svg style="margin-right: 4px;" width="13" height="9" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.10199 9.1978C9.29153 9.19801 9.47384 9.27059 9.61166 9.40069C9.74949 9.5308 9.83243 9.70863 9.84353 9.89784C9.85464 10.087 9.79308 10.2734 9.67143 10.4187C9.54977 10.564 9.37721 10.6574 9.189 10.6798L9.10199 10.685H6.1274C5.93786 10.6848 5.75556 10.6122 5.61773 10.4821C5.47991 10.352 5.39697 10.1742 5.38586 9.985C5.37475 9.79579 5.43631 9.60948 5.55797 9.46414C5.67962 9.3188 5.85218 9.22539 6.0404 9.20301L6.1274 9.1978H9.10199ZM11.3329 4.73611C11.5302 4.73611 11.7193 4.81445 11.8588 4.95391C11.9982 5.09336 12.0766 5.2825 12.0766 5.47972C12.0766 5.67694 11.9982 5.86608 11.8588 6.00554C11.7193 6.14499 11.5302 6.22334 11.3329 6.22334H3.89646C3.69924 6.22334 3.51009 6.14499 3.37062 6.00554C3.23116 5.86608 3.15282 5.67694 3.15282 5.47972C3.15282 5.2825 3.23116 5.09336 3.37062 4.95391C3.51009 4.81445 3.69924 4.73611 3.89646 4.73611H11.3329ZM13.5639 0.274414C13.7611 0.274414 13.9502 0.352759 14.0897 0.492214C14.2292 0.631669 14.3075 0.820811 14.3075 1.01803C14.3075 1.21525 14.2292 1.40439 14.0897 1.54385C13.9502 1.6833 13.7611 1.76165 13.5639 1.76165H1.66552C1.46829 1.76165 1.27914 1.6833 1.13968 1.54385C1.00022 1.40439 0.921875 1.21525 0.921875 1.01803C0.921875 0.820811 1.00022 0.631669 1.13968 0.492214C1.27914 0.352759 1.46829 0.274414 1.66552 0.274414H13.5639Z" fill="#3D3D3D"/></svg>Filtrar
        <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
        </button>
      </div>`}

    </div>
    `
        + anunciosPorVendas + `
    
    <button class="btn btn-light" id="btnFechaVendedor" style="margin: 5px auto 5px auto; font-weight: 500;">Ocultar vendedores<svg style="margin-left: 4px;" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
    </div>`
      }
      
      <div id="modalRange" class="modalFaturamento">
        <div class="modalBody">
            <div class="closeModal" id="closeMdlFaturamento"><svg width="13" height="13" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></div>
            <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 25px; color: var(--grey);">
            <h4 style="font-weight: 900;">Range de vendas ML</h4></div>
            
            <div style="display: flex; justify-content: center;">
              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>1 venda</p>
                    <p>1 vendido</p>
                  </div>
                  <div class="row-tabela">
                    <p>2 vendas</p>
                    <p>2 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>3 vendas</p>
                    <p>3 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>4 vendas</p>
                    <p>4 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>5 vendas</p>
                    <p>5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 6 a 25 vendas</p>
                    <p>+5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 26 a 50 vendas</p>
                    <p>+25 vendidos</p>
                  </div>
                </div>
              </div>

              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>De 51 a 100 vendas</p>
                    <p>+50 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 101 a 150 vendas</p>
                    <p>+100 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 151 a 200 vendas</p>
                    <p>+150 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 201 a 250 vendas</p>
                    <p>+200 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 251 a 500 vendas</p>
                    <p>+250 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 501 a 5.000 vendas</p>
                    <p>+500 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 5.001 a 50.000 vendas</p>
                    <p>+5.000 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 50.001 a 500.000 vendas</p>
                    <p>+50.000 vendidos</p>
                  </div>
                </div>
              </div>
            </div>

            <div style="text-align: center; margin-top: 16px; font-size: 16px;"><p>Informações oficiais oferecidas pelo ML. <a href="https://developers.mercadolivre.com.br/pt_br/itens-e-buscas#Valores-nos-campos-sold-quantity-e-available-quantity" target="_blank">Leia aqui.</a></p></div>

        </div>
            
      </div>
      
      
      `

    document.getElementsByClassName('ui-search-breadcrumb__title shops-custom-primary-font')[0].insertBefore(medalhaVendedor, document.getElementsByClassName('seller-subtitle')[0]);

    // document.getElementsByClassName('seller-title')[0].insertAdjacentElement("beforeend", medalhaVendedor);

    /* Sair do Avantpro */
    $('#sairmlpro').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });

    /* Mostrar vendedores */
    var bntMostrarVendedor = document.getElementById("btnMostrarVendedor");
    var btnFechaVendedor = document.getElementById("btnFechaVendedor");
    var infoEscondida = document.getElementsByClassName("infoEscondida")[0];

    bntMostrarVendedor.addEventListener("click", function () {

      if (infoEscondida.classList.contains("escondeInfo")) {
        bntMostrarVendedor.style.transform = "rotate(-180deg)";
        infoEscondida.classList.add("mostraInfo");
        infoEscondida.classList.remove("escondeInfo");
        document.getElementsByClassName("mostraInfo")[0].style.animation = "downInformation .3s";
      }

      else {
        bntMostrarVendedor.style.transform = "rotate(0deg)";
        document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
        setTimeout(function () {
          infoEscondida.classList.add("escondeInfo");
          infoEscondida.classList.remove("mostraInfo");
        }, 305);
      }
    });

    btnFechaVendedor.addEventListener("click", function () {
      bntMostrarVendedor.style.transform = "rotate(0deg)";
      document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
      setTimeout(function () {
        infoEscondida.classList.add("escondeInfo");
        infoEscondida.classList.remove("mostraInfo");
      }, 299);

    });
    /* Fim do mostrar vendedores */


    /* Searchbar vendedores */
    var searchBar = document.getElementById("searchVendedor");

    searchBar.addEventListener("keyup", e => {
      const texto = e.target.value.toUpperCase();
      var vendedores = [].slice.call(document.getElementsByClassName("vendedores"));

      for (let i = 0; i < vendedores.length; i++) {

        const vendedorVisivel = vendedores[i].querySelector('[data-vendedor-nome]').innerHTML.includes(texto);
        vendedores[i].classList.toggle("vendedorEscondido", !vendedorVisivel);

      }
    })
    /* Fim Searchbar vendedores */


    /* Filtrar vendedores */
    const btnDropdown = document.querySelector("[data-dropdown-btn]"); //Botão do dropdown
    const contentDropdown = document.querySelector("[data-dropdown-content]");

    btnDropdown.addEventListener("click", () => {
      contentDropdown.classList.toggle("show-dropdown");
    })

    window.onclick = function (event) { //Fechar dropdown quando clicar fora da tela
      if (event.target != btnDropdown) {
        if (contentDropdown.classList.contains('show-dropdown')) {
          contentDropdown.classList.remove('show-dropdown');
        }
      }
    }


    var filtro = [].slice.call(document.getElementsByClassName("filtro-vendedor"));
    var vendedores = [].slice.call(document.getElementsByClassName("vendedores"));
    for (let i = 0; i < filtro.length; i++) {
      filtro[i].addEventListener('click', () => {
        vendedores.forEach(vendedor => {
          switch (i) {
            case 0:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[0].classList.add('active');

              break
            case 1:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';
              !vendedor.querySelector('[data-vendedor-sem]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[1].classList.add('active');

              break;

            case 2:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-silver]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[2].classList.add('active');

              break;

            case 3:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-gold]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[3].classList.add('active');

              break;

            case 4:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-platinum]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[5].classList.contains('active') ? filtro[5].classList.remove('active') : '';
              filtro[4].classList.add('active');

              break;

            case 5:
              vendedor.classList.contains("vendedorEscondido") ? vendedor.classList.remove("vendedorEscondido") : '';

              !vendedor.querySelector('[data-vendedor-oficial]') ? vendedor.classList.add("vendedorEscondido") : '';

              filtro[1].classList.contains('active') ? filtro[1].classList.remove('active') : '';
              filtro[2].classList.contains('active') ? filtro[2].classList.remove('active') : '';
              filtro[3].classList.contains('active') ? filtro[3].classList.remove('active') : '';
              filtro[4].classList.contains('active') ? filtro[4].classList.remove('active') : '';
              filtro[0].classList.contains('active') ? filtro[0].classList.remove('active') : '';
              filtro[5].classList.add('active');

              break;

            default:
              break;
          }
        });
      })
    }
    /* Fim filtrar vendedores */


    /* Modal range de vendas */
    var modalRange = document.getElementById("modalRange");
    var btnModalRange = document.getElementById("btnModalRange");

    var closeMdl = document.getElementsByClassName("closeModal");

    // var infoSobeModal = document.getElementsByClassName("ui-pdp-container__col col-2 ui-pdp-container--column-left pb-40")[0];
    // var containerMl = document.getElementsByClassName('shops__ui-main')[0]

    function abreModalRange() {
      modalRange.classList.toggle("openModal");
    }

    function unloadScrollBars() { //Desativa scroll da pagina
      // containerMl.style.zIndex = 20
      // infoSobeModal.style.zIndex = -1;
      document.documentElement.style.overflow = 'hidden';
      document.body.scroll = "no";
    }

    function reloadScrollBars() { //Ativa scroll da pagina
      // setTimeout(() => {
      //   infoSobeModal.style.zIndex = '';
      //   containerMl.style.zIndex = '';
      // }, 200);
      document.documentElement.style.overflow = 'auto';
      document.body.scroll = "yes";
    }

    btnModalRange.addEventListener("click", abreModalRange);
    btnModalRange.addEventListener("click", unloadScrollBars);

    for (let i = 0; i <= closeMdl.length; i++) {
      if (closeMdl[i]) {
        closeMdl[i].addEventListener("click", () => {
          reloadScrollBars();

          if (modalRange.classList.contains('openModal')) {
            abreModalRange();
          }
        });
      }
    };

  }


  static dadosAnuncio(itemList) {
    var dadosanuncio = document.getElementsByClassName('dados-anuncio');

    for (let index = 0; index < dadosanuncio.length; index++) {
      const element = dadosanuncio[index];

      element.remove();
    };

    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = '';

      try {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML;
      } catch (error) {
        try {
          id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .andes-tooltip__trigger > .sc-list-item-row-description__id")[0].innerHTML;
        } catch (error) {
          try {
            id = $(this).find(".sc-list-item-row-description__id")[0].innerHTML;
          } catch (error) {
            id = $(this).find(".sc-list-item-row__visible > .sc-list-vis-item-row-description > .sc-list-vis-item-row-description__upper-row > .upper-row__overflow > .sc-list-vis-item-row-description__id")[0].innerHTML;
          }
        }
      }

      id = id.replace('#', 'MLB');
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.sc-list-channel-content'
        ).length
      ) {

        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('div')
        dadosAnuncio.className = 'dados-anuncio';
        dadosAnuncio.setAttribute("style", "color: black; font-size:12px; width: 242px; margin-top: 15px !important");

        let dataCriacao = new Date(item.start_time);
        let catalogo = item.catalogo ? 'Sim' : 'Não';
        let full = item.full ? 'Sim' : 'Não';


        const hoje = new Date();
        const diferencaDias = Math.abs(hoje.getTime() - dataCriacao.getTime());
        const diasCriacao = Math.ceil(diferencaDias / (1000 * 60 * 60 * 24));

        let ean = '';
        if (item.ean != null) {
          if (item.ean != 'Sem EAN') {
            ean = item.ean.split(',');
            ean = ean.filter(x => x.trim());
            ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs de variações' : ean[0];
          } else {
            ean = item.ean;
          }
        }



        dadosAnuncio.innerHTML =
          `<p>Criado em: <strong>${dataCriacao.toLocaleDateString()}</strong> | Há <strong>${diasCriacao}</strong> dias</p>`
          + `<p>Fotos: <strong>${item.fotos}</strong> | Vídeo: <strong>${item.video}</strong></p>`
          + `<p>EAN: <strong>${ean == '' ? 'Sem EAN' : ean}</strong></p>`
          + `<p>Catalogo: <strong>${catalogo}</strong> | Full: <strong>${full}</strong></p>`
          //+ `<p>Recomendação: Em breve<strong></strong></p>`
          + `<center><p style="margin-top: 10px; font-size: 12px; color: gray">powered by: Avantpro</p></center>`



        let ThisElement = $(this)
          .find(
            '.sc-list-channel-content > .sc-list-channel-content__grid'
          )[0]

        if (ThisElement.getElementsByClassName('dados-anuncio').length == 0) {

          $(this)
            .find(
              '.sc-list-channel-content > .sc-list-channel-content__grid > .sc-list-dynamic-cell > .sc-list-item-row-quality .sc-list-text--secondary'
            )
            .after(dadosAnuncio)

          $(this)
            .find(
              '.sc-list-channel-content > .sc-list-channel-content__grid > .sc-list-dynamic-cell > .sc-list-actionable-cell.sc-list-actionable-cell__losing-exposure > .sc-list-actionable-cell__actions'
            )
            .after(dadosAnuncio)

          $(this)
            .find(
              '.sc-list-channel-content > .sc-list-channel-content__grid > .sc-list-channel-content__grid > .sc-list-dynamic-cell > .sc-list-actionable-cell.sc-list-actionable-cell__inactive > .sc-list-actionable-cell__description.sc-list-text--secondary'
            )
            .after(dadosAnuncio)

          $(this)
            .find(
              '.sc-list-channel-content > .sc-list-channel-content__grid > .sc-list-dynamic-cell > .sc-list-catalog-cell.sc-list-catalog-cell--situational'
            )
            .after(dadosAnuncio)

            $(this)
            .find(
              '.sc-list-channel-content > .sc-list-channel-content__grid > .sc-list-dynamic-cell > .sc-list-price-suggestion-actionable-cell > .sc-list-price-suggestion-actionable-cell__actions'
            )
            .after(dadosAnuncio)
        }



        try {
          if (item.temfrete) {
            // renderiza dados frete


            let dadosFrete = document.createElement('div')
            dadosFrete.className = 'dados-frete';

            dadosFrete.innerHTML =
              `<p>Tabela do ML R$ ${item.freteapi.toLocaleString('pt-BR', { mimnimumFractionalDigits: 2 })}</p>`
              + `<p style="color: ${item.fretediferenca ? 'red' : '#00a650'}">${item.fretediferenca ? `Possui Divergência entre o Frete Cobrado e o Frete via Tabela do Mercado Livre` : `Não Possui Diferença entre os Fretes`}</p>`
              + `<center><p style="margin-top: 10px; font-size: 12px; color: gray">powered by: Avantpro</p></center>`
              ;

            let ThisElement = $(this)
              .find(
                '.sc-list-actionable-cell.sc-list-actionable-cell__shipping > .sc-list-actionable-cell__group-text > .sc-list-actionable-cell__description.sc-list-text--secondary'
              )[0];

            if (ThisElement.getElementsByClassName('dados-frete').length == 0) {
              $(this)
                .find(
                  '.sc-list-actionable-cell.sc-list-actionable-cell__shipping > .sc-list-actionable-cell__group-text > .sc-list-actionable-cell__description.sc-list-text--secondary > p'
                )
                .after(dadosFrete) //set
            }

          }
        } catch (error) {

        }

      }
    })


  }



  static dadosAnuncioValor(itemList) {
    // Para cada item

    var dadosanuncioliquido = document.getElementsByClassName('dados-anuncio-liquido');

    for (let index = 0; index < dadosanuncioliquido.length; index++) {
      const element = dadosanuncioliquido[index];

      element.remove();
    };


    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = '';

      try {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML;
      } catch (error) {
        try {
          id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .andes-tooltip__trigger > .sc-list-item-row-description__id")[0].innerHTML;
        } catch (error) {
          try {
            id = $(this).find(".sc-list-item-row-description__id")[0].innerHTML;
          } catch (error) {
            id = $(this).find(".sc-list-item-row__visible > .sc-list-vis-item-row-description > .sc-list-vis-item-row-description__upper-row > .upper-row__overflow > .sc-list-vis-item-row-description__id")[0].innerHTML;
          }
        }
      }

      id = id.replace('#', 'MLB');
      let item = itemList.find((item) => item.id === id);

      if (
        item &&
        $(this).find(
          'div.andes-badge'
        ).length
      ) {

        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('span')
        dadosAnuncio.className = 'dados-anuncio-liquido';

        let visitas = '';

        if (item.visitas > 0 && item.vendas > 0 && item.conversaoreal) {
          visitas = `<span><strong>${item.conversaoreal.toFixed(2)}%</strong></span>`
        }

        dadosAnuncio.innerHTML =
          `<span style="color: rgba(0,0,0,.55);" class="sc-list-item-row-description__info"> Conversão: ${visitas ? visitas : '<strong>Sem Informação</strong>'}</span>`
        $(this)
          .find(
            '.sc-list-channel-content > .sc-list-channel-content__grid > .andes-badge > .andes-badge__content'
          )
          .append(dadosAnuncio)
      }
    })
  }


  static dadosAnuncioPerformance(itemList, email, dadosmonitoramento) {
    // Para cada item
    var botoesperformance = document.getElementsByClassName('botoes-performance');

    for (let index = 0; index < botoesperformance.length; index++) {
      const element = botoesperformance[index];

      element.remove();
    };

    var dadosFormanceCatalogo = document.getElementsByClassName('dados-performance-catalogo');

    for (let index = 0; index < dadosFormanceCatalogo.length; index++) {
      const element = dadosFormanceCatalogo[index];

      element.remove();
    };


    /*    
        var header = document.head;
        var script = document.createElement('script');
        script.src = 'https://code.jquery.com/jquery-3.1.1.min.js';
        header.appendChild(script);
    
        var script = document.createElement('script');
        script.src = 'https://ramcloud.com.br/scriptperformance.js?' + Math.round((new Date()).getTime() / 1000);
        header.appendChild(script);
    
     */

    MeliAPI.scriptBase('https://code.jquery.com/jquery-3.1.1.min.js');
    MeliAPI.scriptBase('https://ramcloud.com.br/scriptperformance2.js');


    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = '';
      let ClassList = $(this).attr('class').split(/\s+/);

      try {
        id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML;
      } catch (error) {
        try {
          id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .andes-tooltip__trigger > .sc-list-item-row-description__id")[0].innerHTML;
        } catch (error) {
          try {
            id = $(this).find(".sc-list-item-row-description__id")[0].innerHTML;
          } catch (error) {
            id = $(this).find(".sc-list-item-row__visible > .sc-list-vis-item-row-description > .sc-list-vis-item-row-description__upper-row > .upper-row__overflow > .sc-list-vis-item-row-description__id")[0].innerHTML;
          }
        }
      }

      id = id.replace('#', 'MLB');
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find('div.andes-tooltip__trigger').length &&
        ClassList.indexOf('sc-list-item-row--catalog') == -1
      ) {


        // renderiza botões
        let btnPerformance = document.createElement('div');
        btnPerformance.id = 'botoes-performance-' + id;
        btnPerformance.className = 'botoes-performance';

        var ItensAtual = dadosmonitoramento.result.find(element => element.MLB == id);


        var encodedTitulo = btoa(item.title);

        if (ItensAtual) {
          btnPerformance.innerHTML =
            `
          <button id="pararMonitorar" class="pararMonitorar" onclick="pararMonitorar('${id}', '${email}')">Parar</button>
          `
        } else {
          btnPerformance.innerHTML =
            `
          <button id="monitorarAnuncio" class="monitorarAnuncio" onclick="monitorarAnuncio('${id}','${encodedTitulo}', '${email}')">Monitorar</button>
          `
        }

        var encodedTitulo = btoa(item.title);


        let dadosPerformance = document.createElement('div');
        dadosPerformance.className = 'dados-performance';
        dadosPerformance.id = 'dados-performance-' + id;
        dadosPerformance.setAttribute("onclick", `verPerformance('${id}','${encodedTitulo}', '${email}')`); //set

        if (ItensAtual) {
          let limite = ``;

          if (ItensAtual.dados.length > 7) { limite = `<p style="color: red; font-size: 12px">Seu monitoramento atigiu o limite de 7 dias.</p>` }

          if (ItensAtual.dados.length <= 1) {
            dadosPerformance.innerHTML = `
              <p>Anúncio adicionado para Monitoramento. Aguarde até amanhã para verificar as métricas.</p>
            `
          } else {

            let dataI = ItensAtual.dados[0].DATA.split('-');
            dataI = dataI[2] + '/' + dataI[1] + '/' + dataI[0];
            let dataF = ItensAtual.dados[ItensAtual.dados.length - 1].DATA.split('-');
            dataF = dataF[2] + '/' + dataF[1] + '/' + dataF[0];

            dadosPerformance.innerHTML = `
            <p>${dataI} à ${dataF} | Há ${(ItensAtual.dados.length) - 1} dias</p>
            <p>${ItensAtual.resumo.VISITAS} visitas | ${ItensAtual.resumo.VENDAS} vendas | conversão ${ItensAtual.resumo.CONVERSAO == 'NAN' ? '0,00' : ItensAtual.resumo.CONVERSAO}%</p>
            <p>Obs: ${decodeURI(ItensAtual.resumo.MOTIVO)}</p>
            ${limite}
            `

          }

        } else {
          dadosPerformance.style = 'display: none;';
        }

        var thisElement = $(this)[0];


        if (thisElement.getElementsByClassName('botoes-performance-conteiner').length == 0) {
          $(this)
            .find(
              '.sc-list-item-row-description'
            )
            .append(dadosPerformance)

          //botoes-performance-conteiner
          let dadosPerformanceconteiner = document.createElement('div');
          dadosPerformanceconteiner.className = 'botoes-performance-conteiner';

          dadosPerformanceconteiner.innerHTML = `<p class="${id}" id="${id}" style="display: none;" >${item.title}</p>`;


          thisElement.getElementsByClassName('sc-list-item-row__interactive-column')[0].insertAdjacentElement('afterend', dadosPerformanceconteiner);

          var Imagens = thisElement.getElementsByClassName('sc-list-item-row-picture')[0];

          dadosPerformanceconteiner.appendChild(Imagens);
          dadosPerformanceconteiner.appendChild(btnPerformance);
        } else {
          let dadosPerformanceconteiner = thisElement.getElementsByClassName('botoes-performance-conteiner')[0];


          if (thisElement.getElementsByClassName('botoes-performance').length == 0) {
            dadosPerformanceconteiner.appendChild(btnPerformance);
          }

        }

      } else {
        let dadosPerformance = document.createElement('div');
        dadosPerformance.className = 'dados-performance-catalogo';
        dadosPerformance.id = 'dados-performance-' + id;
        dadosPerformance.innerHTML = `
          <p>Avantpro informa: Anuncio de catálogo não pode ser monitorado no momento.</p>
        `
        $(this)
          .find(
            '.sc-list-item-row-description'
          )
          .append(dadosPerformance)
      }

    })

  }


  static caixaAviso(aviso, cor) {
    if (aviso.MENSAGEM) {
      var Titulo = document.getElementsByClassName('ui-search-results ui-search-results--without-disclaimer')[0];

      /* Criando botao  */
      var CriadoValue = document.createElement('div');
      CriadoValue.className = 'divAviso';
      CriadoValue.setAttribute("style", `background-color:${cor.MENSAGEM} !important`);
      CriadoValue.innerHTML = `<span class="aviso">${aviso.MENSAGEM}</span>`;
      Titulo.prepend(CriadoValue);
    }
  }



  static tendencias(itemList) {
    if (document.contains(document.querySelector(".loading"))) {
      document.querySelector('.loading').remove();
    }

    // Para cada item
    $('.searches__list_tendencias > .searches__item').each(function () {
      let termo = $(this).find("a")[0].innerHTML;
      let item = itemList.find((item) => item.query === termo)

      if (
        item &&
        $(this).find(
          'a'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('span');
        dadosAnuncio.className = 'dados-anuncio';
        dadosAnuncio.setAttribute("style", "color: red; font-size:12px; margin-left: 5px");
        let cabecalho = '';
        let flecha = '';
        switch (item.dadosContabilizados.classificacao) {
          case 'red':
            flecha = '↓';
            cabecalho = `<p style="
            background: red; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Alta</p>`;
            break;
          case 'orange':
            flecha = '→';
            cabecalho = `<p style="
            background: orange; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Média</p>`;
            break;
          case 'green':
            flecha = '↑';
            cabecalho = `<p style="
            background: green; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }

        dadosAnuncio.innerHTML =
          `<svg height="8" width="8">
            <circle cx="4" cy="4" r="4" fill="${item.dadosContabilizados.classificacao}" />
            <span style="margin-left: 4px; color: ${itens[i].dadosContabilizados.classificacao}"><strong>${flecha}</strong></span>
          </svg>
          <div class="hide">
            ${cabecalho}
            <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${item.paging.total}</strong> anúncio(s)</p>
            <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.full}</strong> estão no Full</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.flex}</strong> usam Flex</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.gold}</strong> são de vendedores Gold</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.silver}</strong> são de vendedores Líder</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
            <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
          </div>
          `
        $(this)
          .find(
            'a'
          )
          .after(dadosAnuncio)
      }
    })
  }


  static pesquisaPorAnuncioValidacao(itemList) {
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {

        /* 
         if (document.contains(document.querySelector(".loading"))) {
           document.querySelector('.loading').remove();
         }
        */

        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'validacao';
        medalhaVendedor.setAttribute("style", "padding: 10px");


        medalhaVendedor.innerHTML =
          `<div>
          <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 10px;">Comece a usar o Avantpro!</h4>
          <button class="btn btn-primary" style="width: 100%; margin: 5px auto 10px auto;" onclick="(function(){
            document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;');
            })()">ENTRAR</button>
          <h5 style="text-align: center; color: var(--grey);">Não possui uma conta? <a href="https://www.viapedidos.com/empresa/cadastromlpro" target="blank">Crie uma aqui</a></h5>
        </div>`

        $(this)
          .find(
            '.ui-search-result__image'
          )
          .after(medalhaVendedor)
      }
    })


  }


  static menuLateralValidacao() {
    let medalhaVendedor = document.createElement('div')
    medalhaVendedor.className = 'ui-menu-lateral'

    medalhaVendedor.innerHTML = `
      <center><img width="180px" src="https://ramcloud.com.br/img/logomelipro.png?time=${new Date().getTime()}" /></center>
      <div style="margin-bottom: 15px;">
        <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 10px;">Comece a usar o Avantpro!</h4>
        <button class="btn btn-primary" style="width: 100%; margin: 5px auto 10px auto;" onclick="(function(){
          document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;');
          })()">ENTRAR</button>
        <h5 style="text-align: center; color: var(--grey);">Não possui uma conta? <a href="https://www.viapedidos.com/empresa/cadastromlpro" target="blank">Crie uma aqui</a></h5>
      </div>

      <div style="margin-bottom: 15px;">
        <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 10px;">Tutoriais</h4>
        <div class="card-videos" style="margin-left: auto; margin-right: auto;" onclick="javascript:window.open('https://www.youtube.com/watch?v=dIOhPlRyz_c', '_blank');">
          <div>
            <img style="width: 105px;" src="https://i.ytimg.com/vi_webp/dIOhPlRyz_c/default.webp"></img>
          </div>
          <div style="margin-left: 8px;">
            <p class="tituloCard" style="font-size: 15px !important;">Como ativar a ferramenta</p>
          </div>
        </div>
      
        <div class="card-videos" style="margin-left: auto; margin-right: auto;" onclick="javascript:window.open('https://www.youtube.com/watch?v=yQcNNssDSSI');">
          <div>
            <p class="tituloCard" style="font-size: 15px !important;">Validou seu e-mail, mas a extensão não carregou?</p>
          </div>
          <div>
            <img style="width: 105px;" src="https://i.ytimg.com/vi_webp/yQcNNssDSSI/default.webp"></img>
          </div>
        </div>
      </div>

      <div style="margin-bottom: 15px;">
        <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 8px;">Contatos</h4>
        <div class="linha-2">
          <button class="btn btn-success" onClick="javascript:window.open('https://linktr.ee/grupoavantpro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.4389 3.74208C16.5175 2.81601 15.42 2.08175 14.2104 1.58214C13.0008 1.08252 11.7034 0.827551 10.3937 0.832091C4.90628 0.832091 0.433918 5.28208 0.433918 10.7421C0.433918 12.4921 0.896229 14.1921 1.76055 15.692L0.353516 20.832L5.6299 19.452C7.08718 20.242 8.72537 20.662 10.3937 20.662C15.8812 20.662 20.3535 16.212 20.3535 10.7521C20.3535 8.10207 19.3183 5.61208 17.4389 3.74208ZM10.3937 18.982C8.90628 18.982 7.44899 18.582 6.17261 17.832L5.8711 17.652L2.73542 18.472L3.5696 15.432L3.36859 15.122C2.54221 13.809 2.1034 12.2913 2.10226 10.7421C2.10226 6.20207 5.82085 2.50209 10.3837 2.50209C12.5947 2.50209 14.6751 3.36208 16.2329 4.92208C17.0042 5.68604 17.6155 6.59474 18.0313 7.5955C18.4471 8.59626 18.6591 9.66917 18.655 10.7521C18.6751 15.292 14.9565 18.982 10.3937 18.982ZM14.9364 12.8221C14.6852 12.7021 13.459 12.1021 13.2379 12.0121C13.0068 11.9321 12.846 11.8921 12.6751 12.1321C12.5043 12.3821 12.0319 12.9421 11.8912 13.1021C11.7505 13.2721 11.5997 13.2921 11.3485 13.1621C11.0972 13.0421 10.2932 12.7721 9.34849 11.9321C8.60477 11.2721 8.11231 10.4621 7.96156 10.2121C7.82085 9.96206 7.94145 9.83206 8.07211 9.70206C8.18266 9.59206 8.32336 9.41206 8.44397 9.27207C8.56457 9.13206 8.61482 9.02207 8.69522 8.86207C8.77563 8.69207 8.73542 8.55207 8.67512 8.43207C8.61482 8.31207 8.11231 7.09207 7.9113 6.59207C7.7103 6.11208 7.49924 6.17207 7.34849 6.16208H6.86608C6.69522 6.16208 6.43392 6.22207 6.20276 6.47207C5.98166 6.72207 5.33844 7.32207 5.33844 8.54207C5.33844 9.76206 6.23291 10.9421 6.35352 11.1021C6.47412 11.2721 8.11231 13.7721 10.6048 14.842C11.1977 15.102 11.66 15.252 12.0219 15.362C12.6148 15.552 13.1575 15.522 13.5897 15.462C14.0721 15.392 15.0671 14.862 15.2681 14.2821C15.4791 13.7021 15.4791 13.2121 15.4088 13.1021C15.3384 12.9921 15.1877 12.9421 14.9364 12.8221Z" fill="currentColor"/></svg>WHATSAPP</button>
          <button class="btn btn-info" onClick="javascript:window.open('https://t.me/mercadolivrepro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.3444 1.22126C20.1394 1.02947 19.8912 0.902585 19.6262 0.854103C19.3612 0.805621 19.0892 0.83735 18.8392 0.945917L1.79307 8.33936C1.49408 8.46516 1.24083 8.69601 1.0723 8.99637C0.90378 9.29673 0.829332 9.64994 0.860422 10.0016C0.888159 10.3531 1.01834 10.6853 1.23144 10.9482C1.44454 11.2111 1.72908 11.3907 2.04239 11.4599L6.37318 12.4083V18.3842C6.37302 18.7075 6.45983 19.0236 6.62259 19.2923C6.78535 19.561 7.01673 19.7703 7.28735 19.8935C7.46646 19.9731 7.65757 20.0146 7.85063 20.0159C8.04468 20.0167 8.23692 19.9747 8.41609 19.8924C8.59526 19.8101 8.75776 19.6891 8.89409 19.5366L11.295 16.8954L14.924 20.4238C15.1919 20.6848 15.5363 20.8297 15.8935 20.8317C16.0506 20.8353 16.207 20.8077 16.3552 20.7501C16.5989 20.665 16.8182 20.5111 16.9915 20.3036C17.1648 20.0961 17.2861 19.8423 17.3433 19.5672L20.8153 2.82232C20.876 2.53338 20.8642 2.23164 20.7812 1.94954C20.6983 1.66744 20.5472 1.41565 20.3444 1.22126ZM6.93646 10.8684L2.33788 9.85884L15.2287 4.26022L6.93646 10.8684ZM7.85063 18.3842V13.5505L10.1776 15.8144L7.85063 18.3842ZM15.9028 19.2001L8.29387 11.8066L19.2547 3.06707L15.9028 19.2001Z" fill="currentColor"/></svg>TELEGRAM</button>
        </div>

        <center>
          <p style="color: var(--grey); margin-top: 5px;"><svg style="margin-right: 4px;" width="16" height="12" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20 2C20 0.9 19.1 0 18 0H2C0.9 0 0 0.9 0 2V14C0 15.1 0.9 16 2 16H18C19.1 16 20 15.1 20 14V2ZM18 2L10 7L2 2H18ZM18 14H2V4L10 9L18 4V14Z" fill="#3D3D3D"/></svg>mlpro@ramsolution.com.br</p>
        </center>

      </div>
      

      <center><small style="color: gray; font-size: 12px; margin-top: -5px">Versão ${chrome.runtime.getManifest().version}</small></center>`

    document.getElementsByClassName('ui-search-filter-groups')[0].insertAdjacentElement("afterbegin", medalhaVendedor);

  }

  /** TENDENCIAS EXTRA */

  static tendenciasExtra(itens) {

    let tentendeciasExtra = document.createElement('div')
    tentendeciasExtra.className = 'tendencias-extra';
    tentendeciasExtra.setAttribute("style", "padding: 5px !important; width: 100%");

    let listaExtra1 = `<div class="searches__column">`
    let listaExtra2 = `<div class="searches__column">`
    let listaExtra3 = `<div class="searches__column">`
    let listaExtra4 = `<div class="searches__column">`
    let cabecalho = '';

    let flecha = '';

    for (let i = 0; i < 25; i++) {
      if (itens[i] == undefined) {
        i = 25;
      } else {
        switch (itens[i].dadosContabilizados.classificacao) {
          case 'red':
            flecha = '↓';
            cabecalho = `<p style="
              background: red; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Alta</p>`;
            break;
          case 'orange':
            flecha = '→';
            cabecalho = `<p style="
              background: orange; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Média</p>`;
            break;
          case 'green':
            flecha = '↑';
            cabecalho = `<p style="
              background: green; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }
        listaExtra1 += `
            <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
              <li class="searches__item">
                <a href="${itens[i].url}">${itens[i].keyword.substring(0, 25)}</a>
                <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                    <svg height="8" width="8">
                    <circle cx="4" cy="4" r="4" fill="${itens[i].dadosContabilizados.classificacao}" />
                    <span style="margin-left: 4px; color: ${itens[i].dadosContabilizados.classificacao}"><strong>${flecha}</strong></span>
                  </svg>
                  <div class="hide">
                    ${cabecalho}
                    <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${itens[i].total}</strong> anúncio(s)</p>
                    <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.full}</strong> estão no Full</p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.flex}</strong> usam Flex</p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.gold}</strong> são de vendedores Gold</p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.silver}</strong> são de vendedores Líder</p>
                    <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
                    <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                  </div>
                </span>
              
              </li>
            </ol>
        `
      }
    }





    for (let i = 25; i < 50; i++) {
      if (itens[i] == undefined) {
        i = 50;
      } else {
        switch (itens[i].dadosContabilizados.classificacao) {
          case 'red':
            flecha = '↓';
            cabecalho = `<p style="
                background: red; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Alta</p>`;
            break;
          case 'orange':
            flecha = '→';
            cabecalho = `<p style="
                background: orange; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Média</p>`;
            break;
          case 'green':
            flecha = '↑';
            cabecalho = `<p style="
                background: green; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }

        listaExtra2 += `
          <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
            <li class="searches__item">
              <a href="${itens[i].url}">${itens[i].keyword.substring(0, 25)}</a>
              <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                  <svg height="8" width="8">
                  <circle cx="4" cy="4" r="4" fill="${itens[i].dadosContabilizados.classificacao}" />
                  <span style="margin-left: 4px; color: ${itens[i].dadosContabilizados.classificacao}"><strong>${flecha}</strong></span>
                </svg>
                <div class="hide">
                  ${cabecalho}
                  <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${itens[i].total}</strong> anúncio(s)</p>
                  <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.full}</strong> estão no Full</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.flex}</strong> usam Flex</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.gold}</strong> são de vendedores Gold</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.silver}</strong> são de vendedores Líder</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
                  <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                </div>
              </span>
            
            </li>
          </ol>
      `
      }
    }


    for (let i = 50; i < 75; i++) {
      if (itens[i] == undefined) {
        i = 75;
      } else {
        switch (itens[i].dadosContabilizados.classificacao) {
          case 'red':
            flecha = '↓';
            cabecalho = `<p style="
                background: red; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Alta</p>`;
            break;
          case 'orange':
            flecha = '→';
            cabecalho = `<p style="
                background: orange; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Média</p>`;
            break;
          case 'green':
            flecha = '↑';
            cabecalho = `<p style="
                background: green; 
                color: white; 
                padding: 5px; 
                text-align: center; 
                font-size: 16px; 
                margin: -15px; 
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                margin-bottom: 10px;
                ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }
        listaExtra3 += `
              <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
                <li class="searches__item">
                  <a href="${itens[i].url}">${itens[i].keyword.substring(0, 25)}</a>
                  <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                      <svg height="8" width="8">
                      <circle cx="4" cy="4" r="4" fill="${itens[i].dadosContabilizados.classificacao}" />
                      <span style="margin-left: 4px; color: ${itens[i].dadosContabilizados.classificacao}"><strong>${flecha}</strong></span>
                    </svg>
                    <div class="hide">
                      ${cabecalho}
                      <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${itens[i].total}</strong> anúncio(s)</p>
                      <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.full}</strong> estão no Full</p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.flex}</strong> usam Flex</p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.gold}</strong> são de vendedores Gold</p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.silver}</strong> são de vendedores Líder</p>
                      <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
                      <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                    </div>
                  </span>
                
                </li>
              </ol>
          `
      }

    }




    for (let i = 75; i < 100; i++) {
      if (itens[i] == undefined) {
        i = 100;
      } else {
        switch (itens[i].dadosContabilizados.classificacao) {
          case 'red':
            flecha = '↓';
            cabecalho = `<p style="
            background: red; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Alta</p>`;
            break;
          case 'orange':
            flecha = '→';
            cabecalho = `<p style="
            background: orange; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Média</p>`;
            break;
          case 'green':
            flecha = '↑';
            cabecalho = `<p style="
            background: green; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }
        listaExtra4 += `
          <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
            <li class="searches__item">
              <a href="${itens[i].url}">${itens[i].keyword.substring(0, 25)}</a>
              <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                  <svg height="8" width="8">
                  <circle cx="4" cy="4" r="4" fill="${itens[i].dadosContabilizados.classificacao}" />
                  <span style="margin-left: 4px; color: ${itens[i].dadosContabilizados.classificacao}"><strong>${flecha}</strong></span>
                </svg>
                <div class="hide">
                  ${cabecalho}
                  <p style="margin: 15px 0px !important;">Esse termo resultou <strong>${itens[i].total}</strong> anúncio(s)</p>
                  <p style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.full}</strong> estão no Full</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.flex}</strong> usam Flex</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.gold}</strong> são de vendedores Gold</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.silver}</strong> são de vendedores Líder</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
                  <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                </div>
              </span>
            
            </li>
          </ol>
      `
      }
    }



    listaExtra1 += "<br></br></div>"
    listaExtra2 += "<br></br></div>"
    listaExtra3 += "<br></br></div>"
    listaExtra4 += "<br></br></div>"


    tentendeciasExtra.innerHTML = `<center><h2 style="margin-top: 15px; width: 100%; border-top: solid 1px lightgray; margin-bottom: -5px;"><strong>Termos Avantpro</strong></h2></center>`
      + `<center><small>Termos 1 ao 50 Mais Buscados por Categoria (pode retornar menos termos dependendo da demanda da categoria)</small></center>`
      + `<div class="tendencias-extra-info" style="background: white; width: 100%; height: 585px; flex-direction: row; display: flex; border-radius: 10px; margin-top: 10px; box-shadow: 0 2px 3px 0 rgb(0 0 0 / 20%); -webkit-box-shadow: 0 2px 3px 0 rgb(0 0 0 / 20%);">
          <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra1}</div>
          <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra2}</div>
          <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra3}</div>
          <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra4}</div>
          </div>`


    if (document.getElementsByClassName('ui-category-navigation-carousel')[0] == undefined) {
      document.getElementsByClassName('ui-search-layout--grid__container')[0].insertAdjacentElement("beforebegin", tentendeciasExtra);
    } else {
      document.getElementsByClassName('ui-category-navigation-carousel')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    }

  }


  static tendenciasCalendario(sazonalidades) {
    let janeiro = '';
    let fevereiro = '';
    let marco = '';
    let abril = '';
    let maio = '';
    let junho = '';
    let julho = '';
    let agosto = '';
    let setembro = '';
    let outubro = '';
    let novembro = '';
    let dezembro = '';


    for (let i = 0; i < sazonalidades.janeiro.length; i++) {
      janeiro += `<li class="li-sazonalidade">${sazonalidades.janeiro[i]}</li>`;
    }


    for (let i = 0; i < sazonalidades.fevereiro.length; i++) {
      fevereiro += `<li class="li-sazonalidade">${sazonalidades.fevereiro[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.marco.length; i++) {
      marco += `<li class="li-sazonalidade">${sazonalidades.marco[i]}</li>`;
    }


    for (let i = 0; i < sazonalidades.abril.length; i++) {
      abril += `<li class="li-sazonalidade">${sazonalidades.abril[i]}</li>`;
    }


    for (let i = 0; i < sazonalidades.maio.length; i++) {
      maio += `<li class="li-sazonalidade">${sazonalidades.maio[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.junho.length; i++) {
      junho += `<li class="li-sazonalidade">${sazonalidades.junho[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.julho.length; i++) {
      julho += `<li class="li-sazonalidade">${sazonalidades.julho[i]}</li>`;
    }


    for (let i = 0; i < sazonalidades.agosto.length; i++) {
      agosto += `<li class="li-sazonalidade">${sazonalidades.agosto[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.setembro.length; i++) {
      setembro += `<li class="li-sazonalidade">${sazonalidades.setembro[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.outubro.length; i++) {
      outubro += `<li class="li-sazonalidade">${sazonalidades.outubro[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.novembro.length; i++) {
      novembro += `<li class="li-sazonalidade">${sazonalidades.novembro[i]}</li>`;
    }

    for (let i = 0; i < sazonalidades.dezembro.length; i++) {
      dezembro += `<li class="li-sazonalidade">${sazonalidades.dezembro[i]}</li>`;
    }




    let calendario = document.createElement('div')
    calendario.className = 'tendencias-calendario';
    calendario.setAttribute("style", "padding: 5px; !important");

    calendario.innerHTML = `<div style="margin-top: 15px">
      <hr size="1" color="lightgray" style="margin-top: 15px;"><center><h2><strong>Calendário de Sazonalidade Avantpro</strong></h2></center>
      <center><p style="margin-top: -5px; margin-bottom: 8px;">Confira as principais datas comemorativas ao longo do ano para poder se programar e vender ainda mais</p></center>
      <table style="width:100%; margin-top: -10px; border-collapse: separate !important; text-indent: initial !important; border-spacing: 10px !important;" cellspacing="10" cellpadding="4" >
        <tr>
          <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
          <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Janeiro</strong></span></center></div>
          <div style="height: 130px; padding: 5px">
            <ul style="font-size: 13px">
             ${janeiro}
            </ul>
          </div>
          </td>

          <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
          <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Fevereiro</strong></span></center></div>
          <div style="height: 130px; padding: 5px">
            <ul style="font-size: 13px">
            ${fevereiro}
            </ul>
          </div>
          </td>

          <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
          <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Março</strong></span></center></div>
          <div style="height: 130px; padding: 5px">
            <ul style="font-size: 13px">
            ${marco}
            </ul>
          </div>
          </td>

          <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
          <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Abril</strong></span></center></div>
          <div style="height: 130px; padding: 5px">
            <ul style="font-size: 13px">
              ${abril}
            </ul>
          </div>
          </td>
        </tr>


        <tr>
        <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
        <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Maio</strong></span></center></div>
        <div style="height: 130px; padding: 5px">
          <ul style="font-size: 13px">
          ${maio}
          </ul>
        </div>
        </td>

        <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
        <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Junho</strong></span></center></div>
        <div style="height: 130px; padding: 5px">
          <ul style="font-size: 13px">
          ${junho}
          </ul>
        </div>
        </td>

        <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
        <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Julho</strong></span></center></div>
        <div style="height: 130px; padding: 5px">
          <ul style="font-size: 13px">
          ${julho}
          </ul>
        </div>
        </td>

        <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
        <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Agosto</strong></span></center></div>
        <div style="height: 130px; padding: 5px">
          <ul style="font-size: 13px">
          ${agosto}
          </ul>
        </div>
        </td>
      </tr>



      <tr>
      <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
      <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Setembro</strong></span></center></div>
      <div style="height: 130px; padding: 5px">
        <ul style="font-size: 13px">
        ${setembro}
        </ul>
      </div>
      </td>

      <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
      <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Outubro</strong></span></center></div>
      <div style="height: 130px; padding: 5px">
        <ul style="font-size: 13px">
        ${outubro}
        </ul>
      </div>
      </td>

      <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
      <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Novembro</strong></span></center></div>
      <div style="height: 130px; padding: 5px">
        <ul style="font-size: 13px">
        ${novembro}
        </ul>
      </div>
      </td>

      <td style="height: 170px; width: 25%; border: 2px solid lightgray; border-radius: 10px; padding: 0px">
      <div style="line-height: 24px; background: lightgray; border-top-right-radius: 3px; border-top-left-radius: 3px; width: 100%; margin-top: -14px;"><center><span style="color: #3498D8"><strong>Dezembro</strong></span></center></div>
      <div style="height: 130px; padding: 5px">
        <ul style="font-size: 13px">
        ${dezembro}
        </ul>
      </div>
      </td>
    </tr>

    </table>

      </div>`

    if (document.getElementsByClassName('ui-category-navigation-carousel')[0] == undefined) {
      document.getElementsByClassName('tendencias-extra')[0].insertAdjacentElement("beforeend", calendario);
    } else {
      document.getElementsByClassName('tendencias-extra')[0].insertAdjacentElement("beforeend", calendario);
    }
  }


  static tendenciasExtraDados(rawTendenciasDadosExtra, ultra) {
    let tentendeciasExtra = document.createElement('div')
    tentendeciasExtra.className = 'andes-card sidebar__card';
    tentendeciasExtra.setAttribute("style", "padding: 10px 12px !important; width: 240px;");

    let totalAnuncios = rawTendenciasDadosExtra.paging.total;
    let lojasOficiais = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'official_store');
    lojasOficiais = lojasOficiais[0].values.length;

    let anunciosPremium = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'installments');
    anunciosPremium = anunciosPremium[0] != undefined ? anunciosPremium[0].values.filter(item => String(item.id) == 'no_interest') : '';
    anunciosPremium = anunciosPremium[0] != undefined ? anunciosPremium[0].results : 0;
    let anunciosClassicos = (totalAnuncios - anunciosPremium);

    let anunciosFull = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'shipping');
    anunciosFull = anunciosFull[0] != undefined ? anunciosFull[0].values.filter(item => String(item.id) == 'fulfillment') : 0;
    anunciosFull = anunciosFull[0] != undefined ? anunciosFull[0].results : 0;

    let vendedoresMedalhas = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'power_seller');
    vendedoresMedalhas = vendedoresMedalhas[0] != undefined ? vendedoresMedalhas[0].values.filter(item => String(item.id) == 'yes') : 0;
    vendedoresMedalhas = vendedoresMedalhas[0] != undefined ? vendedoresMedalhas[0].results : 0;

    let anunciosHoje = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'since');
    anunciosHoje = anunciosHoje[0] != undefined ? anunciosHoje[0].values.filter(item => String(item.id) == 'today') : 0;
    anunciosHoje = anunciosHoje[0] != undefined ? anunciosHoje[0].results : 0;

    let anunciosVideo = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'has_video');
    anunciosVideo = anunciosVideo[0] != undefined ? anunciosVideo[0].values.filter(item => String(item.id) == 'yes') : 0;
    anunciosVideo = anunciosVideo[0] != undefined ? anunciosVideo[0].results : 0;

    let anunciosFreteGratis = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'shipping_cost');
    anunciosFreteGratis = anunciosFreteGratis[0] != undefined ? anunciosFreteGratis[0].values.filter(item => String(item.id) == 'free') : 0;
    anunciosFreteGratis = anunciosFreteGratis[0] != undefined ? anunciosFreteGratis[0].results : 0;

    let anunciosNacionais = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'SHIPPING_ORIGIN');
    anunciosNacionais = anunciosNacionais[0] != undefined ? anunciosNacionais[0].values.filter(item => String(item.name) == 'Local') : 0;
    anunciosNacionais = anunciosNacionais[0] != undefined ? anunciosNacionais[0].results : 0;
    anunciosNacionais = anunciosNacionais == 0 ? totalAnuncios : anunciosNacionais;

    let anunciosInternacionais = totalAnuncios - anunciosNacionais;

    let qtdPorEstado = rawTendenciasDadosExtra.available_filters.filter(item => String(item.id) == 'state');
    qtdPorEstado = qtdPorEstado[0].values;


    let anunciosEstado = `<strong><p style="margin-top: 20px; margin-bottom: 5px; font-weight: bold; font-size: 14px;">QUANTIDADE DE ANÚNCIOS POR ESTADO:</p></strong>`;
    for (let i = 0; i < qtdPorEstado.length; i++) {
      anunciosEstado += `<p class="menuTendencias">${qtdPorEstado[i].name}: <strong>${qtdPorEstado[i].results.toLocaleString('pt-BR')}</strong></p>`;

    }




    tentendeciasExtra.innerHTML = `<center><img width="100px" src="https://ramcloud.com.br/img/logomelipro.png?time=${new Date().getTime()}"/></center>`
      + `<center><small style="color: gray; font-size: 12px; margin-top: -5px">Versão ${chrome.runtime.getManifest().version}</small></center>`
      + `<center><p style="margin-top: 5px; margin-bottom: 5px; font-weight: bold; font-size: 14px;">MÉTRICAS DESSA CATEGORIA: </p></center>`
      + `<p class="menuTendencias">Total de Anúncios: <strong>${totalAnuncios.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Lojas Oficiais: <strong>${lojasOficiais.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Premium: <strong>${anunciosPremium.toLocaleString('pt-BR')} | ${((anunciosPremium / totalAnuncios) * 100).toFixed(2)}%</strong> </p>`
      + `<p class="menuTendencias">Anúncios Clássico: <strong>${anunciosClassicos.toLocaleString('pt-BR')} | ${((anunciosClassicos / totalAnuncios) * 100).toFixed(2)}%</strong> </p>`
      + `<p class="menuTendencias">Anúncios no Full: <strong>${anunciosFull.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Vendedores C/ Medalha: <strong>${vendedoresMedalhas.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Criados Hoje: <strong>${anunciosHoje.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Com Vídeo: <strong>${anunciosVideo.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios com Frete Gratis: <strong>${anunciosFreteGratis.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Nacionais: <strong>${anunciosNacionais.toLocaleString('pt-BR')}</strong> </p>`
      + `<p class="menuTendencias">Anúncios Internacionais: <strong>${anunciosInternacionais.toLocaleString('pt-BR')}</strong> </p>`
      + `${ultra ? anunciosEstado : ''}`
      + `<center><p style="margin-top: 20px; margin-bottom: 5px; font-size: 12px">powered by:  Avantpro</p></center>`


    if (document.getElementsByClassName('ui-search-filter-dl')[0] == undefined) {
      document.getElementsByClassName('ui-search-breadcrumb__title')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    } else {
      document.getElementsByClassName('ui-search-filter-dl')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    }


  }

  static loadingTendencias() {

    let tentendeciasExtra = document.createElement('div')
    tentendeciasExtra.className = 'loading'

    tentendeciasExtra.innerHTML =
      `
      <center>
      <div class="loader"><svg width="37" height="50" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <defs>
      <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
      <stop offset="0.139315" stop-color="#271BEF"/>
      <stop offset="0.942129" stop-color="#00C2FF"/>
      </linearGradient>
      <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
      <stop offset="0.0921191" stop-color="#00C2FF"/>
      <stop offset="0.970863" stop-color="#271BEF"/>
      </linearGradient>
      </defs>
      </svg>
      <p>Carregando dados Avantpro...</p>
      </div>
      </center>
      `



    if (document.getElementsByClassName('ui-view-desktop-with-menu')[0] == undefined) {
      document.getElementsByClassName('ui-view-desktop-without-menu')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    } else {
      document.getElementsByClassName('ui-view-desktop-with-menu')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    }

  }

  static tenteNovamenteTendencias() {

    if (document.contains(document.querySelector(".loading"))) {
      document.querySelector('.loading').remove();
    }

    let tenteNovamente = document.createElement('div')
    tenteNovamente.className = 'tenteNovamente'



    tenteNovamente.innerHTML =
      `<center><p class="msgTenteNovamente"><strong>Avantpro informa: O Mercado Livre esta com instabilidade para nos informar as tendências, tente novamente mais tarde....</p></strong>`


    if (document.getElementsByClassName('ui-view-desktop-with-menu')[0] == undefined) {
      document.getElementsByClassName('ui-view-desktop-without-menu')[0].insertAdjacentElement("beforeend", tenteNovamente);
    } else {
      document.getElementsByClassName('ui-view-desktop-with-menu')[0].insertAdjacentElement("beforeend", tenteNovamente);
    }

  }


  static botaoAnunciosMaisVendidos(itemList) {
    /* Criando botao  */
    var CriadoValue = document.createElement('div');
    CriadoValue.className = 'subtitleData';
    itemList
    for (let i = 0; i < itemList.RESULT.length; i++) {
      itemList.RESULT[i].title = itemList.RESULT[i].title.replace(/'/g, ' ').replace(/"/g, ' ');
      //.replace('a', 'x')
    }


    let json = JSON.stringify(itemList).replace(/"/g, "\\'");


    CriadoValue.innerHTML = `<button style="margin-bottom: -15px !important; margin-top: 8px; width: 100%" class="botaoAnunciosMaisVendidos"onclick="(function(){
      document.dispatchEvent(new CustomEvent('AnunciosMaisVendidos',{detail : { teste: '${json}' } } ));
      })()      
      "> Veja os 20 anúncios mais vendidos dessa categoria</button>`;

    if (document.getElementsByClassName('tendencias-extra-info')[0] != undefined) {
      document.getElementsByClassName('tendencias-extra-info')[0].insertAdjacentElement("beforebegin", CriadoValue);
    }
  }

  static botaoAnunciosMaisVendidosGratis(itemList) {

    /*  var Titulo = document.getElementsByClassName('andes-card searches')[0];
 
     var CriadoValue = document.createElement('div');
     CriadoValue.className = 'subtitleData';
     CriadoValue.setAttribute("style", "  margin-top: -20px");
 
     CriadoValue.innerHTML = `<button class="botaoAnunciosMaisVendidos" style="background: gray"> Veja os 20 anúncios mais vendidos dessa categoria</button>`;
     Titulo.prepend(CriadoValue); */
  }

  /** FIM TENDENCIAS EXTRA */


  /** VERSAO GRATIS */

  static pesquisaPorAnuncioGratis(itemList) {
    // Para cada item
    $('.ui-search-layout > .ui-search-layout__item').each(function () {
      let id = $(this).find('input[name=itemId]').val()
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.ui-search-item__group.ui-search-item__group--title'
        ).length
      ) {

        if (document.contains(document.querySelector(".loading"))) {
          document.querySelector('.loading').remove();
        }

        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'medalha-vendedor';
        medalhaVendedor.setAttribute("style", "margin-left: -7px; margin-right: -7px; color: gray");


        let tipoMedalha = '';
        switch (item.seller.seller_reputation.power_seller_status) {
          case 'platinum':
            tipoMedalha = 'Platinum';
            break;
          case 'silver':
            tipoMedalha = 'Líder';
            break;
          case 'gold':
            tipoMedalha = 'Gold';
            break;
          default:
            tipoMedalha = 'Sem Medalha';
            break;
        }

        var data = item.start_time;

        const hoje = new Date();
        const dataCriacao = new Date(data);
        const diferencaDias = Math.abs(hoje.getTime() - dataCriacao.getTime());
        const diasCriacao = Math.ceil(diferencaDias / (1000 * 60 * 60 * 24));
        var reputacao = '';

        switch (item.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="green" />
            </svg>
            </div>`
            break;
          case '4_light_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgreen" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '3_yellow':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="yellow" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '2_orange':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="orange" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '1_red':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="red" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          default:
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`;
            break;
        }

        let reputacaoCinza =
          `<div>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect  width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      </div>`;

        let conversaoporvisita = '';
        if (parseInt(item.visitas) > 0 && item.vendas > 0) {
          if (item.index == 0) {
            conversaoporvisita = `<p style="margin-right: -15px">1 Venda a Cada <strong>${(item.visitas / item.vendas).toFixed(0)}</strong> Visitas | Conversão: <strong>${((1 / (item.visitas / item.vendas)) * 100).toFixed(2)}%</strong></p>`
          } else {
            conversaoporvisita = `<p style="margin-right: -15px">1 Venda a Cada <button style="width: 15px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> Visitas | Conversão: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          }
        }

        let ean = '';
        if (item.ean != null) {
          if (item.ean != 'Sem EAN') {
            ean = item.ean.split(',');
            ean = ean.filter(x => x.trim());
            ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs de variações' : ean[0];
          } else {
            ean = item.ean;
          }
        }

        let lojaoficial = item.seller.tags?.includes('brand');

        // if (item.index == 0) {
        medalhaVendedor.innerHTML =
          `<div style="justify-content: end; text-align: right;">
          <div class="cardInfos cardBadge">
            ${lojaoficial ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="14" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.68059 17.1067L5.29877 14.6686L2.68059 14.0591L2.93514 11.24L1.15332 9.10669L2.93514 6.97336L2.68059 4.15431L5.29877 3.54478L6.68059 1.10669L9.15332 2.21145L11.626 1.10669L13.0079 3.54478L15.626 4.15431L15.3715 6.97336L17.1533 9.10669L15.3715 11.24L15.626 14.0591L13.0079 14.6686L11.626 17.1067L9.15332 16.0019L6.68059 17.1067ZM7.29877 15.1638L9.15332 14.3257L11.0442 15.1638L12.0624 13.3353L14.0624 12.84L13.8806 10.7067L15.226 9.10669L13.8806 7.46859L14.0624 5.33526L12.0624 4.87812L11.0079 3.04955L9.15332 3.88764L7.26241 3.04955L6.24423 4.87812L4.24423 5.33526L4.42605 7.46859L3.08059 9.10669L4.42605 10.7067L4.24423 12.8781L6.24423 13.3353L7.29877 15.1638ZM8.38968 11.8115L12.4988 7.50669L11.4806 6.40193L8.38968 9.64002L6.82605 8.04002L5.80787 9.10669L8.38968 11.8115Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Loja oficial</p></div>' : ''}

            <div class="badgeBorder" style="position: relative;">${item.seller.seller_reputation.power_seller_status == "platinum" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado platinum</p>' : `${item.seller.seller_reputation.power_seller_status == "gold" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado gold</p>' : `${item.seller.seller_reputation.power_seller_status == "silver" ? '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Mercado líder</p>' : '<svg style="vertical-align: middle;" width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Sem medalha</p>'}`}`}</div>

            ${item.catalogo ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="14" height="11" viewBox="0 0 17 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.36954 5.90669C1.69656 5.90669 1.15332 6.44269 1.15332 7.10669C1.15332 7.77069 1.69656 8.30669 2.36954 8.30669C3.04251 8.30669 3.58575 7.77069 3.58575 7.10669C3.58575 6.44269 3.04251 5.90669 2.36954 5.90669ZM2.36954 1.10669C1.69656 1.10669 1.15332 1.64269 1.15332 2.30669C1.15332 2.97069 1.69656 3.50669 2.36954 3.50669C3.04251 3.50669 3.58575 2.97069 3.58575 2.30669C3.58575 1.64269 3.04251 1.10669 2.36954 1.10669ZM2.36954 10.7067C1.69656 10.7067 1.15332 11.2507 1.15332 11.9067C1.15332 12.5627 1.70467 13.1067 2.36954 13.1067C3.0344 13.1067 3.58575 12.5627 3.58575 11.9067C3.58575 11.2507 3.04251 10.7067 2.36954 10.7067ZM5.61278 12.7067H15.3425C15.7885 12.7067 16.1533 12.3467 16.1533 11.9067C16.1533 11.4667 15.7885 11.1067 15.3425 11.1067H5.61278C5.16683 11.1067 4.80197 11.4667 4.80197 11.9067C4.80197 12.3467 5.16683 12.7067 5.61278 12.7067ZM5.61278 7.90669H15.3425C15.7885 7.90669 16.1533 7.54669 16.1533 7.10669C16.1533 6.66669 15.7885 6.30669 15.3425 6.30669H5.61278C5.16683 6.30669 4.80197 6.66669 4.80197 7.10669C4.80197 7.54669 5.16683 7.90669 5.61278 7.90669ZM4.80197 2.30669C4.80197 2.74669 5.16683 3.10669 5.61278 3.10669H15.3425C15.7885 3.10669 16.1533 2.74669 16.1533 2.30669C16.1533 1.86669 15.7885 1.50669 15.3425 1.50669H5.61278C5.16683 1.50669 4.80197 1.86669 4.80197 2.30669Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Item catálogo</p></div>' : ''}

            ${item.taxas.listing_type_name ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="15" height="10" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Anúncio premium</p></div>' : ''}
            
            ${item.flex ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Está no flex</p></div>' : ''}

            ${item.video == "Sim" ? '<div class="badgeBorder" style="position: relative;"><svg style="vertical-align: middle;" width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.5 0C3.808 0 0 3.808 0 8.5C0 13.192 3.808 17 8.5 17C13.192 17 17 13.192 17 8.5C17 3.808 13.192 0 8.5 0ZM6.8 12.325V4.675L11.9 8.5L6.8 12.325Z" fill="#3d3d3d"/></svg><p class="tooltiptext" style="bottom: 160%; left: 50%;">Tem video</p></div>' : ''}
          </div>
        </div>


        <div style="display: flex;">
          <div style="text-align: start; width: 50%; position: relative;">
            <p class="nome-vendedor" style="margin-bottom: 5px; font-weight: unset; max-width: 100% !important;"><strong style="color: var(--grey);">Vendedor: </strong>${item.seller.nickname.substring(0, 22)}</p>
            ${document.getElementsByClassName('ui-search-layout__item shops__layout-item')[0] ? '' : `<div class="tooltiptext">${item.seller.nickname.substring(0, 22)}</div>`}

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Comissão: </strong>R$ ${item.taxas.sale_fee_amount.toFixed(2)}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Fotos: </strong>${item.fotos}</p>

            <p style="min-width: 135px;"><strong style="color: var(--grey);">Criado em: </strong>${dataCriacao.toLocaleDateString()} <div class="cardInfo" style="border: 1px solid var(--grey-light); border-radius: 50px; padding: 2px 4px 2px 4px; display: inline-flex; font-weight: 600;">Há ${diasCriacao} dias</div></p>

            <p style="margin-top: 5px;"><strong style="color: var(--grey);">EAN: </strong>${ean == '' ? 'Sem EAN' : ean}</p>
          </div>

          <div style="text-align: start; width: 50%; margin-left: 25px;">
            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Localização: </strong>${item.seller.tags ? (item.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : item.seller.address.city != null ? (item.seller.address.city + ' / ' + item.seller.address.state.replace('BR-', '')) : 'Não Informado') : 'Não Informado'}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Qualidade: </strong>${(parseFloat(item.health == null ? 1 : item.health) * 100).toFixed(0)}%</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Vendas: </strong>${item.vendas > 0 ? '+ de ' : ''} ${item.vendas}</p>

            <p style="margin-bottom: 5px;"><strong style="color: var(--grey);">Visitas: </strong>Acesse o anúncio</p>
          </div>
        </div>`
          + `<div class="linha">${reputacao}</div>`
          + `<p style="margin-top: 5px; color: var(--grey); text-align: center;">Informações: <strong>Avantpro</strong> grátis</p>`
        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(medalhaVendedor)

        var card = document.getElementsByClassName('cardBadge');

        // Card com badges
        for (let i = 0; i < card.length; i++) {
          var cardBadge = card[i].getElementsByTagName('div');

          var ultimo = cardBadge[cardBadge.length - 1];

          ultimo.classList.remove('badgeBorder');

        }
        // } else {

        /** BOTAO ASSINE JA */

        let botaoRastreio = document.createElement('div')

        botaoRastreio.innerHTML = `
        <button style="margin: 10px auto -10px auto; width: 95%" class="btn btn-primary" onClick="javascript:window.open('https://www.avantpro.com.br/', '_blank');">ASSINE O AVANTPRO</button>`

        try {
          $(this)
            .find(
              '.ui-search-variations-pill'
            )
            .remove()
        } catch (error) {

        }

        $(this)
          .find(
            '.ui-search-result__image'
          )
          .append(botaoRastreio)

        /** FIM ASSINE JA */

        /* medalhaVendedor.innerHTML =
          `<br><span>Vendedor: <button style="width: 120px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></span>`
          + `<p> Criado em: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Há <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> dias</p>`
          + `<p> Localização: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `<p>Qualid.: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Comissão: R$ <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `<p>EAN: <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `<p>Catálogo: <button style="width: 25px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Loja Oficial: <button style="width: 25px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Flex: <button style="width: 25px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `<p>Fotos: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Vídeo: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `<p>Vendas: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Visitas: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          + `${conversaoporvisita}`
          + `${reputacaoCinza}`
          + `<p style="margin-top: 5px;">powered by:  Avantpro Grátis</p>`
        $(this)
          .find(
            '.ui-search-item__group.ui-search-item__group--title'
          )
          .after(medalhaVendedor) */
        //}




      }
    })
  }


  static tendenciasExtraGratis(itens) {
    let tentendeciasExtra = document.createElement('div')
    tentendeciasExtra.className = 'tendencias-extra';

    let listaExtra1 = `<div class="searches__column">`
    let listaExtra2 = `<div class="searches__column">`
    let listaExtra3 = `<div class="searches__column">`
    let listaExtra4 = `<div class="searches__column">`
    let cabecalho = '';

    for (let i = 0; i < 25; i++) {
      if (itens[i] == undefined) {
        i = 25;
      } else {
        switch (itens[i].dadosContabilizados.classificacao) {
          case 'red':
            cabecalho = `<p style="
            background: red; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Alta</p>`;
            break;
          case 'orange':
            cabecalho = `<p style="
            background: orange; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Média</p>`;
            break;
          case 'green':
            cabecalho = `<p style="
            background: green; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Baixa</p>`;
            break;

          default:
            break;
        }
        listaExtra1 += `
          <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
            <li class="searches__item">
              <a href="${itens[i].url}">${itens[i].keyword.substring(0, 25)}</a>
              <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                  <svg height="8" width="8">
                  <circle cx="4" cy="4" r="4" fill="${itens[i].dadosContabilizados.classificacao}" />
                </svg>
                <div class="hide">
                  ${cabecalho}
                  <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${itens[i].total}</strong> anúncio(s)</p>
                  <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.full}</strong> estão no Full</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.flex}</strong> usam Flex</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.gold}</strong> são de vendedores Gold</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.silver}</strong> são de vendedores Líder</p>
                  <p class="menuTendencias"><strong>${itens[i].dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
                  <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                </div>
              </span>       
            </li>
          </ol>
      `
      }
    }


    for (let i = 25; i < 50; i++) {
      if (itens[i] == undefined) {
        i = 50;
      } else {
        switch ('gratis') {
          case 'red':
            cabecalho = `<p style="
              background: red; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Alta</p>`;
            break;
          case 'orange':
            cabecalho = `<p style="
              background: orange; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Média</p>`;
            break;
          case 'green':
            cabecalho = `<p style="
              background: green; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Baixa</p>`;
            break;
          default:
            cabecalho = `<p style="
            background: lightgray; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Assine Já para Verificar</p>`;
            break;
        }

        listaExtra2 += `
        <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
          <li class="searches__item">
          <a><button style="width: 80px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></a>
            <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
              <div class="hide">
                ${cabecalho}
                <p  style="margin: 15px 0px !important;">Esse termo resultou <strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> anúncio(s)</p>
                <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> estão no Full</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> usam Flex</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Platinum</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Gold</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Líder</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Sem Medalha</p>
                <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
              </div>
            </span>
          
          </li>
        </ol>
    `
      }
    }


    for (let i = 50; i < 75; i++) {
      if (itens[i] == undefined) {
        i = 75;
      } else {
        switch ('gratis') {
          case 'red':
            cabecalho = `<p style="
              background: red; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Alta</p>`;
            break;
          case 'orange':
            cabecalho = `<p style="
              background: orange; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Média</p>`;
            break;
          case 'green':
            cabecalho = `<p style="
              background: green; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Baixa</p>`;
            break;

          default:
            cabecalho = `<p style="
              background: lightgray; 
              color: white; 
              padding: 5px; 
              text-align: center; 
              font-size: 16px; 
              margin: -15px; 
              border-top-left-radius: 6px;
              border-top-right-radius: 6px;
              margin-bottom: 10px;
              ">Concorrência Baixa</p>`;
            break;
        }
        listaExtra3 += `
            <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
              <li class="searches__item">
                <a><button style="width: 80px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></a>
                <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
                  <div class="hide">
                    ${cabecalho}
                    <p  style="margin: 15px 0px !important;">Esse termo resultou <strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> anúncio(s)</p>
                    <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> estão no Full</p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> usam Flex</p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Platinum</p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Gold</p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Líder</p>
                    <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Sem Medalha</p>
                    <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
                  </div>
                </span>
              
              </li>
            </ol>
        `
      }

    }




    for (let i = 75; i < 100; i++) {
      if (itens[i] == undefined) {
        i = 100;
      } else {
        switch ('gratis') {
          case 'red':
            cabecalho = `<p style="
          background: red; 
          color: white; 
          padding: 5px; 
          text-align: center; 
          font-size: 16px; 
          margin: -15px; 
          border-top-left-radius: 6px;
          border-top-right-radius: 6px;
          margin-bottom: 10px;
          ">Concorrência Alta</p>`;
            break;
          case 'orange':
            cabecalho = `<p style="
          background: orange; 
          color: white; 
          padding: 5px; 
          text-align: center; 
          font-size: 16px; 
          margin: -15px; 
          border-top-left-radius: 6px;
          border-top-right-radius: 6px;
          margin-bottom: 10px;
          ">Concorrência Média</p>`;
            break;
          case 'green':
            cabecalho = `<p style="
          background: green; 
          color: white; 
          padding: 5px; 
          text-align: center; 
          font-size: 16px; 
          margin: -15px; 
          border-top-left-radius: 6px;
          border-top-right-radius: 6px;
          margin-bottom: 10px;
          ">Concorrência Baixa</p>`;
            break;
          default:
            cabecalho = `<p style="
          background: lightgray; 
          color: white; 
          padding: 5px; 
          text-align: center; 
          font-size: 16px; 
          margin: -15px; 
          border-top-left-radius: 6px;
          border-top-right-radius: 6px;
          margin-bottom: 10px;
          ">Concorrência Baixa</p>`;
            break;
        }
        listaExtra4 += `
        <ol class="searches__list_tendencias" start=${i + 1} style="margin: 5px 5px -1px -12px !important;">
          <li class="searches__item">
            <a><button style="width: 80px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></a>
            <span class="dados-anuncio" style="color: red; font-size:12px; margin-left: 5px">
              <div class="hide">
                ${cabecalho}
                <p  style="margin: 15px 0px !important;">Esse termo resultou <strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> anúncio(s)</p>
                <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> estão no Full</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> usam Flex</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Platinum</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Gold</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Líder</p>
                <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Sem Medalha</p>
                <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
              </div>
            </span>
          
          </li>
        </ol>
    `
      }
    }







    listaExtra1 += "</div>"
    listaExtra2 += "</div>"
    listaExtra3 += "</div>"
    listaExtra4 += "</div>"

    tentendeciasExtra.innerHTML = `<center><h2 style="margin-top: 15px; width: 100%; border-top: solid 1px lightgray; margin-bottom: -5px;"><strong>Termos Avantpro</strong></h2></center>`
      + `<center><small>Termos 1 ao 80 (pode retornar menos termos dependendo da demanda da categoria)</small></center>`
      + `<center> <a href="https://www.avantpro.com.br/" target="_blank"><button class="assineja">ASSINE JÁ O AVANTPRO E LIBERE TODOS OS RECURSOS</button></a> </center>`
      + `<div class="tendencias-extra-info" style="background: white; width: 100%; height: 585px; flex-direction: row; display: flex; border-radius: 10px; margin-top: 10px; box-shadow: 0 2px 3px 0 rgb(0 0 0 / 20%); -webkit-box-shadow: 0 2px 3px 0 rgb(0 0 0 / 20%);">
      <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra1}</div>
      <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra2}</div>
      <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra3}</div>
      <div style="width: 25%; border-right: 1px solid lightgray;">${listaExtra4}</div>
      </div>`


    if (document.getElementsByClassName('ui-category-navigation-carousel')[0] == undefined) {
      document.getElementsByClassName('ui-search-layout--grid__container')[0].insertAdjacentElement("beforebegin", tentendeciasExtra);
    } else {
      document.getElementsByClassName('ui-category-navigation-carousel')[0].insertAdjacentElement("beforeend", tentendeciasExtra);
    }

  }


  static tendenciasGratis(itemList) {
    if (document.contains(document.querySelector(".loading"))) {
      document.querySelector('.loading').remove();
    }

    // Para cada item
    $('.searches__list_tendencias > .searches__item').each(function () {
      let termo = $(this).find("a")[0].innerHTML;
      let item = itemList.find((item) => item.query === termo)
      if (
        item &&
        $(this).find(
          'a'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('span')
        dadosAnuncio.className = 'dados-anuncio'
        dadosAnuncio.setAttribute("style", "color: red; font-size:12px; margin-left: 5px");
        let cabecalho = '';
        switch (item.dadosContabilizados.classificacao) {
          case 'red':
            cabecalho = `<p style="
            background: red; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Alta</p>`;
            break;
          case 'orange':
            cabecalho = `<p style="
            background: orange; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Média</p>`;
            break;
          case 'green':
            cabecalho = `<p style="
            background: green; 
            color: white; 
            padding: 5px; 
            text-align: center; 
            font-size: 16px; 
            margin: -15px; 
            border-top-left-radius: 6px;
            border-top-right-radius: 6px;
            margin-bottom: 10px;
            ">Concorrência Baixa</p>`;
            break;

          default:

            break;
        }

        let cabecalhoCinza = `<p style="
        background: gray; 
        color: white; 
        padding: 5px; 
        text-align: center; 
        font-size: 16px; 
        margin: -15px; 
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
        margin-bottom: 10px;
        ">Concorrência <button style="width: 50px; background: rgb(0 0 0 / 30%); height: 12px; border-radius: 4px; border: none; "></button></p>`;

        if (item.index <= 2) {
          dadosAnuncio.innerHTML =
            `<svg height="8" width="8">
            <circle cx="4" cy="4" r="4" fill="${item.dadosContabilizados.classificacao}" />
          </svg>
          <div class="hide">
            ${cabecalho}
            <p  style="margin: 15px 0px !important;">Esse termo resultou <strong>${item.paging.total}</strong> anúncio(s)</p>
            <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.full}</strong> estão no Full</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.platinum}</strong> são de vendedores Platinum</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.gold}</strong> são de vendedores Gold</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.silver}</strong> são de vendedores Líder</p>
            <p class="menuTendencias"><strong>${item.dadosContabilizados.sem}</strong> são de vendedores Sem Medalha</p>
            <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>
          </div>
          `
          $(this)
            .find(
              'a'
            )
            .after(dadosAnuncio)
        } else {
          dadosAnuncio.innerHTML =
            `<svg height="8" width="8">
            <circle cx="4" cy="4" r="4" fill="lightgray" />
          </svg>
          <div class="hide">
            ${cabecalhoCinza}
            <p  style="margin: 15px 0px !important;">Esse termo resultou <strong><button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> anúncio(s)</p>
            <p  style="margin: 15px 0px !important;"><strong>Dos 50 anúncios da primeira página: </strong></p>
            <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> estão no Full</p>
            <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Platinum</p>
            <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Gold</p>
            <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Líder</p>
            <p class="menuTendencias"><strong><button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> são de vendedores Sem Medalha</p>
            <center><p style="margin-top: 10px; margin-bottom: -5px; font-size: 12px; ">powered by:  Avantpro Grátis</p></center>
          </div>
          `
          $(this)
            .find(
              'a'
            )
            .after(dadosAnuncio)
        }

      }
    })
  }

  static menuLateralGratis(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, rawVendedoresCompleto, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdOferta, qtdInternacional, qtdFlex, linkMenu) {
    // renderiza a medalha do vendedor
    let medalhaVendedor = document.createElement('div')
    medalhaVendedor.className = 'ui-menu-lateral'

    let anunciosPorVendas = '';

    try {
      for (let i = 0; i < rawVendedoresCompleto.length; i++) {
        let full = '';
        let gratis = '';
        let reputacao = '';
        let estado = '';
        for (let x = 0; x < rawVendedoresCompleto[i].val.available_filters.length; x++) {
          if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping") full = rawVendedoresCompleto[i].val.available_filters[x].values.length == 2 ? rawVendedoresCompleto[i].val.available_filters[x].values[1].results : 0;
          if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping_cost") gratis = rawVendedoresCompleto[i].val.available_filters[x].values[0].results
        }

        // Reputação
        switch (rawVendedoresCompleto[i].val.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="green" />
            </svg>
        `
            break;
          case '4_light_green':
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgreen" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
        `
            break;
          case '3_yellow':
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="yellow" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
        `
            break;
          case '2_orange':
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="orange" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
        `
            break;
          case '1_red':
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="red" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
       `
            break;
          default:
            reputacao =
              `
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect  width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
            <svg class="svg-termometro-menu" width="40" height="8">
            <rect width="40" height="8" fill="lightgray" />
            </svg>
        `;
            break;
        }

        // Vendedores

        //   <button class="btn btn-success" style="position: absolute; right: 0; margin-top: -5px; border-radius: 50%; width: 23.5px; padding: 3px;">
        //   <svg width="9" height="14" viewBox="0 0 17 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.6429 2.2V7.7C10.6429 8.932 11.0393 10.076 11.7143 11H5.28571C5.98213 10.054 6.35713 8.91 6.35713 7.7V2.2H10.6429ZM13.8571 0H3.14285C2.55356 0 2.07142 0.495 2.07142 1.1C2.07142 1.705 2.55356 2.2 3.14285 2.2H4.21428V7.7C4.21428 9.526 1.99999 11 0.999993 11C1.78814e-07 11 -0.121944 13.2 0.999993 13.2C2.12193 13.2 7.39642 13.2 7.39642 13.2V20.9C7.39642 20.9 7.5 22 8.46785 22C9.4357 22 9.53928 20.9 9.53928 20.9V13.2C9.53928 13.2 15 13.2 16 13.2C17 13.2 17 11 16 11C15 11 12.7857 9.526 12.7857 7.7V2.2H13.8571C14.4464 2.2 14.9286 1.705 14.9286 1.1C14.9286 0.495 14.4464 0 13.8571 0Z" fill="currentColor"/></svg>
        // </button>

        if (rawVendedoresCompleto[i].val.results.length > 0) {
          anunciosPorVendas += `
          <div class="vendedores">

            <div style="display: flex; align-items: baseline; margin-bottom: 5px;">
              <h4 class="nome-vendedor">${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "platinum" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "gold" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : `${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status == "silver" ? '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '<svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}`}`}
              ${rawVendedoresCompleto[i].val.seller.nickname} </h4>` +
            '<p class="tituloCard" style="margin-bottom: 0px;">: ' + rawVendedoresCompleto[i].val.qtdAnuncio + ' anúncio(s)</p></div>' + `

            <div class="linha-2" style="text-align: start; align-items: start;">
              <div>
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="10" height="13" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
                <ul>
                  <li>Concluidas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.completed}</strong></li>
                  <li>Canceladas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.canceled}</strong></li>
                  <li>Total: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.total}</strong></li>
                </ul>
              </div>

              <div style="margin-left: 10px;">
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="12" height="13" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.2211 2.06592H12.4433V0.565918H10.8877V2.06592H4.6655V0.565918H3.10994V2.06592H2.33217C1.46883 2.06592 0.784389 2.74092 0.784389 3.56592L0.776611 14.0659C0.776611 14.4637 0.9405 14.8453 1.23222 15.1266C1.52395 15.4079 1.91961 15.5659 2.33217 15.5659H13.2211C14.0766 15.5659 14.7766 14.8909 14.7766 14.0659V3.56592C14.7766 2.74092 14.0766 2.06592 13.2211 2.06592ZM13.2211 14.0659H2.33217V6.56592H13.2211V14.0659ZM5.44328 9.56592H3.88772V8.06592H5.44328V9.56592ZM8.55439 9.56592H6.99883V8.06592H8.55439V9.56592ZM11.6655 9.56592H10.1099V8.06592H11.6655V9.56592ZM5.44328 12.5659H3.88772V11.0659H5.44328V12.5659ZM8.55439 12.5659H6.99883V11.0659H8.55439V12.5659ZM11.6655 12.5659H10.1099V11.0659H11.6655V12.5659Z" fill="#3d3d3d"/></svg>Últimos 60 dias</p>
                <ul>
                  <li>Vendas: <strong>${rawVendedoresCompleto[i].val.seller.seller_reputation.metrics.sales.completed}</strong></li>
                  <li>Reclamações: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.claims.value}</strong></li>
                  <li>Atrasos: <strong>${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.delayed_handling_time.value}</strong></li>
                </ul>
              </div>
            </div>

            <div class="linha-2" style="text-align: start; margin-top: 10px; align-items: start;">
              <div>
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="15" height="13" viewBox="0 0 15 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.42598 6.99829H9.72598V5.49829H3.42598V6.99829ZM3.42598 4.74829H9.72598V3.24829H3.42598V4.74829ZM2.02598 12.2483C1.64098 12.2483 1.31151 12.1015 1.03758 11.808C0.763177 11.514 0.625977 11.1608 0.625977 10.7483V1.74829C0.625977 1.33579 0.763177 0.982791 1.03758 0.689291C1.31151 0.395291 1.64098 0.248291 2.02598 0.248291H13.226C13.611 0.248291 13.9407 0.395291 14.2151 0.689291C14.489 0.982791 14.626 1.33579 14.626 1.74829V10.7483C14.626 11.1608 14.489 11.514 14.2151 11.808C13.9407 12.1015 13.611 12.2483 13.226 12.2483H2.02598ZM2.02598 10.7483H13.226V1.74829H2.02598V10.7483ZM2.02598 10.7483V1.74829V10.7483Z" fill="#3D3D3D"/></svg>Anúncios</p>
                <ul>
                  <li>Total: <strong>${rawVendedoresCompleto[i].val.paging.total}</strong></li>
                  <li>No full: <strong>${full}</strong></li>
                  <li>Frete grátis: <strong>${gratis}</strong></li>
                </ul>
              </div>

              <div style="margin-left: 10px;">
                <p class="tituloCard" style="margin-bottom: 3px;"><svg style="margin-right: 4px;" width="9" height="13" viewBox="0 0 11 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.7771 7.06748C5.3035 7.06748 4.8493 6.88311 4.51441 6.55492C4.17952 6.22673 3.99139 5.78161 3.99139 5.31748C3.99139 4.85335 4.17952 4.40823 4.51441 4.08004C4.8493 3.75185 5.3035 3.56748 5.7771 3.56748C6.2507 3.56748 6.7049 3.75185 7.03979 4.08004C7.37468 4.40823 7.56281 4.85335 7.56281 5.31748C7.56281 5.54729 7.51663 5.77486 7.42688 5.98718C7.33714 6.1995 7.20561 6.39241 7.03979 6.55492C6.87397 6.71742 6.67712 6.84632 6.46046 6.93427C6.24381 7.02222 6.0116 7.06748 5.7771 7.06748ZM5.7771 0.41748C4.45102 0.41748 3.17925 0.933729 2.24157 1.85266C1.30388 2.77159 0.7771 4.01792 0.7771 5.31748C0.7771 8.99248 5.7771 14.4175 5.7771 14.4175C5.7771 14.4175 10.7771 8.99248 10.7771 5.31748C10.7771 4.01792 10.2503 2.77159 9.31263 1.85266C8.37495 0.933729 7.10318 0.41748 5.7771 0.41748Z" fill="#3D3D3D"/></svg>Localização</p>
                <ul>
                  <li>${rawVendedoresCompleto[i].val.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : (rawVendedoresCompleto[i].val.cidade != null ? (rawVendedoresCompleto[i].val.cidade + ' / ' + rawVendedoresCompleto[i].val.uf.replace('BR-', '')) : 'Não Informado')}</li>
                </ul>

                ${rawVendedoresCompleto[i].val.seller.tags[0] == 'brand' ? '<p style="color: #2AC568; font-weight: bold; font-size: 13px; display: flex; align-items: center; margin-top: 10px;"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 22 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.6 21L5.7 17.8L2.1 17L2.45 13.3L0 10.5L2.45 7.7L2.1 4L5.7 3.2L7.6 0L11 1.45L14.4 0L16.3 3.2L19.9 4L19.55 7.7L22 10.5L19.55 13.3L19.9 17L16.3 17.8L14.4 21L11 19.55L7.6 21ZM8.45 18.45L11 17.35L13.6 18.45L15 16.05L17.75 15.4L17.5 12.6L19.35 10.5L17.5 8.35L17.75 5.55L15 4.95L13.55 2.55L11 3.65L8.4 2.55L7 4.95L4.25 5.55L4.5 8.35L2.65 10.5L4.5 12.6L4.25 15.45L7 16.05L8.45 18.45ZM9.95 14.05L15.6 8.4L14.2 6.95L9.95 11.2L7.8 9.1L6.4 10.5L9.95 14.05Z" fill="#2AC568"/></svg>Loja Oficial</p>' : ''}
              </div>
            </div>

            <div class="linha" style="margin-top: 10px; margin-bottom: 10px;">
              ${reputacao}
            </div>
          </div>
          `
        } else {

        }
      }

    } catch (error) {

    }

    /**Linha para o botão sair Avantpro */
    var btnLinha = document.createElement("div");
    btnLinha.className = "linha";
    btnLinha.style.marginTop = "20px";
    btnLinha.innerHTML = `
      <button class="btn btn-danger" id="sairmlpro" style="margin-right: auto; position: relative;" title="Sair do Avantpro" role="button"><svg style="margin-right: 5px;" width="16" height="18" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.30314 0.919189H9.80314C10.2452 0.919189 10.6691 1.09478 10.9817 1.40734C11.2942 1.71991 11.4698 2.14383 11.4698 2.58586V3.41919C11.4698 3.6402 11.382 3.85216 11.2257 4.00844C11.0695 4.16473 10.8575 4.25252 10.6365 4.25252C10.4155 4.25252 10.2035 4.16473 10.0472 4.00844C9.89094 3.85216 9.80314 3.6402 9.80314 3.41919V2.58586H2.30314V15.9192H9.80314V15.0859C9.80314 14.8648 9.89094 14.6529 10.0472 14.4966C10.2035 14.3403 10.4155 14.2525 10.6365 14.2525C10.8575 14.2525 11.0695 14.3403 11.2257 14.4966C11.382 14.6529 11.4698 14.8648 11.4698 15.0859V15.9192C11.4698 16.3612 11.2942 16.7851 10.9817 17.0977C10.6691 17.4103 10.2452 17.5859 9.80314 17.5859H2.30314C1.86111 17.5859 1.43719 17.4103 1.12463 17.0977C0.812069 16.7851 0.636475 16.3612 0.636475 15.9192V2.58586C0.636475 2.14383 0.812069 1.71991 1.12463 1.40734C1.43719 1.09478 1.86111 0.919189 2.30314 0.919189Z" fill="currentColor"/><path d="M11.2991 12.8317C11.6241 13.1567 12.1491 13.1567 12.4741 12.8317L15.4641 9.84171C15.6203 9.68544 15.708 9.47352 15.708 9.25255C15.708 9.03158 15.6203 8.81965 15.4641 8.66338L12.4741 5.67338C12.3156 5.53021 12.1083 5.45337 11.8948 5.45876C11.6814 5.46415 11.4782 5.55135 11.3272 5.70233C11.1762 5.85331 11.089 6.05654 11.0836 6.26999C11.0782 6.48344 11.1551 6.69081 11.2982 6.84921L12.8616 8.41921H5.63656C5.41554 8.41921 5.20358 8.50701 5.0473 8.66329C4.89102 8.81957 4.80322 9.03153 4.80322 9.25255C4.80322 9.47356 4.89102 9.68552 5.0473 9.8418C5.20358 9.99808 5.41554 10.0859 5.63656 10.0859H12.8616L11.2982 11.6559C11.1427 11.8121 11.0554 12.0235 11.0556 12.244C11.0557 12.4644 11.1433 12.6758 11.2991 12.8317Z" fill="currentColor"/></svg>Sair<div class="tooltiptext">Sair do Avantpro</div></button>

      <button class="btn btn-disabled" style="cursor: pointer; pointer-events: all;" onclick="abrirExcelPesquisa()"><svg width="14" height="20" viewBox="0 0 14 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.04074 0.418945H11.3265C11.819 0.418945 12.2914 0.619123 12.6396 0.975442C12.9879 1.33176 13.1836 1.81503 13.1836 2.31895V17.5189C13.1836 18.0229 12.9879 18.5061 12.6396 18.8624C12.2914 19.2188 11.819 19.4189 11.3265 19.4189H2.04074C1.54819 19.4189 1.07582 19.2188 0.727538 18.8624C0.379256 18.5061 0.183594 18.0229 0.183594 17.5189V2.31895C0.183594 1.81503 0.379256 1.33176 0.727538 0.975442C1.07582 0.619123 1.54819 0.418945 2.04074 0.418945ZM2.04074 2.31895V6.11895H11.3265V2.31895H2.04074ZM2.04074 8.01895V9.91895H3.89788V8.01895H2.04074ZM5.75502 8.01895V9.91895H7.61216V8.01895H5.75502ZM9.46931 8.01895V9.91895H11.3265V8.01895H9.46931ZM2.04074 11.8189V13.7189H3.89788V11.8189H2.04074ZM5.75502 11.8189V13.7189H7.61216V11.8189H5.75502ZM9.46931 11.8189V13.7189H11.3265V11.8189H9.46931ZM2.04074 15.6189V17.5189H3.89788V15.6189H2.04074ZM5.75502 15.6189V17.5189H7.61216V15.6189H5.75502ZM9.46931 15.6189V17.5189H11.3265V15.6189H9.46931Z" fill="currentColor"/></svg><div class="tooltiptext" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>

      <button class="btn btn-disabled" style="cursor: pointer; pointer-events: all;"><svg width="16" height="20" viewBox="0 0 197 232" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="0.160156" y="121.496" width="40" height="110" fill="currentColor"/><rect x="52.2922" y="81.4956" width="40" height="150" fill="currentColor"/><rect x="104.424" y="101.496" width="40" height="130" fill="currentColor"/><rect x="156.556" y="66.6699" width="40" height="165" fill="currentColor"/><circle cx="20.1602" cy="71.6655" r="15" fill="currentColor"/><circle cx="72.2922" cy="31.6655" r="15" fill="currentColor"/><circle cx="124.424" cy="51.6699" r="15" fill="currentColor"/><circle cx="176.556" cy="15.0698" r="15" fill="currentColor"/><path d="M19.2476 74.2711L72.4429 31.2452L124.465 53.5404L177.269 15.5996" stroke="currentColor" stroke-width="13"/></svg><div class="tooltiptext" style="width: 200px;">Recurso disponível para assinantes Avantpro Ultra</div></button>
    `;

    try {
      document.getElementsByClassName('pesquisa-semelhante')[0].insertAdjacentElement("afterEnd", btnLinha);
    } catch (err) {
      document.getElementsByClassName('ui-search-search-result shops__result')[0].insertAdjacentElement("afterEnd", btnLinha);
    }

    medalhaVendedor.innerHTML =
      `<center><a href="${linkMenu.MENSAGEM}" target="_blank"><img width="200px" src="https://ramcloud.com.br/img/logomeliproMenuExtGratis.png?time=${new Date().getTime()}"  /></a></center>
      <center><p style="font-size: 13px; font-weight: 600; color: var(--grey);">Fique por dentro das novidades!</p></center>
      <div class="linha-2">
        <button class="btn btn-success" onClick="javascript:window.open('https://linktr.ee/grupoavantpro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M17.4389 3.74208C16.5175 2.81601 15.42 2.08175 14.2104 1.58214C13.0008 1.08252 11.7034 0.827551 10.3937 0.832091C4.90628 0.832091 0.433918 5.28208 0.433918 10.7421C0.433918 12.4921 0.896229 14.1921 1.76055 15.692L0.353516 20.832L5.6299 19.452C7.08718 20.242 8.72537 20.662 10.3937 20.662C15.8812 20.662 20.3535 16.212 20.3535 10.7521C20.3535 8.10207 19.3183 5.61208 17.4389 3.74208ZM10.3937 18.982C8.90628 18.982 7.44899 18.582 6.17261 17.832L5.8711 17.652L2.73542 18.472L3.5696 15.432L3.36859 15.122C2.54221 13.809 2.1034 12.2913 2.10226 10.7421C2.10226 6.20207 5.82085 2.50209 10.3837 2.50209C12.5947 2.50209 14.6751 3.36208 16.2329 4.92208C17.0042 5.68604 17.6155 6.59474 18.0313 7.5955C18.4471 8.59626 18.6591 9.66917 18.655 10.7521C18.6751 15.292 14.9565 18.982 10.3937 18.982ZM14.9364 12.8221C14.6852 12.7021 13.459 12.1021 13.2379 12.0121C13.0068 11.9321 12.846 11.8921 12.6751 12.1321C12.5043 12.3821 12.0319 12.9421 11.8912 13.1021C11.7505 13.2721 11.5997 13.2921 11.3485 13.1621C11.0972 13.0421 10.2932 12.7721 9.34849 11.9321C8.60477 11.2721 8.11231 10.4621 7.96156 10.2121C7.82085 9.96206 7.94145 9.83206 8.07211 9.70206C8.18266 9.59206 8.32336 9.41206 8.44397 9.27207C8.56457 9.13206 8.61482 9.02207 8.69522 8.86207C8.77563 8.69207 8.73542 8.55207 8.67512 8.43207C8.61482 8.31207 8.11231 7.09207 7.9113 6.59207C7.7103 6.11208 7.49924 6.17207 7.34849 6.16208H6.86608C6.69522 6.16208 6.43392 6.22207 6.20276 6.47207C5.98166 6.72207 5.33844 7.32207 5.33844 8.54207C5.33844 9.76206 6.23291 10.9421 6.35352 11.1021C6.47412 11.2721 8.11231 13.7721 10.6048 14.842C11.1977 15.102 11.66 15.252 12.0219 15.362C12.6148 15.552 13.1575 15.522 13.5897 15.462C14.0721 15.392 15.0671 14.862 15.2681 14.2821C15.4791 13.7021 15.4791 13.2121 15.4088 13.1021C15.3384 12.9921 15.1877 12.9421 14.9364 12.8221Z" fill="currentColor"/></svg>WHATSAPP</button>
        <button class="btn btn-info" onClick="javascript:window.open('https://t.me/mercadolivrepro', '_blank');"><svg style="margin-right: 4px;" width="15" height="15" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M20.3444 1.22126C20.1394 1.02947 19.8912 0.902585 19.6262 0.854103C19.3612 0.805621 19.0892 0.83735 18.8392 0.945917L1.79307 8.33936C1.49408 8.46516 1.24083 8.69601 1.0723 8.99637C0.90378 9.29673 0.829332 9.64994 0.860422 10.0016C0.888159 10.3531 1.01834 10.6853 1.23144 10.9482C1.44454 11.2111 1.72908 11.3907 2.04239 11.4599L6.37318 12.4083V18.3842C6.37302 18.7075 6.45983 19.0236 6.62259 19.2923C6.78535 19.561 7.01673 19.7703 7.28735 19.8935C7.46646 19.9731 7.65757 20.0146 7.85063 20.0159C8.04468 20.0167 8.23692 19.9747 8.41609 19.8924C8.59526 19.8101 8.75776 19.6891 8.89409 19.5366L11.295 16.8954L14.924 20.4238C15.1919 20.6848 15.5363 20.8297 15.8935 20.8317C16.0506 20.8353 16.207 20.8077 16.3552 20.7501C16.5989 20.665 16.8182 20.5111 16.9915 20.3036C17.1648 20.0961 17.2861 19.8423 17.3433 19.5672L20.8153 2.82232C20.876 2.53338 20.8642 2.23164 20.7812 1.94954C20.6983 1.66744 20.5472 1.41565 20.3444 1.22126ZM6.93646 10.8684L2.33788 9.85884L15.2287 4.26022L6.93646 10.8684ZM7.85063 18.3842V13.5505L10.1776 15.8144L7.85063 18.3842ZM15.9028 19.2001L8.29387 11.8066L19.2547 3.06707L15.9028 19.2001Z" fill="currentColor"/></svg>TELEGRAM</button>
      </div>
      <center><p style="margin-top: 10px; margin-bottom: 15px; font-size: 13px; font-weight: 500; color: var(--grey);">Precisa de Ajuda? Mande um Email: <strong style="font-weight: 600;">mlpro@ramsolution.com.br</strong></p></center>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="14" height="14" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11 6.09L13.45 7.58L12.8 4.77L15 2.89L12.11 2.64L11 0L9.87 2.64L7 2.89L9.18 4.77L8.5 7.58L11 6.09ZM14 22H8V9H14V22ZM0 16V22H6V16H0ZM4 20H2V18H4V20ZM16 12V22H22V12H16ZM20 20H18V14H20V20Z" fill="#3D3D3D"/></svg>Concorrência</p>
      <div class="linha">
        <div class="cardInfos" style="border-radius: 50px; min-height: auto !important; width: 100%; display: flex; margin: 2px 0 5px 0;">
          <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.42026" cy="9.72747" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.34497 4.90731L4.80105 2.61261L11.8889 2.61261L8.34497 4.90731Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M9.79444 8.26514L6.89478 11.1899" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.93628 8.34985L9.62879 11.0627" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Sem</p><p style="font-size: 16px;"><strong>${qtdSemMedalha}</strong></p></div>
          <div class="medalhaLider" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="15" height="14" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.85581" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3D3D3D" stroke-width="2"/><path d="M8.78052 4.90755L5.23659 2.61285L12.3244 2.61285L8.78052 4.90755Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="2"/><path d="M7.32202 9.61481L8.25936 11.1147L10.3896 8.60327" stroke="#3D3D3D" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Líder</p><p style="font-size: 16px;"><strong>${qtdLider}</strong></p></div>
          <div class="medalhaGold" style="margin: 0 auto 0 auto; position: relative;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.41928" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#DCA414" stroke-width="2"/><path d="M8.34399 4.90755L4.80007 2.61285L11.8879 2.61285L8.34399 4.90755Z" stroke="#DCA414" stroke-width="2"/><path d="M6.88525 9.60211L7.82259 11.102L9.95288 8.59058" stroke="#DCA414" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Gold</p><p style="font-size: 16px;"><strong>${qtdGold}</strong></p></div>
          <div style="margin: 0 auto 0 auto;"><p class="tituloCard"><svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg"><ellipse cx="8.13657" cy="9.72771" rx="4.28989" ry="4.38982" stroke="#3CABEA" stroke-width="2"/><path d="M8.06128 4.90755L4.51735 2.61285L11.6052 2.61285L8.06128 4.90755Z" stroke="#3CABEA" stroke-width="2"/><path d="M6.60254 9.60211L7.53988 11.102L9.67016 8.59058" stroke="#3CABEA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>Platinum</p><p style="font-size: 16px;"><strong>${qtdPlatinum}</strong></p></div>
        </div>
      </div>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important;"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.1772 20.6408C2.62661 20.6408 2.15543 20.4449 1.76368 20.0532C1.37126 19.6608 1.17505 19.1893 1.17505 18.6387V6.62631C1.17505 6.07574 1.37126 5.60459 1.76368 5.21285C2.15543 4.82045 2.62661 4.62425 3.1772 4.62425H5.17935C5.17935 3.52311 5.57143 2.58047 6.35561 1.79633C7.13978 1.01219 8.08246 0.620117 9.18364 0.620117C10.2848 0.620117 11.2275 1.01219 12.0117 1.79633C12.7959 2.58047 13.1879 3.52311 13.1879 4.62425H15.1901C15.7407 4.62425 16.2122 4.82045 16.6046 5.21285C16.9964 5.60459 17.1922 6.07574 17.1922 6.62631V18.6387C17.1922 19.1893 16.9964 19.6608 16.6046 20.0532C16.2122 20.4449 15.7407 20.6408 15.1901 20.6408H3.1772ZM3.1772 18.6387H15.1901V6.62631H13.1879V8.62838C13.1879 8.912 13.0922 9.14958 12.9006 9.34111C12.7084 9.53331 12.4705 9.62941 12.1869 9.62941C11.9032 9.62941 11.6656 9.53331 11.4741 9.34111C11.2819 9.14958 11.1858 8.912 11.1858 8.62838V6.62631H7.18149V8.62838C7.18149 8.912 7.08573 9.14958 6.89419 9.34111C6.70198 9.53331 6.46406 9.62941 6.18042 9.62941C5.89678 9.62941 5.65919 9.53331 5.46766 9.34111C5.27545 9.14958 5.17935 8.912 5.17935 8.62838V6.62631H3.1772V18.6387ZM7.18149 4.62425H11.1858C11.1858 4.07368 10.9899 3.60253 10.5982 3.21079C10.2057 2.81838 9.73423 2.62218 9.18364 2.62218C8.63305 2.62218 8.16188 2.81838 7.77013 3.21079C7.37771 3.60253 7.18149 4.07368 7.18149 4.62425ZM3.1772 18.6387V6.62631V18.6387Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Vendas</p>
      <div class="linha">
        <div class="cardInfos cardApendice" style="width: 100%; padding-right: 8px; padding-left: 8px; margin-top: 2px;">
          <div style="display: flex; align-items: center; justify-content: center;">
            <div style="margin-right: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="6" height="10" viewBox="0 0 9 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.78274 1.43042L4.78274 11.6152M4.78274 11.6152L7.87524 8.643M4.78274 11.6152L1.4193 8.643" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Menor qtd.</p><p><strong>${menorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
            <div class="divMenorVendas" style="position: relative;"><p class="tituloCard"><svg style="margin-right: 4px;" width="7" height="10" viewBox="0 0 10 13" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4.74973 11.615V1.43018M4.74973 1.43018L1.65723 4.40241M4.74973 1.43018L8.11317 4.40241" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Maior qtd.</p><p><strong>${maiorVenda.toLocaleString('pt-BR', {})}</strong></p></div>
            <div style="margin-left: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="7" viewBox="0 0 13 7" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.86401 1.64771H11.1973M1.86401 5.39771H11.1973" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Total</p><p><strong>+ de ${totalVendas.toLocaleString('pt-BR', {})}</strong></p></div>
          </div>
          <span><svg width="21" height="21" viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.23726 8.23726C8.83737 7.63714 9.65131 7.3 10.5 7.3C11.3487 7.3 12.1626 7.63714 12.7627 8.23726C13.3629 8.83737 13.7 9.65131 13.7 10.5C13.7 11.3487 13.3629 12.1626 12.7627 12.7627C12.1626 13.3629 11.3487 13.7 10.5 13.7C9.65131 13.7 8.83737 13.3629 8.23726 12.7627C7.63714 12.1626 7.3 11.3487 7.3 10.5C7.3 9.65131 7.63714 8.83737 8.23726 8.23726ZM10.5 2C5.80548 2 2 5.80548 2 10.5C2 15.1945 5.80548 19 10.5 19C15.1945 19 19 15.1945 19 10.5C19 5.80548 15.1945 2 10.5 2Z" fill="#3166FE" stroke="white" stroke-width="4"/><path d="M10.4999 9.19998C10.6723 9.19998 10.8376 9.26846 10.9595 9.39036C11.0814 9.51226 11.1499 9.67759 11.1499 9.84998V13.75C11.1499 13.9224 11.0814 14.0877 10.9595 14.2096C10.8376 14.3315 10.6723 14.4 10.4999 14.4C10.3275 14.4 10.1622 14.3315 10.0403 14.2096C9.91838 14.0877 9.8499 13.9224 9.8499 13.75V9.84998C9.8499 9.67759 9.91838 9.51226 10.0403 9.39036C10.1622 9.26846 10.3275 9.19998 10.4999 9.19998ZM11.4749 7.57498C11.4749 7.83356 11.3722 8.08156 11.1893 8.2644C11.0065 8.44725 10.7585 8.54998 10.4999 8.54998C10.2413 8.54998 9.99332 8.44725 9.81047 8.2644C9.62763 8.08156 9.5249 7.83356 9.5249 7.57498C9.5249 7.31639 9.62763 7.06839 9.81047 6.88555C9.99332 6.7027 10.2413 6.59998 10.4999 6.59998C10.7585 6.59998 11.0065 6.7027 11.1893 6.88555C11.3722 7.06839 11.4749 7.31639 11.4749 7.57498Z" fill="#3166FE"/></svg></span>
          <div class="tooltiptext" style="color: white;">
            <p>Quantidade de vendas aproximada conforme tabela de range ML.</p>
            <p style="text-decoration: underline; margin-top: 8px; cursor: pointer; width: fit-content; margin-left: auto; margin-right: 8px" id="btnModalRange">Saiba mais.</p>
          </div>
        </div>
      </div>

      <p class="tituloCard" style="font-size: 15px !important; margin-left: 10px; margin-bottom: 0px !important; margin-top: 2px;"><svg style="margin-right: 4px" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 2C4 2.53043 3.78929 3.03914 3.41421 3.41421C3.03914 3.78929 2.53043 4 2 4C1.46957 4 0.960859 3.78929 0.585786 3.41421C0.210714 3.03914 0 2.53043 0 2C0 1.46957 0.210714 0.960859 0.585786 0.585786C0.960859 0.210714 1.46957 0 2 0C2.53043 0 3.03914 0.210714 3.41421 0.585786C3.78929 0.960859 4 1.46957 4 2ZM4 8C4 8.53043 3.78929 9.03914 3.41421 9.41421C3.03914 9.78929 2.53043 10 2 10C1.46957 10 0.960859 9.78929 0.585786 9.41421C0.210714 9.03914 0 8.53043 0 8C0 7.46957 0.210714 6.96086 0.585786 6.58579C0.960859 6.21071 1.46957 6 2 6C2.53043 6 3.03914 6.21071 3.41421 6.58579C3.78929 6.96086 4 7.46957 4 8ZM2 16C2.53043 16 3.03914 15.7893 3.41421 15.4142C3.78929 15.0391 4 14.5304 4 14C4 13.4696 3.78929 12.9609 3.41421 12.5858C3.03914 12.2107 2.53043 12 2 12C1.46957 12 0.960859 12.2107 0.585786 12.5858C0.210714 12.9609 0 13.4696 0 14C0 14.5304 0.210714 15.0391 0.585786 15.4142C0.960859 15.7893 1.46957 16 2 16ZM10 2C10 2.53043 9.78929 3.03914 9.41421 3.41421C9.03914 3.78929 8.53043 4 8 4C7.46957 4 6.96086 3.78929 6.58579 3.41421C6.21071 3.03914 6 2.53043 6 2C6 1.46957 6.21071 0.960859 6.58579 0.585786C6.96086 0.210714 7.46957 0 8 0C8.53043 0 9.03914 0.210714 9.41421 0.585786C9.78929 0.960859 10 1.46957 10 2ZM8 10C8.53043 10 9.03914 9.78929 9.41421 9.41421C9.78929 9.03914 10 8.53043 10 8C10 7.46957 9.78929 6.96086 9.41421 6.58579C9.03914 6.21071 8.53043 6 8 6C7.46957 6 6.96086 6.21071 6.58579 6.58579C6.21071 6.96086 6 7.46957 6 8C6 8.53043 6.21071 9.03914 6.58579 9.41421C6.96086 9.78929 7.46957 10 8 10ZM10 14C10 14.5304 9.78929 15.0391 9.41421 15.4142C9.03914 15.7893 8.53043 16 8 16C7.46957 16 6.96086 15.7893 6.58579 15.4142C6.21071 15.0391 6 14.5304 6 14C6 13.4696 6.21071 12.9609 6.58579 12.5858C6.96086 12.2107 7.46957 12 8 12C8.53043 12 9.03914 12.2107 9.41421 12.5858C9.78929 12.9609 10 13.4696 10 14ZM14 4C14.5304 4 15.0391 3.78929 15.4142 3.41421C15.7893 3.03914 16 2.53043 16 2C16 1.46957 15.7893 0.960859 15.4142 0.585786C15.0391 0.210714 14.5304 0 14 0C13.4696 0 12.9609 0.210714 12.5858 0.585786C12.2107 0.960859 12 1.46957 12 2C12 2.53043 12.2107 3.03914 12.5858 3.41421C12.9609 3.78929 13.4696 4 14 4ZM16 8C16 8.53043 15.7893 9.03914 15.4142 9.41421C15.0391 9.78929 14.5304 10 14 10C13.4696 10 12.9609 9.78929 12.5858 9.41421C12.2107 9.03914 12 8.53043 12 8C12 7.46957 12.2107 6.96086 12.5858 6.58579C12.9609 6.21071 13.4696 6 14 6C14.5304 6 15.0391 6.21071 15.4142 6.58579C15.7893 6.96086 16 7.46957 16 8ZM14 16C14.5304 16 15.0391 15.7893 15.4142 15.4142C15.7893 15.0391 16 14.5304 16 14C16 13.4696 15.7893 12.9609 15.4142 12.5858C15.0391 12.2107 14.5304 12 14 12C13.4696 12 12.9609 12.2107 12.5858 12.5858C12.2107 12.9609 12 13.4696 12 14C12 14.5304 12.2107 15.0391 12.5858 15.4142C12.9609 15.7893 13.4696 16 14 16Z" fill="#3D3D3D"/></svg>Outras informações</p>
      <div class="linha-3">
        <div class="cardInfos" style="width: 80px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="13" height="13" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.49334 15.4688L5.19789 13.183L2.74334 12.6116L2.98198 9.96875L1.31152 7.96875L2.98198 5.96875L2.74334 3.32589L5.19789 2.75446L6.49334 0.46875L8.81152 1.50446L11.1297 0.46875L12.4252 2.75446L14.8797 3.32589L14.6411 5.96875L16.3115 7.96875L14.6411 9.96875L14.8797 12.6116L12.4252 13.183L11.1297 15.4688L8.81152 14.433L6.49334 15.4688ZM7.07289 13.6473L8.81152 12.8616L10.5843 13.6473L11.5388 11.933L13.4138 11.4688L13.2433 9.46875L14.5047 7.96875L13.2433 6.43304L13.4138 4.43304L11.5388 4.00446L10.5502 2.29018L8.81152 3.07589L7.0388 2.29018L6.08425 4.00446L4.20925 4.43304L4.37971 6.43304L3.11834 7.96875L4.37971 9.46875L4.20925 11.5045L6.08425 11.933L7.07289 13.6473ZM8.09561 10.5045L11.9479 6.46875L10.9933 5.43304L8.09561 8.46875L6.62971 6.96875L5.67516 7.96875L8.09561 10.5045Z" fill="#42D235" stroke="#42D235" stroke-width="0.5"/></svg>Oficiais</p><p><strong>${qtdLojasOficiais}</strong></p></div>
        <div class="cardInfos" style="width: 85px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="12" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.79724 12.024L13.4372 6.38399L12.3172 5.26399L7.79724 9.78399L5.51724 7.50399L4.39724 8.62399L7.79724 12.024ZM8.91724 16.344C7.81057 16.344 6.77057 16.1339 5.79724 15.7136C4.8239 15.2939 3.97724 14.724 3.25724 14.004C2.53724 13.284 1.96737 12.4373 1.54764 11.464C1.12737 10.4907 0.917236 9.45066 0.917236 8.34399C0.917236 7.23733 1.12737 6.19733 1.54764 5.22399C1.96737 4.25066 2.53724 3.40399 3.25724 2.68399C3.97724 1.96399 4.8239 1.39386 5.79724 0.973594C6.77057 0.553861 7.81057 0.343994 8.91724 0.343994C10.0239 0.343994 11.0639 0.553861 12.0372 0.973594C13.0106 1.39386 13.8572 1.96399 14.5772 2.68399C15.2972 3.40399 15.8671 4.25066 16.2868 5.22399C16.7071 6.19733 16.9172 7.23733 16.9172 8.34399C16.9172 9.45066 16.7071 10.4907 16.2868 11.464C15.8671 12.4373 15.2972 13.284 14.5772 14.004C13.8572 14.724 13.0106 15.2939 12.0372 15.7136C11.0639 16.1339 10.0239 16.344 8.91724 16.344ZM8.91724 14.744C10.7039 14.744 12.2172 14.124 13.4572 12.884C14.6972 11.644 15.3172 10.1307 15.3172 8.34399C15.3172 6.55733 14.6972 5.04399 13.4572 3.80399C12.2172 2.56399 10.7039 1.94399 8.91724 1.94399C7.13057 1.94399 5.61724 2.56399 4.37724 3.80399C3.13724 5.04399 2.51724 6.55733 2.51724 8.34399C2.51724 10.1307 3.13724 11.644 4.37724 12.884C5.61724 14.124 7.13057 14.744 8.91724 14.744Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Clássicos</p><p><strong>${qtdClassico}</strong></p></div>
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="13.2" height="8.2" viewBox="0 0 20 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.86688 1.64453L13.6664 7.34387L18.4159 3.54431L16.5161 13.0432H3.21765L1.31787 3.54431L6.06732 7.34387L9.86688 1.64453Z" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>Premium</p><p><strong>${qtdPremium}</strong></p></div>  
      </div>

      <div class="linha-3">
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="9" height="12" viewBox="0 0 11 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M7.02363 0.674853L0.233168 6.75717C-0.18632 7.13732 0.0496419 7.83862 0.613329 7.89105L5.91592 8.40228L2.73699 12.8329C2.59279 13.0361 2.61245 13.318 2.78942 13.4949C2.98606 13.6915 3.29412 13.6981 3.49731 13.508L10.2878 7.4257C10.7073 7.04556 10.4713 6.34426 9.90761 6.29182L4.60502 5.78059L7.78395 1.34994C7.92815 1.14676 7.90849 0.864925 7.73152 0.687961C7.63885 0.593328 7.51269 0.538916 7.38026 0.536464C7.24783 0.534011 7.11974 0.583715 7.02363 0.674853Z" fill="#3D3D3D"/></svg>FULL</p><p><strong>${qtdFull}</strong></p></div>
        <div class="cardInfos" style="width: 100px;"><p class="tituloCard" style="display: flex; align-items: center;"><svg style="margin-right: 4px;" width="12" height="11" viewBox="0 0 19 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2.60074 1.19312C2.08399 1.19312 1.58841 1.39563 1.22302 1.75611C0.857621 2.11659 0.652344 2.6055 0.652344 3.1153V13.3669C0.652382 13.8457 0.833483 14.3071 1.16021 14.661C1.48693 15.015 1.93577 15.2359 2.41889 15.2806C2.51861 15.8795 2.83057 16.4241 3.29921 16.8174C3.76786 17.2106 4.36277 17.4271 4.97801 17.4281C5.59326 17.4291 6.18891 17.2147 6.6589 16.823C7.12888 16.4313 7.4427 15.8877 7.54448 15.2891H9.34739C9.44869 15.8874 9.76175 16.4308 10.2309 16.8227C10.7001 17.2147 11.295 17.4298 11.9098 17.4298C12.5245 17.4298 13.1194 17.2147 13.5886 16.8227C14.0578 16.4308 14.3708 15.8874 14.4721 15.2891H16.023C16.2789 15.2891 16.5323 15.2394 16.7687 15.1428C17.005 15.0462 17.2198 14.9046 17.4008 14.7261C17.5817 14.5476 17.7252 14.3357 17.8231 14.1025C17.921 13.8693 17.9714 13.6194 17.9714 13.3669V8.7426C17.9713 8.45802 17.9071 8.17703 17.7835 7.9199L16.3123 4.85551C16.1544 4.52665 15.9052 4.24874 15.5935 4.05411C15.2819 3.85947 14.9206 3.75611 14.5518 3.75603H13.2087V3.1153C13.2087 2.6055 13.0034 2.11659 12.638 1.75611C12.2726 1.39563 11.777 1.19312 11.2603 1.19312H2.60074ZM14.3604 14.0077C14.1532 13.4318 13.7449 12.9475 13.2087 12.6416V9.309H16.6725V11.8719H15.5901C15.4178 11.8719 15.2526 11.9394 15.1308 12.0596C15.009 12.1797 14.9406 12.3427 14.9406 12.5126C14.9406 12.6826 15.009 12.8455 15.1308 12.9657C15.2526 13.0859 15.4178 13.1534 15.5901 13.1534H16.6725V13.3669C16.6725 13.5369 16.6041 13.6998 16.4823 13.82C16.3605 13.9402 16.1953 14.0077 16.023 14.0077H14.3604ZM11.9098 12.2991C11.3723 12.2989 10.8481 12.4631 10.4092 12.7691C9.97029 13.0751 9.63836 13.5078 9.4591 14.0077H7.43277C7.25386 13.5079 6.92235 13.0751 6.48386 12.7689C6.04536 12.4627 5.52145 12.298 4.98421 12.2977C4.44697 12.2973 3.92281 12.4612 3.48388 12.7668C3.04495 13.0724 2.71282 13.5047 2.5332 14.0043C2.3735 13.9878 2.22566 13.9135 2.11819 13.7958C2.01073 13.6781 1.95126 13.5253 1.95128 13.3669V3.1153C1.95128 2.94537 2.0197 2.7824 2.1415 2.66224C2.2633 2.54208 2.42849 2.47457 2.60074 2.47457H11.2603C11.4325 2.47457 11.5977 2.54208 11.7195 2.66224C11.8413 2.7824 11.9098 2.94537 11.9098 3.1153V12.2991ZM13.2087 5.03748H14.5509C14.6741 5.03729 14.7947 5.07165 14.8988 5.13654C15.0029 5.20143 15.0862 5.29418 15.1389 5.40398L16.398 8.02754H13.2087V5.03748ZM4.98212 16.1434C4.63762 16.1434 4.30723 16.0084 4.06363 15.7681C3.82004 15.5278 3.68318 15.2018 3.68318 14.862C3.68318 14.5221 3.82004 14.1962 4.06363 13.9558C4.30723 13.7155 4.63762 13.5805 4.98212 13.5805C5.32661 13.5805 5.657 13.7155 5.9006 13.9558C6.1442 14.1962 6.28105 14.5221 6.28105 14.862C6.28105 15.2018 6.1442 15.5278 5.9006 15.7681C5.657 16.0084 5.32661 16.1434 4.98212 16.1434ZM13.2087 14.862C13.2087 15.2018 13.0718 15.5278 12.8282 15.7681C12.5846 16.0084 12.2543 16.1434 11.9098 16.1434C11.5653 16.1434 11.2349 16.0084 10.9913 15.7681C10.7477 15.5278 10.6108 15.2018 10.6108 14.862C10.6108 14.5221 10.7477 14.1962 10.9913 13.9558C11.2349 13.7155 11.5653 13.5805 11.9098 13.5805C12.2543 13.5805 12.5846 13.7155 12.8282 13.9558C13.0718 14.1962 13.2087 14.5221 13.2087 14.862Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Frete grátis</p><p><strong>${qtdFreteGratis}</strong></p></div>
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="14" viewBox="0 0 13 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.1447 1.2159C11.005 0.803834 10.6139 0.510498 10.1529 0.510498H2.47034C2.00939 0.510498 1.62526 0.803834 1.47859 1.2159L0.0258789 5.39943V10.9868C0.0258789 11.3709 0.340167 11.6852 0.724297 11.6852H1.42272C1.80685 11.6852 2.12113 11.3709 2.12113 10.9868V10.2884H10.5022V10.9868C10.5022 11.3709 10.8164 11.6852 11.2006 11.6852H11.899C12.2831 11.6852 12.5974 11.3709 12.5974 10.9868V5.39943L11.1447 1.2159ZM2.71479 1.90734H9.90152L10.6558 4.07942H1.9605L2.71479 1.90734ZM11.2006 8.89152H1.42272V5.39943H11.2006V8.89152Z" fill="#3D3D3D"/><path d="M3.16872 8.19316C3.74731 8.19316 4.21635 7.72412 4.21635 7.14553C4.21635 6.56694 3.74731 6.0979 3.16872 6.0979C2.59013 6.0979 2.12109 6.56694 2.12109 7.14553C2.12109 7.72412 2.59013 8.19316 3.16872 8.19316Z" fill="#3D3D3D"/><path d="M9.45461 8.19316C10.0332 8.19316 10.5022 7.72412 10.5022 7.14553C10.5022 6.56694 10.0332 6.0979 9.45461 6.0979C8.87602 6.0979 8.40698 6.56694 8.40698 7.14553C8.40698 7.72412 8.87602 8.19316 9.45461 8.19316Z" fill="#3D3D3D"/><path d="M2.81958 13.7804H5.61325V12.3835L9.80377 14.4788H7.01009V15.8756L2.81958 13.7804Z" fill="#3D3D3D"/></svg>
        Flex</p><p><strong>${qtdFlex}</strong></p></div>  
      </div>

      <div class="linha-3">
        <div class="cardInfos" style="width: 100px; padding-left: 2px; padding-right: 2px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="14" viewBox="0 0 12 22" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M5.76363 20.8397C5.44101 20.8397 5.17039 20.7304 4.95177 20.5118C4.73391 20.2939 4.62498 20.0237 4.62498 19.701V18.3916C3.77099 18.2018 3.02138 17.8697 2.37615 17.3953C1.73091 16.9208 1.20903 16.2566 0.810506 15.4026C0.677664 15.1369 0.67273 14.8572 0.795704 14.5634C0.919437 14.2689 1.14261 14.0552 1.46523 13.9224C1.73091 13.8085 2.00609 13.8135 2.29075 13.9372C2.57541 14.0602 2.79365 14.264 2.94547 14.5486C3.26809 15.118 3.67611 15.5499 4.16952 15.8444C4.66294 16.1382 5.27022 16.2851 5.99136 16.2851C6.76944 16.2851 7.4291 16.1097 7.97033 15.759C8.51081 15.4076 8.78105 14.8618 8.78105 14.1217C8.78105 13.4574 8.5723 12.9306 8.15479 12.5412C7.73729 12.1525 6.76944 11.7115 5.25124 11.2181C3.61917 10.7057 2.4995 10.0939 1.89222 9.38259C1.28494 8.67056 0.981303 7.80215 0.981303 6.77736C0.981303 5.54383 1.37983 4.58546 2.17689 3.90227C2.97394 3.21908 3.78997 2.83004 4.62498 2.73516V1.48264C4.62498 1.16003 4.73391 0.889407 4.95177 0.670786C5.17039 0.452925 5.44101 0.343994 5.76363 0.343994C6.08625 0.343994 6.35687 0.452925 6.57549 0.670786C6.79335 0.889407 6.90228 1.16003 6.90228 1.48264V2.73516C7.62342 2.84902 8.24968 3.08169 8.78105 3.43315C9.31242 3.78385 9.7489 4.2154 10.0905 4.72779C10.2613 4.9745 10.2947 5.24967 10.1907 5.55331C10.0859 5.85695 9.87226 6.0752 9.54964 6.20804C9.28396 6.3219 9.00878 6.32646 8.72412 6.2217C8.43946 6.1177 8.17377 5.93286 7.92706 5.66718C7.68036 5.40149 7.39114 5.1973 7.05941 5.05459C6.72693 4.91263 6.31398 4.84166 5.82056 4.84166C4.98555 4.84166 4.34981 5.02688 3.91333 5.39732C3.47684 5.767 3.2586 6.22702 3.2586 6.77736C3.2586 7.40362 3.54326 7.89703 4.11259 8.25761C4.68191 8.61818 5.66874 8.99773 7.07308 9.39626C8.38252 9.77581 9.37429 10.3782 10.0484 11.2033C10.7217 12.0292 11.0583 12.983 11.0583 14.0647C11.0583 15.4121 10.6598 16.4369 9.86277 17.1391C9.06571 17.8412 8.07888 18.2777 6.90228 18.4485V19.701C6.90228 20.0237 6.79335 20.2939 6.57549 20.5118C6.35687 20.7304 6.08625 20.8397 5.76363 20.8397Z" fill="#303030" stroke="#303030" stroke-width="0.5"/></svg>Patrocinados</p><p><strong><button style="width: 50px; background: var(--grey-thin); height: 18px; border-radius: 4px; border: none;"></button></strong></p></div>

        <div class="cardInfos" style="width: 85px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="10" viewBox="0 0 17 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.78094 6.19487C1.0631 6.19487 0.483643 6.77554 0.483643 7.49487C0.483643 8.21421 1.0631 8.79487 1.78094 8.79487C2.49878 8.79487 3.07824 8.21421 3.07824 7.49487C3.07824 6.77554 2.49878 6.19487 1.78094 6.19487ZM1.78094 0.994873C1.0631 0.994873 0.483643 1.57554 0.483643 2.29487C0.483643 3.01421 1.0631 3.59487 1.78094 3.59487C2.49878 3.59487 3.07824 3.01421 3.07824 2.29487C3.07824 1.57554 2.49878 0.994873 1.78094 0.994873ZM1.78094 11.3949C1.0631 11.3949 0.483643 11.9842 0.483643 12.6949C0.483643 13.4055 1.07175 13.9949 1.78094 13.9949C2.49013 13.9949 3.07824 13.4055 3.07824 12.6949C3.07824 11.9842 2.49878 11.3949 1.78094 11.3949ZM5.2404 13.5615H15.6188C16.0945 13.5615 16.4836 13.1715 16.4836 12.6949C16.4836 12.2182 16.0945 11.8282 15.6188 11.8282H5.2404C4.76472 11.8282 4.37553 12.2182 4.37553 12.6949C4.37553 13.1715 4.76472 13.5615 5.2404 13.5615ZM5.2404 8.36154H15.6188C16.0945 8.36154 16.4836 7.97154 16.4836 7.49487C16.4836 7.01821 16.0945 6.62821 15.6188 6.62821H5.2404C4.76472 6.62821 4.37553 7.01821 4.37553 7.49487C4.37553 7.97154 4.76472 8.36154 5.2404 8.36154ZM4.37553 2.29487C4.37553 2.77154 4.76472 3.16154 5.2404 3.16154H15.6188C16.0945 3.16154 16.4836 2.77154 16.4836 2.29487C16.4836 1.81821 16.0945 1.42821 15.6188 1.42821H5.2404C4.76472 1.42821 4.37553 1.81821 4.37553 2.29487Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Catálogo</p><p><strong>${qtdCatalogo}</strong></p></div>
        <div class="cardInfos" style="width: 70px;"><p class="tituloCard"><svg style="margin-right: 4px;" width="11" height="11" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.7439 8.16L8.56811 0.984171C8.28108 0.697138 7.88242 0.521729 7.4439 0.521729H1.8627C0.985649 0.521729 0.268066 1.23931 0.268066 2.11636V7.69756C0.268066 8.13608 0.443476 8.53474 0.738482 8.82975L7.91431 16.0056C8.20135 16.2926 8.6 16.468 9.03853 16.468C9.47705 16.468 9.87571 16.2926 10.1627 15.9976L15.7439 10.4164C16.0389 10.1294 16.2144 9.73071 16.2144 9.29219C16.2144 8.85366 16.031 8.44703 15.7439 8.16ZM9.03853 14.8814L1.8627 7.69756V2.11636H7.4439V2.10838L14.6197 9.28421L9.03853 14.8814Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.56633 6.01597C5.22685 6.01597 5.7623 5.48051 5.7623 4.82C5.7623 4.15948 5.22685 3.62402 4.56633 3.62402C3.90582 3.62402 3.37036 4.15948 3.37036 4.82C3.37036 5.48051 3.90582 6.01597 4.56633 6.01597Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Oferta</p><p><strong>${qtdOferta}</strong></p></div>
      </div>

      <div class="linha-2">
        <div class="cardInfos"><p class="tituloCard"><svg style="margin-right: 4px;" width="10" height="10" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12.2226 12.6463L10.3883 5.55484L13.4642 2.4789C13.9284 2.01471 13.9284 1.2653 13.4642 0.801112C13 0.336925 12.2506 0.336925 11.7864 0.801112L8.71047 3.87705L1.61904 2.04267C1.33941 1.96438 1.03181 2.04827 0.824886 2.25519C0.433403 2.64668 0.528478 3.30101 1.00944 3.56946L6.1882 6.39932L3.11786 9.46967L1.09892 8.96074C0.964701 8.92718 0.819293 8.97192 0.724219 9.067L0.399847 9.39137C0.215291 9.57593 0.254439 9.88352 0.472551 10.0121L2.51386 11.2369L2.83823 11.4271L3.00041 11.6899L3.17378 11.9863L3.96794 13.3174L4.24757 13.7872C4.38179 14.0109 4.68379 14.0444 4.86835 13.8599L5.19272 13.5355C5.29339 13.4348 5.33253 13.295 5.29898 13.1608L4.79564 11.1475L7.87158 8.07151L10.7014 13.2503C10.9643 13.7368 11.6186 13.8319 12.0101 13.4404C12.217 13.2335 12.3009 12.9259 12.2226 12.6463Z" fill="var(--grey)"/></svg>Internacional</p><p><strong>${qtdInternacional}</strong></p></div>

        <div class="cardInfos" style="width: auto;"><p class="tituloCard"><svg style="margin-right: 4px;" width="12" height="12" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.8427 10.1738C14.5025 10.1738 15.0831 9.81303 15.3821 9.26749L18.5313 3.55693C18.6055 3.42356 18.6435 3.27314 18.6417 3.12055C18.6398 2.96796 18.5982 2.81849 18.5209 2.68694C18.4436 2.55538 18.3333 2.4463 18.2009 2.37049C18.0685 2.29467 17.9186 2.25475 17.766 2.25468H4.74707L3.92019 0.494873H1.0437V2.25468H2.80302L5.96979 8.93312L4.78225 11.0801C4.1401 12.2592 4.98457 13.6934 6.32165 13.6934H16.8776V11.9336H6.32165L7.28928 10.1738H13.8427ZM5.58274 4.01448H16.2706L13.8427 8.41398H7.66753L5.58274 4.01448ZM6.32165 14.5733C5.35403 14.5733 4.57113 15.3652 4.57113 16.3331C4.57113 17.301 5.35403 18.0929 6.32165 18.0929C7.28928 18.0929 8.08097 17.301 8.08097 16.3331C8.08097 15.3652 7.28928 14.5733 6.32165 14.5733ZM15.1182 14.5733C14.1506 14.5733 13.3677 15.3652 13.3677 16.3331C13.3677 17.301 14.1506 18.0929 15.1182 18.0929C16.0859 18.0929 16.8776 17.301 16.8776 16.3331C16.8776 15.3652 16.0859 14.5733 15.1182 14.5733Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/></svg>Supermercado</p><p><strong>${qtdSupermercado}</strong></p></div>  
      </div>

      <div class="linha-2">
        <div class="cardInfos">
          <p class="tituloCard">
            <svg style="margin-right: 4px;" width="19" height="11" viewBox="0 0 29 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M21.0166 11.8958C21.2041 11.8961 21.3848 11.8263 21.5233 11.7C21.6618 11.5737 21.748 11.4002 21.765 11.2135C21.7819 11.0269 21.7283 10.8406 21.6148 10.6915C21.5013 10.5424 21.3361 10.4411 21.1516 10.4078L21.1405 10.4057L21.1292 10.4047L21.0392 10.3967L21.0282 10.3958H21.0171H20.0171H19.7671V10.6458V11.6458V11.8958H20.0171H21.0166ZM21.0166 11.8958L21.0171 11.6458M21.0166 11.8958H21.0171V11.6458M21.0171 11.6458H20.2671H20.0171V11.3958V10.8958V10.6458H20.2671H21.0171L21.1071 10.6538C21.2301 10.676 21.3402 10.7435 21.4159 10.8429C21.4916 10.9423 21.5273 11.0665 21.516 11.1909C21.5047 11.3154 21.4472 11.4311 21.3549 11.5152C21.2626 11.5994 21.142 11.646 21.0171 11.6458ZM18.2671 7.39575V7.64575V8.64575V8.89575H18.0171H17.0171H17.006L16.995 8.89477L16.905 8.88677L16.8937 8.88577L16.8826 8.88375C16.6981 8.85036 16.5329 8.74913 16.4194 8.6C16.3059 8.45087 16.2523 8.26464 16.2693 8.07798C16.2862 7.89133 16.3724 7.71778 16.5109 7.59152C16.6493 7.46531 16.83 7.39548 17.0173 7.39575H17.0171H18.2671ZM18.2671 7.39575H18.0171M18.2671 7.39575H18.0171M18.0171 7.39575L17.0176 7.39575L18.0171 7.39575ZM27.7009 16.9583C27.6318 17.109 27.5147 17.2326 27.368 17.3097L27.2748 17.3497L19.2803 20.3477L19.2802 20.3477C19.1476 20.3975 19.0036 20.4087 18.8649 20.3801L18.7449 20.3453L10.7539 17.3487L10.7534 17.3485C10.5958 17.2898 10.4625 17.1798 10.3749 17.0363C10.2873 16.8927 10.2505 16.7239 10.2704 16.5569C10.2903 16.3899 10.3658 16.2345 10.4846 16.1155C10.6018 15.9982 10.7545 15.9231 10.9188 15.9019L11.0315 15.8953L11.2671 15.8817V15.6458V3.64575V3.64574C11.2671 2.94429 11.5351 2.26935 12.0163 1.759C12.4966 1.24955 13.1532 0.942555 13.8521 0.900541L14.0207 0.895752H24.0171C24.7186 0.895713 25.3935 1.16372 25.9039 1.64493C26.4133 2.12529 26.7203 2.78186 26.7623 3.48071L26.7671 3.64929V15.6458V15.8963L27.0176 15.8958C27.1861 15.8954 27.3497 15.9518 27.4822 16.0558C27.6147 16.1598 27.7084 16.3054 27.7481 16.4691C27.7877 16.6328 27.7711 16.8051 27.7009 16.9583ZM12.7671 16.3278V16.501L12.9293 16.5618L18.9293 18.8118L19.0171 18.8448L19.1049 18.8118L25.1049 16.5618L25.2671 16.501V16.3278V3.64575C25.2671 3.31423 25.1354 2.99629 24.901 2.76187C24.6666 2.52745 24.3486 2.39575 24.0171 2.39575H14.0171C13.6856 2.39575 13.3676 2.52745 13.1332 2.76187C12.8988 2.99629 12.7671 3.31423 12.7671 3.64575V16.3278ZM19.7671 5.64575V5.89575H20.0171H22.0171C22.216 5.89575 22.4068 5.97477 22.5474 6.11542C22.6881 6.25607 22.7671 6.44684 22.7671 6.64575C22.7671 6.84466 22.6881 7.03543 22.5474 7.17608C22.4068 7.31673 22.216 7.39575 22.0171 7.39575H20.0171H19.7671V7.64575V8.64575V8.89575H20.0171H21.0171C21.6138 8.89575 22.1861 9.1328 22.6081 9.55476C23.0301 9.97672 23.2671 10.549 23.2671 11.1458C23.2671 11.7425 23.0301 12.3148 22.6081 12.7367C22.1861 13.1587 21.6138 13.3958 21.0171 13.3958H20.0171H19.7671V13.6458V14.6458C19.7671 14.8447 19.6881 15.0354 19.5474 15.1761C19.4068 15.3167 19.216 15.3958 19.0171 15.3958C18.8182 15.3958 18.6274 15.3167 18.4868 15.1761C18.3461 15.0354 18.2671 14.8447 18.2671 14.6458V13.6458V13.3958H18.0171H16.0171C15.8182 13.3958 15.6274 13.3167 15.4868 13.1761C15.3461 13.0354 15.2671 12.8447 15.2671 12.6458C15.2671 12.4468 15.3461 12.2561 15.4868 12.1154C15.6274 11.9748 15.8182 11.8958 16.0171 11.8958H18.0171H18.2671V11.6458V10.6458V10.3958H18.0171H17.0171C16.4204 10.3958 15.8481 10.1587 15.4261 9.73674C15.0042 9.31479 14.7671 8.74249 14.7671 8.14575C14.7671 7.54902 15.0042 6.97672 15.4261 6.55476C15.8481 6.1328 16.4204 5.89575 17.0171 5.89575H18.0171H18.2671V5.64575V4.64575C18.2671 4.44684 18.3461 4.25607 18.4868 4.11542C18.6274 3.97477 18.8182 3.89575 19.0171 3.89575C19.216 3.89575 19.4068 3.97477 19.5474 4.11542C19.6881 4.25607 19.7671 4.44684 19.7671 4.64575V5.64575Z" fill="#3D3D3D" stroke="#3D3D3D" stroke-width="0.5"/><path d="M4.82644 4.68677L4.82644 14.8716M4.82644 14.8716L7.91895 11.8993M4.82644 14.8716L1.463 11.8993" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Menor preço
          </p>
          <p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(menorPreco)}</strong></p>
        </div>
        <div class="cardInfos">
          <p class="tituloCard">
            <svg style="margin-right: 4px;" width="21" height="13" viewBox="0 0 28 21" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M23.6809 0.645752C24.4461 0.645709 25.1824 0.938077 25.7392 1.46304C26.2959 1.98799 26.631 2.70586 26.6759 3.46975L26.6809 3.64575V15.6458C26.9055 15.6453 27.1237 15.7205 27.3004 15.8591C27.4771 15.9978 27.6019 16.192 27.6548 16.4102C27.7077 16.6285 27.6856 16.8583 27.592 17.0624C27.4984 17.2666 27.3388 17.4333 27.1389 17.5358L27.0319 17.5818L19.0319 20.5818C18.8518 20.6494 18.656 20.6636 18.4679 20.6228L18.3299 20.5828L10.3299 17.5828C10.1198 17.5045 9.94208 17.3579 9.8253 17.1665C9.70851 16.9751 9.65945 16.75 9.68598 16.5273C9.71252 16.3047 9.81311 16.0974 9.9716 15.9388C10.1301 15.7802 10.3373 15.6794 10.5599 15.6528L10.6809 15.6458V3.64575C10.6809 2.88054 10.9732 2.14424 11.4982 1.58749C12.0232 1.03075 12.741 0.695644 13.5049 0.650752L13.6809 0.645752H23.6809ZM23.6809 2.64575H13.6809C13.4157 2.64575 13.1614 2.75111 12.9738 2.93865C12.7863 3.12618 12.6809 3.38054 12.6809 3.64575V16.3278L18.6809 18.5778L24.6809 16.3278V3.64575C24.6809 3.38054 24.5756 3.12618 24.388 2.93865C24.2005 2.75111 23.9461 2.64575 23.6809 2.64575ZM18.6809 3.64575C18.9461 3.64575 19.2005 3.75111 19.388 3.93865C19.5756 4.12618 19.6809 4.38054 19.6809 4.64575V5.64575H21.6809C21.9461 5.64575 22.2005 5.75111 22.388 5.93865C22.5756 6.12618 22.6809 6.38054 22.6809 6.64575C22.6809 6.91097 22.5756 7.16532 22.388 7.35286C22.2005 7.54039 21.9461 7.64575 21.6809 7.64575H19.6809V8.64575H20.6809C21.344 8.64575 21.9798 8.90914 22.4487 9.37799C22.9175 9.84683 23.1809 10.4827 23.1809 11.1458C23.1809 11.8088 22.9175 12.4447 22.4487 12.9135C21.9798 13.3824 21.344 13.6458 20.6809 13.6458H19.6809V14.6458C19.6809 14.911 19.5756 15.1653 19.388 15.3529C19.2005 15.5404 18.9461 15.6458 18.6809 15.6458C18.4157 15.6458 18.1614 15.5404 17.9738 15.3529C17.7863 15.1653 17.6809 14.911 17.6809 14.6458V13.6458H15.6809C15.4157 13.6458 15.1614 13.5404 14.9738 13.3529C14.7863 13.1653 14.6809 12.911 14.6809 12.6458C14.6809 12.3805 14.7863 12.1262 14.9738 11.9386C15.1614 11.7511 15.4157 11.6458 15.6809 11.6458H17.6809V10.6458H16.6809C16.0179 10.6458 15.382 10.3824 14.9132 9.91352C14.4443 9.44468 14.1809 8.80879 14.1809 8.14575C14.1809 7.48271 14.4443 6.84683 14.9132 6.37799C15.382 5.90914 16.0179 5.64575 16.6809 5.64575H17.6809V4.64575C17.6809 4.38054 17.7863 4.12618 17.9738 3.93865C18.1614 3.75111 18.4157 3.64575 18.6809 3.64575ZM20.6809 10.6458H19.6809V11.6458H20.6809C20.8059 11.646 20.9264 11.5994 21.0187 11.5152C21.111 11.4311 21.1685 11.3154 21.1798 11.1909C21.1911 11.0665 21.1554 10.9423 21.0797 10.8429C21.004 10.7435 20.8939 10.676 20.7709 10.6538L20.6809 10.6458ZM17.6809 7.64575H16.6809C16.556 7.64552 16.4355 7.69208 16.3431 7.77626C16.2508 7.86044 16.1933 7.97614 16.182 8.10057C16.1708 8.22501 16.2065 8.34916 16.2821 8.44858C16.3578 8.54801 16.468 8.61549 16.5909 8.63775L16.6809 8.64575H17.6809V7.64575Z" fill="#3D3D3D"/><path d="M4.89207 14.8713V4.68652M4.89207 4.68652L1.79956 7.65876M4.89207 4.68652L7.83802 7.65876" stroke="#3D3D3D" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
            Maior preço
          </p>
          <p><strong>${Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(maiorPreco)}</strong></p>
        </div>
      </div>

      <center><p style="margin-top: 10px; font-size: 12px">Informações: <strong>Avantpro</strong></p></center>
      <button style="margin-left: auto; margin-right: auto;" class="btn btn-info" onClick="javascript:window.open('https://avantpro.com.br/', '_blank');">Conheça outras ferramentas</button>
      ${rawVendedoresCompleto == undefined ? '' : `<div style="display: flex; align-items: center; margin: 25px 5px 10px 5px;"><p style="font-size: 15px; font-weight: 700; color: var(--grey); margin-right: auto;"><svg width="13" height="13" viewBox="0 0 17 17" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.41895 0.593018C9.47981 0.593018 10.4972 1.01444 11.2474 1.76459C11.9975 2.51474 12.4189 3.53215 12.4189 4.59302C12.4189 5.65388 11.9975 6.6713 11.2474 7.42144C10.4972 8.17159 9.47981 8.59302 8.41895 8.59302C7.35808 8.59302 6.34066 8.17159 5.59052 7.42144C4.84037 6.6713 4.41895 5.65388 4.41895 4.59302C4.41895 3.53215 4.84037 2.51474 5.59052 1.76459C6.34066 1.01444 7.35808 0.593018 8.41895 0.593018ZM8.41895 10.593C12.8389 10.593 16.4189 12.383 16.4189 14.593V16.593H0.418945V14.593C0.418945 12.383 3.99895 10.593 8.41895 10.593Z" fill="#3D3D3D"/></svg> Vendedores nessa página (${rawVendedoresCompleto.length})</p>

      <button class="btnMostraVendedor" id="btnMostrarVendedor"><svg style="transform: rotate(180deg);" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
      </div>

      <div class="infoEscondida escondeInfo">
        <div class="linha" style="margin-bottom: 15px;">
          <div class="searchBar">
            <input style="height: 35px;" placeholder="Procure por uma loja" type="text" disabled></input>
            <button style="height: 35px;" class="btn-searchbar" disabled>
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15.9 17.3L10.3 11.7C9.8 12.1 9.225 12.4167 8.575 12.65C7.925 12.8833 7.23333 13 6.5 13C4.68333 13 3.146 12.371 1.888 11.113C0.629333 9.85433 0 8.31667 0 6.5C0 4.68333 0.629333 3.14567 1.888 1.887C3.146 0.629 4.68333 0 6.5 0C8.31667 0 9.85433 0.629 11.113 1.887C12.371 3.14567 13 4.68333 13 6.5C13 7.23333 12.8833 7.925 12.65 8.575C12.4167 9.225 12.1 9.8 11.7 10.3L17.325 15.925C17.5083 16.1083 17.6 16.3333 17.6 16.6C17.6 16.8667 17.5 17.1 17.3 17.3C17.1167 17.4833 16.8833 17.575 16.6 17.575C16.3167 17.575 16.0833 17.4833 15.9 17.3ZM6.5 11C7.75 11 8.81267 10.5627 9.688 9.688C10.5627 8.81267 11 7.75 11 6.5C11 5.25 10.5627 4.18733 9.688 3.312C8.81267 2.43733 7.75 2 6.5 2C5.25 2 4.18733 2.43733 3.312 3.312C2.43733 4.18733 2 5.25 2 6.5C2 7.75 2.43733 8.81267 3.312 9.688C4.18733 10.5627 5.25 11 6.5 11Z" fill="currentColor"/></svg>    
            </button>
            <div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div>
          </div>
          <div style="position: relative;">
            <button class="btn btn-light" disabled><svg style="margin-right: 4px;" width="13" height="9" viewBox="0 0 15 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9.10199 9.1978C9.29153 9.19801 9.47384 9.27059 9.61166 9.40069C9.74949 9.5308 9.83243 9.70863 9.84353 9.89784C9.85464 10.087 9.79308 10.2734 9.67143 10.4187C9.54977 10.564 9.37721 10.6574 9.189 10.6798L9.10199 10.685H6.1274C5.93786 10.6848 5.75556 10.6122 5.61773 10.4821C5.47991 10.352 5.39697 10.1742 5.38586 9.985C5.37475 9.79579 5.43631 9.60948 5.55797 9.46414C5.67962 9.3188 5.85218 9.22539 6.0404 9.20301L6.1274 9.1978H9.10199ZM11.3329 4.73611C11.5302 4.73611 11.7193 4.81445 11.8588 4.95391C11.9982 5.09336 12.0766 5.2825 12.0766 5.47972C12.0766 5.67694 11.9982 5.86608 11.8588 6.00554C11.7193 6.14499 11.5302 6.22334 11.3329 6.22334H3.89646C3.69924 6.22334 3.51009 6.14499 3.37062 6.00554C3.23116 5.86608 3.15282 5.67694 3.15282 5.47972C3.15282 5.2825 3.23116 5.09336 3.37062 4.95391C3.51009 4.81445 3.69924 4.73611 3.89646 4.73611H11.3329ZM13.5639 0.274414C13.7611 0.274414 13.9502 0.352759 14.0897 0.492214C14.2292 0.631669 14.3075 0.820811 14.3075 1.01803C14.3075 1.21525 14.2292 1.40439 14.0897 1.54385C13.9502 1.6833 13.7611 1.76165 13.5639 1.76165H1.66552C1.46829 1.76165 1.27914 1.6833 1.13968 1.54385C1.00022 1.40439 0.921875 1.21525 0.921875 1.01803C0.921875 0.820811 1.00022 0.631669 1.13968 0.492214C1.27914 0.352759 1.46829 0.274414 1.66552 0.274414H13.5639Z" fill="#3D3D3D"/></svg>Filtrar<div class="tooltiptext tooltipGratis">Recurso disponível para assinantes Avantpro Ultra</div></button>
          </div>
        </div>
        `
        + anunciosPorVendas + `
        
        <button class="btn btn-light" id="btnFechaVendedor" style="margin: 5px auto 5px auto;">Ocultar vendedores<svg style="margin-left: 4px;" width="15" height="10" viewBox="0 0 17 11" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.53719 0.653383C8.73831 0.653383 8.93288 0.691092 9.12092 0.766507C9.30997 0.841922 9.46734 0.942474 9.59304 1.06817L16.5315 8.00632C16.808 8.28284 16.9463 8.63478 16.9463 9.06213C16.9463 9.48948 16.808 9.84141 16.5315 10.1179C16.255 10.3945 15.903 10.5327 15.4756 10.5327C15.0483 10.5327 14.6963 10.3945 14.4198 10.1179L8.53719 4.23558L2.65459 10.1179C2.37806 10.3945 2.02611 10.5327 1.59874 10.5327C1.17137 10.5327 0.819424 10.3945 0.542891 10.1179C0.266357 9.84141 0.12809 9.48948 0.12809 9.06213C0.12809 8.63478 0.266357 8.28284 0.542891 8.00632L7.48134 1.06817C7.63218 0.917336 7.79558 0.81075 7.97156 0.748407C8.14753 0.685059 8.33608 0.653383 8.53719 0.653383Z" fill="#3D3D3D"/></svg></button>
        </div>`
      }
      
      <div id="modalRange" class="modalFaturamento">
        <div class="modalBody">
            <div class="closeModal" id="closeMdlFaturamento"><svg width="13" height="13" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.575 8.40005L1.675 13.3C1.49167 13.4834 1.25833 13.575 0.975 13.575C0.691667 13.575 0.458333 13.4834 0.275 13.3C0.0916663 13.1167 0 12.8834 0 12.6C0 12.3167 0.0916663 12.0834 0.275 11.9L5.175 7.00005L0.275 2.10005C0.0916663 1.91672 0 1.68338 0 1.40005C0 1.11672 0.0916663 0.883382 0.275 0.700048C0.458333 0.516715 0.691667 0.425049 0.975 0.425049C1.25833 0.425049 1.49167 0.516715 1.675 0.700048L6.575 5.60005L11.475 0.700048C11.6583 0.516715 11.8917 0.425049 12.175 0.425049C12.4583 0.425049 12.6917 0.516715 12.875 0.700048C13.0583 0.883382 13.15 1.11672 13.15 1.40005C13.15 1.68338 13.0583 1.91672 12.875 2.10005L7.975 7.00005L12.875 11.9C13.0583 12.0834 13.15 12.3167 13.15 12.6C13.15 12.8834 13.0583 13.1167 12.875 13.3C12.6917 13.4834 12.4583 13.575 12.175 13.575C11.8917 13.575 11.6583 13.4834 11.475 13.3L6.575 8.40005Z" fill="var(--grey)"/></svg></div>
            <div style="display: flex; align-items: center; justify-content: center; margin-bottom: 25px; color: var(--grey);">
            <h2 style="font-weight: 900;">Range de vendas ML</h2></div>
            
            <div style="display: flex; justify-content: center;">
              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>1</p>
                    <p>1 vendido</p>
                  </div>
                  <div class="row-tabela">
                    <p>2</p>
                    <p>2 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>3</p>
                    <p>3 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>4</p>
                    <p>4 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>5</p>
                    <p>5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 6 a 25 vendas</p>
                    <p>+5 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 26 a 50 vendas</p>
                    <p>+25 vendidos</p>
                  </div>
                </div>
              </div>

              <div class="cardInfos tabela" style="font-size: 13px !important;">
                <div class="header-tabela">
                  <p>Dado real</p>
                  <p>Referência</p>
                </div>
                <div class="body-tabela">
                  <div class="row-tabela">
                    <p>De 51 a 100 vendas</p>
                    <p>+50 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 101 a 150 vendas</p>
                    <p>+100 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 151 a 200 vendas</p>
                    <p>+150 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 201 a 250 vendas</p>
                    <p>+200 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 501 a 5.000 vendas</p>
                    <p>+500 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 5.001 a 50.000 vendas</p>
                    <p>+5.000 vendidos</p>
                  </div>
                  <div class="row-tabela">
                    <p>De 50.001 a 500.000 vendas</p>
                    <p>+50.000 vendidos</p>
                  </div>
                </div>
              </div>
            </div>

            <div style="text-align: center; margin-top: 16px;"><p>Informações oficiais oferecidas pelo ML. <a href="https://developers.mercadolivre.com.br/pt_br/itens-e-buscas#Valores-nos-campos-sold-quantity-e-available-quantity" target="_blank">Leia aqui.</a></p></div>

        </div>
            
      </div>
      
      `

    document.getElementsByClassName('ui-search-filter-groups')[0].insertAdjacentElement("afterbegin", medalhaVendedor);

    /* Mostrar vendedores */
    var bntMostrarVendedor = document.getElementById("btnMostrarVendedor");
    var btnFechaVendedor = document.getElementById("btnFechaVendedor");
    var infoEscondida = document.getElementsByClassName("infoEscondida")[0];

    bntMostrarVendedor.addEventListener("click", function () {

      if (infoEscondida.classList.contains("escondeInfo")) {
        bntMostrarVendedor.style.transform = "rotate(-180deg)";
        infoEscondida.classList.add("mostraInfo");
        infoEscondida.classList.remove("escondeInfo");
        document.getElementsByClassName("mostraInfo")[0].style.animation = "downInformation .3s";
      }

      else {
        bntMostrarVendedor.style.transform = "rotate(0deg)";
        document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
        setTimeout(function () {
          infoEscondida.classList.add("escondeInfo");
          infoEscondida.classList.remove("mostraInfo");
        }, 305);
      }
    });

    btnFechaVendedor.addEventListener("click", function () {
      bntMostrarVendedor.style.transform = "rotate(0deg)";
      document.getElementsByClassName("mostraInfo")[0].style.animation = "upInformation .3s";
      setTimeout(function () {
        infoEscondida.classList.add("escondeInfo");
        infoEscondida.classList.remove("mostraInfo");
      }, 299);

    });
    /* Fim do mostrar vendedores */


    /* Modal range de preços */
    var modalRange = document.getElementById("modalRange");
    var btnModalRange = document.getElementById("btnModalRange");

    var closeMdl = document.getElementsByClassName("closeModal");

    // var infoSobeModal = document.getElementsByClassName("ui-pdp-container__col col-2 ui-pdp-container--column-left pb-40")[0];
    // var containerMl = document.getElementsByClassName('shops__ui-main')[0]

    function abreModalRange() {
      modalRange.classList.toggle("openModal");
    }

    function unloadScrollBars() { //Desativa scroll da pagina
      // containerMl.style.zIndex = 20
      // infoSobeModal.style.zIndex = -1;
      document.documentElement.style.overflow = 'hidden';
      document.body.scroll = "no";
    }

    function reloadScrollBars() { //Ativa scroll da pagina
      // setTimeout(() => {
      //   infoSobeModal.style.zIndex = '';
      //   containerMl.style.zIndex = '';
      // }, 200);
      document.documentElement.style.overflow = 'auto';
      document.body.scroll = "yes";
    }

    btnModalRange.addEventListener("click", abreModalRange);
    btnModalRange.addEventListener("click", unloadScrollBars);

    for (let i = 0; i <= closeMdl.length; i++) {
      if (closeMdl[i]) {
        closeMdl[i].addEventListener("click", () => {
          reloadScrollBars();

          if (modalRange.classList.contains('openModal')) {
            abreModalRange();
          }
        });
      }
    };


    /* Sair Avantpro */


    $('#sairmlpro').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });

  }

  static menuLateralMaisVendidosGratis(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, rawVendedoresCompleto, qtdSupermercado, qtdInternacional, maiorVenda, menorVenda, totalVendas, qtdFlex) {
    // renderiza a medalha do vendedor
    let medalhaVendedor = document.createElement('div')
    medalhaVendedor.className = 'ui-menu-lateral'

    let anunciosPorVendas = '';

    for (let i = 0; i < rawVendedoresCompleto.length; i++) {
      let full = '';
      let gratis = '';
      let reputacao = '';
      let estado = '';
      for (let x = 0; x < rawVendedoresCompleto[i].val.available_filters.length; x++) {
        if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping") full = rawVendedoresCompleto[i].val.available_filters[x].values.length == 2 ? rawVendedoresCompleto[i].val.available_filters[x].values[1].results : 0;
        if (rawVendedoresCompleto[i].val.available_filters[x].id == "shipping_cost") gratis = rawVendedoresCompleto[i].val.available_filters[x].values[0].results
      }


      switch (rawVendedoresCompleto[i].val.seller.seller_reputation.level_id) {
        case '5_green':
          reputacao =
            `
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="green" />
          </svg>
          `
          break;
        case '4_light_green':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgreen" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          `
          break;
        case '3_yellow':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="yellow" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          `
          break;
        case '2_orange':
          reputacao =
            `
            <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="orange" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          `
          break;
        case '1_red':
          reputacao =
            `
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="red" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
         `
          break;
        default:
          reputacao =
            `
            <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect  width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          <svg class="svg-termometro-menu" width="10" height="6">
          <rect width="10" height="6" fill="lightgray" />
          </svg>
          `;
          break;
      }


      if (rawVendedoresCompleto[i].val.results.length > 0) {
        anunciosPorVendas += `<p class="p-vendedor p-${rawVendedoresCompleto[i].val.seller.seller_reputation.power_seller_status}"> `
          + rawVendedoresCompleto[i].val.seller.nickname + ': <strong>' + rawVendedoresCompleto[i].val.qtdAnuncio + '</strong>'
          + `<br> <p class="p-vendedor-detalhes" style="font-size: 11px !important">Concluidas ${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.completed} + Canceladas ${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.canceled} = ${rawVendedoresCompleto[i].val.seller.seller_reputation.transactions.total}`
          + `<br> Últimos 60 dias: <br> Vendas ${rawVendedoresCompleto[i].val.seller.seller_reputation.metrics.sales.completed} - Reclamações: ${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.claims.value} - Atrasos: ${rawVendedoresCompleto[i].val.results[0].seller.seller_reputation.metrics.delayed_handling_time.value}`
          + `<br>Total de Anúncios: ${rawVendedoresCompleto[i].val.paging.total}`
          + `<br>Localização:  ${rawVendedoresCompleto[i].val.seller.tags.includes('international_seller') ? 'Vendedor Internacional' : (rawVendedoresCompleto[i].val.cidade != null ? (rawVendedoresCompleto[i].val.cidade + ' / ' + rawVendedoresCompleto[i].val.uf.replace('BR-', '')) : 'Não Informado')}`
          + `<br>No Full: ${full} - Frete Grátis: ${gratis} &nbsp; ${reputacao}`
          + '</p></p>'
      } else {
        // console.log('não tem results');
      }
    }


    medalhaVendedor.innerHTML = `<center><button id="sairmlpro">Sair do Avantpro</button></center>`
      + `<center><img width="100px" src="https://ramcloud.com.br/img/logomelipro.png?time=${new Date().getTime()}" /></center>`
      + `<center style="margin-top: -20px !important; margin-bottom: -20px !important"><small style="color: gray; font-size: 12px;">Versão ${chrome.runtime.getManifest().version}</small></center>`
      + `<center><span class="redesSocias">PARTICIPE DOS NOSSOS GRUPOS: </span></center>`
      + `<div class="botoesRedesSociais"><button class="telegram" onClick="javascript:window.open('https://t.me/mercadolivrepro', '_blank');">
      <svg style="float: left; margin-right: -30px; margin-top: 40px; margin-left: -5px;" xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-telegram" viewBox="0 0 50 50">
      <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
    </svg>TELEGRAM</button>`
      + `<button class="whatsapp" onClick="javascript:window.open('https://linktr.ee/grupoavantpro', '_blank');">
    <svg style="float: left; margin-right: -30px; margin-top: 40px; margin-left: -5px;" xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-telegram" viewBox="0 0 70 70">
    <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.911.928 3.145.929 3.178 0 5.767-2.587 5.768-5.766.001-3.187-2.575-5.77-5.764-5.771zm3.392 8.244c-.144.405-.837.774-1.17.824-.299.045-.677.063-1.092-.069-.252-.08-.575-.187-.988-.365-1.739-.751-2.874-2.502-2.961-2.617-.087-.116-.708-.94-.708-1.793s.448-1.273.607-1.446c.159-.173.346-.217.462-.217l.332.006c.106.005.249-.04.39.298.144.347.491 1.2.534 1.287.043.087.072.188.014.304-.058.116-.087.188-.173.289l-.26.304c-.087.086-.177.18-.076.354.101.174.449.741.964 1.201.662.591 1.221.774 1.394.86s.274.072.376-.043c.101-.116.433-.506.549-.68.116-.173.231-.145.39-.087s1.011.477 1.184.564.289.13.332.202c.045.072.045.419-.1.824zm-3.423-14.416c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm.029 18.88c-1.161 0-2.305-.292-3.318-.844l-3.677.964.984-3.595c-.607-1.052-.927-2.246-.926-3.468.001-3.825 3.113-6.937 6.937-6.937 1.856.001 3.598.723 4.907 2.034 1.31 1.311 2.031 3.054 2.03 4.908-.001 3.825-3.113 6.938-6.937 6.938z"/>
    </svg>WHATSAPP</button></div>`
      + `<button class="assineja" onClick="javascript:window.open('https://www.avantpro.com.br/', '_blank');">ASSINE JÁ O AVANTPRO E LIBERE TODOS OS RECURSOS</button>`
      + `<p class="p-null">Sem Medalha: <strong>${qtdSemMedalha}</strong> </p>`
      + `<p class="p-silver"> Mercado Líder: <strong>${qtdLider}</strong> </p>`
      + `<p class="p-gold"> Mercado Gold: <strong>${qtdGold}</strong> </p>`
      + `<p class="p-platinum"> Mercado Platinum: <strong>${qtdPlatinum}</strong> </p>`
      + `<p class="p-full">Anúncios no <span class="full">FULL</span>: <strong>${qtdFull}</strong> </p>`
      + `<p class="p-menorpreco">Menor Preço: <strong>R$ ${menorPreco.toFixed(2)}</strong> </p>`
      + `<p class="p-maiorpreco">Maior Preço: <strong>R$ ${maiorPreco.toFixed(2)}</strong> </p>`
      + `<p class="p-menorvenda">Menor Qtd de Vendas: <strong>${menorVenda}</strong> * </p>`
      + `<p class="p-maiorvenda">Maior Qtd de Vendas: <strong>${maiorVenda}</strong> * </p>`
      + `<p class="p-totalvendas">Total de Vendas: <strong>${totalVendas}</strong> * </p>`
      + `<p class="p-fretegratis">Frete Grátis: <strong>${qtdFreteGratis}</strong> </p>`
      + `<p class="p-classico">Anúncios Classicos: <strong>${qtdClassico}</strong> </p>`
      + `<p class="p-premium">Anúncios Premium: <strong>${qtdPremium}</strong> </p>`
      + `<p class="p-oficial">Lojas Oficiais: <strong>${qtdLojasOficiais}</strong> </p>`
      + `<p class="p-catalogo">Itens em Catalogo: <strong>${qtdCatalogo}</strong> </p>`
      + `<p class="p-supermercado">Itens em Supermercado: <strong>${qtdSupermercado}</strong> </p>`
      + `<p class="p-flex">Itens Com Flex Ativo: <strong>${qtdFlex}</strong> </p>`
      + `<small style="margin-top: 5px; font-size: 11px">*Qtds aproximadas conforme range de vendas </small>`
      + `<center><p style="margin-top: 10px; margin-bottom: -5px; font-size: 12px">powered by:  Avantpro</p></center>`
      + `<button class="vejamais" onClick="javascript:window.open('https://bit.ly/sp-pro', '_blank');">UTILIZE NOSSA FERRAMENTA EM OUTRAS PLATAFORMAS</button>`
      + ` ${rawVendedoresCompleto == undefined ? '' : `<br><p>Anúncios por ${rawVendedoresCompleto.length} Vendedor(es): </p>`} `
      + anunciosPorVendas

    document.getElementsByClassName('seller-title')[0].insertAdjacentElement("afterbegin", medalhaVendedor);

    $('#sairmlpro').click(function () {
      chrome.storage.local.set({ emailmlpro: '' });
      parent.window.postMessage("Reload", "*");
    });

  }

  static botaoPalavrasChavesGratis(itemList) {

    var Titulo = document.getElementsByClassName('ui-search-view-options__group')[0];

    /* Criando botao  */
    var TermosValue = document.createElement('div');
    TermosValue.className = 'subtitleData'
    TermosValue.innerHTML = `<button class="botaoPalavrasChaves" style="background: gray" onclick="alert('Recurso disponível na versão paga, assine já em www.avantpro.com.br')"> Veja os termos mais usados nos títulos</button>`;
    Titulo.appendChild(TermosValue);
  }



  static botaoPalavrasChavesMaisVendidosGratis(itemList) {
    var Titulo = document.getElementsByClassName('promotions_boxed-width')[0];

    /* Criando botao  */
    var CriadoValue = document.createElement('div');
    CriadoValue.className = 'subtitleData'
    CriadoValue.innerHTML = `<button style="margin-bottom: 10px !important; width: 98.5%; background: gray" class="botaoPalavrasChaves" > Veja os termos mais usados nos títulos</button>`;
    Titulo.prepend(CriadoValue);


  }


  static dadosAnuncioGratis(itemList) {
    // Para cada item
    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML
      id = id.replace('#', 'MLB');
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.sc-list-channel-content__container'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('div')
        dadosAnuncio.className = 'dados-anuncio'
        dadosAnuncio.setAttribute("style", "color: black; font-size:12px; width: 242px; margin-top: 15px !important");



        dadosAnuncio.innerHTML =
          `<p>Criado em: <button style="width: 75px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> |  Há <strong><button style="width: 20px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong> dias</p>`
          + `<p>Fotos: <strong><button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong></p>`
          + `<p>EAN: <strong><button style="width: 90px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong></p>`
          + `<p>Vídeo: <strong><button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong></p>`
          + `<p>Catalogo: <strong><button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></strong></p>`
          + `<p>Full: <strong><button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          //+ `<p>Recomendação: <strong></strong></p>`
          + `<center><p style="margin-top: 10px; font-size: 12px; color: gray">powered by:  Avantpro</p></center>`
        $(this)
          .find(
            '.sc-list-channel-content__container > .sc-list-item-row-quality .sc-list-text--secondary'
          )
          .after(dadosAnuncio)
      }
    })
  }


  static dadosAnuncioValorGratis(itemList) {
    // Para cada item
    $('.sc-item-rows > .sc-list-item-row').each(function () {
      let id = $(this).find(".sc-list-item-row__visible > .sc-list-item-row-description > .sc-list-item-row-description__upper-row > .upper-row__overflow > .sc-list-item-row-description__id")[0].innerHTML
      id = id.replace('#', 'MLB');
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'div.andes-tooltip__trigger'
        ).length
      ) {
        // renderiza a quantidade de vendas
        let dadosAnuncio = document.createElement('p')
        dadosAnuncio.className = 'dados-anuncio-liquido'
        dadosAnuncio.setAttribute("style", "color: black; font-size:13px; width: 180px; margin-top:-20px;")

        dadosAnuncio.innerHTML =
          `<br> <p style="color: black" class="sc-list-item-row-description__info">Conversão: <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
        $(this)
          .find(
            '.andes-tooltip__trigger'
          )
          .before(dadosAnuncio)
      }
    })
  }

  static pesquisaPorAnuncioMaisVendidosGratis(itemList) {
    // Para cada item
    $('.items_container > .promotion-item').each(function () {
      let id = $(this).find('.promotion-item__link-container').attr('href');
      id = id.split('-')[1];
      id = 'MLB' + id;
      let item = itemList.find((item) => item.id === id)
      if (
        item &&
        $(this).find(
          'p.promotion-item__title'
        ).length
      ) {

        if (document.contains(document.querySelector(".loading"))) {
          document.querySelector('.loading').remove();
        }

        // renderiza a medalha do vendedor
        let medalhaVendedor = document.createElement('div')
        medalhaVendedor.className = 'medalha-vendedor';
        medalhaVendedor.setAttribute("style", "margin-left: -7px; margin-right: -7px; color: gray");




        let tipoMedalha = '';
        switch (item.seller.seller_reputation.power_seller_status) {
          case 'platinum':
            tipoMedalha = 'Platinum';
            break;
          case 'silver':
            tipoMedalha = 'Líder';
            break;
          case 'gold':
            tipoMedalha = 'Gold';
            break;
          default:
            tipoMedalha = 'Sem Medalha';
            break;
        }

        var data = item.start_time;

        const hoje = new Date();
        const dataCriacao = new Date(data);
        const diferencaDias = Math.abs(hoje.getTime() - dataCriacao.getTime());
        const diasCriacao = Math.ceil(diferencaDias / (1000 * 60 * 60 * 24));
        var reputacao = '';

        switch (item.seller.seller_reputation.level_id) {
          case '5_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="green" />
            </svg>
            </div>`
            break;
          case '4_light_green':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgreen" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '3_yellow':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="yellow" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '2_orange':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="orange" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          case '1_red':
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="red" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`
            break;
          default:
            reputacao =
              `<div>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect  width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            <svg class="svg-termometro" width="45" height="6">
            <rect width="45" height="6" fill="lightgray" />
            </svg>
            </div>`;
            break;
        }

        let reputacaoCinza =
          `<div>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect  width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      <svg class="svg-termometro" width="45" height="6">
      <rect width="45" height="6" fill="lightgray" />
      </svg>
      </div>`;

        let conversaoporvisita = '';
        if (parseInt(item.visitas) > 0 && item.vendas > 0) {
          if (item.index == 0) {
            conversaoporvisita = `<p style="line-height: 0.3 !important; margin-right: -15px">1 Venda a Cada <strong>${(item.visitas / item.vendas).toFixed(0)}</strong> Visitas | Conversão: <strong>${((1 / (item.visitas / item.vendas)) * 100).toFixed(2)}%</strong></p>`
          } else {
            conversaoporvisita = `<p style="line-height: 0.3 !important; margin-right: -15px">1 Venda a Cada <button style="width: 15px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> Visitas | Conversão: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
          }
        }

        let ean = '';
        if (item.ean != null) {
          if (item.ean != 'Sem EAN') {
            ean = item.ean.split(',');
            ean = ean.filter(x => x.trim());
            ean = ean.length > 1 ? ean[0] + ' + ' + (ean.length - 1) + ' EANs de variações' : ean[0];
          } else {
            ean = item.ean;
          }
        }

        if (item.index == 0) {
          medalhaVendedor.innerHTML =
            `<br><p class="p2-${item.seller.seller_reputation.power_seller_status}"><span style="margin-left: 20px">Vendedor:  <strong>${item.seller.nickname}</strong></span></p>`
            + `<p style=" line-height: 0.3 !important;">Anúncio Criado em: <strong>${dataCriacao.toLocaleDateString()}</strong> | Há  <strong>${diasCriacao}</strong> dias</p>`
            + `<p style=" line-height: 0.3 !important;">Qualidade do Anúncio:  <strong>${(parseFloat(item.health == null ? 1 : item.health) * 100).toFixed(0)}%</strong> | <strong>${item.taxas.listing_type_name}</strong></p>`
            + `<p style=" line-height: 0.3 !important;">Comissão do ML: <strong>R$ ${item.taxas.sale_fee_amount.toFixed(2)}</strong></p>`
            + `<p style=" line-height: 0.3 !important;">EAN: <strong>${ean == '' ? 'Sem EAN' : ean}</strong></p>`
            + `<p style=" line-height: 0.3 !important;">Fotos: <strong>${item.fotos}</strong> | Vídeo: <strong>${item.video}</strong></p>`
            + `<p style=" line-height: 0.3 !important;">Vendas: <strong>${item.vendas}</strong> | Visitas: <strong>Acesse o Anúncio</strong></p>`
            + `${conversaoporvisita}`
            + `${reputacao}`
            + `<p style="margin-top: 5px;">powered by:  Avantpro Grátis</p>`
          $(this)
            .find(
              '.promotion-item__title'
            )
            .after(medalhaVendedor)
        } else {

          /** BOTAO ASSINE JA */

          let botaoRastreio = document.createElement('div')

          botaoRastreio.innerHTML = `<center><button style=" z-index: -1; margin-bottom: -10px; margin-top: 10px; width: 95%" class="assineja" onClick="javascript:window.open('https://www.avantpro.com.br/', '_blank');">Assine já o Avantpro e libere todos os recursos!</button></center>`

          try {
            $(this)
              .find(
                '.ui-search-variations-pill'
              )
              .remove()
          } catch (error) {

          }

          $(this)
            .find(
              '.promotion-item__description'
            )
            .before(botaoRastreio)

          /** FIM ASSINE JA */


          medalhaVendedor.innerHTML =
            `<br><span>Vendedor: <button style="width: 120px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></span>`
            + `<p style="margin: -1px 0px">Anúncio Criado em: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Há <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> dias</p>`
            + `<p style="margin: -1px 0px">Qualid.: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Comissão: R$ <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
            + `<p style="margin: -1px 0px">EAN: <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
            + `<p style="margin: -1px 0px">Catálogo: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Loja Oficial: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
            + `<p style="margin: -1px 0px">Fotos: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Vídeo: <button style="width: 30px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
            + `<p style="margin: -1px 0px">Vendas: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> | Visitas: <button style="width: 40px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button></p>`
            + `${conversaoporvisita}`
            + `${reputacaoCinza}`
            + `<p style="margin-top: 5px;">powered by:  Avantpro Grátis</p>`
          $(this)
            .find(
              '.promotion-item__title'
            )
            .after(medalhaVendedor)
        }




      }
    })
  }
  /** FIM VERSAO GRATIS */


  static _createElement(type, className, innerHTML) {
    var element = document.createElement(type)
    element.className = className
    if (innerHTML != 'undefined') {
      element.innerHTML = innerHTML
    }

    return element
  }
}



