/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


class RenderFrame {

    static ValidarEmailModal() {

        var body = document.body;

        var ModalValidaEmail = document.createElement('div');


        ModalValidaEmail.innerHTML = `
    <div class="bodyValidacao">
      <div class="headerValidacao">
          <div style="display: flex;">
                <svg width="20" height="25" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
                <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
                <defs>
                <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
                <stop offset="0.380208" stop-color="#F2A008"/>
                <stop offset="0.792994" stop-color="#F9D043"/>
                </linearGradient>
                <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
                <stop stop-color="#1B22B8"/>
                <stop offset="1" stop-color="#4D43FA"/>
                </linearGradient>
                </defs>
                </svg>
                <span style="align-self: center;font-weight: 600;color: white;">&nbsp; Avantpro</span>
          </div>
      </div>
      <div class="containerValidacao" id="validateForm">
          <div class="info">
              <h2 style="font-weight: bold; font-size:18px; margin:15px 0;">Avantpro</h2>
              <p>Para utilizar a extensão <strong>Avantpro</strong> você precisa fazer seu cadastro no nosso
                  site. </p>
              <p><a style="text-decoration: underline;" href="https://www.viapedidos.com/empresa/cadastromlpro" target="_blank">Clique aqui para fazer seu cadastro <strong>gratuitamente</strong></a>
              </p>
          </div>
          <div class="row" style="margin-top:20px;">
              <div class="col-md-12">
                  <form id="validationForm" autocomplete="off">
                      <label>Se você já fez o cadastro digite o e-mail cadastrado e clique em validar para ativar a extensão </label>
                      <input style="margin-top: 10px;" placeholder="Digite seu e-mail" type="email" name="email" id="userEmail" class="form-control" required>
                      <div class="message" id="message" style="display: none; margin-top:10px;  margin-bottom:10px; color: red">
                          <p>Login Inválido, por favor confirme seu e-mail e tente novamente.</p>
                      </div>
                      <p>
                        <a style="text-decoration: underline;" href="https://www.youtube.com/watch?v=yQcNNssDSSI" target="_blank">Fez o login e a extensão não carregou? Clique aqui e veja esse tutorial!</a>
                      </p>
                      <span class="btnValidando" id="btnValidando">Validando...</span>
                      <button class="btnValidar" id="sendEmail" type="submit">Validar</button>
                      <button type="button" class="btnFechar" id="remover" style="margin-top:5px; width: 100px;">Fechar</button>
                  </form>
              </div> 
          </div>
      </div>
      <div class="container" id="validatedMessage" style="display: none; height: 10px;">
          <div class="alert alert-success" style="margin-top: 18px; padding: -5px; color: #00a650; margin-left: 25px;">
              <h4 style="font-size: 14.5px; font-weight: bold;"><i class="fa fa-check"></i> Obrigado por ativar sua extensão. Aguarde, a página irá recarregar.</h4>
          </div>
      </div>
    </div>
    `
        body.appendChild(ModalValidaEmail);

    }

    static RastreioModal(ASSINANTE, ULTRA) {
        var body = document.body;
        var ModalRastreio = document.createElement('div');

        if (ULTRA) {
            var ultra = document.createElement('span');
            ultra.className = 'ultra';
            body.appendChild(ultra);
        }


        ModalRastreio.setAttribute('style', `
          display: none;
          position:fixed;
          top:0;
          left:0;
          z-index:1000;
          background-color: #ededed;
          width:100%;
          height: 100%;
          overflow-y: auto;   
        `);

        ModalRastreio.className = 'bodyRastreio';

        /**GRATIS */
        if (!ASSINANTE) {
            ModalRastreio.innerHTML = ``;
        }

        /**PREMIUM */
        if (ASSINANTE) {
            ModalRastreio.innerHTML = /* html */`
          <div class="body-rastreio">
            <div style="display: flex; justify-content: space-between; background: linear-gradient(90deg, rgba(95,183,245,1) 14%, rgba(7,135,218,1) 42%, rgba(255,209,112,1) 66%, rgba(244,179,44,1) 97%);" class="p-1 mb-2 text-white">
                <div style="display: flex;">
                    <svg width="25" height="25" viewBox="0 0 503 529" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M180.575 64.866C201.361 14.5657 271.467 -49.4621 324.916 64.866C381.649 186.219 459.31 360.028 488.922 433.756C509.304 484.501 511.748 528.948 454.537 528.948C432.087 528.948 416.149 519.997 397.254 509.12C396.915 508.925 396.576 508.73 396.235 508.534C367.148 491.784 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647C91.8362 518.607 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9517 359.922L46.0485 359.71L180.575 64.866ZM236.782 173.436C244.125 158.597 257.196 154.494 266.12 173.436C275.628 193.618 293.166 232.834 299.125 247.672C302.589 256.624 299.125 273.884 282.816 268.092C275.35 265.441 272.03 260.377 268.917 255.629C265.156 249.893 261.698 244.619 251.601 244.619C240.729 244.619 236.121 250.77 231.602 256.802C227.742 261.955 223.946 267.021 216.365 268.092C202.824 270.006 199.696 255.989 203.202 247.672L236.782 173.436Z" fill="url(#paint0_linear_35_21)"/>
                    <path d="M396.235 508.533C367.148 491.783 330.737 470.816 253.054 470.816C178.262 470.816 143.113 490.252 113.463 506.647L113.463 506.647C91.8362 518.606 73.135 528.948 44.1088 528.948C-4.81039 528.948 -8.95649 479.003 12.2642 433.756L45.9973 359.822C135.44 313.658 297.194 451.5 396.235 508.533Z" fill="url(#paint1_linear_35_21)"/>
                    <defs>
                    <linearGradient id="paint0_linear_35_21" x1="251.109" y1="-132.003" x2="251.109" y2="737.323" gradientUnits="userSpaceOnUse">
                    <stop offset="0.380208" stop-color="#F2A008"/>
                    <stop offset="0.792994" stop-color="#F9D043"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear_35_21" x1="302.803" y1="439.737" x2="10.1936" y2="454.391" gradientUnits="userSpaceOnUse">
                    <stop stop-color="#1B22B8"/>
                    <stop offset="1" stop-color="#4D43FA"/>
                    </linearGradient>
                    </defs>
                    </svg>
                    <span style="font-weight: 600;color: white;">&nbsp; Avantpro</span>
                </div>
                <div style="display: flex;">
                    <span id="nomeproduto" style="font-weight: 500;"></span>
                </div>
                <div style="margin-right: 15px;">
                    <button id="fecharFrame" style="background: none;color: white;border: none;font-weight: 600;">Fechar
                        <svg class="svg-icon" viewBox="0 0 20 20">
                            <path fill="none"
                                d="M13.864,6.136c-0.22-0.219-0.576-0.219-0.795,0L10,9.206l-3.07-3.07c-0.219-0.219-0.575-0.219-0.795,0
                                c-0.219,0.22-0.219,0.576,0,0.795L9.205,10l-3.07,3.07c-0.219,0.219-0.219,0.574,0,0.794c0.22,0.22,0.576,0.22,0.795,0L10,10.795
                                l3.069,3.069c0.219,0.22,0.575,0.22,0.795,0c0.219-0.22,0.219-0.575,0-0.794L10.794,10l3.07-3.07
                                C14.083,6.711,14.083,6.355,13.864,6.136z M10,0.792c-5.086,0-9.208,4.123-9.208,9.208c0,5.085,4.123,9.208,9.208,9.208
                                s9.208-4.122,9.208-9.208C19.208,4.915,15.086,0.792,10,0.792z M10,18.058c-4.451,0-8.057-3.607-8.057-8.057
                                c0-4.451,3.606-8.057,8.057-8.057c4.449,0,8.058,3.606,8.058,8.057C18.058,14.45,14.449,18.058,10,18.058z">
                            </path>
                        </svg>
                    </button>
                </div>
            </div>

            <div id="loadingframe" style="display: flex; align-items: center; justify-content: center; height: 100%; width: 100%;">
                <center>
                    <div class="loader">
                    <svg width="100" height="113" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                    <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                    <defs>
                    <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
                    <stop offset="0.139315" stop-color="#271BEF"/>
                    <stop offset="0.942129" stop-color="#00C2FF"/>
                    </linearGradient>
                    <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
                    <stop offset="0.0921191" stop-color="#00C2FF"/>
                    <stop offset="0.970863" stop-color="#271BEF"/>
                    </linearGradient>
                    </defs>
                    </svg>
                    <p style="font-size: 25px;"><strong>Carregando dados Avantpro...</strong></p>
                    </div>
                    <button  id="fecharFrameLoading" class="btn btn-danger" style="font-size: 16px !important; margin-top: 20px;">Fechar</button>
                </center>
             </div>

      
            <div class="tabMenu">
                <input class="impMenu" type="radio" name="tabs" id="tab1" checked>
                <label class="lblMenu" for="tab1">Ferramentas</label>
    
                <input class="impMenu" type="radio" name="tabs" id="tab2">
                <label class="lblMenu" for="tab2">Rastrear Anúncios</label>
    
                <input class="impMenu" type="radio" name="tabs" id="tab3">
                <label class="lblMenu" for="tab3">Rastrear Concorrentes</label>

                <input class="impMenu" type="radio" name="tabs" id="tab4">
                <label class="lblMenu" for="tab4">Rastrear Criados</label>

                ${ULTRA ? `` :
                    `<input class="impMenu" type="radio" name="tabs" id="tab5">
                  <label class="lblMenu" for="tab5" style="color: orange; font-weight: bold;">Conheça o Avantpro Ultra</label>`
                }
    
                <div class="tabs">
                    <div class="content">
                        <div class="container" style="padding-right: 5px">
                            <div id="grafico" style=" height: 50%;">
                                <div style="display: flex; margin-bottom: -25px;">
                                    <h5 class="card-title ml-blue-font">Visitas do Anúncio</h5>
                                    <small
                                        style="font-size: 12px; color: gray; margin-left: 10px; align-self: center; margin-bottom: .5rem;">
                                        (Mensal)
                                    </small>
                                </div>
                                <div>
                                    <center>
                                        <p id="semanuncio" style="display: none"></p>
                                    </center>
                                   
                                    <center>
                                        <p id="errografico"></p>
                                    </center>
                                    <canvas id="myChart" style="width:100%; height: 220px;"></canvas>
                                </div>
                            </div>
    
    
                            <div id="nomes" style="height: 45%;">
                                <div style="display: flex">
                                    <h5 class="card-title ml-blue-font">Criador de Titulos Com Código de Barras</h5>
                                    <strong><small
                                            style="font-size: 12px; color: gray; margin-left: 10px; align-self: center; margin-bottom: .5rem;">(Digite
                                            os termos separando por vírgula, conforme exemplo abaixo)
                                        </small></strong>
                                </div>
    
                                <div id="dados2">
                                    <div class="row default-table-height" style="height: 26px">
                                        <div class="col col-sm-6">
                                            <span>Nome do produto</span>
                                        </div>
                                        <div class="col col-sm-6">
                                            <span>Subnomes relacionados ao produto</span>
                                        </div>
                                    </div>
    
                                    <div class="row default-table-height">
                                        <div class="col col-sm-6">
                                            <input class="form-control" id="nome" style="width: 100%" type="text"
                                                maxlength="55" placeholder="Ex: Trio Nicho Redondo, Nicho Bebê"></input>
                                        </div>
                                        <div class="col col-sm-6">
                                            <input class="form-control" id="subnome" style="width: 100%" type="text"
                                                maxlength="55" placeholder="Ex: Quarto de Bebê, Com Led"></input>
                                        </div>
                                    </div>
    
                                    <div class="row default-table-height" style="height: 26px">
                                        <div class="col col-sm-6">
                                            <span>Vantagens do produto</span>
                                        </div>
                                        <div class="col col-sm-6">
                                            <span>Quebra de objeção</span>
                                        </div>
                                    </div>
    
    
    
                                    <div class="row default-table-height">
                                        <div class="col col-sm-6">
                                            <input class="form-control" id="vantagem" style="width: 100%" type="text"
                                                maxlength="55" placeholder="Ex: Pintado, Branco, Kit C/ 3"></input>
                                        </div>
                                        <div class="col col-sm-6">
                                            <input class="form-control" id="objecao" style="width: 100%" type="text"
                                                maxlength="55" placeholder="Ex: Pronta Entrega, Envio Imediato"></input>
                                        </div>
                                    </div>
    
                                    <div class="row default-table-height">
                                        <div class="col col-sm-12">
                                            <button id="criar">Criar Titulos</button>
                                        </div>
                                    </div>
    
                                </div>
      
                            </div>
                        </div>
    
     
                        <div style="width: 50%" class="container" style="background-color: #ededed;">
     
                            <div class="row-calculadora" style="height: 56%; margin-bottom: 10px">
                                <div class="card" style="width: 465px;">
                                    <div class="card-body" style="width: 465px">
                                        <h5 class="card-title ml-blue-font">Tarifas e Custos da Venda</h5>
                                        <div class="container">
                                            <div class="row default-table-height">
                                                <div class="col col-sm-6">
                                                    <p class="card-text card-content"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                                                            viewBox="0 0 24 24">
                                                            <path
                                                                d="M24 3.875l-6 1.221 1.716 1.708-5.351 5.358-3.001-3.002-7.336 7.242 1.41 1.418 5.922-5.834 2.991 2.993 6.781-6.762 1.667 1.66 1.201-6.002zm0 16.125v2h-24v-20h2v18h22z" />
                                                        </svg> Comiss&atilde;o ML</p>
                                                </div>
                                                <div class="col col-sm-6">
                                                ${ULTRA ?
                                                   `<select name="comissao" id="comissao">
                                                        <option value="premium">Premium</option>
                                                        <option value="classico">Classico</option>
                                                    </select>`
                                                    :
                                                    `` }
                                                    <label id="comissaovlr"></label>
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-6">
                                                    <p class="card-text card-content">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-truck" viewBox="0 0 18 18">
                                                            <path
                                                                d="M0 3.5A1.5 1.5 0 0 1 1.5 2h9A1.5 1.5 0 0 1 12 3.5V5h1.02a1.5 1.5 0 0 1 1.17.563l1.481 1.85a1.5 1.5 0 0 1 .329.938V10.5a1.5 1.5 0 0 1-1.5 1.5H14a2 2 0 1 1-4 0H5a2 2 0 1 1-3.998-.085A1.5 1.5 0 0 1 0 10.5v-7zm1.294 7.456A1.999 1.999 0 0 1 4.732 11h5.536a2.01 2.01 0 0 1 .732-.732V3.5a.5.5 0 0 0-.5-.5h-9a.5.5 0 0 0-.5.5v7a.5.5 0 0 0 .294.456zM12 10a2 2 0 0 1 1.732 1h.768a.5.5 0 0 0 .5-.5V8.35a.5.5 0 0 0-.11-.312l-1.48-1.85A.5.5 0 0 0 13.02 6H12v4zm-9 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm9 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
                                                        </svg> Outros Custos ML <strong>*</strong>
                                                    </p>
                                                </div>
                                                <div class="col col-sm-6">
                                                    <input class="form-control" id="custoenvio" data-index="1" tabindex="1">
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-6">
                                                    <p class="card-text card-content"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-percent" viewBox="0 0 18 18">
                                                            <path
                                                                d="M13.442 2.558a.625.625 0 0 1 0 .884l-10 10a.625.625 0 1 1-.884-.884l10-10a.625.625 0 0 1 .884 0zM4.5 6a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 1a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm7 6a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 1a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />
                                                        </svg> Alíquota de Impostos %</p>
                                                </div>
                                                <div class="col col-sm-6">
                                                    <input class="form-control" id="imposto" data-index="2" tabindex="2">
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-6">
                                                    <p class="card-text card-content"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-basket2" viewBox="0 0 18 18">
                                                            <path
                                                                d="M4 10a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0v-2zm3 0a1 1 0 0 1 2 0v2a1 1 0 0 1-2 0v-2zm3 0a1 1 0 1 1 2 0v2a1 1 0 0 1-2 0v-2z" />
                                                            <path
                                                                d="M5.757 1.071a.5.5 0 0 1 .172.686L3.383 6h9.234L10.07 1.757a.5.5 0 1 1 .858-.514L13.783 6H15.5a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-.623l-1.844 6.456a.75.75 0 0 1-.722.544H3.69a.75.75 0 0 1-.722-.544L1.123 8H.5a.5.5 0 0 1-.5-.5v-1A.5.5 0 0 1 .5 6h1.717L5.07 1.243a.5.5 0 0 1 .686-.172zM2.163 8l1.714 6h8.246l1.714-6H2.163z" />
                                                        </svg> Custo do Produto</p>
                                                </div>
                                                <div class="col col-sm-6">
                                                    <input class="form-control" id="custototal" data-index="3" tabindex="3">
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-6">
                                                    <p class="card-text card-content-vermelho">
                                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-cash" viewBox="0 0 18 18">
                                                            <path d="M8 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" />
                                                            <path
                                                                d="M0 4a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4zm3 0a2 2 0 0 1-2 2v4a2 2 0 0 1 2 2h10a2 2 0 0 1 2-2V6a2 2 0 0 1-2-2H3z" />
                                                        </svg> Custo Total
                                                    </p>
                                                </div>
                                                <div class="col col-sm-6">
                                                    <label id="custofinal"></label>
                                                </div>
                                            </div>
                                            <div class="row defaultsmall-table-height" style="margin-top: -15px;">
                                                <div class="col col-sm-12">
                                                    <center><small style="font-size: 12px" class="obs">* Frete Grátis Acima
                                                            de R$
                                                            79,00
                                                            ou R$ 6,00 Fixo por Anúncio Abaixo de R$ 79,00</small></center>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row-calculadora" style="height: 38%;">
                                <div class="card" style="width: 465px;">
                                    <div class="card-body" style="width: 465px">
                                        <h5 class="card-title ml-blue-font">Precifica&ccedil;&atilde;o da Venda</h5>
                                        <div class="container">
                                            <div class="row default-table-height">
                                                <div class="col col-sm-7">
                                                    <p class="card-text card-content align-middle"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="19"
                                                            viewBox="0 0 24 24">
                                                            <path
                                                                d="M24 3.875l-6 1.221 1.716 1.708-5.351 5.358-3.001-3.002-7.336 7.242 1.41 1.418 5.922-5.834 2.991 2.993 6.781-6.762 1.667 1.66 1.201-6.002zm0 16.125v2h-24v-20h2v18h22z" />
                                                        </svg> Pre&ccedil;o de Venda</p>
                                                </div>
                                                <div class="col col-sm-5">
                                                    <input class="form-control" id="preco" data-index="4" tabindex="4">
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-7">
                                                    <p class="card-text card-content"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-percent" viewBox="0 0 18 18">
                                                            <path
                                                                d="M13.442 2.558a.625.625 0 0 1 0 .884l-10 10a.625.625 0 1 1-.884-.884l10-10a.625.625 0 0 1 .884 0zM4.5 6a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 1a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5zm7 6a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm0 1a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5z" />
                                                        </svg> Margem de Contribuição %</p>
                                                </div>
                                                <div class="col col-sm-5">
                                                    <label class="col col-sm-12" id="margem"></label>
                                                </div>
                                            </div>
                                            <div class="row default-table-height">
                                                <div class="col col-sm-7">
                                                    <p class="card-text card-content-verde"><svg
                                                            xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                                            fill="currentColor" class="bi bi-cash-coin" viewBox="0 0 18 18">
                                                            <path fill-rule="evenodd"
                                                                d="M11 15a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm5-4a5 5 0 1 1-10 0 5 5 0 0 1 10 0z" />
                                                            <path
                                                                d="M9.438 11.944c.047.596.518 1.06 1.363 1.116v.44h.375v-.443c.875-.061 1.386-.529 1.386-1.207 0-.618-.39-.936-1.09-1.1l-.296-.07v-1.2c.376.043.614.248.671.532h.658c-.047-.575-.54-1.024-1.329-1.073V8.5h-.375v.45c-.747.073-1.255.522-1.255 1.158 0 .562.378.92 1.007 1.066l.248.061v1.272c-.384-.058-.639-.27-.696-.563h-.668zm1.36-1.354c-.369-.085-.569-.26-.569-.522 0-.294.216-.514.572-.578v1.1h-.003zm.432.746c.449.104.655.272.655.569 0 .339-.257.571-.709.614v-1.195l.054.012z" />
                                                            <path
                                                                d="M1 0a1 1 0 0 0-1 1v8a1 1 0 0 0 1 1h4.083c.058-.344.145-.678.258-1H3a2 2 0 0 0-2-2V3a2 2 0 0 0 2-2h10a2 2 0 0 0 2 2v3.528c.38.34.717.728 1 1.154V1a1 1 0 0 0-1-1H1z" />
                                                            <path
                                                                d="M9.998 5.083 10 5a2 2 0 1 0-3.132 1.65 5.982 5.982 0 0 1 3.13-1.567z" />
                                                        </svg>Margem de Contribuição $</p>
                                                </div>
                                                <div class="col col-sm-5">
                                                    <label class="col col-sm-12" id="lucro"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
    
                        </div>
    
                    </div>
    
    
                    <div class="content">
                        <div style="width: 100%; padding: 0px 15px; margin-bottom: 15px">
                            <div
                                style="border-top: 2px solid #3498d8; background-color: #fff; height: 85px; width: 100%; padding: 1px 10px; border-radius: 4px; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 12%);">
                                <center>
                                    <small id="beta">Qualquer problema com esse recurso reportar para:
                                        <strong>mlpro@ramsolution.com.br</strong>
                                    </small>
                                </center>
                                <p style="margin-bottom: 5px; font-size: 14px">Esse recurso te permite monitorar até ${ULTRA ? '50' : '10'}
                                    anúncios
                                    durante 7 dias. Os dados são atualizados todo dia de madrugada. Caso deseje
                                    acompanhar
                                    esse anúncio, basta clicar no botão abaixo:
                                </p>
                                <center>
                                    <p style="display: none" id="txtAcompanhar"></p>
                                    <button style="display: none" id="btnAcompanharLoading">Adicionando Anúncio...
                                        Aguarde</button>
                                    <button id="btnAcompanhar"><img style="vertical-align: top;"
                                            src="https://img.icons8.com/ios-glyphs/20/ffffff/pin.png" /> Acompanhar
                                        Anúncio</button>
                                </center>
                            </div>

                        
                            <div style="display: flex; justify-content: center; width: 100%; background: #ffa830; margin: 10px 0px; padding: 5px 10px; color: white; border-radius: 5px;">
                            &#128680; &#128680; &#128680; Atenção, devido as alterações do Mercado Livre em não informar o número exato das vendas dos anúncios nós estamos calculando as métricas do rastreio com base no número de estoque. Esse calculo esta em fase de testes, pedimos a compreensão de todos. Qualquer problema podem reportar para: mlpro@ramsolution.com.br
                            </div>
    
                            <div style="justify-content: center; display: flex;">
                                <button id="refazertodosanuncios" class="refazertodosanuncios"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png"
                                        style="margin-right: 3px;">Refazer Todos os Rastreios
                                </button>
                                <button id="removertodosanuncios" class="removertodosanuncios"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png"
                                        style="margin-right: 3px;">Remover Todos os Rastreios
                                </button>
                                <button id="excelAnunciosTodos" class="excelAnunciosTodos"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/color/28/000000/ms-excel.png"
                                        style="margin-right: 3px;">Baixar Todos os Rastreios
                                </button>
                            </div>
    
    
    
                            <div style="margin-bottom: 15px;" id="AnuncioContent">
                                <center>
                                    <iframe style="margin-top: 30px"
                                        src="https://c.tenor.com/I6kN-6X7nhAAAAAj/loading-buffering.gif" width="200"
                                        height="200" frameBorder="0" class="giphy-embed"></iframe>
                                    <p><strong>Carregando dados Avantpro...</strong></p>
                                </center>
                            </div>
    
                            <table style="margin-bottom: 15px; display: none;" id="TabelaOcultaAnuncios">
                            </table>
    
                        </div>
                    </div>
    
    
                    <div class="content">
                        <div style="width: 100%; padding: 0px 15px;">
                            <div
                                style="border-top: 2px solid #3498d8; background-color: #fff; height: 85px; width: 100%; padding: 1px 10px; border-radius: 4px; border: 1px solid #ddd; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 12%);">
                                <center><small id="beta">Qualquer problema com esse recurso reportar para:
                                        <strong>mlpro@ramsolution.com.br</strong> | * Vendas Dia: valor aproximado conforme
                                        dados fornecidos pela api do ML</small></center>
                                <p style="margin-bottom: 5px; font-size: 14px" id="sellerTitulo"></p>
                                <center style="margin-top: -20px;">
                                    <p style="display: none;" id="txtAcompanharConcorrente"></p>
                                    <button style="display: none" id="btnAcompanharConcorrenteLoading">Adicionando
                                        Concorrente... Aguarde</button>
                                    <button class="rastrearConcorrente" id="btnAcompanharConcorrente"> <img style="vertical-align: top;"
                                            src="https://img.icons8.com/ios-glyphs/20/ffffff/pin.png" /> Acompanhar
                                        Concorrente Desse Anúncio</button>
                                </center>
                            </div>
    
    
                            <div style="justify-content: center; display: flex;">
                                <button id="refazertodosconcorrentes" class="refazertodosconcorrentes"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png"
                                        style="margin-right: 3px;">Refazer Todos os Rastreios
                                </button>
                                <button id="removertodosconcorrentes" class="removertodosconcorrentes"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png"
                                        style="margin-right: 3px;">Remover Todos os Rastreios
                                </button>
                                <button id="excelConcorrentesTodos" class="excelConcorrentesTodos"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/color/28/000000/ms-excel.png"
                                        style="margin-right: 3px;">Baixar Todos os Rastreios
                                </button>
                            </div>
    
    
                            <div style="margin-bottom: 15px;" id="AnuncioContentConcorente">
                                <center>
                                    <iframe style="margin-top: 30px"
                                        src="https://c.tenor.com/I6kN-6X7nhAAAAAj/loading-buffering.gif" width="200"
                                        height="200" frameBorder="0" class="giphy-embed"></iframe>
                                    <p><strong>Carregando dados Avantpro...</strong></p>
                                </center>
                            </div>
    
    
                            <table style="margin-bottom: 15px; display: none;" id="TabelaOcultaConcorrentes">
                            </table>
    
    
                        </div>
                    </div>

                    <div class="content">
                        <div style="width: 100%; padding: 0px 15px; margin-bottom: 15px">
                            <div
                                style="border-top: 2px solid #3498d8; background-color: #fff; height: 104px; width: 100%; padding: 1px 10px; border-radius: 4px; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 12%);">
                                <center>
                                    <small id="beta">Qualquer problema com esse recurso reportar para:
                                        <strong>mlpro@ramsolution.com.br</strong>
                                    </small>
                                </center>
                                <p style="margin-bottom: 5px; font-size: 14px;text-align: center;">Esse recurso te permite monitorar até 4 concorrentes e saber os anúncios que ele criou durante 7 dias. 
                                Os dados são atualizados todo dia de madrugada. 
                                Caso deseje acompanhar esse anúncio, basta clicar no botão abaixo:
                                </p>
                                <center>
                                    <p style="display: none" id="txtAcompanharCriado"></p>
                                    <button style="display: none" id="btnAcompanharCriadoLoading">Adicionando Concorrente ...
                                        Aguarde</button>
                                    ${ULTRA ? `<button id="btnAcompanharCriado"><img style="vertical-align: top;"
                                    src="https://img.icons8.com/ios-glyphs/20/ffffff/pin.png" /> 
                                    Acompanhar Criados desse Concorrente
                                </button>` : `<button onclick="alert('Recurso disponível na versão Ultra, assine já em www.avantpro.com.br')" id="btnAcompanharCriadoPremium"><img style="vertical-align: top; "
                                src="https://img.icons8.com/ios-glyphs/20/ffffff/pin.png" /> 
                                Acompanhar Criados desse Concorrente
                            </button>`}
                                </center>
                            </div>
    
                            <div style="justify-content: center; display: flex;">
                                <button id="refazertodoscriado" class="refazertodoscriado"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png"
                                        style="margin-right: 3px;">Refazer Todos os Rastreios
                                </button>
                                <button id="removertodoscriado" class="removertodoscriado"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png"
                                        style="margin-right: 3px;">Remover Todos os Rastreios
                                </button>
                                ${ULTRA ? ``: `<button style="margin-top: 7px;" class="botaoUltraMenu" onclick="javascript:window.open('https://avantpro.com.br/ml/', '_blank');"> 📢 Recurso disponível na versão Ultra, clique aqui e saiba mais!  📢</button>`}
                                <button id="excelcriadoTodos" class="excelcriadoTodos"
                                    style="background: white; border: lightgray 1px solid; border-radius: 10px; margin: 5px 20px -5px 5px; width: 280px;">
                                    <img src="https://img.icons8.com/color/28/000000/ms-excel.png"
                                        style="margin-right: 3px;">Baixar Todos os Rastreios
                                </button>
                            </div>
    
    
    
                            ${ULTRA ? `
                            <div style="margin-bottom: 15px;display: flex;margin-top: 20px;" id="AnuncioCriado">
                                <center style="position: relative;left: 42.7%;">
                                    <iframe style="margin-top: 30px display: flex"
                                     src="https://c.tenor.com/I6kN-6X7nhAAAAAj/loading-buffering.gif" width="200"
                                     height="200" frameBorder="0" class="giphy-embed"></iframe>
                                    <p><strong>Carregando dados Avantpro...</strong></p>
                                 </center>
                            </div>` 
                            :
                            `<div style="margin-bottom: 15px;display: flex;justify-content: center;margin-top: 20px;" id="AnuncioCriadoPremium"><div id="blocoAnuncioCriados1" style="
                            background-color: #fff;
                            margin-top: 10px;
                            margin-left: 2px;
                            margin-right: 2px;
                            height: 50%;
                            width: 25%;
                            border-top: 2px solid #3498d8;
                            border-radius: 4px;
                            box-shadow:0 1px 2px 0 rgb(0 0 0 / 12%);
                        ">
                                
                            <div class="HeaderCriado">
                            
                                <div>
                                    <p style="text-align: center;margin: 10px 0 0 0;">Vendedor 1</p>
                                </div>
                                
                                
                                <div class="groupButtons" style=" display: flex;margin-left: auto;justify-content: center;flex-direction: row;margin-top: 5px;margin-bottom: 15px;">
                                
                                    
                                    <button id="excelCriado1" disabled value="tabVendedor1" style="display: none; height: 33.3%; background: none; border: none;">
                                        <center>
                                        <img src="https://img.icons8.com/color/28/000000/ms-excel.png">
                                        <center>
                                    </center></center></button>
                                    
                                    
                                    <div id="btnRefazerCriar1" disabled style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png">
                                        </center>
                                    </div>
                                    
                                    <div id="btnPararCriar1" disabled style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png">
                                        </center>
                                    </div>
                                
                                </div>
                            </div>				
                        
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">12/01/2023 - 8 Anúncio(s)</p>
                                                    
                                        <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                            <div>
                                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                            </div>
                                            <div>
                                                <a href="https://www.avantpro.com.br/" target="_blank" style="margin-left: 5px;">Produto 1</a>
                                                <div style="display: flex;flex-direction: column;">
                                                    <p style="
                                                    margin-left: 5px;
                                                    margin-bottom: 0px;
                                                    ">Marca: Marca X</p>
                                                    <p style="
                                                    margin-left: 5px;
                                                    ">Preço: R$&nbsp;199,99</p>									
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                            <div>
                                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                            </div>
                                            <div>
                                                <a href="https://www.avantpro.com.br/" target="_blank" style="margin-left: 5px;">Produto 2</a>
                                                <div style="display: flex;flex-direction: column;">
                                                    <p style="
                                                    margin-left: 5px;
                                                    margin-bottom: 0px;
                                                    ">Marca: Marca X</p>
                                                    <p style="
                                                    margin-left: 5px;
                                                    ">Preço: R$&nbsp;199,99</p>									
                                                </div>
                                            </div>
                                        </div>
                                        
                                                                        
                                                                        <div id="hideData-CAMICADO MAXMIX-0" style="display: none;">
                                                                        <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                                        <div>
                                                                            <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                                        </div>
                                                                        <div>
                                                                            <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 3</a>
                                                                            <div style="display: flex;flex-direction: column;">
                                                                                <p style="
                                                                                margin-left: 5px;
                                                                                margin-bottom: 0px;
                                                                                ">Marca: Marca X</p>
                                                                                <p style="
                                                                                margin-left: 5px;
                                                                                ">Preço: R$&nbsp;199,99</p>									
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                                
                                                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                                    <div>
                                                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                                    </div>
                                                                    <div>
                                                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 4</a>
                                                                        <div style="display: flex;flex-direction: column;">
                                                                            <p style="
                                                                            margin-left: 5px;
                                                                            margin-bottom: 0px;
                                                                            ">Marca: Marca X</p>
                                                                            <p style="
                                                                            margin-left: 5px;
                                                                            ">Preço: R$&nbsp;199,99</p>									
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                                
                                                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                                <div>
                                                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                                </div>
                                                                <div>
                                                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 5</a>
                                                                    <div style="display: flex;flex-direction: column;">
                                                                        <p style="
                                                                        margin-left: 5px;
                                                                        margin-bottom: 0px;
                                                                        ">Marca: Marca X</p>
                                                                        <p style="
                                                                        margin-left: 5px;
                                                                        ">Preço: R$&nbsp;199,99</p>									
                                                                    </div>
                                                                </div>
                                                            </div>
                                                                                
                                                            <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                            <div>
                                                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                            </div>
                                                            <div>
                                                                <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 6</a>
                                                                <div style="display: flex;flex-direction: column;">
                                                                    <p style="
                                                                    margin-left: 5px;
                                                                    margin-bottom: 0px;
                                                                    ">Marca: Marca X</p>
                                                                    <p style="
                                                                    margin-left: 5px;
                                                                    ">Preço: R$&nbsp;199,99</p>									
                                                                </div>
                                                            </div>
                                                        </div>
                                                                                
                                                        <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                        <div>
                                                            <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                        </div>
                                                        <div>
                                                            <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 7</a>
                                                            <div style="display: flex;flex-direction: column;">
                                                                <p style="
                                                                margin-left: 5px;
                                                                margin-bottom: 0px;
                                                                ">Marca: Marca X</p>
                                                                <p style="
                                                                margin-left: 5px;
                                                                ">Preço: R$&nbsp;199,99</p>									
                                                            </div>
                                                        </div>
                                                    </div>
                                                                                
                                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                    <div>
                                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                    </div>
                                                    <div>
                                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 8</a>
                                                        <div style="display: flex;flex-direction: column;">
                                                            <p style="
                                                            margin-left: 5px;
                                                            margin-bottom: 0px;
                                                            ">Marca: Marca X</p>
                                                            <p style="
                                                            margin-left: 5px;
                                                            ">Preço: R$&nbsp;199,99</p>									
                                                        </div>
                                                    </div>
                                                </div>
                                        </div>
                                
                                <button id="BtnHide-CAMICADO MAXMIX-0" onclick="DataToggle('hideData-CAMICADO MAXMIX-0','BtnHide-CAMICADO MAXMIX-0')" style="					
                                    width: 100%;
                                    background: #FFF159;
                                    border: 1px solid #FFA200;
                                    justify-content: center;
                                    align-items: center;
                                    display: inline-flex;				
                                "> 
                                Mostrar Mais
                                <img style="padding-left: 5px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAAYUlEQVQokd3MMQ5AQBRF0TNsxS5EYYk6y1JYh4LoNTOJiEyGjtf85L93L59Og1C4DXEPaiwYCgQh7hZU6dlixZgRJHBHfy1zgiyYExSBd4LqCZjSYcMUb1cKngXzG/DPOQDq1BYG8QcmggAAAABJRU5ErkJggg==">
                                </button>
                                
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">13/01/2023 - 4 Anúncio(s)</p>
                                                    
                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                    <div>
                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                    </div>
                                    <div>
                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 1</a>
                                        <div style="display: flex;flex-direction: column;">
                                            <p style="
                                            margin-left: 5px;
                                            margin-bottom: 0px;
                                            ">Marca: Marca X</p>
                                            <p style="
                                            margin-left: 5px;
                                            ">Preço: R$&nbsp;199,99</p>									
                                        </div>
                                    </div>
                                </div>
                                        
                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                <div>
                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                </div>
                                <div>
                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 2</a>
                                    <div style="display: flex;flex-direction: column;">
                                        <p style="
                                        margin-left: 5px;
                                        margin-bottom: 0px;
                                        ">Marca: Marca X</p>
                                        <p style="
                                        margin-left: 5px;
                                        ">Preço: R$&nbsp;199,99</p>									
                                    </div>
                                </div>
                            </div>
                                        
                                
                                <div id="hideData-CAMICADO MAXMIX-1" style="display: none;">
                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                <div>
                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                </div>
                                <div>
                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 3</a>
                                    <div style="display: flex;flex-direction: column;">
                                        <p style="
                                        margin-left: 5px;
                                        margin-bottom: 0px;
                                        ">Marca: Marca X</p>
                                        <p style="
                                        margin-left: 5px;
                                        ">Preço: R$&nbsp;199,99</p>									
                                    </div>
                                </div>
                            </div>
                                        
                            <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                            <div>
                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                            </div>
                            <div>
                                <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 4</a>
                                <div style="display: flex;flex-direction: column;">
                                    <p style="
                                    margin-left: 5px;
                                    margin-bottom: 0px;
                                    ">Marca: Marca X</p>
                                    <p style="
                                    margin-left: 5px;
                                    ">Preço: R$&nbsp;199,99</p>									
                                </div>
                            </div>
                        </div>
                                        </div>
                                
                                <button id="BtnHide-CAMICADO MAXMIX-1" onclick="DataToggle('hideData-CAMICADO MAXMIX-1','BtnHide-CAMICADO MAXMIX-1')" style="					
                                    width: 100%;
                                    background: #FFF159;
                                    border: 1px solid #FFA200;
                                    justify-content: center;
                                    align-items: center;
                                    display: inline-flex;				
                                "> 
                                Mostrar Mais
                                <img style="padding-left: 5px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAAYUlEQVQokd3MMQ5AQBRF0TNsxS5EYYk6y1JYh4LoNTOJiEyGjtf85L93L59Og1C4DXEPaiwYCgQh7hZU6dlixZgRJHBHfy1zgiyYExSBd4LqCZjSYcMUb1cKngXzG/DPOQDq1BYG8QcmggAAAABJRU5ErkJggg==">
                                </button>
                                
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">14/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">15/01/2023 - 1 Anúncio(s)</p>
                                                    
                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                    <div>
                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                    </div>
                                    <div>
                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 1</a>
                                        <div style="display: flex;flex-direction: column;">
                                            <p style="
                                            margin-left: 5px;
                                            margin-bottom: 0px;
                                            ">Marca: Marca X</p>
                                            <p style="
                                            margin-left: 5px;
                                            ">Preço: R$&nbsp;199,99</p>									
                                        </div>
                                    </div>
                                </div>
                                        
                                
                                <div id="hideData-CAMICADO MAXMIX-3" style="display: none;"></div>
                                
                                
                                
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">16/01/2023 - 1 Anúncio(s)</p>
                                                    
                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                    <div>
                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                    </div>
                                    <div>
                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 1</a>
                                        <div style="display: flex;flex-direction: column;">
                                            <p style="
                                            margin-left: 5px;
                                            margin-bottom: 0px;
                                            ">Marca: Marca X</p>
                                            <p style="
                                            margin-left: 5px;
                                            ">Preço: R$&nbsp;199,99</p>									
                                        </div>
                                    </div>
                                </div>
                                        
                                
                                <div id="hideData-CAMICADO MAXMIX-4" style="display: none;"></div>
                                
                                
                                
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">17/01/2023 - 3 Anúncio(s)</p>
                                                    
                                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                                <div>
                                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                                </div>
                                                <div>
                                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 1</a>
                                                    <div style="display: flex;flex-direction: column;">
                                                        <p style="
                                                        margin-left: 5px;
                                                        margin-bottom: 0px;
                                                        ">Marca: Marca X</p>
                                                        <p style="
                                                        margin-left: 5px;
                                                        ">Preço: R$&nbsp;199,99</p>									
                                                    </div>
                                                </div>
                                            </div>
                                                    
                                            <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                            <div>
                                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                            </div>
                                            <div>
                                                <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 2</a>
                                                <div style="display: flex;flex-direction: column;">
                                                    <p style="
                                                    margin-left: 5px;
                                                    margin-bottom: 0px;
                                                    ">Marca: Marca X</p>
                                                    <p style="
                                                    margin-left: 5px;
                                                    ">Preço: R$&nbsp;199,99</p>									
                                                </div>
                                            </div>
                                        </div>
                                        
                                
                                <div id="hideData-CAMICADO MAXMIX-5" style="display: none;">
                                            <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                            <div>
                                                <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                            </div>
                                            <div>
                                                <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 3</a>
                                                <div style="display: flex;flex-direction: column;">
                                                    <p style="
                                                    margin-left: 5px;
                                                    margin-bottom: 0px;
                                                    ">Marca: Marca X</p>
                                                    <p style="
                                                    margin-left: 5px;
                                                    ">Preço: R$&nbsp;199,99</p>									
                                                </div>
                                            </div>
                                        </div>
                                        </div>
                                
                                <button id="BtnHide-CAMICADO MAXMIX-5" onclick="DataToggle('hideData-CAMICADO MAXMIX-5','BtnHide-CAMICADO MAXMIX-5')" style="					
                                    width: 100%;
                                    background: #FFF159;
                                    border: 1px solid #FFA200;
                                    justify-content: center;
                                    align-items: center;
                                    display: inline-flex;				
                                "> 
                                Mostrar Mais
                                <img style="padding-left: 5px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAAYUlEQVQokd3MMQ5AQBRF0TNsxS5EYYk6y1JYh4LoNTOJiEyGjtf85L93L59Og1C4DXEPaiwYCgQh7hZU6dlixZgRJHBHfy1zgiyYExSBd4LqCZjSYcMUb1cKngXzG/DPOQDq1BYG8QcmggAAAABJRU5ErkJggg==">
                                </button>
                                
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">18/01/2023 - 3 Anúncio(s)</p>
                                                    
                                    <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                    <div>
                                        <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                    </div>
                                    <div>
                                        <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 1</a>
                                        <div style="display: flex;flex-direction: column;">
                                            <p style="
                                            margin-left: 5px;
                                            margin-bottom: 0px;
                                            ">Marca: Marca X</p>
                                            <p style="
                                            margin-left: 5px;
                                            ">Preço: R$&nbsp;199,99</p>									
                                        </div>
                                    </div>
                                </div>
                                        
                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                <div>
                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                </div>
                                <div>
                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 2</a>
                                    <div style="display: flex;flex-direction: column;">
                                        <p style="
                                        margin-left: 5px;
                                        margin-bottom: 0px;
                                        ">Marca: Marca X</p>
                                        <p style="
                                        margin-left: 5px;
                                        ">Preço: R$&nbsp;199,99</p>									
                                    </div>
                                </div>
                            </div>
                                        
                                
                                <div id="hideData-CAMICADO MAXMIX-6" style="display: none;">
                                <div class="infoProduto" style="display: flex;margin: -7px 5px 0px 5px;padding: 8px 0px;border-top: 1px solid #dddddd;">
                                <div>
                                    <img style="border-radius: 100%;width: 60px;border: 2px solid gray;margin: 10px 5px;" src="https://http2.mlstatic.com/resources/frontend/statics/img-not-available/1.1.0/W.webp">
                                </div>
                                <div>
                                    <a href="https://www.avantpro.com.br/"  target="_blank" style="margin-left: 5px;">Produto 3</a>
                                    <div style="display: flex;flex-direction: column;">
                                        <p style="
                                        margin-left: 5px;
                                        margin-bottom: 0px;
                                        ">Marca: Marca X</p>
                                        <p style="
                                        margin-left: 5px;
                                        ">Preço: R$&nbsp;199,99</p>									
                                    </div>
                                </div>
                            </div>
                                        </div>
                                
                                <button id="BtnHide-CAMICADO MAXMIX-6" onclick="DataToggle('hideData-CAMICADO MAXMIX-6','BtnHide-CAMICADO MAXMIX-6')" style="					
                                    width: 100%;
                                    background: #FFF159;
                                    border: 1px solid #FFA200;
                                    justify-content: center;
                                    align-items: center;
                                    display: inline-flex;				
                                "> 
                                Mostrar Mais
                                <img style="padding-left: 5px;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAABmJLR0QA/wD/AP+gvaeTAAAAYUlEQVQokd3MMQ5AQBRF0TNsxS5EYYk6y1JYh4LoNTOJiEyGjtf85L93L59Og1C4DXEPaiwYCgQh7hZU6dlixZgRJHBHfy1zgiyYExSBd4LqCZjSYcMUb1cKngXzG/DPOQDq1BYG8QcmggAAAABJRU5ErkJggg==">
                                </button>
                                
                                </div></div><div id="blocoAnuncioCriados2" style="
                            background-color: #fff;
                            margin-top: 10px;
                            margin-left: 2px;
                            margin-right: 2px;
                            height: 50%;
                            width: 25%;
                            border-top: 2px solid #3498d8;
                            border-radius: 4px;
                            box-shadow:0 1px 2px 0 rgb(0 0 0 / 12%);
                        ">
                                
                            <div class="HeaderCriado">
                            
                                <div>
                                    <p style="text-align: center;margin: 10px 0 0 0;">Vendedor 2</p>
                                </div>
                                
                                
                                <div class="groupButtons" style=" display: flex;margin-left: auto;justify-content: center;flex-direction: row;margin-top: 5px;margin-bottom: 15px;">
                                
                                    
                                    <button id="excelCriado2" value="tabVendedor1" style="display: none; height: 33.3%; background: none; border: none;">
                                        <center>
                                        <img src="https://img.icons8.com/color/28/000000/ms-excel.png">
                                        <center>
                                    </center></center></button>
                                    
                                    
                                    <div id="btnRefazerCriar2" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png">
                                        </center>
                                    </div>
                                    
                                    <div id="btnPararCriar2" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png">
                                        </center>
                                    </div>
                                
                                </div>
                            </div>				
                        
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">12/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">13/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">14/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">15/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">16/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">17/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">18/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div></div><div id="blocoAnuncioCriados3" style="
                            background-color: #fff;
                            margin-top: 10px;
                            margin-left: 2px;
                            margin-right: 2px;
                            height: 50%;
                            width: 25%;
                            border-top: 2px solid #3498d8;
                            border-radius: 4px;
                            box-shadow:0 1px 2px 0 rgb(0 0 0 / 12%);
                        ">
                                
                            <div class="HeaderCriado">
                            
                                <div>
                                    <p style="text-align: center;margin: 10px 0 0 0;">Vendedor 3</p>
                                </div>
                                
                                
                                <div class="groupButtons" style=" display: flex;margin-left: auto;justify-content: center;flex-direction: row;margin-top: 5px;margin-bottom: 15px;">
                                
                                    
                                    <button id="excelCriado3" value="tabVendedor1" style="display: none; height: 33.3%; background: none; border: none;">
                                        <center>
                                        <img src="https://img.icons8.com/color/28/000000/ms-excel.png">
                                        <center>
                                    </center></center></button>
                                    
                                    
                                    <div id="btnRefazerCriar3" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png">
                                        </center>
                                    </div>
                                    
                                    <div id="btnPararCriar3" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png">
                                        </center>
                                    </div>
                                
                                </div>
                            </div>				
                        
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">12/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">13/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">14/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">15/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">16/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">17/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">18/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div></div><div id="blocoAnuncioCriados4" style="
                            background-color: #fff;
                            margin-top: 10px;
                            margin-left: 2px;
                            margin-right: 2px;
                            height: 50%;
                            width: 25%;
                            border-top: 2px solid #3498d8;
                            border-radius: 4px;
                            box-shadow:0 1px 2px 0 rgb(0 0 0 / 12%);
                        ">
                                
                            <div class="HeaderCriado">
                            
                                <div>  
                                    <p style="text-align: center;margin: 10px 0 0 0;">Vendedor 4</p>    
                                </div>
                                
                                
                                <div class="groupButtons" style=" display: flex;margin-left: auto;justify-content: center;flex-direction: row;margin-top: 5px;margin-bottom: 15px;">
                                
                                    
                                    <button id="excelCriado4" value="tabVendedor1" style="display: none; height: 33.3%; background: none; border: none;">
                                        <center>
                                        <img src="https://img.icons8.com/color/28/000000/ms-excel.png">
                                        <center>
                                    </center></center></button>
                                    
                                    
                                    <div id="btnRefazerCriar4" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/4a90e2/restart.png">
                                        </center>
                                    </div>
                                    
                                    <div id="btnPararCriar4" style="height: 33.3%; cursor: pointer;">
                                        <center>
                                        <img src="https://img.icons8.com/glyph-neue/28/fa314a/delete-trash.png">
                                        </center>
                                    </div>
                                
                                </div>
                            </div>				
                        
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">24/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div>
                                <div class="DiaCriado" style="margin-top: 10px;">
                                    <p style="
                                    margin: -9px 0px 3px 0px;
                                    padding: 0 5px;
                                    text-align: center;
                                    background: #dddddd;
                                    border: 1px solid #bcb7b7;
                                    ">25/01/2023 - 0 Anúncio(s)</p>
                                                    
                                    <div style="display: flex;width: 100%;flex-direction: row;">
                                        <p style="
                                        text-align: center;
                                        width: 100%;
                                        margin: 10px;
                                        ">Sem Produto</p>
                                    </div>
                                </div></div></div>`}
                            
    
                            <table style="margin-bottom: 15px; display: none;" id="TabelaOcultaAnuncios">
                            </table>
    
                        </div>
                    </div>
    
                    ${ULTRA ? `` :
                    `<div class="content">
                          <div
                              style="border-top: 2px solid #3498d8; background-color: #fff; height: 500px; width: 100%; padding: 1px 10px; border-radius: 4px; border: 1px solid #ddd; box-shadow: 0 1px 2px 0 rgb(0 0 0 / 12%);">
                              <center>
                                  <p style="margin-top: 10px">Você sabia que agora o Avantpro conta com uma versão <span
                                          style="color: #3498d8; font-size: 18px; font-weight: bold;">Ultra</span> com ainda
                                      mais recursos e também uma versão para celular?</p>
                                  <p>&#128226; <a href="https://avantpro.com.br/ml/" target="_blank">Clique aqui para ficar
                                          por dentro dessa novidade!</a> &#128226;</p>
                                  <img style="width: 30%;" src="https://ramcloud.com.br/img/qrcodeframe.png"></img>
                              </center>
    
                          </div>
    
                      </div>
                      `
                    }
                
                </div>
        
            </div>
      
        </div>
          `;
        }

        body.appendChild(ModalRastreio);

        document.getElementById('fecharFrame').onclick = () => {
            document.getElementsByClassName('bodyRastreio')[0].style.display = 'none';

            var pValidate = document.getElementById('FremeCarregado');
            pValidate.remove();

            var ScriptFrame = document.getElementById('ScriptFrame');
            ScriptFrame.remove();

            var bodyRastreio = document.getElementsByClassName('bodyRastreio')[0];
            bodyRastreio.remove();


            var bootRemover = document.getElementsByClassName('bootRemover')[0];
            bootRemover.remove();

            RenderFrame.RastreioModal(ASSINANTE, ULTRA);
        }

        document.getElementById('fecharFrameLoading').onclick = () => {
            window.location.reload();
        }

        function ValidarFrame() {
            if (document.getElementsByClassName('bodyRastreio')[0].style.display == 'block' && document.getElementById('FremeCarregado') == undefined) {
                /** Bootstrap */
                var head = document.head;
                var bootstrap = document.createElement('link');
                bootstrap.className = 'bootRemover';
                bootstrap.setAttribute('href', 'https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css');
                bootstrap.setAttribute('rel', 'stylesheet');
                bootstrap.setAttribute('integrity', 'sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6');
                bootstrap.setAttribute('crossorigin', 'anonymous');
                head.appendChild(bootstrap);

                document.getElementsByClassName('bodyRastreio')[0].insertAdjacentHTML('beforebegin', '<p style="display:none;" id="FremeCarregado" ></p>');

                try {
                    chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {

                        var emailmlpro = await response.emailmlpro;
                        var tokenmlpro = await response.tokenmlpro;

                        document.body.insertAdjacentHTML('beforebegin', `
                            <p id="EmailFrame" style="display:none;">${emailmlpro}</p>
                            <p id="TokenFrame" style="display:none;">${tokenmlpro}</p>
                        `);

                        // MeliAPI.scriptBase2('https://ramcloud.com.br/scriptframe.js', 'ScriptFrame'); Produção
                        MeliAPI.scriptBase2('https://ramcloud.com.br/scriptframe-criado.js', 'ScriptFrame');

                    });
                } catch (error) {
                    window.location.reload();
                }
            }
        }

        var IntervarFrame = setInterval(ValidarFrame, 400);
    }

}