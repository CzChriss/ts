/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


class MeliAdapter {
  static items(itemList, rawItems) {
    let items = [];

    $.each(rawItems, function (index, dados) {
      let item = itemList.find(
        (item) => item.id === dados.id
      );


      if (dados.status == "under_review") {
        return;
      }

      if (!dados.price) {
        return;
      }


      let ean = dados.attributes.filter(item => String(item.id) == 'GTIN');
      let atributos = [];



      if (ean == '') {
        if (dados.variations) {
          for (let i = 0; i < dados.variations.length; i++) {
            atributos = dados.variations[i].attributes.filter(item => String(item.id) == 'GTIN');
            ean += atributos.length > 0 ? (atributos[0].value_name != null ? atributos[0].value_name + ',' : '') : '';
          }
        }
      } else {
        ean = ean[0].value_name;
      }

      if (ean == '') ean = 'Sem EAN'; 

      
      item.price = dados.price;
      item.title = dados.title;
      item.available_quantity = dados.available_quantity;
      item.seller_id = dados.seller_id;
      item.start_time = dados.start_time;
      item.logistic_type = dados.shipping.logistic_type;
      item.free_shipping = dados.shipping.free_shipping;
      item.listing_type_id = dados.listing_type_id;
      item.health = dados.health;
      item.category_id = dados.category_id;
      item.video = dados.video_id != null ? 'Sim' : 'Não';
      item.fotos = ((dados.pictures.length) / (dados.variations.length == 0 || dados.variations.length == undefined ? 1 : dados.variations.length)).toFixed(0);
      item.loja_oficial = dados.official_store_id != null ? true : false;
      item.catalogo = dados.catalog_listing;
      item.full = dados.shipping.logistic_type == 'fulfillment' ? true : false;
      item.vendas = dados.sold_quantity;
      item.ean = ean;
      item.tags = dados.tags;
      item.supermercado = dados.tags.includes('supermarket_eligible');
      item.oferta = dados.original_price ? true : false;
      item.variacoes = dados.variations.length > 0 ? true : false;
      item.variacoesId = dados.variations.length > 0 ? dados.variations : '';
      item.jsonVariacao = {
        mlb: dados.id,
        temVariacao: dados.variations.length > 0 ? true : false,
        variacoes: dados.variations.length > 0 ? dados.variations : ''
      }
      item.atributos = dados.attributes;
      item.flex = dados.shipping.tags.includes('self_service_in');
      item.linkanuncio = dados.permalink;


      items.push(item);
    });
    return items;
  }

  static itemsAnuncio(itemList, rawItems) {
    let items = [];

    $.each(rawItems, function (index, dados) {
      let item = itemList.find(
        (item) => item.id === dados.id
      );


      if (dados.status == "under_review") {
        return;
      }

      let ean = dados.attributes.filter(item => String(item.id) == 'GTIN');
      let atributos = [];



      if (ean == '') {
        if (dados.variations) {
          for (let i = 0; i < dados.variations.length; i++) {
            atributos = dados.variations[i].attributes.filter(item => String(item.id) == 'GTIN');
            ean += atributos.length > 0 ? (atributos[0].value_name != null ? atributos[0].value_name + ',' : '') : '';
          }
        }
      } else {
        ean = ean[0].value_name;
      }

      if (ean == '') ean = 'Sem EAN'


      // Informação sobre cada item
      item.price = dados.price;
      item.title = dados.title;
      item.available_quantity = dados.available_quantity;
      item.seller_id = dados.seller_id;
      item.start_time = dados.start_time;
      item.logistic_type = dados.shipping.logistic_type;
      item.free_shipping = dados.shipping.free_shipping;
      item.listing_type_id = dados.listing_type_id;
      item.health = dados.health;
      item.category_id = dados.category_id;
      item.video = dados.video_id != null ? 'Sim' : 'Não';
      item.fotos = ((dados.pictures.length) / (dados.variations.length == 0 || dados.variations.length == undefined ? 1 : dados.variations.length)).toFixed(0);
      item.loja_oficial = dados.official_store_id != null ? true : false;
      item.catalogo = dados.catalog_listing;
      item.full = dados.shipping.logistic_type == 'fulfillment' ? true : false;
      item.vendas = dados.sold_quantity;
      item.ean = ean;
      item.tags = dados.tags;
      item.supermercado = dados.tags.includes('supermarket_eligible');
      item.oferta = dados.original_price ? true : false;
      item.variacoes = dados.variations.length > 0 ? true : false;
      item.variacoesId = dados.variations.length > 0 ? dados.variations : '';
      item.jsonVariacao = {
        mlb: dados.id,
        temVariacao: dados.variations.length > 0 ? true : false,
        variacoes: dados.variations.length > 0 ? dados.variations : ''
      }



      items.push(item);
    });
    return items;
  }

  static sellers(itemList, rawSellers) {
    let items = [];

    for (let x = 0; x < rawSellers.length; x++) {
      for (let i = 0; i < itemList.length; i++) {
        if (itemList[i].seller_id == rawSellers[x].id) {
          itemList[i].seller = rawSellers[x];
        }
      }
    }


    /* $.each(rawSellers, function (index, dados) {
      let item = itemList[index];

      // Information about each seller
      item.seller = dados;

      items.push(item);
    }); */
    return itemList;
  }

  static taxas(
    itemList,
    rawTaxas
  ) {
    let items = [];
    $.each(rawTaxas, function (index, dados) {
      let item = itemList[index];

      // Information about each seller
      item.taxas = dados;

      items.push(item);
    });
    return items;
  }


  static frete(
    itemList,
    rawFrete
  ) {
    let items = [];
    $.each(rawFrete, function (index, dados) {
      let item = itemList[index];

      // Information about each seller
      item.frete = dados;

      items.push(item);
    });
    return items;
  }


  static visitas(itemList, rawVisitas) {
    /*     let visitas = [];
    
        console.log(rawVisitas);
    
        for (const [key, value] of Object.entries(rawVisitas)) {
          let dividido = JSON.stringify(value).split(":");
          visitas.push({
            mlb: dividido[0].replace("{", "").replace("\"", "").replace("\"", ""),
            total: dividido[1].replace("\"", "").replace("}", "")
          })
        } */

    for (let x = 0; x < rawVisitas.length; x++) {
      for (let i = 0; i < itemList.length; i++) {
        if (itemList[i].id == rawVisitas[x].ID) {
          itemList[i].visitas = parseInt(rawVisitas[x].VALUE);
        }
      }
    }

    return itemList;
  }

  static ConvertDataProduto(rawItems) {
    const now = new Date();

    /*Criado em */
    const past = new Date(rawItems.date_created);
    const diff = Math.abs(now.getTime() - past.getTime());
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

    /*Atualizado em */
    const AtualizadoBruto = new Date(rawItems.last_updated);
    const AtualizadoDiff = Math.abs(now.getTime() - AtualizadoBruto.getTime());
    const AtualizadoDays = Math.ceil(AtualizadoDiff / (1000 * 60 * 60 * 24));

    var meses = (days / 30);




    var mediaMes = meses < 1 ? 'Menos de um Mês Vendendo' : (rawItems.numero_vendas / meses)
    var mediaDia = (rawItems.numero_vendas / days)


    rawItems.mediaMes = mediaMes;
    rawItems.mediaDia = mediaDia;


    rawItems.past = past;
    rawItems.AtualizadoBruto = AtualizadoBruto;
    rawItems.days = days;
    rawItems.AtualizadoDays = AtualizadoDays;
  }

  static ConvertDataVendedor(rawItems) {
    const now = new Date();
    const Criacao = new Date(rawItems.seller.seller.registration_date);
    const CriacaoDiff = Math.abs(now.getTime() - Criacao.getTime());
    const CriacaoDays = Math.ceil(CriacaoDiff / (1000 * 60 * 60 * 24));

    rawItems.seller.Criacao = Criacao;
    rawItems.seller.CriacaoDays = CriacaoDays;
  }



  static criadosHoje(
    rawVendedoresCompleto,
    rawVendedoresCompletoHoje
  ) {
    let items = [];
    $.each(rawVendedoresCompletoHoje, function (index, dados) {
      let item = rawVendedoresCompleto[index];

      // Information about each seller
      item.hoje = dados.paging;

      items.push(item);
    });
    return items;
  }


  static itemsFreteLogado(itemList, rawItems) {
    let items = [];

    $.each(rawItems, function (index, dados) {
      let item = itemList.find(
        (item) => item.id === dados.id
      );

      if(item.frete.includes('A pagar')) {
        item.temfrete = true;
        item.fretehtml =  parseFloat(item.frete.split("R$ ")[1].replace(',', '.'));
        item.freteapi = dados.list_cost;
        item.fretediferenca = !(parseFloat(item.fretehtml) == parseFloat(item.freteapi));
        item.fretevalordiferenca = item.fretehtml - item.freteapi;  
      } else {
        item.temfrete = false;
        item.fretehtml =  0;
        item.freteapi = 0;
        item.fretediferenca = 0;
        item.fretevalordiferenca = 0;
      }

      items.push(item);
    });
    return items;
  }

  


  static excelPesquisa(itemList) {
    let items = [];
    $.each(itemList, function (index, dados) {
      let item = {};
      item.mlb = itemList[index].id;
      item.descricao = itemList[index].title;
      item.preco = itemList[index].price;
      item.taxa = itemList[index].taxas.sale_fee_amount;
      item.tipoanuncio = itemList[index].taxas.listing_type_name;
      item.vendedor = itemList[index].seller.nickname;
      item.linkvendedor = itemList[index].seller.permalink;
      item.idvendedor = itemList[index].seller_id;
      item.linkanuncio = itemList[index].linkanuncio;
      item.datacriacao = itemList[index].start_time;
      item.reputacaovendedor = itemList[index].seller.seller_reputation.power_seller_status;
      item.supermercado = itemList[index].supermercado;
      item.fretegratis = itemList[index].free_shipping;
      item.vendas = itemList[index].vendas;
      
      const now = new Date();

      /*Criado em */
      const past = new Date(item.datacriacao);
      const diff = Math.abs(now.getTime() - past.getTime());
      const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

      item.criadoem = days;

      items.push(item);
    });
    return items;
  }





  //parse text with '1' to text with '01'
  static _parseNN(str_num) {
    if (str_num < 10) {
      str_num = '0' + str_num;
    }
    return str_num;
  }
}
