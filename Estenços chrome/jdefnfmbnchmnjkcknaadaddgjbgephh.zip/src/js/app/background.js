/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */


chrome.action.onClicked.addListener(async function (tab) {
  chrome.storage.local.get(['emailmlpro','tokenmlpro'],async function (dados) {
    var existeEmail = await dados.emailmlpro;

    if (existeEmail == null || existeEmail == '') {
      chrome.scripting.executeScript({
        target: {tabId: tab.id},
        func: () => {
          document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;');  
        }
      });
    } else {
      chrome.scripting.executeScript({
        target: {tabId: tab.id},
        func: () => {
          document.getElementsByClassName('bodyRastreio')[0].style.display = 'block';
        }
      });
    }

  });
});

chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
        console.log("This is a first install!");
    }else if(details.reason == "update"){
        var thisVersion = chrome.runtime.getManifest().version;
        console.log("Updated from " + details.previousVersion + " to " + thisVersion + "!");
    }
}); 



/* let lifeline;

keepAlive();

chrome.runtime.onConnect.addListener(port => {
  if (port.name === 'keepAlive') {
    lifeline = port;
    setTimeout(keepAliveForced, 100000); // 5 minutes 5 seconds
    console.log('keepAlive');
    port.onDisconnect.addListener(keepAliveForced);
  }
});

function keepAliveForced() {
  lifeline?.disconnect();
  lifeline = null;
  keepAlive();
}

async function retryOnTabUpdate(tabId, info, tab) {
  if (info.url && /^(file|https?):/.test(info.url)) {
    keepAlive();
  }
} */

//async function keepAlive() {
//  if (lifeline) return;
//  for (const tab of await chrome.tabs.query({ url: '*://*/*' })) {
//    try {
//      await chrome.scripting.executeScript({
//        target: { tabId: tab.id },
//        function: () => chrome.runtime.connect({ name: 'keepAlive' }),
//      });
//      chrome.tabs.onUpdated.removeListener(retryOnTabUpdate);
//      return;
//    } catch (e) { }
//  }
//  chrome.tabs.onUpdated.addListener(retryOnTabUpdate);

//  async function retryOnTabUpdate(tabId, info, tab) {
//    if (info.url && /^(file|https?):/.test(info.url)) {
//      keepAlive();
//    }
//  }
//}
