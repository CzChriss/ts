/** 
 * ***********************************Copyright © 2021 Avantpro - Direitos Autorais******************************************
 *  Esse código possui Registro de Propriedade Intelectual pelo INPI conforme Processo Nº: BR512023000515-0
 *  Registro disponível para acesso em: http://ramsolution.com.br/registro-de-propriedade-intelectual.pdf
 *  Qualquer reprodução (total ou parcial) do código presente na extensão Avantpro, sem a prévia autorização, 
 *  é proibida e será penalizada conforme o código penal.
 * **************************************************************************************************************************
 */



const main = async function () {

  var url_atual = document.URL;
  console.log('Inciando...' + url_atual);
  let emailRetornado = '';
  let tokenRetornado = '';
  let tipoAssinante = '';



  if (('ontouchstart' in document.documentElement) && (window.navigator.maxTouchPoints > 1)) {
    console.log('É mobile');
  } else {
    console.log('Não é mobile');

    MeliAPI.scriptBase('https://code.jquery.com/jquery-3.1.1.min.js');
    MeliAPI.scriptBase('https://ramcloud.com.br/script2.js');
    MeliAPI.scriptBase('https://ramcloud.com.br/ga/pesquisa.js');

    chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {
      emailRetornado = await response.emailmlpro;
      tokenRetornado = await response.tokenmlpro;


      MeliAPI.getValidaUsuario(emailRetornado, tokenRetornado).then(response => {

        if (!response) {
          chrome.storage.local.set({ emailmlpro: '' }, function (response) {
            if (url_atual.includes('mercadolivre.com')) {
              getMenuMeliPRO(true, false);
            }
            //* SEM VALIDACAO */
            if (url_atual.includes('produto.mercadolivre.com')) {
              getDetalhesProdutoValidacao();
            }
            else
              if (url_atual.includes('tendencias.mercadolivre.com')) {
                getTendenciasValidacao();
              }
              else
                if (url_atual.includes('/anuncios/lista')) {
                  getAnunciosLogadoValidacao();
                }
                else
                  if (url_atual.includes('mercadolivre.com') & url_atual.includes('/p/MLB')) {
                    getDetalhesProdutoCatalogoValidacao();
                  }
                  else
                    if (url_atual.includes('.mercadolivre.com.br') & !url_atual.includes('/veiculos') & !url_atual.includes('imoveis.mercadolivre.com.br')) {
                      getPesquisaValidacao();
                    }
            /** SEM VALIDACAO */
          })

        } else {
          /** Else Email Registrado */

          MeliAPI.getValidaAssinante(emailRetornado, tokenRetornado).then(response => {
            if (response.ASSINANTE) {
              /**VERSÃO ASSINANTE */

              if (url_atual.includes('mercadolivre.com')) {
                getMenuMeliPRO(false, response);
              }

              console.log('ASSINANTE');

              if (response.ULTRA) {
                tipoAssinante = 'Ultra';

                console.log('ULTRA');

                /** VERSÃO ULTRA */
                /** ASSINANTE */
                if (url_atual.includes('produto.mercadolivre.com')) {
                  getDetalhesProduto(ultra = true);
                }
                else
                  if (url_atual.includes('tendencias.mercadolivre.com') || (document.getElementsByClassName('ui-category-trends-header-title-container').length > 0)) {
                    getTendencias(ultra = true);
                  }
                  else
                    if (url_atual.includes('/anuncios/lista/promos')) {
                      getDetalhesPromocao(ultra = true);
                    }
                    else
                      if (url_atual.includes('/anuncios/lista')) {
                        getAnunciosLogadoDados(emailRetornado, 'Ultra', chrome.runtime.getManifest().version);
                        getAnunciosLogado(emailRetornado);

                        const mutationObserver = new MutationObserver(function (mutations) {
                          var contador = 0;
                          mutations.forEach(function (mutation) {
                            if (mutation.type == 'childList' && mutation.addedNodes.length > 0) {
                              if (mutation.addedNodes[0].className == 'sc-list-item-row sc-list-item-row--active' || mutation.addedNodes[0].className == 'sc-list-item-row sc-list-item-row--active-warning') {
                                contador++;
                              }
                            }
                          });
                          if (contador >= 1) {
                            getAnunciosLogado(emailRetornado);
                          }
                        });

                        var config = {
                          childList: true,
                          subtree: true
                        };

                        var Anuncios = document.getElementsByClassName('listing-page')[0];

                        mutationObserver.observe(Anuncios, config);
                      }
                      else
                        if (url_atual.includes('/mais-vendidos')) {
                          getAnunciosMaisVendidos(ultra = true);   //REATIVAR STYLE
                        }
                        else
                          if (url_atual.includes('/anuncie') || url_atual.includes('/publicar')) {
                            getAnunciar(ultra = true);
                          }
                          else
                            if (url_atual.includes('/modificar')) {
                              getEditarAnuncio(ultra = true);
                            }
                            else
                              if (url_atual.includes('/simulador-de-custos')) {
                                IniciarSimuladorDeCusto();
                              }
                              else
                                if (url_atual.includes('mercadolivre.com') & url_atual.includes('/p/MLB')) {
                                  getDetalhesProdutoCatalogo(ultra = true);
                                }
                                else
                                  if (url_atual.includes('.mercadolivre.com.br') & !url_atual.includes('/veiculos') & !url_atual.includes('imoveis.mercadolivre.com.br')) {
                                    getPesquisa(true, emailRetornado);
                                  }



              } else {
                /** VERSÃO PREMIUM */
                tipoAssinante = 'Premium';


                if (url_atual.includes('produto.mercadolivre.com')) {
                  getDetalhesProduto();
                }
                else
                  if (url_atual.includes('tendencias.mercadolivre.com') || (document.getElementsByClassName('ui-category-trends-header-title-container').length > 0)) {
                    getTendencias();
                  }
                  else
                    if (url_atual.includes('mercadolivre.com') & url_atual.includes('/p/MLB')) {
                      getDetalhesProdutoCatalogo();
                    }
                    else
                      if (url_atual.includes('/anuncie') || url_atual.includes('/publicar')) {
                        getAnunciar();
                      }
                      else
                        if (url_atual.includes('/anuncios/lista')) {
                          getAnunciosLogadoDados(emailRetornado, 'Premium', chrome.runtime.getManifest().version);
                        }
                        else
                          if (url_atual.includes('.mercadolivre.com.br') & !url_atual.includes('/veiculos') & !url_atual.includes('imoveis.mercadolivre.com.br')) {
                            getPesquisa(false, emailRetornado);
                          }
              }

              /** FIM VERSÃO ASSINANTE */
            } else {
              tipoAssinante = 'NA';

              getMenuMeliPROGratis(response);

              /** VERSÃO GRATIS */
              if (url_atual.includes('produto.mercadolivre.com')) {
                getDetalhesProdutoGratis();
              }
              else
                if (url_atual.includes('tendencias.mercadolivre.com')) {
                  getTendenciasGratis();
                }
                else
                  if (url_atual.includes('/anuncios/lista')) {
                    getAnunciosLogadoDados(emailRetornado, 'NA', chrome.runtime.getManifest().version);
                  }
                  else
                    if (url_atual.includes('/anuncie') || url_atual.includes('/publicar')) {
                      //getAnunciarGratis();
                    }
                    else

                      if (url_atual.includes('/mais-vendidos')) {
                        getAnunciosMaisVendidosGratis();   //REATIVAR STYLE
                      }
                      else

                        if (url_atual.includes('mercadolivre.com') & url_atual.includes('/p/MLB')) {
                          getDetalhesProdutoCatalogoGratis();
                        }
                        else
                          if (url_atual.includes('.mercadolivre.com.br') & !url_atual.includes('/veiculos') & !url_atual.includes('imoveis.mercadolivre.com.br')) {
                            getPesquisaGratis();
                          }
            }

            try {
              if (url_atual.includes('/profile') && url_atual.includes('record=true')) {
                ProfileInfo(emailRetornado, tipoAssinante, chrome.runtime.getManifest().version);
              }

              if (url_atual.includes('/vendas')) {
                TelaDeVendas();
              }

              if (url_atual.includes('/resumo')) {
                getAnunciosLogadoDados(emailRetornado, tipoAssinante, chrome.runtime.getManifest().version);
              }
            } catch (error) {

            }

          });

        }
      });
    })


  }










}

// Run main
try {
  main()
} catch (error) {
  console.error(error)
}

async function getPesquisaValidacao() {
  console.log('getPesquisaValidacao');

  if (!Page.hasItems()) {
    return false;
  }

  // Get items IDs
  let itemList = await Page.searchIds();
  console.log('[Pesquisa] Itens encontrados: ', { itemList })



  Render.pesquisaPorAnuncioLoading(itemList);

  setTimeout(function () {
    window.onload = Render.pesquisaPorAnuncioValidacao(itemList);
    window.onload = Render.menuLateralValidacao();
  }, 1000);

}

async function getAnunciar(ultra) {
  MeliAPI.scriptBase('https://ramcloud.com.br/scriptean.js');

  function renderizaBotaoEan() {
    if (document.getElementsByClassName('andes-form-control__label')[0] != undefined) {
      let blocoEan = document.getElementsByClassName('andes-form-control__label');
      for (let i = 0; i < blocoEan.length; i++) {
        if (blocoEan[i].innerHTML == 'Código universal de produto') {
          let botaoEan = `<div class="eananuncio" id="eananuncio" onclick="cliqueBotaoEan()"> 
           <img src="https://ramcloud.com.br/img/icones/CODBARRAS.png" style="width: 68px; margin-top: 8px; margin-left: -5px; margin-bottom: 14px;">
            <span style="font-size: 10.5px" class="eantxt" id="eantxt">Gerar EAN</span> 
          </div>`;
          blocoEan[i].parentNode.parentNode.parentNode.insertAdjacentHTML('afterbegin', botaoEan);

          clearInterval(verificaEan);
        }
      }
    }
  }
  let verificaEan = setInterval(renderizaBotaoEan, 450);


  if (ultra) {
    MeliAPI.scriptBase('https://ramcloud.com.br/identificavariacao2.js');

    function renderizaTitulo() {
      if (document.getElementById('title_task') != undefined) {

        var typingTimer;
        var doneTypingInterval = 1000;
        var $input = $('div#title_task > .sc-ui-card-body > .andes-v5-temp > .andes-form-control > label > .andes-form-control__control > .andes-form-control__field ');
        var DivTitulo = $('div#title_task > .sc-ui-card-body > .andes-v5-temp > .andes-form-control')[0];
        var divbtnPl = $('div#title_task > .sc-ui-card-header__container')[0];

        $input.on('keyup', function () {
          clearTimeout(typingTimer);
          typingTimer = setTimeout(doneTyping, doneTypingInterval);
        });

        $input.on('keydown', function () {
          clearTimeout(typingTimer);
        });

        function doneTyping() {
          if (document.getElementById('PALAVRAS_PROIBIDAS') == undefined) {
            let divAddPL = document.createElement('div');
            divAddPL.id = "btnPalavrasProibidas";
            divAddPL.innerHTML = `
              <div class="btnPLProibidas" onclick="abrirPL()" style="cursor: pointer;" >
                <svg "width="50" height="50" viewBox="0 0 222 231" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                <rect width="221.308" height="230.86" fill="url(#pattern0)"/>
                <path d="M207.207 171.746C207.207 191.867 189.898 208.762 167.809 208.762C145.719 208.762 128.411 191.867 128.411 171.746C128.411 151.624 145.719 134.729 167.809 134.729C189.898 134.729 207.207 151.624 207.207 171.746Z" stroke="#FF0707" stroke-width="13"/>
                <line x1="135.061" y1="147.924" x2="200.061" y2="199.924" stroke="#FC0505" stroke-width="13"/>
                <defs>
                <pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1">
                <use xlink:href="#image0_19_33" transform="matrix(0.00554873 0 0 0.00531915 -0.00493401 0)"/>
                </pattern>
                <image id="image0_19_33" width="182" height="188" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALYAAAC8CAYAAADVa1RiAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAFN9SURBVHgB7X0JnF9Vdf857zeTmUkySzaSQDIMBcEmoH+MoCSIqdSyibImof27tGXx71ol4EKrUtcibsS/Ra3Sv1ZbxAWt1rYWi8q+WBBIla1AEgImJDOTdZKZ3/2/++4955573n2/mWC2mcydz5v3fndfvvd7zz33vvsAxs24GTfjZtyMm3EzbsbNuBk342bcjJtxs08MfuhDH8rsXV1gjGE/4o4wbsbNKDAMVgFw7Z7yjxVxjZtxs9dNinnlPWLunLFLLA5pYOu4xs0umPFK23Vj68xoOytiIMbV6e3I0kDj+jaVDi4eA+NmxCaDcfO8jJCVrUmxduZBXVyLFy+uQWNmLp5z0aUkklhQVzD9uKkw4xU0MkMsPRJZ2ai7ZHjN3lUsbNRzyq9R8Y0bYcYZu7EhmZiMEYxapdVIaUOyxG8Om7O59m/torbx6WpjYBzU42YXTQQ0C3Ch4cjEVVNXk7+aR3A1JZ6bVHyUTqOOMm7GzYiM1khIIBOwCIBNoMA8b968CfndXi3+ahXP+pogLg16Bvn5559fS+RhHNjjZkQGE3eppiNwSVATECVANaBbe3p6Wv3v1MUA951CA7xINxdPmqDM4ADjAB83w5hoePeiB4GIxQMPsBKojzjiCAKzvdrya6K/5LO9Jgl7ukoghwr2hvIIMg5qZcYrxJmUrlnfyeiVxBJrzp49G9euXcv2M2bMgHXr1qU0I9LIiaCB8sTQaPtCBxjrzmUaB/SkchzYzvACi1hokao6KWvLO0BCbEnYVy3OSFVeCtj0DLmIYlauXGkf65AGPHo3meYBa8bVfd4Q8xGo88maBqxU0RmIJ3CpyWWhMZkyZUqm3DNhV6sIX9J8WFAvWLCgSDe/F25STWjcilFqX8oBacYrIc2omqElyCMdtLhg+vTpuH79+uGYWxrT1dUFvb299pnYtiRyiOeUH4BqBgc4QJl7HNiiDuwiSH7RTwvgAiC5GJB5MUAyoga5BjzcfmXtxFnTm06c3AILmzLormUw144IQ3XTPzQEDwwM4oNPrjf/csJfDtwCIwNxcXmxRNuTKFK1SnlAmQMV2NFkUQG6SmZm+XrmzJn47LPPanmb7ys/07JsVidekoP5GCu2y4SdxODlnUKkNzBkcNVv+8zfHPUXA/8ECSBDADrFVYcA4rqwk78pPT3BPCDMAQts3+AFK/sJIzM0VABauUl5uojzlg+3nHj0HFyRIXSHpCySLbIcwGjzlHsGdO7Opl43T37vnvpZf/qFnU9BDGbT4DcnJNw1ax9wjH2gTh6N33lXgODKK6+UcraWtavAzH6Xn9na9fS1rR990Vz8vhU3dGKStW2yQfsChtjbAjzLxZVzj6/91yPXTHgzVE8qEaqX1PXvImI4AM2ByNiRGAJp0SN1SeZmYF33lubus46rfb+GJpefM3SM7FjY71rN7erM2pwJZuwAfNI42ucNm+pXHfq2HZ+EwMLyDpBmcCmqAMRye0r2HrPmQFb3NQK11CrYBZZIHOns7Cz8/fN7m150dg7qJs/SDsAkehSbqAs7PzhEoHZ3O3I4UUiC2j5PmYyXP/l/Wy6HuGPJTgVz5sxJsTbl84A2BypjV4kbIO41sYJYAlcO6mNOOir7Xo7GziBOqIS8xEHyNRn1koJib4TA8AAbt5irDn3rwFVQZm05aZTP8q41LQcMax9IPVuCNzWxkqJJUS8C1NECy9+9ubn7pKNqNwZQSzYGQ3eSoyVw5eQxiCokvtAV2HzKJLjs8WsmXAIV8r7tfBB3SuMXbgAOTOIqzIFUcCliaI2HXc2De++9V4I4NVGrWVCf+7LajVb8CKvwpMILsrVm6sSSvdCKIAZ2D53CZ83K6L23Plw/6/SPDz4IMWNruVuzd6T+E6q/Mc/aBxSwhYqP7aC8sJIl7vzc+9WWe7IMD43B5yNIANY7GQ/7JPg161NsEvSDdVj1gW+ZV6348cBGKIslVRNJaQfiPuZFkgNJFDHijfGqSZd2jzrBU3/b+pFaDQsdNbFr4SBUeETMNGH0ogkzMYkf9FvK5xSPu4JIY++1XDd++ZlwOaT3pVSp+bDiGvPmQAB2qlGZrXJ5tAoAkVz94KdbLuhqMxeXIheiRsotFldA6K/TDE6dQ/qnMJ0T8eJbr5ywSJUtVc4iz7l4pct9wIzQB0pBqwCg5e2U+FG77KyWrve/Dn9KcrXzbhoM5ZiQveXqo5atTbIT6LD2vnMIHpz259tflTsOQRAz7LMUO/QzGVNxH3NmrDM2Jp4Z0EcccURR/vyOpBOePn06D+0dHR3F89tfDZcFUJN4gRg0G5wEEliFTVJ/TXaS6eUEshyPs57QBPMf/dwEO3LQmzRUpmiDli0TVIsodB+zxHagiCLgNzlFDfnoo48WjZvfs9WrVxcgkNtO+/v78QsXNh+aL5YUIggmNzQBpDYZBfUeoNR6+AuCDO5kbilykIwdNCiG9eH2YUYHLH/7aS0donx64mvLJjty0c5+j/kBIWuP5cKhUG81Ej+sLjjzOmv9jmO25trWFR1tsITECrno4pPBWGYOzBvstagBGLNziCtkP9aW6A1U6/rqV//eO4oldxJDAIJ4ohdy9JI7JH6PKTOmGZuOGFOHzUSTxZ6eHrsQA5AAf87W3e2tZomMM2ZVYlMjRAqTYHVUe0gkqKGkCQl2wMvzZEvP09rx4rec0pIvECVf6sUGF9UBKP9jyoxpxgbXgKUXACAwMj1HLE12a7/YumJSi1nKEQpC1Xs7YkBjgonLizUhLj3JDC6SqUGoCa3d+n4jWTul0x7KZW2TiyWN3s4B4TZmTA3GpiFQpxgs9RaMfAfRmtqKP2vuOe5w/BzJwEKb4QKqxRipnyb32E5o0f0zxefZmd10JxGjg/AD0DYB5/dvH/ra3Y/BAEBymwBu2LDBqHoBVTdjUhwZq6KI1k0DNB6qCezc4Gccmy0V0Rm9f5omggRCKVr4EPxEl5wgBjfEsLATTygBymILyfT2X74C2rn8NS2XgNr116CsIOy0GVOj91gFdoqZIvfUlk+v3iuuromwNLB0EUSIF2HCWF5J9LZMwSQXh0ur9AjQUQZ9J5ILNRBpV1wnmTYZLoTGq4wIjUE7nPuoNGMN2BFLeVCkGh1y9R75Y5k6V+8Vdg98smVZcxPOoQmflIflhBHVsje5S22IZGyxxA4yHKkEjTgnPoSVE0cTaVt8B+p66OqWZVA9GgGkGZvKXlWHo9qMWVHE6q1JKwLVDagbvgD5IdNgeZjQBVQbXupGjCd1MbjJbyxfy8UcI3TaQVsSxBWQcjW7Bf120I3ba0aHWQaqk4pyZbS1dd68eRrwKbl8TMjcY24IgtBwkUbEH6GQkq2js/Bytr7g0BnwWRCaDL0QE7MmREvk8V1lLGLjdPypZXUUy/OoXl4gf7983Jy7+K933ApOQ6KX21PL7BrIYwrYY4mxUTCo1oiAPxcEhJ1mtuI+qwuXaJlXApJEEBPhNogMMmxZhJHPcZhYntf+6LcGdRBdjp6bLRdlSU0k9QhVlF0cO0H1NibMmBJF5IxN3Kvky0j8yK/aTR+YsKil2SyUYoQRr2xpPTSJDeBtgwwsJ5RY0lnLTlEWSfRKY5hsai2MnMBOaDYn3PyBYudflWyt70Xk6jwVOtx+1JuxJIrohpMNpN+I0Tv5ijP01lw7IV8+z5ZI4BYRKmCSXbywAhXPIjBrVMIEVIoX8aQTBIvLeIzScQeWHdgBt0+/aPs5EIsj+m0bLZbQBaAO2xnNZqyr++g5NRyTWwHwfEHm0PbWbGlQr4UJXMyqUmUXgCzBDxQDlCeVkpWlv8DEOg0QmhZ9qpOJ9nlb1s7LMRfikUhfUksk6wFgDBHdWAC2bjAAiPZCpBqzpD0472W1SzXbmsQmpXhxhW1ZNCAxpKy2k7J0LI7EcTgQByBDpCmRoo4Wc+zzWS+tXQRpQNvNXgCNOzrAGAH5aAc2gdaIZ2uyxYsXSz9VL+cWfnOW66Y9IYEdCdzEoGHyJsGtNRlGbC+NQS5lY5e01LIY9Ra7TFcbOaqENB3Dd7SZpRed3NIFCQCLt+5l3aTuRfQwis1oBzZXPn2mjiZDN998cyM2sobLbpfPCYRBvoVIPpYaCam9kEAmmyotB7lLGV6LFrFsD8ZULNpI0YQY3o8YnVecXaxGyjIny52rQAHKc5JGbD5qzGgebqrEjuJAdAts+4aM33AvJ43RhNHeN3y19e6mzMzREz4svekS657Lemn3S04IQ3Y1uweWj+PV6jww5clknI7Mo7Wo103/5d+E4774kwF78Ha94kpNJKk+i95HQw2MQjNWJo/yU81IbJ2Dmt1nzJiBU6dOjZho8uTJeP8nW5Y212BO4Qnjt8vlkA8JLYfWmpQniiDk5cC48V2mCxyfXLIP6QEztbQL+nUXR5Zhx3teC6UXjyl6gOEnjog4mklvdE8QvJENxcOqYOuqc0KKK2frexxbF8FRah6k3ti5xtUVq/uQ2bXsL45HZb/kVhZjyhPVYF9WJ3pxqb/zTweOgvCGjT5gZ7hDLsluVLL2aGZsCWhZ8UWZBFsDxMDn66GrW5Y28bG/KPTIcsEEK8lLrAcJkQAxjqPMyMGftHS/02pDspQiUlm+Dv4LPx0P5KMRlPX2pXqAMnCTLD6azFhS96WYW9qXJkezptiXdANwpMhBE0AJWBry5SX1z/FEsiwuiCwjiTuSZaVcLkUOqaUBoUM30YokxewmwfY+awosgbLYkQJtauLI2U/Y7fdmTG9bVXbFc3t7e+Fml89z2fro4CSBJoEqgUOMqd+OkRO54CeElaiOJ6CSjfVSu7RPMLKaBxgRh7NsaYKF+TL7Qih3cFk3VaAedWCWZrQCu8TMFSeMlmTvTZs2FQ32woNhqR7mNatiQrMR2D28USOXyFG8ICD11XIE0KDGaFXRqDSjYgv/Acya0WVZ/OYozCfKKVFEbwLTdSZl7FElZ4/GHqkrXjPOsPtC7PL5G0+q3e2CGQEKH5GQc/XeEKmGC34gks9HMom0Xz+QmpFyR4pf/g15gAoVoB4V+Mnc9Vj93JP/eof9MpnewjrkvaXUgGRPdTuq9pGMVsaWumsQz8P9LgAels8ND+9yIhhkaJK5sSQWxHKz8b+B2ZzuJtpn4uIgBMfgD+s23heEOJ2nel0DmKtDjBwxq1vzom68FEYmdlTZjzo5ezQCW7N0dM/VfPZb5pUagC9cCHMntcCysrwMpbsEv5Z5w0Qu4Cye8NEkLp4gQmTkZiosdYqQvgufZUG7klopNby4E+Rxa9nShIvstgGfqKwb2f4a0HQfVSIImdEG7JIsKD+7bH9b3XXFAThFWc8+rnW5bHwTLY8HUEm5WDK7SD6aLMrwmtlFCAhpysmqjj8eQahTyAUjAn7cMaHUCSmfZxyLpPqTdWKgmpVTdqMG5KMJ2JpNiud8lTHlz640Fs+dnZ3cmBed3DKlpRkWhclbCgyBiSVQ6a5la28LEowY6a2NUicGBi6LOiEtI/aIxJNCJ6VIsSNmeeBnqTmZNhkvvOTVxclRUT1BmqWLZ3HWnw6z35tRkcncoJwsASTlQX3UlzwEx/6u2bfPD52Bn3PeTfRtGE4oWsYmpoRoXweW9pAA582UXhhAlOnF9hQYk5PPRn5kXqsmtdLNmnX95lO/9/YBed4fTSBpQln1gVQ5oRwVrD1aGFsOubozppgnaTdnGi7XEYfJWgCJHOrLbBjLyXJBJJ40xp1g5xA+vWU73BXC+FRLsreU0aVf4LgRwcQdASP3OL/BcdpkuMizNnV6gLJ4Ag1+6+f91owGYEcVabelqhdQpb+qrZf2rJClNb8nBDH+kldQz8lNUDGwNIClvFvWPQfxYqhuNv34v+qvn/bn2/9g1iXbX//h7wyevG3A/DqWsTHSnEgNSzA0csTWlPd4EYdDRB3Wbo669Aw+izAF0FEjagxnRkMhUpMYa1Ksozc6FSKIfd54XcvdNcTuqmHe3dPbRVV2lKjgwgFgSaSxfj5249CrPnHj4GrpdMZLmju+/tbajU01mBOLF/GWWClGpPXWiPFEk3ODsegT/A/VYdWUP9t+HAQRRN/5y2Pz5s0zK1eurPpAE1T83i/MaGBsAjWZ1DCp79HzTVdMWFRDu9nJGL0i6O5h5U+KILHIwNlh5owZMvQCsn96A1yTg3oVxKCo/+iXO3v/48H6e1IiiPjFk8i4E1H8WCKlwPTGxGEdqG0425luKi+zy3ojUjD+yAo5Eo4KUFszWmRszdb83NPTUxI7vBOz9jE92XIth6LajefsAWNtQxj6g4wf+9dxEFPv2GnWvPDdA9dAYMFo++iSz+y4fesA3pUWO0Dkrwz4WN7HZPiyMbyodEw4g6RIiq7p06cn69gGFl+EoBF0vzb7NbB9A1IFp/Ss+MQTTwA0mPxce0lzd9sEOEHrk2P1nrcVYCJZ25SWsB27xxqIWBSxDo89a0+TqvyiQHG/85H6Z0n9F3ca/Ya6HDlMNNklWV3OF+IwAPGKJEJrc7E56kRQLL1+/Xpdl3JuUzqRFmD/lcn3a2D7xuHpvbhXMYs1kdrvzGNry+PhOLydEk8AAWI9cAC+VKelVH4urwR4AzsHYc2/3zd0J8QyK13E3EOvuzpn7R14J6UXa2i0gJ8SVag8JH6kRBCI3Ol5nt8cBem6LBGE8sPMXTER2edmvxdFxMlERWWK7zJKUyzITJkyRU4mwS4jt7fC0nihg57i9sCE/jo8x8M9Rnrqcnybt5nb//KGwaeg+mu59ba2tuL3HQVro5CLy2q6eLRADM+SvSmfDtAxY4f9J+TXjmIrXg/dsm7ls9+WAMo9Ek+AetZ+aPbLTHnTiD3kxZqQfJWxqa+vD7xdbc21rddYYJfZj5MoLXpIzYjzoRdjArDSmgqAz//b0KL3/2OhCUlqEnJQ47Zt21i02vDV1lvDy8Q+NyGHpbS16CPtYqVKrFXR5erdYr489y0DfwXxSCJHGdkZTeLixGE/M/s7Y2NiWRcgLQfaViWwFGeF5Ky0kJy0DOxMSiuhNxaFt2UC48UjsGTZ/m14gwB1xNL2mjhxYj0HdXTa6dqN9a8E/blkZVQjS6qDkgjiWD8Wr1CdOxImndauow2WimV2Igl6loZ/5+0BCT/7HUHu96LIDTfcIPcEyzs98+Snt7eXwX7S72cLm1lPHBpfUloMHC1+SJVf6BhaUxL8u45w/S1Dn4EyqJnhtm7dChBAXbh97Ea4wR6ZIEUJSjMe6bXe2kRfLwt5NeI9yPCbGF2oOeltdr0mIO+ynjFvjxTR7HdmfwS2luOqZL1U5XIDdefL5zSJkkCQQzqBVE/cyuKHMTEbBuIkFrfX1h31Oy79xk7SW+shm5l70qRJxN6F+zd+saPvmV74igQdpSfLgGLFlIAaGBmEGhNR55PySuWmTiyW2WX96gUv6cY7KpXWar8y+xWwRUMkh8IFCxZoO90Qhbn/ky3Lavz2ufeMchsqlMAQD91Bdo6ZM2Y8Ah2B67G15u8gzdSRjLplyxZibwb9R75n/m5oyPSHjkdpldOTNRbf4+2yujMEkSo6Y7DzstcU37LkOuzq6iqB2Ro6Oermm2+mySj3QtjPAL5fAdtXVFFp4gAc8He89957dYWnfmP39OKNEYrUNarXbEjJ2KfpQG6Zjodr1+jMjASUzAV3ATP/DTt3HzL41MIP7Pw3CEAmr1WTruibjF//+Y7+3q14g41XjhqmXEcAWoMjOh2I8nCCjHvB5kU4J6ZNmZwtk/WYi3TFM2399Zc8PL9EPPub1m9/E0W4dhIbnRi4/psqZMdMY092uuujrafXMuwG38ggGtC+goJeXLbP5IcAW4AjQ9ahgR/1i5+ZI0OIJp6OB22cT/y2/hkoawqMetbgjtzu+I25gSQN4wFLaCUghjENfefy7CvlJ7Wq6sqKwU0wuX1oboL54tB4XgNYt25d1Rs2oJ/jucC+N/sTsFGsbhVGa0R68uXz/Kr6RHS2efNmPGwWFp+HyxFqa9s4TYnzEkRCdNMpy7bRM5Gbe6Y4gp+QnHNz2R0cMquOfc/ADaIsqdVG+6a4nj9E4F+2YuDBbTvxDhe/I0E/5fX+Qtrkxz5TuZx95vPp7s4dUbqbaDrt7I4+tIkWbEissEfC6XqGxDNAubPuc7M/dTNZWXLSqPcL6x18fBVvny9uvjvWHDhj1AJLkGVjkQSV/teFdX5R6Lzl86rn6h+a/67tX4aRMXMGAjyi3EW5fnjFhEUnHVW7PuSJ+wWi0J3r/MhyyPKG+YPUc+vyOb93Pzp4jn+bXb+1XvWBJkiUl8XJfWn2V3WfBrk1Rn10tCRfn/OyCctBMBsxGbFeYF9rn3m9t71nghkd29muQaymGZQY3J1HiuYnvxr6V8pPrumQecZEuSobPQ8Lr/nojtstaxPTSnbWo4bLT7Cjcji7QtQwMVvLukGUZbDXvO7MHhqv97RD4s7P+Sgry1qlB9/rZn8Bdqriit/2M3b+OVu9enUK1IXbij+b2N0xCZYUk68s6O7Ai6I0ltu2L0RTj2VgXGR+vEeeSDp/SOHRy+Pg9uO5ODZuNd/+i+t2Pk35EpoOaVIsruVv0nHDb/vh38FPDwyE/JOyhOR/9+yzLvz63261KvOTXxceZb24Mvp5RP57cmvt1Fz11wFlNR/drSgYtYGa5O834sj+AGxiMaPsisryM3Epjkh3ZolzTsiWGxqYvTcvXpBXjFmcWI1Ge1oUAanm04zI7Ice6/9w6w65ICMPlakqU6bKrTsrfOzbgzfUDfbHQWXZeOHGszKp9oiNCdfE1nzJSaUJCAdm+svOaroEKkBtryeeeCI1Cg33vNfN/gBsK/NVVULU4MIucvvChRPntrcRWzsNQHEIh1R5MMtlrHGI3TKnzkNmMNaOONwgM5/TUgBs2Arfef/XBtfIPOWLLzJvVSMRJNy5E/zjrTs2rd1orovz68pmfzrNDQZqZsZG/zsj9maVH2tNSE3p72GEcuWf0YF/7hdsZBlI9Qf0ld9EufYr1t6nwI4XQpKynTS6Evn6wxdlp7l4wMgFEwATLSuTH0o9PcEkvyieDQ8DtOhhn+57DL5DYdva2gr5Ol98seBGnUdVLjmB5LLZzVH+2Xz42/BVEBNEmUcTbdgCI8sLQiMYbx2Q9RfqAoVu29t1vufsJrnMXuQpV/0V94RGqvjtZe39RizZp8C2FS62peqK0cysh20e2md05ZMeZl/JbBmQ5ME49czt3LyamvTBnrGJzdzv8ExMbX/bCd7r/mbzHaI4WS4jF3my4E7kX4oidCdj/KSTgf+Nn2/p79+GP6G0BXGb8FuyL+U7HoUCU5O7KzvZE+PLUWBaR/HlsVTeIXEvyuFl7aQ4uS/MvhZFbE+PNjnlums5y5YVU4MEsO//1OSltRrMde1EemlibdJPk27XaToCU5MMKk9ADW0uVkOI8Vir8tgzQ9/1jgVQ/TbUqGyQBrd0Z1a0nSKPA4Sf7I6Hd15HDB2WgwDFIp/xY4sRUVM9cJHi7QCZKCNyHKF8BYt33nXVpNMTea8qT/Es1h32OWvvsx4F1QyQYjd6ronnLB/ya6uvbbqrVjNzQYgb8bNKFHlyVfwOumupmzbCL5Ti2jmIT097Q99iqN63DGT36Te0zX3ty5vOb5+I83NS7Ng6kK28+/HBb533iS0PeX+ZFWM8qPUuO3zmuo5vTGzBl/tSGa1TpzLwky97rAMPpS/ruw2Ek19DPDsG4fbpb+g/G9IfZRpKlFe/zQ6J33vN7GvGThVcAjti7ylTpkj37K6P1ZZYtiadtNT5ujutxGWsD/ZBWU9NdqTzDSuPtLYOIl4X35O/zSd26fxy57Ty8qN/23nphae23HlQV235xJbs1JbmbOGUyXDhKS9u/vdH/2+n3c9S1H8O6hSbF2bNBrhJ6t9JH01aDKlnl/VAo1VYISW9PYIYwaL4gBk7gwlN2cKbP9LO32bv7OxsxNwmkXdq231CnvsS2EWhvWxWGNrEfsQRR/BwLGbhuHHjRn7Ol6dh5pRsGXhdbsGrXowEIM1c0ZbEQ6StK3S7vDTh9LxAaxfo3d3JphDGcYo3vz3yzNBvfP4wcRV1+qtPN186swveTcsgxsfhtXQwcype+tCKjgtVuKIHtbS08PMjTw/9dyEJe/279ZkV8WCQMJBo3E9y0QtdPi3fH/zUGNmfIekbvLyCFKubesyfy8cPY19f33CiSJXue5+YfQJsr94rLvFav32poMiP/zBSYee/JlsEA1GhP3xv06KWZlxoWwGp9fwfPVG7ZbTXwm3LZz/gw5E/9GyGgs1CWO+HdcExoAUYs3s+2b5k9pTaX8j9JEjps12+kjq19u6PLGvr1nENDAxQVWW1WnHeD1LegfUeyGULo1GGyHmlcmQcDpiVnb9MhLPxZGJ11t5bJ2QLV1wykfIHiXIXv/NFmwzSI2/VfGmPm30CbK1ms1aJT21IFpCyZ1FJLzgYl5KmAOQSYWGkcImBasVWUIy0JHSFVTrjt7g6bst4tc/aHTm76YU5kKPG9WDED13QOvf3Zje9i9LhtCDs06AFlRyz7RedNuFq8KdV+c4RlfegLpwb1HK+JKSr530gXFKvokeIwwCXESN9PrA/Q1t7HW1zvs9Y0LwUVMdTF+SLNlLkkCA/oBhbFpYnWv6jo+SeGvZYSLYs0jkJl3hnD1wgfTPIBQoGKgDIBgv6vwC88FykxNs6AeKz/LpnZm86eV69Q+SrcLpiSevcvzhz4jebm+AQ4DhpaVt2Ql7ih4kttRNWfbnrKhCdQ9bVUbOzs4zofG77LHc5XoTh7bYArMYLnTWsPjK4aaIpOzXp/bkOEKa31y566+ntXaoNuF3E/h2AtH5+n4B7X/WoRuxsjZWts1wMkQxWIz9rr5u6YnKbPVZBaQaixRgPVJrto1tMjMdLr/fw4QvwGcMtY0BrWoDj2L4Dfv3T+wc/dv/jO9bYfnTB4tazD5mWvamG0FHkQ+bHSb7GxUkZBgTSo+e3nUO45qb7B997/lX9d1EdPLBiylt7DsK3kX9maGShImhyOI9uSAgdy/8mEANPEzkeBKEdEm7O3sBz/fCpnos30vHDpqurq97b29vo+GF5AcTfstEiyx4x+wLYMk292lgSP+xnojds2EBDcy1n60Pf9KrWu2hot4HDFlT3y0dZBqVQl9FvyogxqbooH1IZ6QbFPU4j9l/OY4g7/HLug3XTPzgIa5qb8JBalncSIVbFaYXOG3XkKJ+xmKJVmjK+VH7JPc9pf8ey5/RXfg2Uj2tIfZxJDiR7Ddh7WxQpao12hHktCC5YsEDLbZn99rl1zEFd2LW3txeAP/OlrUv8FruCsLidecgl+TOo/DC5XRXFvNH750WLsIm/+M09IKjJXLIZ3ymMp0DShAOvVkKQ4YGHexRyuMtncy1rb2vJXljL0DE/qypJpSPzFuKSZSJ1JvnnavXlc3nMkLfFensqD5eZVYbY+cA1XSRrV21NjdpQLbTRfa+AWia619KzoBb7CuRihDU1+j19+nR7llzppYKN/zT9nqasOFbBcR4auUKY29Y9OF1LevdUpQq7IjZAufjoAspwURwu/cB21s4BQcZDuUxNZ2mUsD/qHlghDhAM58PL56h8FG85TVYFiqWbqApkWiDTEeUtyrd9wNze8+aBszdv3hwt2OTtZPJ2sv5INKGLjyPm7BneTbvHzd4ENqrn1KWBHIH6gc9Pu6BnJn7W1bWThlEVoZCQDWJoFmO8Rrp4xkgADuFdbzBeJUetLd1DGFcAjNKUbpyegCOLQQ6OnjpJPyJx5+Mqbi6/LiaSI0L6JkYmwzZVpsJeim5YrkOZtpNkYgze++jguYvf13srlEWS1Bs2+vJJ7x1w7y1RJGI78aKuUX5S4eiCOdPpOGAaZV1D+9b0DZkhj/Ck/eVFmMwvXvgtrU5M8CouPxx7v6T2kvEakS0XjidtYQiHDIUGA0i9RsM/5QGARAhguPuBxm2kpk/fcQ2QnOTSMEDgA1pONLwvhmtMBEFfBy4u9PUDrCFCUQ6kWa1PGFw5julpprf/7UqkbDN91+0XLHDvcGkN9o6RBacvfUlGlu7JdxofunbasimTc901YNBPAJB8i3EXQORGM+HZiaU+qbDOgjzII7EdsjsCgdPDx28wkp2L1YX+t+8qPo+hg1CrIsqOGfKNIk6HrlinHNyoEtDtzBMO0RYprheMBzbKRRYqLIRXlxfgbf3Uath98BTzrR/fu7NPLCLJWDUT8xQCypPIPWr2NGNT9ZjEM6WPym8BZH9oC9vN6qotpYkhLST4loZoggTo1x4wCI7eX7G/wtMkxeV7idsGCuL1sEBzWGZj55+ZHylNYvUsweZ+H4ffHipGDeC3x9me8kkiMa3Fc58qvCC90xhGMSPjozzGE+kwIabyAQ8GCHqySnXp8W3OetnE1JZWEGeQQKJN9fMeN3uDsaMKgDSYJaiL+/bt23k3300fn7aoe0btMjlhC6o4+l1Eh0w8xGgoJ4ieJcMMEbzQAVIVxgwcxSPWMjDozuL8B1G5HAdNDDi/wj+lbcRQHZclqO6iOIHilEM85dV4oSpqDETlDlE9yXyXDeKEZjxi47bBr9/78NAACBam9zWhzM7aXoN/j5i9IWPrQpp8+dzeZcE0+KGjo4MrYt7cpqVELsxY/FpUxr/JnVnWM570QwwrX0zQful38O/SDjMhLxyzP4heBJB5iQ/giS8+yAaDQoMiCc+x//ACRXjpQb4GJ93Ib5yWGPG4LkHlEUxc3+Fli6yWdb7nnM6LIRARQHo9QrdtyuwxcO9RYEc79cM9erbfPheGmbu/v3iXFVe8rbO7vQ2XuI08TlhEgSvwsyjnCjyRD/4w/Aa3YYqeiUQpBgS/hU+kQe4u7cxd6ONAkYbYpFT8Nz5uQ/H5Z4o3iNdGyumSYklADnFSvTq2LzYxiR0hGb/YS3n29QM0G8xIM16EKu6+3FQDxOJIfxhqnmKd3oEXybZSbQyJtiaTwR5mapn43jCNejZVDhW6Jn5na78x83M5sJfScCkXxaVIoFf2yElmgsKHoT2sTAb/WpxwRq4mcmzeRYs3Zf220eILyHjiYqRELVUKkW/Kr6oKUe7UymXIv/Qf14GMAWVVFDYrn9z5Z8e/67kfQfpFhEbL7PKgHSm27Fazpxg7JUdViR5Y4T/7wjs657a3ZcuI5cJ46TQTpAUm7QEATaqiyvJbManRgjwt5M1oudknrzs9qX+LbDq/xvgXEjBRHLdjzgEVSvh0/TnRETOfD3JDkaYffZDS8JpCCOOUPFZC+EWxGsl5VZ3ACK27SCMaYXgMOHz2hIsg3Y6pduU6hMZtvtvMnhRFqDfS3Qj7wvT09NBvYu3i2S6f2xcJznzpxEuUjOqPGjAmvIBq3Qjz4MdsYPkXw+uOdEwBhhdzEaXfWMY0RrrTiwssPxR2GcUdds0iAMqVd59vELNPRhxLGihked/H+Eg+lof5qAWRH5UvD02U8nPAMh2e49wDT1C9UF5Ffjjvsg7svaUFTrg5n9RDNZBTwNZ42yNsnUpodxo9I9aFpMNXIpa216ZNmyBfuoWOSXiKYwxqZTC0ByJ+jUvXrTyQEZjFJPoRw2GVwC8BQxQWSGJmtiMm9aiVvYnzhCI8xUX9I+M8ozhoEsUrW/IVNnmwZhh1Qvnj+OkVuBBvyCvQiCXiDK+LxeXQeaJRMG4D+/uYw1v4y2NiwUaDPKtof3LbI2ZPM3aqF2t3+UydIXvoSzOX1mpZt61dwdjMQl4NHFTJGTEjz+AhhJN+NB4jRo9ewQqsCuBHCZ8uaz3Cq2UY5RGIQRWLc94JPcDaGDpuDIQ7UFz+ORMsSmwc5oeO/Q0ITQ94lgdRJxjyR3VExzJEdQvxKGMgjEwuny0T8ISLTm+xe7Wzvr6+RhPDFAaovU2DcM/b7AlgUyZZ9FDHARdUIp/9Z+ykfb583nwZeYm0Bv5Ohyl6JqUplHzTxP3HuE4prsDALq9YcdxwWOCQRw67mMu9xEfGUzsaMSAKJ9I2VCbyJ8IbSi+U0wj25gmjKBexLcdrQnyIcmSh8M4+pEt1I+Vt6sHkh+Y09rpi6TS5YAMA6Xcf582bJ4kuixplD5g9sUBDjcYFWblypQZ1tJyeL8ZEhc7ZetmU9tpS8BqoIqAnQ5JFecQGqnNBmR7T4AkHACN9WhhxMVw+f+yfZF5gZ490WTJiY2CmdAuHFCfnjexD3oHZnXoQMyIwy1KmQDwgivyAGIl8lKxHdJ5FunxHrhgg9hfL68Ajka9gLg4EOZyy09aCR/dtHfh/d/9mSK6xG333J0lpe+l/twJ8tzO2ENhKaeU6a91TGdwgAH/IjOblviqZUYL8WgQVxydIRuIjzYDCBiYPrzDGyOR2gljelKuHQU6WcSGr85BRyDM+lJqcIBsTO5erwSEmMHTM4IE5ZfmIYYFHj1jzIeXluJUCWxvB6qDT4HJTPGJkKPKaZdjx7nOmLwMoiRuybSWoRQ/acx9o2t3AJjopMk+7+PyLBPT2ecl0dXVRGLj5k7NPbKrZF1hpBc9P2IjR6IUAOeMvneLPW0mMFKx5rwlvsJdhaJO9OC4M1CSTZFeIw/FvkqG9JjK4+0kdBjYPezZcWVC96ADixQK5Ogo0jNC53q7Ww2QS/Tko/u5Q6crLIhXSIBG/4c51RuIK1VWWsTAc3Fy+bb1ObXffsMk1WXI0jgBsLy+OJAEDu1lDsrt7iu61wy3IlK5135779xNb8FQbqF73GBHMElg2LLZYU/0c8oSlhRCyD9nWr0qRe7wQBJE9AEZpgDBSP55+rSuEiRdPwgJNYGXnS+ZD5wlk7kReUotG0l/Vwg3dYzv7UJccD798ZOe5r3j3Wtqrrfdnp/Zrg/5twkrQ7wzyPTV5xAq74po5c6YGenGteNf0bntiEg/bYQOcZyFi8MBakl0kyzm5AwXrhSE8iA76hCjvF6Qaxav6UKWDchQIk0/JalLsidVzgq1BsDRSnjBmTR8ljUSuUgJj06698FpcFo0aNEIhS2+ZGLHECEH16/oRa2wgSDr+bgTzuzLN72miw3U0awOUWbywF0oFt/cYdx/P7r6Y4rgirQckQAzirXN6XvOtudd0TawtUa9kgS6vY5fivDkAnnggiNfEBDORfIfMeCFO5yTHgtCSkkkj5hJsggErkGROlQ/S8kUjiaEilHPogsaMza++idrheuA0TVRiOUoYwwUHSNYz5VXMBzivlHdRLjb3/HrHuYsvW/sLCOycWmpPMbe8/85sbc3uYmyseLbGKHtUzwW47WYnC2pv6wY8IlZvEb6Z4r4o4M8N8WzGExwl4zrVWDinFHk8Lt7Adgn64RVZt+xwGnbBBRkXGPaIkv2dXSgdCtR7dsYsyAI8EjFLh8iR4vGTTSCiNibosjlFks8pKA8UIT4/vUTS0XslkSsnBEgjqxdDmRHFiOQP2fEHytNE1eUVj5jbfCpAaaMTJtpe2hnYjYCWie62OEgAW7x4cSbekiE/kYovnzDWent72e6Zb/esaG+1m52M2TLQDv/z2yPh9ocX47O9s8xjz74At2yfDJvzqxgIwTBdHNS11szsXIuTWjbB4TMfNYfPfsTecWbXM8Znyt2E7CjJy9rbdYu68cKFoG3faCEeR44YlZY5TVRlLEL7WAO3GTFeREwqmJn6cwgrxxPKh/wd0pQysaRkZlrvN/k7ShdAl1/K/BwWWDDuvfTa547/4g/77RdQLSunzh4psbZ9ufuDH/yg2V3ydajb3WPoDfRU78wS96yjo8NuT82ufdfsngte1fqdex995dwf3PPH+PgzR8LmAQKxLWmdn3MIioaqM8CtHxqQ7a8c7HD4rEfhxBfeCi/uuR8I6EIEcJn04gvS4OteTsfwdjc9U2Mygui9VDnnMfFOuCCm+JHfh5biSxQnyHiDe8BTqFsFdk6HxiUWcQS2NWYkaYYaQT+Z9GURk8eyrBUJdrn7hk3m6rnLnrSH6xRgzhff6hs3bjQzZsyo57rsRrv+bEL13QXu3xXY1JyAgYRKYgYkQC1+N537RzcuG6ov+OzmgUnuBFCPUGOYmxWIyc4/M4sbBra2O3zWIwXAT3vJT8zhMx8vlTs0YKyN8ElKmRPLsndgeKzQRBjB9CBGj/I2VSnPG5YGTKSNwCifEuA6jzIfkJpNqHzHZZL5jPMT6gVApjVUh/721zx+JJRl7BRrg/gNsBtl7d8J2Kz7ieMqgGx11/7b50m2psvqPl9+7BP3IDbNteCleA2E58iOgMtuntU18A37KnWAWV3Pwnkv/545cf5tMLvrt9SPnCzJZSs3mhF+tPIvTPDUzBckLyqZQUTshnyWB2JqLNwz1Eo+AIjyTmmFmWMZwBLb3C1KZfMeAGI/oE3Ir7S965F8EvnO1fJDqATeIfHb5Hptk69Ka5DTfd8BOxGHfKFAiyJsl4sgTbkIUtif+PL7L2ib0P05G0gDkOwitxJQge2C/xTbm1KnsH/HHvarnMX/w5z2kpsUW/rCKUauZr0QIh6+eZgFLOE5FgF0fOkRozw6xLr0+AWJEF53Utk1wwgg0wv5imOTnZjyKUenbQPm9mlnPZ76GkIVaxfP9mSwG264QX9S8HmZ3QlsujcCdelNmVe/4rl7AGtzHRhtcFMA0SGqHgDL4HX+YvaWYGffIb4obEpkAZg15Rk46ffvMOcv+kH+vC6a+YGahFFhTQqM3l+aBRPh1Chgp7ESmJq/GcwUljJZTIGDb90JfEEjaUcUEfXs1gWpc7ycR0rTTzO4U3B53dO9j+4456S3r6IFG4B44UYCWwMchJ/0QDEC87tsgopED/+cYuxaviADW7Zs0auMePyLbzqxrXXOxbIZOUY9AEb4cWjQ2UECufAXwB78Ub0h/czN5u2T4MGnjsLrbz0Tn+mdAUce/ISZ3LoFw5BO8iayAEvPktWi3xjCOTZDHuYZvOhBSODDUrloG64J/ig8Itl7WyGCOPqUbpHgHcUDIMsX5x9i0vbqv8hCpEtJtDVj/6dv6P0ppE3h54gjjjAbNmxIuaP093zM7gB2lvgtGdt+Hk5+FImZe96RV19jZesQIREQRWfUXRoTJZpyC2BPZzzuAME8svYwuP6W1+DajTOgfeJWOHjqOu/Mh+UQsDxnBfDHQEefeWp09pfsELxxOoQHHR/yltWwocrdq4EaOAFl/KZcIyF/dKHf+CTTjPMIqrzuam3JjtjcN/j1Ox/mk3WIhcETHShQx4NaOXO7ZJ4vsClxucCjJ4mpZ2bro49acWhn+0s/DECwwih2o4GLOnmAGPAm4S/VIYIblupQ6gIRHl7bAz+6ZzHc+/h8nD11XX6tL7AshguxNRYUPvxxan47qNvaCsAUWlgaE2MEw74m3kaKvLmKT6+S4OVtr8V/I6MK6SAzbTgnyMdP57AFTPvj1UKdOH866VDGKJrgr+XFR7Xu+Oy3e2+LI4IC1ODEDtkAVYBu1IiV5ndZeUT1HFGjP+me3PRzNuug85brMpHQmZyTgS6dK6+JxDFgwTYOYSpiEAMzOHEx7k4uu798bD685dor4f9c+wF4pvcgHyFigukESo2RRactty4JI15siI3YmgsoSJGBGNm7NDBsLY3YNi68y6Ph6o3TFkwv3PXoIn+LkH5UCPoTZ6Z1NF0EcSVBrtfm3zlGZEaqAFzC1kjM8wE2Jy4/jARKBFm9erWu4cK9vb0dcrbubsomL6U8Y9wQES0wcM1ISifBLuwwE+7aDmS2S7013E0B8Nd9dAX+9bfegmtzOVyxlvGMGMRg+lJXeC2MzhqL+oJ4EdjQq2f+QBJvx/7F8j7J3kI1wcWgV70wspev0RW9gF9b4zhEeOSXfI0fScifKIORZXTxItJzlmHnzZ+bs7BUlR4LHiOyAfQzwPNk7F0NQL2HVhlBZJTuEtB6wljI2n/4irUragWw60pzQc/25vTSTrdNmhAJ8rK2owgmtCikNmT9OLsL/zIPJTVjPcqTtLM2rznuZ3DJqd81s7rWAUBQ82HFAkupMtVCiLR3eQhxJJoCtV8ZH5YWaABkBmX8cf6Cmo/io3ByNIrjCGWJNDr57+074PZpZz58DsR67OFUf6DsOEoYodlVGZt7lf8YUuoqvh+zefPm5EpjztY9ne0vWZ735850EhXUjDQRxAalcywXxBOVaxXSQNXEUoRHOQLE5PHw0z3wzZ+dUpT74GnPweS2rYp3Mh63MRwTwhfKOWE4cQ38DjDvpmXgjL45GV5YloI+sTUGzY2vPPKHsrB0JFpIP+No2LsMhsFR2iW1Lrl9c3M295TjJ9923Y97V0HayEotgtsj8OyXyCx5+j1Hu8zau+JZNhklJIcWydp25ps9++yzDGp7VsimTZuyV778gQvaWg/7XMSQRjE2sSoIhmV/KTtTwbqB7UN8cnWzmu2lv1JeSmkA5JNLuPiU78GZx98CMQuSrpeMZGAUjBmvZUqWRLX0ru9V4eI0UeUllUevY1EjjoyXwqT8VKXft6X+pYPPfvivILA2TJ06dSjXipCOO7WHhHXaYgfOiBn7+Ygi8jl11aBaFMlOeWVvvnxemxuLDCDECjdZptVCCaxqYIMSMcogBkh1AHpWy/dRhyF/dSivgmqwg1UNwqcvXAFHHvKkSQExgFRUpBINtJ0ME+xNFD69simBVxYjgr9yfsqdMvWsOxeUOpp1r9frfVd8acNx1/379o05uekldglkDW5IPI/I7IoooplasnVJHIEysGuvfPlDyyY0T10aopL51Hk2IllIPMfZQkx5McIOS3ZxEBP9rxZT6LlcBmuzadtEuOGWxbB2wwx44ZynoKNtO2bhICX3SWIe2llbR4KJPySSFvDAzzn9q+6smQD3bd0ijH+tnV+8cNzGjeP2roNLH+WhExjqIfz5b/vK+aUhz86d8h9qIfxy+UIIOfT+W459QevA52/sv23Hjh2iEUogkG6phh8xEY9UK9IoQlORgVLG8lXG5aI+ITSsAQk8Uypbqvxx9mIVlo5T+ERMFMD7RQekKBzGOfORiByisHP5tDY/uHMR/vk1l+MXf3ym8RoOoXnwimlfS7H2xNkbEmzDITlAx7uJvgBBF25I41E8EO0bwp1fy+HhAOOeHY5Kc5MZI8vJ6bl8iXKQrt7ER625/NB8wfppn5ydls+7Cqz7I6I55nxOBkL1p7Hjqn4XzUgZW/eYyhcIANJiyCuOu/eMlpaD3qBjNAJIKcjJOQtTTYmVG3X81O94ZIvjG44U/AgRMXycDnWATdva4O5HjsLv37kQjnvBwzi9YxNHHjpYFnoG22t50v2WK4D0potgf6RRwIXIok5MB94gqznF5A/knJLj8WlmAGKkCOlDyt7EZaPekwufGcx49fETb//7f+l7Sn/mwx5n19/fn2ogyVBppqowI2VsmZB89adIsKenR7Nz8duf51bYTZz4exfFMaaAZ1LRsCs9lYKWOnmqDnzXMKaBncRTSszzjIyYTBNLeXEgf/q5aXjex6+Av/z6G83TG6cpELkhn377/6xE83MmJ70WCPTSvL9bF7e7yYnZfnSgXMdLBKJbUe4onaA3d/GGPADbczg3vkTFZf80SviyhQvhRYdPXK4qCNVVrsAymY7I7KqMnQIw9vb2pjJZy3tm0QmOeeGXu7s6jv1wHF1qdEl0WhaJJfvILMT+MSG+ICgCVEbKiwlXjo8m5mmuRkiNHMgMCvDr1XPwpvv+F3RO2gZHzVmDgLEajQRaqQYsbllgWQI7+vcnmUFJBA8yis9QJkYCCPFicHMwDINwOGNFM74Q81krGQ7joTRixg6uzU3ZnPWbzZd/syob8LJ2leE47VbWlStXSnuEEZiRAFv39yxxL5h8xowZ2datWyWrF37+17yvfDTLJhwNgtO0XB3fBRCZfQRgjCmFk7IuGCPsKmRtkUZQB6ZGwzjUSOo1NGxgeUojF09ycL8I73rkBXD8Cx8x7W3bXAj+3AaTqE+OdMYQDfwUO3hUA00OaMVRxMEai6IzgI83qL7BTxiFCBL8AuVBpI8ibhBxUOkxTht4ZAJYcGTrjr/5+tO3QXo4LIz9yoXfIGU8qEcEZmlGGoAGqeJcIPptT/bJgZyJ44BLq4w5Wx/aPft/3xPeSSQw8dqhL1J55U++RUNhpe45qArD3mypPoRIpRfUd9xNeHVT2sX+orxGakbB3fz2Tio+UltCMt23veZfzFtf+6+cjlTnMSABvKiRsgOl5/YNplYvYxWeYnD2F35p/xQmpfcGkCuRJuQA9Fch8pYy2D/55AeKV8fytQ2Tq/+Gcp12PQeyVvdVvhspsw0VZiRyi6isaIMFqMMm5TOPawcfdNZlwEO980aA0JVLwWOtSMKP0T80M8f1YIQdqrQoxSpjEiIHVvIBqmeTsIv9ff6Hp+HJ7/sgrnluKqORxBEJYBJbDLEzJqcaBsnNAB8dIcQdQ6ILgKilwPggwYhiYZN+UF4A+QOrBlhmB6D0yJ+vdTq2odg/8vMvHlnsH8lBXQTJQc3jAABnTVecdm9oGgF7uNYr7p6tjUq8SNjK1s1N7UurQhsTRAjDbkrMoIUJFdw9o7LTG6oQoLKTiLrBcn2hSiPYxSJLvKPNqPgxYVfuKGuemwInv/cD+PkfnIIMPHEVwMj/1Z2oIjQhRXCXgywDlrXjMhmJUJRfiCCPBM4IjNQmtEfcdzYA4L22lBR/jE22JWWjqAMj83Z0z4TLfOXYA+O5gu0+bSiTpKw8SNgnzXCMzYn4DU+MklwM0f70HWd0vXJh8QM1T+p8MU8Jdw8KDD50KqQqlNAv68B1OlGxlMHS711nbJ1+qp1M8vnz/3xqDvAr4M7fHEHlNR7IRUVkdFAnEHtmfmLp1H/yCDbkwzvp2x6Cdxjo4Tg15IM8M7HdkPedGA7PbOw7FJ0BziX3x8KxG+XJp5HfW1uyEy45d4ZVmWFfXx9XUL5CiclGAD4OTZqGrI3DuEkmlv617jpLXaf/wdZ788IUb8iU3lcEiCZtYVnb20XydFFsFhrjpW5TWtaGUthyfE5OjveNpMIGWd1EfiG6h/icCFovxefKh8IfQKOtAW/8w5/DG199CxwyfaMhaTXIxyDkED/IR/I2+yB778eYUMcUT3IpnlxlIiDT1nd25j0kYCjN8DuY9b1Dn+o+68GrbMN2dXUN5Zo1664P2AEoL7VzO2DpeORgRsLYVDDR5SM3Nv4z0YU58fhfnJgVL+lq5koMzZGWI5QBI3/IjU/xYWl0olE1HhWkblf6ZrZHYRf5M0okMeFStYD8XzO2AZmbuEypanXm7//jFfD6T74ZvnvrSz37gUMgMpQ9gXrG9qIEv6jghBpGN/qK4fIinTceTo3nHAkxB8XxaYQkVnGgF/5IDPGdCOl1MuqQrOMO15SOWiGi2v35OaiTI37iNxlMz8+CGdHk0RDthZbIIDGu+16H9qyQyW3zlsTRaBCK5kZV6mi4DP7L8flWjjozetdyenFYaR27o3gKwFfFNaYiT9q/f3ayJkhRyYEyjgcxpLF63RR4z1fOz68luDqXw61n0tfRsF/UQkZnF2bIXwYDeUg4cIfwIoHLFBXFdQoGqPNvjExH6P4gdBZR1xTe95Mg64fOJ/XutRrOufWr8xbmE8gIsBCD2STcJMNUorsRsJmeolIFt1IvIsa2S6RNTZNOKydr0r8ia59vE9uUTaBKhCzOsonZ3jWjiQBL3iN9tk+31CWSIMZ0WSr9aRIKoSpbx7t/95aXwJ984mL43m0LIuUb++LDOoW2DRxLewASk/pwHnPh6wxO7DIuLqQD4jkd2jiKQhRgvwDRV9douT/gh1SR0t0+dU/LFnFmq6tBNm4FQ5XNcAs0jYYIfnmAnrdv3+72hbzsjkWtE2a9yXfkykjTeTMlex7+pDCXDK7LXtUPA7MaEaYs2pjIXScoVzmrOL/aqLyk7JnRETZtbcWf/HJ+rhacgvN7noGOSQMkHYT3GYgRs8COrHfzEAwvMkDwXyzqZBTWwc97Rj8B9aQO9KIDs2/+PxOvhFGaGSlOiiC8aimOi0Bobq51fvz/rf0aRDJeCQDybhIVlTS7sv6e+U9uGAiiiPEqGmmwrfXQRX4MAjEAQpq1UPyHpJ8iFq9WCxCUwNdl1oIJCBAL22jISAHYa0CUWISlVKqoo0JcEfWSBrh/TowU371lAfzJxy/C791yLIVHQbeON6WWO79b3GXIX3vnDsGqVLY3bvOJAK01tN0WhJ8wAtKZzcb7McKvjJtGvyB4Ntfg6LcvPahDeG9kMOHneYkimqWtoE+tzxT47LPPovJvmmqT3BAjdLwmirWiwSEGYmhyU5EtFYDjMeWw0egxvGgR5cto/bgMY1SuJItXjFfDijY6rbjTrV4/BS778vn4nr873+rAg1o5o7MVPANj6JS0SBJvS834mWmaJ4YunvjF3gxdvE4d6M8n919JpvQyDPFEIwaEeLycnj+/5byDToe4UbNExaQqP80l3uzS7j7//plMkN2kfYbNRwcvMRNhSSRIM21S7mamqyqT7mMQpWeiPFQbLMUlJ32aWUV5UqMCggonRzAA3W2Dn7JYpP1855aX4B9//EL43q0vAWC0Zhgn6hCKvOpIXZwYhsUKnhDy5NJXOA0IQnUY5c24XeK6ABCr/vQ37h3TH9TVfMIwBdUVkgJ5yTRV2EtW1vaF6enpMeqT0YX/F3S/t8PuJQ+x6GE30WiWS3gAq8deZVbCPoQgjBj6VU8WIV1LjTq7HJR0bNJP/J/CGRhc7XTupi/XV/cL/bbxCxBFg9ftiF3oeHM7e9KsS2BOua4wkadQ7WvWT8HLvnQe3PHfh5t3nnNTrvfuNbRgEvozsvbEzSJdLhh4KA/ICWVkJTSKpXzXfiTDRHkjFg5rDCSYM6X4VIyhPtPcnB0jClWHGLiFJ/sZxUcffXRIVHS6kYSpAnYRqThiIe6iUCylS+DjlClTYOPGjTD74HOPBs1aIj/llUHNgNouhJVF4XiEnRMbqaOUyxxrvquAG+R3aeduQ/1ohlYNDm1/yJidfUP1TQ9BfVv/pk2/fGjL4JO9m9Zfv0lEzsEnTZpkTz9KEYXOQi7und0+YUJ3Z63tsO4MJ3Vg1jEfsXmuPQouv8/PEdEBpbpB+M4vjsU7/7sH3nHOT825r7gv9uHZNtQSRNMGk6or1wuAcIZ+o1X4Qq8BYnkZ3KWVCXdqOA7GQ5kNO6EZ5ouCcEyzZ8/GtWvXWlDDhAkTqoBcCe6qipZdUV/W1HziWZ54Nn36dFy/fn3Nrvu/+Pf/4xUdk475PkcTrQbK1UNXlniXnknahZdsw5cNyjvt6lDepafToLAN3kDn9Ox98KF6feutg4PP/ffAwBMPPv74Ox6y4XKg1v0xXQDpio3scr0+5ipQTcXSHqG64aL7tFnvnNPc/PtHz5rRcsK63uk5KJoWagI596T74B1n32TmzOjjcrLOmVcnQQyBgklZXJF+RSCOJzA5+YnDxiua8e7D+ND6797ce+yfXPHIkxCfM6LPHJErkQDVLBhVWMpeVrg1vGPPbldduXJldF4I+G2qr1r06J9MbJ27QlCrH3uHQk6ibZ4xEOnIBKqM2A6Bz7pmd9MA7ATS8nI8eJ/BztoM9Q/Vt/54cMf6O55dd92P16+/oR9iJklVZmp4aWSqmBt34Xc0XB805zMn1GpzTq3V2hYaaJpfyDTTe3P2/k8L8hLQjNr2CmQr2JwAG/yXO4Fax4cg3hCIUx0HIv/29wOPbXnt8W94SB8UXyyv2xNZczFEgp3KrwEemZGKImyXq/zAf6lAG9dg4W2P4GACHvQgH/ehenn4L51d6NyIdVOyb3g2QTwR6bmK5XrpHxrsu377jsf/7de//mN7nrNlZOMZ2UAaxCYqc/BXJV+hcq9DY+Aa+8KrPxxfuutRtLD/7ep32XwXhz9Om/X27p5Djjp11fqeJZd/6Zz5d/76sALguewdasBLCsY/FwkajFJCXh6nOgt544WWIjxng6RpBF7IQXIx0cISLW76LQBTOpq7RV1FxoNa10FDtg4pN7ZPsbZ8cTfa+HTywl+f0dZ22Nc5tJHMGDpcnQ+zMRBvKgLFyEL8iNylyFAtnoR4YnY29e23b972wKc2rf/+A2vWX98H5UqqGvKKu32f006u/GtxABXMPXXqVKg4A1rWr342Ffb0bM9ApP3MGujs54zF/+fo+578o4vmztx2ypv+6M6ON556BwamhYhFU2JEzLwxA0u2j1ma4kTlBko0Ac7LmnUDbzv8tfd9Ezxbz5gxw6xbt05uiLKnQ9VzrRwRQhjWYfhKhQYVyZUF8cu8/KYM2S889mcvmjr1ZT/jICYe8oGAxXYegCXASmATXEOYclgdh7NzURHwrajRf/2mzf91/cMPX/gQxL1fVhpANVOn7Kt+S5ZNMU/KkJvejyPvJTsPdAly9vvWpYd0fvf2j5x22MG1S7/2/m/OPWTGRlb/EVhj0cPtynPPRVY8CCOI+1/02pgxZfiD6EDADC3jstaPr9n++vnn3f9DcKAeyrLM5OsjLFvbLdK56DsEFSRTVYkjsZdAlhWnl9XxqEP/cuoLjvirxzldgwrYgUELFHl529ZjXbJqgsVjYNchZvH062G+c/TnE8AvP/Pbz39pzZqvpeRmfZF9iR3yibLJJ8oACuB5g2DOMqWKFvZVYMbcD4iwErDDAjsfObK+vr4ifjuK5M98qq3YYMTtM7P7uiUffNO9l/7paffM1RNDEbWAZ7Crkrkl03sbNam0dlYPWI+gTwz+q4e3vu74N/zKftG3atuqEfYgflcSRKO9IpI56HfVxZX3XN/PB15w2PtOzzM9M1hr4/NFhQbKnc4vqgylxFkRJ8blzCsyl583fH7NM1e9+TcPv+0/N2263745q2fcdUgfr5UCutm6dSs/51ohQ9qO3F77B28/7Omhwg8k0rVvlkiZP7oPDAxwWH9eRxF2x44dKXYzW/q+/9CPfnbXlx979o2rOiY3HX3YwRv8mkPRfBi2oGJ4BtoA5ZrbuQOEM0eA/Dh794+shfqPXlwQZ5Xk///hp1vf/9Pb12+HNOEUxh9UWTyLwyorTRVjg4m/xFlMIvMr9YZ66WWDU1757Hubmzov5+xBYGkALWoMx87Br7vLD5gOAZFH9JHT3AwO9V+/bsOPrn788fesytVqBEByliAzDZ7pLkUU6QYVfrHCD+YLW9xAZFJ2UD1qRs9+REDt7tcVtNioGdw8/sMFFx80pfmiWg3nUrYlgaMSQuSaTVEoQ75AhE3J43K+bN0dew8OmQfaF93xCghEI+/DfTJP3isrq8qkmLmoGKs8z2etGth40nE/e3FHh5WzUYDNBHlXydtlOylHGxWH9wME8rhTDNUHbtu67aFP3f/g626F8tBlh+66H7qrQAyictnYI7hWr1497BCYiCclWoCXG2WY9DAV3DARJ6j4rdFqKfTiCrnJzlf4XXrqqYeuuHzjpe0Ta0uRVxdFYQxIrUgR1PDCZBBFyNEY/n6Dn4jGYRzr21fBALdsr//t9MV3vA8UqHNs1b1GRJKRy44xw36eelde5i0xkErYWPnTPvz87lf+ytQH/qUcpcaTbOuobvx029urMhiQ+PIe6ztu27TlvnNuv/uIc3JQk07UeqLDxovPseUNrHt/veJebBug5xzUVawhLykbRn5yNWndvyda2Le1tZkG8TSK26h8yoa3uy1LYlZe5qIO7CtY9p6rEqM4r//Xf33ioFfd+Y6v3vjM8blk82MWE3ifiRBBfJ0Xx6CwXVB4WJBn9N0dL9GE/yB06U50ueWXvX+bqFdLmMXdrplAMIX7lVdeWQDHRDrK2AzH2Ck5G6CB2i9Xb2Gu3spedvS3u2fMPP3nYGqdDoomEidcLgVjF89yRRBEGJOwc/7ype1V2wfWXH33f51wPXhQ+fMqUsCQIkWStT1TpHqcFvAjdysDCrkv5Xcko6M2HMYvism82I6XeRFGsrAOm0F5xKU7en15NI96+AfHLz1kRvNlTTWY4yb5CKUFG6RdQJbgEXkblHx2UfphW3C+d+/dNHjVrJPv+jiUO+qI5jvQYOQcjrGLwHKRxh45JYxOyB58UtzvfPC8JzdtuuvM3LrPRFGmjPHErEbcaGLun6n+6oOrtm1f9c5f3NH90hzU/wjiMxD+DGbLUHWIPw8x5Bmtiv3qnilSFZv0TxnLQW18/aQaBhLhNeMmChvSUHJm4ZaDuhGLR2nl5R5K+fGHQcpPQdePfO1d/zjphFtf+uQzO99ZN9mqIlFB4uqbk24rKrUdvaIWXgdzbhi2rFr3zdvh2hzUn2hQRylAQ6KukgZH4KbZABOXNZq9i/srX3LzMZO7jv+H/Ge3w69gZiB2Vm9tCxYPiyquLEP1bbdt3/bIJ++67w9vgzIwioqxe1aEyFHV2wHSDBDJ1jkTGw9aVGFSxjSwj4ZUv6prRN0Vfvxnl+3nlzG/63gk+3OcOZtnns11G4H+nQOc9tAn21SsePJVMPjMCctrmZkbGFmrBEnGcOIIMT0XWDD+xs05U//BHZ/wJ0ClyAKg8QQfYBjGbghstZGFNCO60uwkEv3wrfXcxXXCghu7Oyef9L4sa7sAQE4ATQWY2dWJG/Xttw0Obb31f9b8zZdWr/5KnyosFzpn6OIdvlwbUK/y0+O220o3UH7lb21kZbocuzqiukn5Iz8009IgB/VbN5gGqKmwyyr8lcBrz6Neu3YttZcMG7VbDnKQIL//2wtOn3NQy6mTJ9b4ECQjVhDlSmW8j8T52TkIt951f98VJ7/5gftFHdrRBOSCjKgHyeSQsK80uyL3pVha32vKbwT044/9p0PbJ718UXPWcUZe8m73yQ7sJLAbGFxVt3uY6zufqsPOp3bufOb2p9b+wy2rVq2QYK4qdARgq/vNKyvF1pB4rlLlVYE7tggEoEe5YRtAhZdGdiB2TO3fSYTT9hr0EuTGg3wkozL/vu3rCxYdNrv5hEmTmhblE8nOPP/dTRm025IM1Y09Badv5876AzsGYfWmzYMPfO2fn/3Rh659gvYfSIaWV0qEG0n7lcxIgU3snRrq5D01USldXlTQrKOHeoT08FMwsz/qgeyGAzwD16vZuFLyIb+eD/mptGCY35IVRwTghGkUFoVaC6vCeqBXMbkOm1W4axYvuVfEWTC+X+UUUccA9CuiUsSgu26vqlE0iYNGZsTABjXceRmQC+plUQnuqgqSlSLdZTo67UaqNhihW2o4Q2Uv3avAjsP83h0milMtlmnRRrK4FD8k0BuBU7prkqryp+11vqsYNgXi1KXDDEc2yYyMxFQNd3ZylSk1Vwq4+kr5p9+pQlRVWFUlpuQ0gOqK5jT8JJVkRCkT/67svLtMqs00iNlOTEKle0RSUO4AkbbMy8CVRJSPoJkYQSltuqfar3IOBDAihh62DXbl+IVkwnY7IZQzWSwTQ1l+ItWTnChE6ji65zNmI34PQnnBRV8yPnomEzGEUMnp8smTTAnUANUVvC9MiuEQKljPalig3AZUj6W4rB4fVN3moAYVPqr3HNRVX9zVaVcBubjbUZ/yrdTKIyXg52WKyP1qT7EY4/eO0GVfWqjlK2zN+d1eE/KrJb9axdWWXxNzYE+y9/yapK72/JrsL2kvw7T5qzXvPK0+jRaf3gSfdrPPj73X/BXtG7flEGUZbogdLUazabTdIQcL1QPVia2jphxQVFdFHebgpjptmzNnDtX3RHHX7TNZ3bndxJ3CExaozai9auqS+5CqRvzdajgBAratMF9pTeLiioJqkOtLVoC8CMSyUlpU/JQepZ8ENIwtIKeMJCD6LUUMeUUAh9BuETlZoHuA67abCNVtGbUflNuNCUhgR7fXXgU1QFxRdNc9rsQEuUZigiicBrqsNG3Xoi4NaGJoTt9XVg3KFQSwFytsHxtdXmtSOzIlczO4fXtRm+m2o/YrmB3KINbtVjWiNiVGEplHmf89LpJwgkIckRVVxQKSWVMVpSusEZBTgNaVQ/kjsWOsAzllsOK5ir0bsrgXNTXgi2dFXFWjqWyziIyoraCxynGPmiTzEXiILX1Go0pSMniz+B1d3r4JVC/3rFKqFBjBMMZvoR6gRswrpCmApEAlSULWtwRmc6Orol1To2ppPz+kR9i9YlJDud4rkmIAe6cCykuKLpopdC+vkp1xmGvclE2qDUtMLsQ6ukptqAhHt59u6yJe1Zk4D4KA9mnbyWFeZ0j2/hTYo0tUju4MI5kIVgF5HNRlkxriGdiiPXX76QmnFv+qyCyKw3eUVHvtV21VBSrZExvJcrJy2F2xREqOH46dx5l6ZKYRKXBdqzlK1F5C5KwiMm6vDwWWlvgA2I8Bbk2ykvzQosGZHAI/FOvGU5dMK5XuuHl+BhN3rHBPEVZqJE39xgbp7rY23FNAsPHqpWgyep9FypiKOIyKf9zsIaP3p5A1qHZQOxN1WyejTvgZdW3ZqDdWyVeFXcUEYpyR9x8z0rblq9E7igeaGa+IsWHG23HcjJtxM27GzbgZN+Nm3IybUW7+P6z8WRm+QkUmAAAADmVYSWZNTQAqAAAACAAAAAAAAADSU5MAAAAASUVORK5CYII="/>
                </defs>
                </svg>
              </div>
            <div><p class="tooltiptext tooltipPLProibidas" style="position: absolute;bottom: 80px;left: 62px;">Palavras ou Produtos não Recomendados<p>
            </div>
            <div id="bolinhaVermelha" style="display: none"></div>
            `;
            divbtnPl.prepend(divAddPL);
            let divAdd = document.createElement('div');
            divAdd.id = "PALAVRAS_PROIBIDAS";
            divAdd.innerHTML = `<div style="background: linear-gradient(90deg, rgba(94,191,240,1) 0%, rgba(10,99,244,1) 100%);width: 110px;border-radius: 5px;display: flex;align-items: center;position: absolute;top: -2px;right: 43%;">
            <img src="https://ramcloud.com.br/img/logoavant.png" alt="" style="width: 21px;margin: 4px;"> 
            <span style="color: white;font-weight: bold;font-size: 17px;">Avantpro</span></div>
            <strong><p style="margin-bottom: -8px;display: flex;justify-content: center;">Palavras ou Produtos não Recomendados</p></strong> <p style="margin-bottom: 10px; font-size: 12px" >As palavras ou produtos não recomendados são aqueles que não podem ser utilizados/vendidos ou que necessitam de alguma autorização para uso dentro da plataforma. Recurso em versão de teste, qualquer problema reportar para mlpro@ramsolution.com.br. &nbsp;<a href="https://forms.gle/wF6ytWq89LBGd4RP6" target="_blank" rel="noopener noreferrer">Quer sugerir alguma palavra ou produto? Clique aqui!</a></span></p>
            <div id="palavrasResult">
            </div>
            `;
            DivTitulo.prepend(divAdd);
          }

          var DivPalavras = document.getElementById('palavrasResult');

          const settings = {
            "async": true,
            "crossDomain": true,
            "url": `https://ramcloud.com.br:12998/ram/xdados/MLPRO/VALIDA/TITULO?TITULO=${$input[0].value}`,
            "method": "GET",
            "headers": {
              "accept": "application/json"
            }
          };

          $.ajax(settings).done(function (response) {

            let dados = response.result;
            let html = ``;
            html += `<div>`;
            for (let i = 0; i < dados.length; i++) {
              html += `<span class="palavraProibida">${dados[i].PALAVRA}</span><span style="margin-right: 5px"></span>`;
            }

            html += `</div>`;
            DivPalavras.innerHTML = `<p>${html}</p>`;

            var cont = document.getElementsByClassName('palavraProibida').length;
            var teste = document.getElementById('bolinhaVermelha');
            teste.innerText = `${cont}`

            if (dados.length > 0) {
              teste.style.display = "block";
            } else {
              teste.style.display = "none";
            }


          });

        }

        doneTyping();
        clearInterval(verificaTitulo);
      }
    }
    let verificaTitulo = setInterval(renderizaTitulo, 450);

    function renderizaBotaoEanVariacao() {
      if (document.getElementById('variations_task')[0] != undefined) {
        let blocoEan = document.getElementsByClassName('syi-multivalue syi-multivalue syi-multivalue-tooltip');
        for (let i = 0; i < blocoEan.length; i++) {
          if (blocoEan[i].innerText == 'Pode ser um EAN, UPC ou outro GTIN' || blocoEan[i].getElementsByClassName('andes-form-control__bottom')[0].innerText == 'Pode ser um EAN, UPC ou outro GTIN') { // ** Pode ser um EAN, UPC ou outro GTIN
            let botaoEan = `<div class="eananunciovariacao" id="eananunciovariacao" onclick="cliqueBotaoEanVariacao(${i})"> 
             <img src="https://ramcloud.com.br/img/icones/CODBARRAS.png" style="width: 52px; margin-top: 4px; margin-left: -4px; margin-bottom: 5px;">
            </div>`;
            blocoEan[i].parentNode.parentNode.insertAdjacentHTML('afterbegin', botaoEan);

            clearInterval(verificaEanVariacao);
          }
        }
      }
    }
    let verificaEanVariacao = setInterval(renderizaBotaoEanVariacao, 450);
  }

}


async function getEditarAnuncio(ultra) {
  MeliAPI.scriptBase('https://ramcloud.com.br/scripteanEditar.js');


  function renderizaBotaoEan() {
    if (document.getElementsByClassName('andes-form-control__label')[0] != undefined) {
      let blocoEan = document.getElementsByClassName('andes-form-control__label');
      for (let i = 0; i < blocoEan.length; i++) {
        if (blocoEan[i].innerHTML == 'Código universal do produto') {
          let botaoEan = `<div class="eananuncio" id="eananuncio" style="height: 65px !important;" onclick="cliqueBotaoEan()"> 
           <img src="https://ramcloud.com.br/img/icones/CODBARRAS.png" style="width: 78px; margin-top: 3px; margin-left: -4px; margin-bottom: 5px;">
            <span class="eantxt" id="eantxt">Gerar EAN</span> 
          </div>`;
          blocoEan[i].parentNode.parentNode.parentNode.insertAdjacentHTML('afterbegin', botaoEan);

          clearInterval(verificaEan);
        }
      }
    }
  }
  let verificaEan = setInterval(renderizaBotaoEan, 450);


  if (ultra) {
    MeliAPI.scriptBase('https://ramcloud.com.br/identificavariacaoeditar.js');
  }

}



async function getAnunciosLogado(emailRetornado, tipo) {
  if (!Page.hasItemsLogados()) {
    return false;
  }

  let itemListLogados = Page.searchIdsLogados();
  console.log('[BuscaDados] Itens encontrados Logados: ', { itemListLogados });

  const rawItems = await MeliAPI.getItems(itemListLogados);
  console.log('[BuscaDados] Itens encontrados', { rawItems });

  itemListLogados = MeliAdapter.itemsAnuncio(
    itemListLogados,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados', { itemListLogados });

  let rawFreteApi = '';

  try {
    rawFreteApi = await MeliAPI.getFreteDiferenca(itemListLogados);
    console.log('[BuscaDados] Itens encontrados frete api', { rawFreteApi });
  } catch (error) {

  }

  if (rawFreteApi.length > 0) {
    itemListLogados = MeliAdapter.itemsFreteLogado(
      itemListLogados,
      rawFreteApi
    );
    console.log('[MeliAdapter] Itens Mapeados valor frete', { itemListLogados });
  }



  /** PERFORMANCE */
  //adiciona scripts
  var header = document.head;

  MeliAPI.scriptBase('https://ramcloud.com.br/scriptperformance2.js');

  // var style = document.createElement('style');
  // style.innerHTML = ``;
  // header.appendChild(style);


  // insere modal
  var body = document.body;
  let modal = document.createElement('div');
  modal.className = 'dadosModal';


  modal.innerHTML =
    `
   <div id="modalPerformance" class="modalPerformance">
    <div class="modal-performance">
      <span class="fecharPerformance" id="fecharPerformance">&times;</span>
      <small class="mlbPerformance" style="font-size: 11px; font-weight: bold"></small><small style="font-size: 12px;"> | Esse recurso te permite monitorar até 30 anúncios por 7 dias</small>
      <p class="tituloPerformance"></p>
      <input class="inputPerformance" id="inputPerformance" placeholder="O que você alterou no anúncio?"></input>
      <p class="caracteresPerformance">0 / 150</p>
      <div style="display: flex; justify-content: space-between">
        <button class="cancelarPerformance" id="cancelarPerformance">Cancelar</button>
        <button class="gravarPerformance" id="gravarPerformance">Gravar</button>
      </div>
      <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by: <strong>Avantpro</strong></p></center>
    </div>
  </div>

  <div id="modalInfoPerformance" class="modalInfoPerformance">
    <div class="modal-info-performance">
      <span class="fecharInfoPerformance" id="fecharInfoPerformance">&times;</span>
      <small class="mlbInfoPerformance" style="font-size: 11px;"></small>
      <p class="tituloPrincipalInfoPerformance">Análise Detalhada de Performance</p>
      <p class="tituloInfoPerformance"></p>
      <div class="tabelaPerformance"></div>
      <p><span style="font-size: 16px; font-weight: bold">**</span> Linha amarela se refere a conversão original que estava no dia que se iniciou o monitoramento</p>
      <center><p style="margin-top: 15px; margin-bottom: -5px; font-size: 12px; color: gray">powered by: <strong>Avantpro</strong></p></center>
    </div>
  </div>
   `

  body.appendChild(modal);


  var RegistrosBanco = new Promise((resolve, reject) => {
    const settings = {
      "async": true,
      "crossDomain": true,
      "url": "https://ramcloud.com.br:12998/ram/xdados/MLPRO/PERFORMANCE/GETINFO?EMAIL=" + emailRetornado,
      "method": "GET",
      "headers": {
        "accept": "application/json"
      }
    };

    $.ajax(settings).done(function (response) {
      resolve(response);
    });
  });

  let ItensMonitora = {};

  await RegistrosBanco.then(result => {
    ItensMonitora = result;
  })


  /**  FIM PERFORMANCE */

  var intervalo = setInterval(() => {
    clearInterval(intervalo);
    Render.dadosAnuncio(itemListLogados);
    Render.dadosAnuncioValor(itemListLogados);
    Render.dadosAnuncioPerformance(itemListLogados, emailRetornado, ItensMonitora);
  }, 1000)

  // Render.dadosAnuncio(itemListLogados);
  // Render.dadosAnuncioValor(itemListLogados);
  // Render.dadosAnuncioPerformance(itemListLogados, emailRetornado, ItensMonitora);

}






async function getPesquisa(ultra, email) {

  if (!Page.hasItems()) {
    return false;
  }

  var DadosState = await ValidaTeste();

  /** Pesquisa */
  try {
    var url_atual = document.URL;
    if (!url_atual.includes('_Desde_') && url_atual.includes('lista.') && !url_atual.includes('_CustId_') && !url_atual.includes('_Deal_') && !url_atual.includes('_NoIndex_') && !url_atual.includes('?matt_tool=') && !url_atual.includes('_product_') && !url_atual.includes('_Loja_')) {
      url_atual = url_atual.split('/')[3];
      url_atual = url_atual.split('#')[0];
      url_atual = url_atual.replaceAll('-', ' ');
      let encoded = decodeURIComponent(url_atual).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
      encoded = encoded.replaceAll("%27", '');
      encoded = encoded.replace(/\"/g, '');
      MeliAPI.postBIPesquisa(email, encoded);
    }
  } catch (error) {

  }

  let aviso = '';
  let cor = '';
  let linkMenuUltra = '';
  let linkMenuPremium = '';

  try {
    aviso = await MeliAPI.getAviso();
    cor = aviso.value.find(msg => msg.TITULO == "COR");
    linkMenuUltra = aviso.value.find(msg => msg.TITULO == "LINKULTRA");
    linkMenuPremium = aviso.value.find(msg => msg.TITULO == "LINKPREMIUM");
    aviso = aviso.value.find(msg => msg.TITULO == "MLB");
    Render.caixaAviso(aviso, cor);
  } catch (error) {

  }

  // Get items IDs
  let itemList = Page.searchIds();
  console.log('[Pesquisa] Itens encontrados: ', { itemList });


  Render.pesquisaPorAnuncioLoading(itemList);


  // Get items details
  const rawItems = await MeliAPI.getItems(itemList);
  console.log('[MeliAPI] Itens encontrados', { rawItems });


  //var DadosState = await ValidaTeste();
  let classicoTx = [];
  let premiumTx = [];
  let pesquisaSemelhante = '';


  try {
    pesquisaSemelhante = DadosState.initialState.related_searches ? DadosState.initialState.related_searches.related_searches : [];
    let categoriaPesquisa = DadosState.initialState.melidata_track.event_data.category_id;


    if (categoriaPesquisa.length > 0) {
      await Promise.all([
        MeliAPI.getTaxaClassico(categoriaPesquisa),
        MeliAPI.getTaxaPremium(categoriaPesquisa),
      ]).then(results => {
        classicoTx = results[0].sale_fee_amount;
        premiumTx = results[1].sale_fee_amount;
      })

    } else {
      categoriaPesquisa = rawItems[0].category_id;

      await Promise.all([
        MeliAPI.getTaxaClassico(categoriaPesquisa),
        MeliAPI.getTaxaPremium(categoriaPesquisa),
      ]).then(results => {
        classicoTx = results[0].sale_fee_amount;
        premiumTx = results[1].sale_fee_amount;
      })

    }

  } catch (error) {
    classicoTx = 0;
    premiumTx = 0;
  }


  let vetorLink = [];
  for (let i = 0; i < rawItems.length; i++) {
    vetorLink[i] = rawItems[i].permalink;
  }





  // Mapping items
  itemList = await MeliAdapter.items(
    itemList,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados COM VENDEDOR', { itemList })

  //vendedores unicos
  let idVendedor = await itemList.map(({ seller_id }) => seller_id);

  let idVendedorUnicos = idVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let idVendedorUnicosJson = []

  for (let i = 0; i < idVendedorUnicos.length; i++) {
    idVendedorUnicosJson.push({
      seller_id: idVendedorUnicos[i],
    })
  }


  // Get sellers details
  const rawSellers = await MeliAPI.getSellers(idVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores Encontrados', { rawSellers })


  // Mapping sellers
  itemList = MeliAdapter.sellers(
    itemList,
    rawSellers
  );
  console.log('[MeliAdapter] Vendedores Mapeados com ajuste', { itemList })


  // Get sellers details
  const rawTaxas = await MeliAPI.getTaxas(itemList);
  console.log('[MeliAPI] Taxas Canculadas', { rawTaxas })



  itemList = MeliAdapter.taxas(
    itemList,
    rawTaxas
  );
  console.log('[MeliAdapter] Taxas Mapeadas', { itemList })



  //qtd medalhas
  let qtdSemMedalha = 0;
  let qtdLider = 0;
  let qtdGold = 0;
  let qtdPlatinum = 0;
  let menorPreco = 0;
  let maiorPreco = 0;
  let qtdFull = 0;
  let qtdFreteGratis = 0;
  let qtdClassico = 0;
  let qtdPremium = 0;
  let qtdLojasOficiais = 0;
  let qtdCatalogo = 0;
  let qtdSupermercado = 0;
  let qtdOferta = 0;
  let menorVenda = 0;
  let maiorVenda = 0;
  let totalVendas = 0;
  let qtdFlex = 0;
  let qtdInternacional = 0;

  let qtdVendas = itemList.map(({ vendas }) => vendas)
  menorVenda = Math.min(...qtdVendas);
  maiorVenda = Math.max(...qtdVendas);


  let valores = itemList.map(({ price }) => price)
  menorPreco = Math.min(...valores);
  maiorPreco = Math.max(...valores);


  let nicknameVendedor = await itemList.map(({ seller }) => seller.nickname);

  let nicknameVendedorUnicos = nicknameVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let nicknameVendedorUnicosJson = [];

  for (let i = 0; i < nicknameVendedorUnicos.length; i++) {
    nicknameVendedorUnicosJson.push({
      nickname: nicknameVendedorUnicos[i],
      qtdAnuncio: 0
    })
  }

  // Get items details

  let rawVendedoresCompleto = [];
  let rawVendedoresCompletoHoje = [];
  let concatTitulos = '';

  try {

    rawVendedoresCompleto = await MeliAPI.getVendedor(nicknameVendedorUnicosJson);
    console.log('[MeliAPI] Vendedores consulta completa', { rawVendedoresCompleto })

    rawVendedoresCompletoHoje = await MeliAPI.getVendedorHoje(nicknameVendedorUnicosJson);

    rawVendedoresCompleto = MeliAdapter.criadosHoje(
      rawVendedoresCompleto,
      rawVendedoresCompletoHoje
    );
    console.log('[MeliAdapter] Vendedores com Criados Hoje', { rawVendedoresCompleto })


    for (let x = 0; x < rawVendedoresCompleto.length; x++) {
      rawVendedoresCompleto[x].qtdAnuncio = 0;
    }

    concatTitulos = '';

    for (let i = 0; i < itemList.length; i++) {
      totalVendas += itemList[i].vendas;
      concatTitulos += itemList[i].title.replace(/'/g, ' ').replace(/"/g, ' ').trim() + ' ';
      for (let x = 0; x < rawVendedoresCompleto.length; x++) {
        if (itemList[i].seller.nickname == rawVendedoresCompleto[x].seller.nickname) {
          rawVendedoresCompleto[x].qtdAnuncio += 1;
          rawVendedoresCompleto[x].cidade = itemList[i].seller.address.city;
          rawVendedoresCompleto[x].uf = itemList[i].seller.address.state;
          break;
        }
      }
    }
  } catch (error) {

  }

  // Start
  concatTitulos = concatTitulos.trim();
  let arrayConcatTitulos = concatTitulos.split(" ");
  arrayConcatTitulos = arrayConcatTitulos.filter(x => x.trim());


  var count = {};
  arrayConcatTitulos.forEach(function (i) { count[i] = (count[i] || 0) + 1; });


  var SortArr2 = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val),
        intB = parseInt(b.val);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJson = SortArr2(count);
  //end

  try {
    var SortArr = function (j) {
      var arr = [];
      for (var key in j) {
        arr.push({ key: key, val: j[key] });
      }
      arr.sort(function (a, b) {
        var intA = parseInt(a.val.qtdAnuncio),
          intB = parseInt(b.val.qtdAnuncio);
        if (intA > intB)
          return -1;
        if (intA < intB)
          return 1;
        return 0;
      });
      return arr;
    };

    var arrJsonVendedores = SortArr(rawVendedoresCompleto);
  } catch (error) {

  }


  for (let i = 0; i < itemList.length; i++) {
    if (itemList[i].logistic_type == 'fulfillment') qtdFull += 1;
    if (itemList[i].free_shipping) qtdFreteGratis += 1;
    if (itemList[i].listing_type_id == 'gold_special') qtdClassico += 1;
    if (itemList[i].listing_type_id == 'gold_pro') qtdPremium += 1;
    if (itemList[i].loja_oficial) qtdLojasOficiais += 1;
    if (itemList[i].catalogo) qtdCatalogo += 1;
    if (itemList[i].supermercado) qtdSupermercado += 1;
    if (itemList[i].oferta) qtdOferta += 1;
    if (itemList[i].flex) qtdFlex += 1;
    try {
      if (itemList[i].seller.tags.includes('international_seller')) qtdInternacional += 1;
    } catch (error) {

    }
  }


  for (let i = 0; i < itemList.length; i++) {

    switch (itemList[i].seller.seller_reputation.power_seller_status) {
      case 'platinum':
        qtdPlatinum += 1;
        break;
      case 'silver':
        qtdLider += 1;
        break;
      case 'gold':
        qtdGold += 1;
        break;
      default:
        qtdSemMedalha += 1;
        break;
    }
  }

  let qtdAnuncios = itemList.length;

  let porcSemMedalha = (qtdSemMedalha / qtdAnuncios) * 100;
  let classificacao = '';

  if (porcSemMedalha >= 40) {
    classificacao = 'btn-success';
  }
  else if (porcSemMedalha >= 15) {
    classificacao = 'btn-warning';
  } else {
    classificacao = 'btn-danger';
  }

  let classificacaotxt = '';
  let classificacaoCor = '';


  switch (classificacao) {
    case 'btn-danger':
      classificacaotxt = "Concorrência Alta";
      classificacaoCor = "var(--danger)";
      break;
    case 'btn-warning':
      classificacaotxt = "Concorrência Média";
      classificacaoCor = "var(--warning)";
      break;
    case 'btn-success':
      classificacaotxt = "Concorrência Baixa";
      classificacaoCor = "var(--success)";
      break;

    default:
      break;
  }


  let patrocinados = 0;

  try {
    //patrocinados = document.querySelectorAll('.ui-search-item__ad-container'); mudou em 01/06
    patrocinados = document.querySelectorAll('.ui-search-item__pub-container');
  } catch (error) {

  }


  let itemExcel = {};
  let links = [];

  for (let i = 0; i < rawItems.length; i++) {
    links.push({
      index: i,
      url: rawItems[i].permalink,
      vendedor: rawItems[i].seller
    })
  }



  if (ultra) {

    try {
      itemExcel = MeliAdapter.excelPesquisa(itemList);

      MeliAPI.scriptBase('https://ramcloud.com.br/scriptexcelpesquisa.js');

      // insere modal excel
      let body = document.body;
      let modal = document.createElement('div');
      modal.className = 'dadosModalExcelPesquisa';


      modal.innerHTML =
        `
    <div id="modalExcelPesquisa" class="modalExcelPesquisa">
      <div class="modal-excel-pesquisa">
       <span class="fecharExcelPesquisa" id="fecharExcelPesquisa">&times;</span>
       <h3>Planilha de Análise de Lucratividade</h3>
       <small class="mlbEan" style="font-size: 11px !important; font-weight: bold !important"></small><small style="font-size: 12px;"> Esse recurso te permite informar o preço de custo do produto pesquisado e sua aliquota de imposto para que possa ser gerado um excel que analisa todos os anúncios da tela de pesquisa e informa qual será sua margem de contribuição se vender o produto com o mesmo valor.</small>
      <div>

      <div class="dadosExcelPesquisa">
        <div style="width: 50%; margin-right: 15px;">
          <span class="lbl-excel-pesquisa">Qual preço de custo do produto?</span>
          <input class="input-custo-pesquisa" id="input-custo-pesquisa" placeholder="Custo do produto" type="number"></input>
        </div>

        <div style="width: 50%">
          <span class="lbl-imposto-pesquisa">Qual sua aliquota do imposto?</span>
          <input class="input-imposto-pesquisa" id="input-imposto-pesquisa" placeholder="Aliquota de imposto" type="number"></input>
        </div>
      </div>

      <div>
        <center>
          <button class="gravarExcelPesquisa" id="gravarExcelPesquisa" onclick="gerarExcelPesquisa(${JSON.stringify(itemExcel).replace(/'/g, '&apos;').replace(/"/g, '&quot;')})">Gerar Planilha</button>
          <button class="loadingGravarExcelPesquisa" id="loadingGravarExcelPesquisa" onclick="">Gerando Planilha...</button>
        </center>
      </div>
        <center><p style="margin-bottom: -5px !important; font-size: 12px !important; color: gray !important">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

      body.appendChild(modal);
    } catch (error) {

    }



    try {
      MeliAPI.scriptBase('https://ramcloud.com.br/scriptanalisemercado.js');

      // insere modal Ean
      let body = document.body;
      let modal = document.createElement('div');
      modal.className = 'dadosModalMercado';



      modal.innerHTML =
        `
    <div id="modalMercado" class="modalMercado">
    <span id="emailuser" style="display: none" value="${email}"></span>
     <div class="modal-mercado">
       <span class="fecharMercado" id="fecharMercado">&times;</span>
       <h3>Análise de Mercado Feita nas 5 Primeiras Páginas - <span style="color: ${classificacaoCor}; font-weight: bold;">${classificacaotxt}</span> - <span id="paginaBuscada"></span> </h3>

       <div class="loadingAnalise" style="width: 100%; height: 400px; display: flex;">
          <div style="align-self: center; flex-direction: column-reverse; display: flex; margin-left: 40%;">
          <center>
          <div class="loader">
          <svg width="60" height="73" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_23)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_23)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
          <defs>
          <linearGradient id="paint0_linear_120_23" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
          <stop offset="0.139315" stop-color="#271BEF"/>
          <stop offset="0.942129" stop-color="#00C2FF"/>
          </linearGradient>
          <linearGradient id="paint1_linear_120_23" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
          <stop offset="0.0921191" stop-color="#00C2FF"/>
          <stop offset="0.970863" stop-color="#271BEF"/>
          </linearGradient>
          </defs>
          </svg>
          <p style="font-size: 18px;"><strong>Carregando dados Avantpro...</strong></p>
          </div>
          </center>
          </div>
       </div>

       <div class="dadosAnalise" style="width: 100%; height: 400px; display: none;">
          <div style="width: 25.5%; height: 370px;">
            <div style="width: 100%; height: 385px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Menu</span></center>
              <br>
              <ul>
                <li class="p-null">Sem Medalha:  <strong><span id="menuSemMedalha"></span></strong></li>
                <li class="p-silver">Mercado Líder:  <strong><span id="menuMercadoLider"></span></strong></li>
                <li class="p-gold">Mercado Gold:  <strong><span id="menuMercadoGold"></span></strong></li>
                <li class="p-platinum">Mercado Platinum:  <strong><span id="menuMercadoPlatinum"></span></strong></li>
                <li class="p-full">Anúncios no <span class="full">FULL</span>:  <strong><span id="menuAnuncioFull"></span></strong></li>
                <li class="p-classico">Anúncios Classicos:  <strong><span id="menuAnunciosClassicos"></span></strong></li>
                <li class="p-premium">Anúncios Premium:  <strong><span id="menuAnunciosPremium:"></span></strong></li>
                <li class="p-fretegratis">Frete Grátis:  <strong><span id="menuFreteGratis"></span></strong></li>
                <li class="p-oficial">Lojas Oficiais:  <strong><span id="menuLojasOficiais"></span></strong></li>
                <li class="infoSemCatalogo"><center style="margin-top: 20px;font-size: 15px;"><img style="width: 17px;display: inline;vertical-align: middle;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAABPklEQVR4nO3aQY6DMAyF4VylR5qSahbtNaAX7I1qe9NKrVgWFUHi58QeTaTs/w9CCBIp/Y/1Icfxd54p4pA8nmgYH3ScnvfhekkR43mYXvMMhZBFfCiErMSHQMhGvGuE7Ix3iZDCeFcIqYx3gRBlfFeEgOK5BwIdzy0RVvHcAlEaf0i3j9kVIRVXvhbAaETtstEAGIXQrHktgLUI7QOLAHAtArHboABcikBtlUgA70Ug93k0gLcQ6JeUBYDXEBZvWCsAf0Pwz5TDAfJ4/rgLaITpEsqLeMs7YX7loyBoT7xXBJXEoxDQo0QujEcgYIe5XBmvRUCO01kZr0GoP2gyKF6D6LZseiHIMt4aQS3irRDUMh6NoB7xKAT1jNciXMTXIlzFlyJcxu9FuI7fQoSIX0OEil8iQsb/iZ89UqPxBpFOWy65ReMyAAAAAElFTkSuQmCC"> 
                    <b> A análise dessa tela não contabiliza os dados de produtos em catálogo!</b></center></li>
              </ul>
            </div>
          </div>

          <div style="width: 36%; height: 370px; margin: 0px 5px 0px 5px;">
            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Top 5 anúncios com mais vendas</span></center>
              <ul class="listaMaisVendas">
                <li style="display: flex;" id="primeiroMaisVendas"></li>
                <li style="display: flex;" id="segundoMaisVendas"></li>
                <li style="display: flex;" id="terceiroMaisVendas"></li>
                <li style="display: flex;" id="quartoMaisVendas"></li>
                <li style="display: flex;" id="quintoMaisVendas"></li>
                <li style="display: none;" id="semInformaçãoVendas"><center>Mais nenhuma informação encontrada.</center></li>
              </ul>
            </div>

            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px 10px 0px 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center style="margin-bottom: 5px;"><span style="font-weight: bold;">Anúncios por UF</span></center>
              <div class="chart-container">
                <canvas id="graficoEstadosUF"></canvas>
              </div>
            </div>
          </div>

          <div style="width: 36%; height: 370px;">
            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Top 5 anúncios com mais estoque no Full</span></center>
              <ul class="listaEstoqueFull">
                <li style="display: flex;" id="primeiroEstoqueFull"></li>
                <li style="display: flex;" id="segundoEstoqueFull"></li>
                <li style="display: flex;" id="terceiroEstoqueFull"></li>
                <li style="display: flex;" id="quartoEstoqueFull"></li>
                <li style="display: flex;" id="quintoEstoqueFull"></li>
                <li style="display: none;" id="semInformaçãoFull"><center>Mais nenhuma informação encontrada.</center></li>
              </ul>
            </div>

            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Vendas por Pagina (5 Paginas)</span></center>
              <div class="chart-containerVendas">
                <canvas id="graficoVendasPg"></canvas>
              </div>
            </div>
          </div>
       </div>


       <center><p style="margin-bottom: -5px !important; margin-top: 5px; font-size: 12px !important; color: gray !important">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

      body.appendChild(modal);
    } catch (error) {

    }
  } else {
    try {
      itemExcel = MeliAdapter.excelPesquisa(itemList);

      MeliAPI.scriptBase('https://ramcloud.com.br/scriptexcelpesquisa.js');

      // insere modal excel
      let body = document.body;
      let modal = document.createElement('div');
      modal.className = 'dadosModalExcelPesquisa';


      modal.innerHTML =
        `
    <div id="modalExcelPesquisa" class="modalExcelPesquisa">
      <div class="modal-excel-pesquisa">
       <span class="fecharExcelPesquisa" id="fecharExcelPesquisa">&times;</span>
       <h3>Planilha de Análise de Lucratividade</h3>
       <small class="mlbEan" style="font-size: 11px !important; font-weight: bold !important"></small><small style="font-size: 12px;"> Esse recurso te permite informar o preço de custo do produto pesquisado e sua aliquota de imposto para que possa ser gerado um excel que analisa todos os anúncios da tela de pesquisa e informa qual será sua margem de contribuição se vender o produto com o mesmo valor.</small>
      <div>

      <div class="dadosExcelPesquisa">
        <div style="width: 50%; margin-right: 15px;">
          <span class="lbl-excel-pesquisa">Qual preço de custo do produto?</span>
          <input class="input-custo-pesquisa" id="input-custo-pesquisa" placeholder="Custo do produto" type="number" disabled="disabled"></input>
        </div>

        <div style="width: 50%">
          <span class="lbl-imposto-pesquisa">Qual sua aliquota do imposto?</span>
          <input class="input-imposto-pesquisa" id="input-imposto-pesquisa" placeholder="Aliquota de imposto" type="number" disabled="disabled"></input>
        </div>
      </div>

      <div>
        <center style="display: flex;flex-wrap: nowrap;justify-content: center;align-items: center;margin-bottom: 20px;">
          <button style="position: relative;top: 8px;box-shadow: rgb(136, 136, 136) 1px 2px 8px;display: none;" class="gravarExcelPesquisaPremium" onclick="alert('Recurso disponível na versão Ultra, assine já em www.avantpro.com.br')">Gerar Planilha</button>
          <div id="btnYoutubeFoto" class="btnYoutubeExcel">
          <center style="position: relative;top: 3px;">
          <small style="vertical-align: middle;text-decoration:none;color: white;font-weight: bold;font-size: 12px;">Como Funciona Esse Recurso</small></center>
          </div> </a> <button style="position: relative;top: -1px;" class="botaoUltraMenuExcel" onclick="javascript:window.open('https://www.avantpro.com.br/', '_blank');"> 📢 Conheça o Avantpro Ultra  📢</button></h3>
        </center>
      </div>
        <center><p style="margin-bottom: -5px !important; font-size: 12px !important; color: gray !important">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

      body.appendChild(modal);
    } catch (error) {

    }



    try {
      MeliAPI.scriptBase('https://ramcloud.com.br/scriptanalisemercado.js');

      // insere modal Ean
      let body = document.body;
      let modal = document.createElement('div');
      modal.className = 'dadosModalMercado';



      modal.innerHTML =
        `
    <div id="modalMercadoPremium" class="modalMercadoPremium">
     <div class="modal-mercadoPremium">
       <span class="fecharMercadoPremium" id="fecharMercadoPremium">&times;</span>
       <h3 style="position: relative;top: 4px;">Análise de Mercado Feita nas 5 Primeiras Páginas <a style="position: absolute;" href="https://www.youtube.com/@avantprooficial" target="_blank">
        <div id="btnYoutubeFoto" class="btnYoutubeMercado"><center style="position: relative;top: 2px;"><img src="https://img.icons8.com/material-rounded/20/FFFFFF/youtube-play.png"> 
          <small style="vertical-align: super;  text-decoration:none; color: white">Como Funciona Esse Recurso</small></center>
        </div> </a> <button style="position: absolute;top: -0.4em;right: 8em;" class="botaoUltraMenu" onclick="javascript:window.open('https://www.avantpro.com.br/ml', '_blank');"> 📢 Clique aqui e Conheça o Avantpro Ultra  📢</button></h3>

       <div class="dadosAnalise" style="width: 100%; height: 400px; display: Flex;">
          <div style="width: 25.5%; height: 370px;">
            <div style="width: 100%; height: 385px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Menu</span></center>
              <br>
              <ul>
                <li class="p-null">Sem Medalha: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-silver">Mercado Líder: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-gold">Mercado Gold:<strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-platinum">Mercado Platinum: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-full">Anúncios no <span class="full">FULL</span>: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-classico">Anúncios Classicos: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-premium">Anúncios Premium: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-fretegratis">Frete Grátis: <strong> <button style="width: 100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="p-oficial">Lojas Oficiais: <strong> <button style="width:100px; background: rgb(0 0 0 / 13%); height: 12px; border-radius: 4px; border: none; "></button> </strong></li>
                <li class="infoSemCatalogo"><center style="margin-top: 20px;font-size: 15px;"><img style="width: 17px;display: inline;vertical-align: middle;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAABPklEQVR4nO3aQY6DMAyF4VylR5qSahbtNaAX7I1qe9NKrVgWFUHi58QeTaTs/w9CCBIp/Y/1Icfxd54p4pA8nmgYH3ScnvfhekkR43mYXvMMhZBFfCiErMSHQMhGvGuE7Ix3iZDCeFcIqYx3gRBlfFeEgOK5BwIdzy0RVvHcAlEaf0i3j9kVIRVXvhbAaETtstEAGIXQrHktgLUI7QOLAHAtArHboABcikBtlUgA70Ug93k0gLcQ6JeUBYDXEBZvWCsAf0Pwz5TDAfJ4/rgLaITpEsqLeMs7YX7loyBoT7xXBJXEoxDQo0QujEcgYIe5XBmvRUCO01kZr0GoP2gyKF6D6LZseiHIMt4aQS3irRDUMh6NoB7xKAT1jNciXMTXIlzFlyJcxu9FuI7fQoSIX0OEil8iQsb/iZ89UqPxBpFOWy65ReMyAAAAAElFTkSuQmCC"> 
                    <b> A análise dessa tela não contabiliza os dados de produtos em catálogo!</b></center></li>
              </ul>
            </div>
          </div>

          <div style="width: 36%; height: 370px; margin: 0px 5px 0px 5px;">
            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Top 5 anúncios com mais vendas</span></center>
                <ul class="listaMaisVendas">
                  <li style="display: flex;" ><b style="margin-right: 4px;">1º:</b>Vendas: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 41%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
                  <li style="display: flex;" ><b style="margin-right: 4px;">2º:</b>Vendas: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 41%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
                  <li style="display: flex;" ><b style="margin-right: 4px;">3º:</b>Vendas: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 41%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
                  <li style="display: flex;" ><b style="margin-right: 4px;">4º:</b>Vendas: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 41%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
                  <li style="display: flex;" ><b style="margin-right: 4px;">5º:</b>Vendas: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 41%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
                </ul>
            </div>

            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px 10px 0px 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center style="margin-bottom: 5px;"><span style="font-weight: bold;">Anúncios por UF</span></center>
              <img style="width: 27em;margin-left: 7px;" src="https://ramcloud.com.br/img/UFBorradas.png" alt="Vendas">
            </div>
          </div>

          <div style="width: 36%; height: 370px;">
            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Top 5 anúncios com mais estoque no Full</span></center>
              <ul class="listaEstoqueFull">
              <li style="display: flex;" ><b style="margin-right: 4px;">1º:</b>Estoque: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 13%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
              <li style="display: flex;" ><b style="margin-right: 4px;">2º:</b>Estoque: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 13%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
              <li style="display: flex;" ><b style="margin-right: 4px;">3º:</b>Estoque: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 13%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
              <li style="display: flex;" ><b style="margin-right: 4px;">4º:</b>Estoque: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 13%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
              <li style="display: flex;" ><b style="margin-right: 4px;">5º:</b>Estoque: <button style="width: 12%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <button style="width: 55%;background: rgb(0 0 0 / 13%);height: 12px;border-radius: 4px;border: none;position: relative;top: 4px;margin-left: 10px;"></button> <img style="width: 23px;position: absolute;right: 13%;" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABRklEQVR4nO3UvUrEQBSG4WAlimBj0FK8DGXtLK0sLLwMrd8vZFOEoDdgoxaC12BhtVhELFzBQhAUBCtBUStXJZBACOaPZALKfjBVwjyZM+fEssb5awEmJQ0khYDdJbwn6TteN/1+f8E46jjOMvCZgs3jQRBMS7rNoOZxSfs5qDkcWAO+SuB2cWBW0mMFNFlhW/CEpMMa8KDyxsCWpDNJL8AHcClpB5iqgY8k7UZzXgmWdJK3GXDtuu5iGQ7cAb1apYxn87UAf3BddylVnYPM8yPf92dqoU1w4AlYt5rGcZxV4K3gDu/TZY+6vTFaFY/uPGm41gNsFHUvsG0CtSUNS+ALk+gwOnlO2d9bQz3PmwOukv8tMB9/zEq224Fno2iSX/BTy0B57Zz3eknZgc1O0Ax+HM2w1SSSwqpoq5F0Ho1Gp+g4/zI/4zAZnYPlZ/kAAAAASUVORK5CYII="></li>
            </ul>
            </div>

            <div style="width: 100%; height: 190px; border: 1px solid lightgray; border-radius: 5px; padding: 10px; margin: 5px 0px 5px 0px;border-top: 2px solid #3498d8;">
              <center><span style="font-weight: bold;">Vendas por Pagina (5 Paginas)</span></center>
              <img style="margin-left: -2px;" src="https://ramcloud.com.br/img/VendasBorradas.png" alt="Vendas">
            </div>
          </div>
       </div>

       <center><p style="margin-bottom: -5px !important; margin-top: 5px; font-size: 12px !important; color: gray !important">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

      body.appendChild(modal);
    } catch (error) {

    }
  }


  /** Download */
  //adiciona scripts
  var header = document.head;


  chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {
    var emailRetornado = await response.emailmlpro;

    Render.botaoPalavrasChaves(concatTitulos, ultra);
    Render.pesquisaPorAnuncio(itemList, emailRetornado, ultra);
    Render.menuLateral(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, arrJsonVendedores, qtdSupermercado, qtdOferta, qtdInternacional, maiorVenda, menorVenda, totalVendas, ultra, qtdFlex, linkMenuUltra, linkMenuPremium, classificacao, classificacaotxt, classicoTx, premiumTx, pesquisaSemelhante, patrocinados, links);

    $('document').ready(function () {
      $(window).scrollTop(0);
    });

  });


  MeliAPI.scriptBase('https://ramcloud.com.br/fotosdownload.js');

  /** VISITAS */
  // Get visitas
  // let rawVisitas = [];
  // let vetorMLB = [];

  // for (let i = 0; i < itemList.length; i++) {
  //   vetorMLB[i] = itemList[i].id;
  // }


  // try {
  //   MeliAPI.getVisitasByIdNovo({ ITEM: vetorMLB })
  //     .then(finalResult => {
  //       rawVisitas = finalResult;
  //       console.log('[MeliAPI] Numero Visitas', { rawVisitas });
  //       // Mapping Visitas
  //       itemList = MeliAdapter.visitas(
  //         itemList,
  //         rawVisitas
  //       );
  //       console.log('[MeliAdapter] Visitas Mapeadas', { itemList })
  //       Render.pesquisaPorAnuncioConversao(itemList);
  //     })

  // } catch (error) {

  // }

  /** FIM VISITAS */

}


/** MAIS VENDIDOS */
async function getAnunciosMaisVendidos(ultra) {

  console.log('getAnunciosMaisVendidos');

  if (!Page.hasItemsMaisVendidos()) {
    return false;
  }

  console.log('pós if');


  $("head").append('<style type="text/css"> .promotion-item { height: 700px !important; }</style>');
  $("head").append('<style type="text/css"> .promotion-item__description { border-top: none !important; }</style>');

  // Get items IDs
  let itemList = Page.searchIdsMaisVendidos();
  console.log('[Pesquisa] Itens mais vendidos encontrados: ', { itemList })


  // Get items details
  const rawItems = await MeliAPI.getItemsMaisVendidos(itemList);
  console.log('[MeliAPI] Itens encontrados', { rawItems })


  Render.pesquisaLoadingMaisVendidos(itemList);



  // Mapping items
  itemList = await MeliAdapter.items(
    itemList,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados COM VENDEDOR', { itemList })

  //vendedores unicos
  let idVendedor = await itemList.map(({ seller_id }) => seller_id);

  let idVendedorUnicos = idVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let idVendedorUnicosJson = []

  for (let i = 0; i < idVendedorUnicos.length; i++) {
    idVendedorUnicosJson.push({
      seller_id: idVendedorUnicos[i],
    })
  }


  // Get sellers details
  const rawSellers = await MeliAPI.getSellers(idVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores Encontrados', { rawSellers })


  // Mapping sellers
  itemList = MeliAdapter.sellers(
    itemList,
    rawSellers
  );
  console.log('[MeliAdapter] Vendedores Mapeados com ajuste', { itemList })


  // Get sellers details
  const rawTaxas = await MeliAPI.getTaxas(itemList);
  console.log('[MeliAPI] Taxas Canculadas', { rawTaxas })



  itemList = MeliAdapter.taxas(
    itemList,
    rawTaxas
  );
  console.log('[MeliAdapter] Taxas Mapeadas', { itemList })



  //qtd medalhas
  let qtdSemMedalha = 0;
  let qtdLider = 0;
  let qtdGold = 0;
  let qtdPlatinum = 0;
  let menorPreco = 0;
  let maiorPreco = 0;
  let qtdFull = 0;
  let qtdFreteGratis = 0;
  let qtdClassico = 0;
  let qtdPremium = 0;
  let qtdLojasOficiais = 0;
  let qtdCatalogo = 0;
  let qtdSupermercado = 0;
  let qtdOferta = 0;
  let menorVenda = 0;
  let maiorVenda = 0;
  let totalVendas = 0;
  let qtdFlex = 0;
  let qtdInternacional = 0;

  let qtdVendas = itemList.map(({ vendas }) => vendas)
  menorVenda = Math.min(...qtdVendas);
  maiorVenda = Math.max(...qtdVendas);


  let valores = itemList.map(({ price }) => price)
  menorPreco = Math.min(...valores);
  maiorPreco = Math.max(...valores);


  let nicknameVendedor = await itemList.map(({ seller }) => seller.nickname);

  let nicknameVendedorUnicos = nicknameVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let nicknameVendedorUnicosJson = []

  for (let i = 0; i < nicknameVendedorUnicos.length; i++) {
    nicknameVendedorUnicosJson.push({
      nickname: nicknameVendedorUnicos[i],
      qtdAnuncio: 0
    })
  }

  // Get items details
  const rawVendedoresCompleto = await MeliAPI.getVendedor(nicknameVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores consulta completa', { rawVendedoresCompleto })

  for (let x = 0; x < rawVendedoresCompleto.length; x++) {
    rawVendedoresCompleto[x].qtdAnuncio = 0;
  }

  let concatTitulos = '';

  for (let i = 0; i < itemList.length; i++) {
    totalVendas += itemList[i].vendas;
    concatTitulos += itemList[i].title.replace(/'/g, ' ').replace(/"/g, ' ').trim() + ' ';
    for (let x = 0; x < rawVendedoresCompleto.length; x++) {
      if (itemList[i].seller.nickname == rawVendedoresCompleto[x].seller.nickname) {
        rawVendedoresCompleto[x].qtdAnuncio += 1;
        rawVendedoresCompleto[x].cidade = itemList[i].seller.address.city;
        rawVendedoresCompleto[x].uf = itemList[i].seller.address.state;
        break;
      }
    }
  }

  // Start
  concatTitulos = concatTitulos.trim();
  let arrayConcatTitulos = concatTitulos.split(" ");
  arrayConcatTitulos = arrayConcatTitulos.filter(x => x.trim());


  var count = {};
  arrayConcatTitulos.forEach(function (i) { count[i] = (count[i] || 0) + 1; });


  var SortArr2 = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val),
        intB = parseInt(b.val);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJson = SortArr2(count);
  //end

  var SortArr = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val.qtdAnuncio),
        intB = parseInt(b.val.qtdAnuncio);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJsonVendedores = SortArr(rawVendedoresCompleto);




  for (let i = 0; i < itemList.length; i++) {
    if (itemList[i].logistic_type == 'fulfillment') qtdFull += 1;
    if (itemList[i].free_shipping) qtdFreteGratis += 1;
    if (itemList[i].listing_type_id == 'gold_special') qtdClassico += 1;
    if (itemList[i].listing_type_id == 'gold_pro') qtdPremium += 1;
    if (itemList[i].loja_oficial) qtdLojasOficiais += 1;
    if (itemList[i].catalogo) qtdCatalogo += 1;
    if (itemList[i].supermercado) qtdSupermercado += 1;
    if (itemList[i].oferta) qtdOferta += 1;
    if (itemList[i].flex) qtdFlex += 1;
    try {
      if (itemList[i].seller.tags.includes('international_seller')) qtdInternacional += 1;
    } catch (error) {

    }
  }


  for (let i = 0; i < itemList.length; i++) {

    switch (itemList[i].seller.seller_reputation.power_seller_status) {
      case 'platinum':
        qtdPlatinum += 1;
        break;
      case 'silver':
        qtdLider += 1;
        break;
      case 'gold':
        qtdGold += 1;
        break;
      default:
        qtdSemMedalha += 1;
        break;
    }
  }


  chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {
    var emailRetornado = response.email;

    Render.botaoPalavrasChavesMaisVendidos(concatTitulos);
    Render.pesquisaPorAnuncioMaisVendidos(itemList, emailRetornado);
    Render.menuLateralMaisVendidos(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, arrJsonVendedores, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdOferta, qtdInternacional, ultra, qtdFlex);
  });

  /** VISITAS */
  // Get visitas
  let rawVisitas = [];
  let vetorMLB = [];

  for (let i = 0; i < itemList.length; i++) {
    vetorMLB[i] = itemList[i].id;
  }


  try {
    MeliAPI.getVisitasByIdNovo({ ITEM: vetorMLB })
      .then(finalResult => {
        rawVisitas = finalResult;
        console.log('[MeliAPI] Numero Visitas', { rawVisitas });
        // Mapping Visitas
        itemList = MeliAdapter.visitas(
          itemList,
          rawVisitas
        );
        console.log('[MeliAdapter] Visitas Mapeadas', { itemList })
        Render.pesquisaPorAnuncioMaisVendidosConversao(itemList);
      })

  } catch (error) {

  }

  /** FIM VISITAS */

}

/** FIM MAIS VENDIDOS */



/** OFERTAS */
async function getAnunciosOfertas(ultra) {

  if (!Page.hasItemsOfertas()) {
    return false;
  }

  jquery();

  $("head").append('<style type="text/css"> .promotion-item { height: 700px !important; }</style>');
  $("head").append('<style type="text/css"> .promotion-item__description { border-top: none !important; }</style>');

  // Get items IDs
  let itemList = Page.searchIdsOfertas();
  console.log('[Pesquisa] Itens ofertas encontrados: ', { itemList })


  // Get items details
  const rawItems = await MeliAPI.getItems(itemList);
  console.log('[MeliAPI] Itens encontrados', { rawItems })


  Render.pesquisaLoadingMaisVendidos(itemList);



  // Mapping items
  itemList = await MeliAdapter.items(
    itemList,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados COM VENDEDOR', { itemList })

  //vendedores unicos
  let idVendedor = await itemList.map(({ seller_id }) => seller_id);

  let idVendedorUnicos = idVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let idVendedorUnicosJson = []

  for (let i = 0; i < idVendedorUnicos.length; i++) {
    idVendedorUnicosJson.push({
      seller_id: idVendedorUnicos[i],
    })
  }


  // Get sellers details
  const rawSellers = await MeliAPI.getSellers(idVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores Encontrados', { rawSellers })


  // Mapping sellers
  itemList = MeliAdapter.sellers(
    itemList,
    rawSellers
  );
  console.log('[MeliAdapter] Vendedores Mapeados com ajuste', { itemList })


  // Get sellers details
  const rawTaxas = await MeliAPI.getTaxas(itemList);
  console.log('[MeliAPI] Taxas Canculadas', { rawTaxas })



  itemList = MeliAdapter.taxas(
    itemList,
    rawTaxas
  );
  console.log('[MeliAdapter] Taxas Mapeadas', { itemList })



  //qtd medalhas
  let qtdSemMedalha = 0;
  let qtdLider = 0;
  let qtdGold = 0;
  let qtdPlatinum = 0;
  let menorPreco = 0;
  let maiorPreco = 0;
  let qtdFull = 0;
  let qtdFreteGratis = 0;
  let qtdClassico = 0;
  let qtdPremium = 0;
  let qtdLojasOficiais = 0;
  let qtdCatalogo = 0;
  let qtdSupermercado = 0;
  let qtdOferta = 0;
  let menorVenda = 0;
  let maiorVenda = 0;
  let totalVendas = 0;
  let qtdFlex = 0;
  let qtdInternacional = 0;

  let qtdVendas = itemList.map(({ vendas }) => vendas)
  menorVenda = Math.min(...qtdVendas);
  maiorVenda = Math.max(...qtdVendas);


  let valores = itemList.map(({ price }) => price)
  menorPreco = Math.min(...valores);
  maiorPreco = Math.max(...valores);


  let nicknameVendedor = await itemList.map(({ seller }) => seller.nickname);

  let nicknameVendedorUnicos = nicknameVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let nicknameVendedorUnicosJson = []

  for (let i = 0; i < nicknameVendedorUnicos.length; i++) {
    nicknameVendedorUnicosJson.push({
      nickname: nicknameVendedorUnicos[i],
      qtdAnuncio: 0
    })
  }

  // Get items details
  const rawVendedoresCompleto = await MeliAPI.getVendedor(nicknameVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores consulta completa', { rawVendedoresCompleto })

  for (let x = 0; x < rawVendedoresCompleto.length; x++) {
    rawVendedoresCompleto[x].qtdAnuncio = 0;
  }

  let concatTitulos = '';

  for (let i = 0; i < itemList.length; i++) {
    totalVendas += itemList[i].vendas;
    concatTitulos += itemList[i].title.replace(/'/g, ' ').replace(/"/g, ' ').trim() + ' ';
    for (let x = 0; x < rawVendedoresCompleto.length; x++) {
      if (itemList[i].seller.nickname == rawVendedoresCompleto[x].seller.nickname) {
        rawVendedoresCompleto[x].qtdAnuncio += 1;
        rawVendedoresCompleto[x].cidade = itemList[i].seller.address.city;
        rawVendedoresCompleto[x].uf = itemList[i].seller.address.state;
        break;
      }
    }
  }

  // Start
  concatTitulos = concatTitulos.trim();
  let arrayConcatTitulos = concatTitulos.split(" ");
  arrayConcatTitulos = arrayConcatTitulos.filter(x => x.trim());


  var count = {};
  arrayConcatTitulos.forEach(function (i) { count[i] = (count[i] || 0) + 1; });


  var SortArr2 = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val),
        intB = parseInt(b.val);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJson = SortArr2(count);
  //end

  var SortArr = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val.qtdAnuncio),
        intB = parseInt(b.val.qtdAnuncio);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJsonVendedores = SortArr(rawVendedoresCompleto);




  for (let i = 0; i < itemList.length; i++) {
    if (itemList[i].logistic_type == 'fulfillment') qtdFull += 1;
    if (itemList[i].free_shipping) qtdFreteGratis += 1;
    if (itemList[i].listing_type_id == 'gold_special') qtdClassico += 1;
    if (itemList[i].listing_type_id == 'gold_pro') qtdPremium += 1;
    if (itemList[i].loja_oficial) qtdLojasOficiais += 1;
    if (itemList[i].catalogo) qtdCatalogo += 1;
    if (itemList[i].supermercado) qtdSupermercado += 1;
    if (itemList[i].oferta) qtdOferta += 1;
    if (itemList[i].flex) qtdFlex += 1;
    try {
      if (itemList[i].seller.tags.includes('international_seller')) qtdInternacional += 1;
    } catch (error) {

    }
  }


  for (let i = 0; i < itemList.length; i++) {

    switch (itemList[i].seller.seller_reputation.power_seller_status) {
      case 'platinum':
        qtdPlatinum += 1;
        break;
      case 'silver':
        qtdLider += 1;
        break;
      case 'gold':
        qtdGold += 1;
        break;
      default:
        qtdSemMedalha += 1;
        break;
    }
  }


  chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {
    var emailRetornado = response.email;

    Render.botaoPalavrasChavesMaisVendidos(concatTitulos);
    Render.pesquisaPorAnuncioMaisVendidos(itemList, emailRetornado);
    Render.menuLateralMaisVendidos(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, arrJsonVendedores, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdOferta, qtdInternacional, ultra, qtdFlex);
  });

  /** VISITAS */
  // Get visitas
  let rawVisitas = [];
  let vetorMLB = [];

  for (let i = 0; i < itemList.length; i++) {
    vetorMLB[i] = itemList[i].id;
  }


  try {
    MeliAPI.getVisitasByIdNovo({ ITEM: vetorMLB })
      .then(finalResult => {
        console.log(`Got the final result: ${finalResult}`);
        rawVisitas = finalResult;
        console.log('[MeliAPI] Numero Visitas', { rawVisitas });
        // Mapping Visitas
        itemList = MeliAdapter.visitas(
          itemList,
          rawVisitas
        );
        console.log('[MeliAdapter] Visitas Mapeadas', { itemList })
        Render.pesquisaPorAnuncioMaisVendidosConversao(itemList);
      })

  } catch (error) {

  }

  /** FIM VISITAS */

}

/** FIM MAIS OFERTAS */


/** VERSÃO GRATIS */
async function getPesquisaGratis() {

  if (!Page.hasItems()) {
    return false;
  }

  // Get items IDs
  let itemList = Page.searchIds();




  // Get items full options
  /*   itemList = Page.searchFull(itemList);
    console.log('[Pesquisa] Full encontrados: ', { itemList })
   */


  // Get items details
  const rawItems = await MeliAPI.getItems(itemList);



  Render.pesquisaPorAnuncioLoading(itemList);



  // Mapping items
  itemList = await MeliAdapter.items(
    itemList,
    rawItems
  );

  //vendedores unicos
  let idVendedor = await itemList.map(({ seller_id }) => seller_id);

  let idVendedorUnicos = idVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let idVendedorUnicosJson = []

  for (let i = 0; i < idVendedorUnicos.length; i++) {
    idVendedorUnicosJson.push({
      seller_id: idVendedorUnicos[i],
    })
  }


  // Get sellers details
  const rawSellers = await MeliAPI.getSellers(idVendedorUnicosJson);

  // Mapping sellers
  itemList = MeliAdapter.sellers(
    itemList,
    rawSellers
  );


  // Get visitas
  let rawVisitas = [];
  let vetorMLB = [];
  vetorMLB[0] = itemList[0].id;

  /* for(let i = 0; i < itemList.length; i++) {
    vetorMLB[i] = itemList[i].id;
  } */

  try {
    rawVisitas = await MeliAPI.getVisitasByIdNovo({ ITEM: vetorMLB });
  } catch (error) {

  }

  // Mapping Visitas
  itemList = MeliAdapter.visitas(
    itemList,
    rawVisitas
  );


  // Get sellers details
  const rawTaxas = await MeliAPI.getTaxas(itemList);


  itemList = MeliAdapter.taxas(
    itemList,
    rawTaxas
  );


  //qtd medalhas
  let qtdSemMedalha = 0;
  let qtdLider = 0;
  let qtdGold = 0;
  let qtdPlatinum = 0;
  let menorPreco = 0;
  let maiorPreco = 0;
  let qtdFull = 0;
  let qtdFreteGratis = 0;
  let qtdClassico = 0;
  let qtdPremium = 0;
  let qtdLojasOficiais = 0;
  let qtdCatalogo = 0;
  let qtdSupermercado = 0;
  let qtdOferta = 0;
  let menorVenda = 0;
  let maiorVenda = 0;
  let totalVendas = 0;
  let qtdFlex = 0;
  let qtdInternacional = 0;

  let vendas = itemList.map(({ vendas }) => vendas)
  menorVenda = Math.min(...vendas);
  maiorVenda = Math.max(...vendas);

  let valores = itemList.map(({ price }) => price)
  menorPreco = Math.min(...valores);
  maiorPreco = Math.max(...valores);


  let nicknameVendedor = await itemList.map(({ seller }) => seller.nickname);

  let nicknameVendedorUnicos = nicknameVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let nicknameVendedorUnicosJson = []

  for (let i = 0; i < nicknameVendedorUnicos.length; i++) {
    nicknameVendedorUnicosJson.push({
      nickname: nicknameVendedorUnicos[i],
      qtdAnuncio: 0
    })
  }

  // Get items details
  let rawVendedoresCompleto = [];
  let concatTitulos = '';

  try {

    rawVendedoresCompleto = await MeliAPI.getVendedor(nicknameVendedorUnicosJson);

    for (let x = 0; x < rawVendedoresCompleto.length; x++) {
      rawVendedoresCompleto[x].qtdAnuncio = 0;
    }

    concatTitulos = '';


    for (let i = 0; i < itemList.length; i++) {
      totalVendas += itemList[i].vendas;
      concatTitulos += itemList[i].title.trim() + ' ';
      for (let x = 0; x < rawVendedoresCompleto.length; x++) {
        if (itemList[i].seller.nickname == rawVendedoresCompleto[x].seller.nickname) {
          rawVendedoresCompleto[x].qtdAnuncio += 1;
          rawVendedoresCompleto[x].cidade = itemList[i].seller.address.city;
          rawVendedoresCompleto[x].uf = itemList[i].seller.address.state;
          break;
        }
      }
    }



    var SortArr = function (j) {
      var arr = [];
      for (var key in j) {
        arr.push({ key: key, val: j[key] });
      }
      arr.sort(function (a, b) {
        var intA = parseInt(a.val.qtdAnuncio),
          intB = parseInt(b.val.qtdAnuncio);
        if (intA > intB)
          return -1;
        if (intA < intB)
          return 1;
        return 0;
      });
      return arr;
    };

    var arrJsonVendedores = SortArr(rawVendedoresCompleto);
  } catch (error) {

  }




  for (let i = 0; i < itemList.length; i++) {
    if (itemList[i].logistic_type == 'fulfillment') qtdFull += 1;
    if (itemList[i].free_shipping) qtdFreteGratis += 1;
    if (itemList[i].listing_type_id == 'gold_special') qtdClassico += 1;
    if (itemList[i].listing_type_id == 'gold_pro') qtdPremium += 1;
    if (itemList[i].loja_oficial) qtdLojasOficiais += 1;
    if (itemList[i].catalogo) qtdCatalogo += 1;
    if (itemList[i].supermercado) qtdSupermercado += 1;
    if (itemList[i].oferta) qtdOferta += 1;
    if (itemList[i].flex) qtdFlex += 1;
    try {
      if (itemList[i].seller.tags.includes('international_seller')) qtdInternacional += 1;
    } catch (error) {

    }
  }


  for (let i = 0; i < itemList.length; i++) {

    switch (itemList[i].seller.seller_reputation.power_seller_status) {
      case 'platinum':
        qtdPlatinum += 1;
        break;
      case 'silver':
        qtdLider += 1;
        break;
      case 'gold':
        qtdGold += 1;
        break;
      default:
        qtdSemMedalha += 1;
        break;
    }
  }

  let aviso = '';
  let cor = '';
  let linkMenu = '';

  try {
    aviso = await MeliAPI.getAviso();
    cor = aviso.value.find(msg => msg.TITULO == "COR");
    linkMenu = aviso.value.find(msg => msg.TITULO == "LINK");
    aviso = aviso.value.find(msg => msg.TITULO == "MLB");
  } catch (error) {

  }


  Render.botaoPalavrasChavesGratis(concatTitulos);
  Render.pesquisaPorAnuncioGratis(itemList);
  Render.menuLateralGratis(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, arrJsonVendedores, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdOferta, qtdInternacional, qtdFlex, linkMenu);
  Render.caixaAviso(aviso, cor);
}

async function getDetalhesProdutoGratis() {
  let produto = '';

  if (document.getElementsByClassName('ui-pdp-syi__link')[0]) { produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href") }

  produto = new URL(produto)
  produto = produto.searchParams.get('itemId')

  if (!produto) {
    produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
    produto = new URL(produto)
    produto = produto.searchParams.get('itemId')
  }

  RenderProdutoGratis(produto);
  return true;
}

async function RenderProdutoGratis(produto) {

  var Titulo = document.getElementsByClassName('ui-pdp-header__subtitlex')[0];
  Titulo = document.getElementsByClassName('ui-pdp-header')[0];

  function ValidarLoding() {
    if (!document.getElementsByClassName('loader')[0]) {
      console.log("if");
      clearInterval(Lodinginterval);
      let local = document.getElementsByClassName('ui-pdp-header')[0];
      local.innerHTML = `
      <center>
      <div class="loader">
      <svg width="60" height="73" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <defs>
      <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
      <stop offset="0.139315" stop-color="#271BEF"/>
      <stop offset="0.942129" stop-color="#00C2FF"/>
      </linearGradient>
      <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
      <stop offset="0.0921191" stop-color="#00C2FF"/>
      <stop offset="0.970863" stop-color="#271BEF"/>
      </linearGradient>
      </defs>
      </svg>
      <p style="font-size: 18px;"><strong>Carregando dados Avantpro...</strong></p>
      </div>
      </center>
      ` + Titulo.innerHTML;
    }
    else {
      let local = document.getElementsByClassName('ui-pdp-header')[0];
      local.innerHTML = '' + Titulo.innerHTML;
    }
  }
  var Lodinginterval = setInterval(ValidarLoding, 500);


  const rawItems = await MeliAPI.getItemUnico(produto);

  rawItems.numero_vendas = document.getElementsByClassName('ui-pdp-subtitle')[0].innerHTML.replace(/([^\d])+/gim, '');

  rawItems.visitas = 1;
  /* FIM VISTAS */

  MeliAdapter.ConvertDataProduto(rawItems);


  if (rawItems.seller_address.country.id == 'BR') {

    var taxa = await MeliAPI.getTaxasByIdEspecifico(rawItems.category_id, rawItems.price, rawItems.listing_type_id);

    rawItems.TAXA = taxa;

    /* Crindo a linha "Comissão do ML"  */
    let supermercado = rawItems.tags.includes('supermarket_eligible');
    rawItems.supermercado = supermercado;
    var ProcentagemComissao = supermercado ? (((taxa.sale_fee_amount > 5 && rawItems.price < 199) ? taxa.sale_fee_amount - 1.5 : taxa.sale_fee_amount) / rawItems.price) * 100 : ((taxa.sale_fee_amount) / rawItems.price) * 100
    rawItems.COMISSAO = ProcentagemComissao;
    rawItems.TAXA.sale_fee_amount = supermercado ? ((taxa.sale_fee_amount > 5 && rawItems.price < 199) ? taxa.sale_fee_amount - 1.5 : taxa.sale_fee_amount) : taxa.sale_fee_amount;

    /* Crindo a linha "TipoAnuncio"  */
    rawItems.TIPOANUNCIO = taxa.listing_type_name;

    /* Crindo a linha "ValorFrete"  */

    var Frete;

    try {
      Frete = await MeliAPI.getFreteById(rawItems.seller_id, produto);
    } catch (error) {
      Frete = { "coverage": { "all_country": { "list_cost": 0, "currency_id": "BRL", "billable_weight": 0 } } }
    }


    rawItems.FRETE = Frete
    if (rawItems.shipping.free_shipping) {
      rawItems.VALORFRETE = Frete.coverage.all_country.list_cost.toFixed(2);
    } else {
      rawItems.VALORFRETE = 0;
    }


    var ValorImposto = (rawItems.price / 100) * 7;


    var ValorVendedor = rawItems.price - (taxa == undefined ? 0 : rawItems.TAXA.sale_fee_amount) - ValorImposto

    if (rawItems.shipping.free_shipping) {
      ValorVendedor = ValorVendedor - (Frete == undefined ? 0 : Frete.coverage.all_country.list_cost)
    }

    var ProcentagemValorVendedor = ((ValorVendedor) / rawItems.price) * 100

    rawItems.ValorVendedor = ValorVendedor;
    rawItems.ProcentagemValorVendedor = ProcentagemValorVendedor;
    rawItems.ValorImposto = ValorImposto;

    var ValorBase = rawItems.price - (taxa == undefined ? 0 : rawItems.TAXA.sale_fee_amount) - ValorImposto

    if (rawItems.shipping.free_shipping) {
      ValorBase = ValorBase - (Frete == undefined ? 0 : Frete.coverage.all_country.list_cost)
    }

    rawItems.ValorBase = ValorBase;

    /** PONTOS NEGATIVOS */
    let ean = rawItems.attributes.filter(item => String(item.id) == 'GTIN');
    let atributos = [];

    if (ean == '') {
      for (let i = 0; i < rawItems.variations.length; i++) {
        atributos = rawItems.variations[i].attributes.filter(item => String(item.id) == 'GTIN');
        ean += atributos.length > 0 ? (atributos[0].value_name != null ? atributos[0].value_name + ',' : '') : '';
      }
    } else {
      ean = ean[0].value_name;
    }

    if (ean == '') ean = 'Sem EAN';


    let semResolucao = 0;

    for (let i = 0; i < rawItems.pictures.length; i++) {
      let tamanho = rawItems.pictures[i].max_size.split('x');
      if (parseInt(tamanho[0]) < 1200 || parseInt(tamanho[1]) < 1200) {
        semResolucao += 1;
      }
    }
    rawItems.semResolucao = semResolucao;
    rawItems.ean = ean;

    /** FIM PONTOS NEGATIVOS */

  } else {
    rawItems.shipping ? '' : rawItems.shipping = {};
    rawItems.COMISSAO = 0;
    rawItems.TIPOANUNCIO = 0;
    rawItems.VALORFRETE = 0;
    rawItems.TAXA.sale_fee_amount = 0;
    rawItems.TAXA.listing_type_name = '';
    rawItems.shipping.free_shipping = true;
    rawItems.FRETE.coverage.all_country.list_cost = 0;
    rawItems.ValorVendedor = 0;
    rawItems.ProcentagemValorVendedor = 0;
    rawItems.ValorImposto = 0;
    rawItems.ValorBase = 0;
    rawItems.semResolucao = 0;
    rawItems.ean = '';
  }



  /** VENDEDOR */


  const sellerBase = await MeliAPI.getSellerById(rawItems.seller_id);

  rawItems.sellerBase = sellerBase;

  const seller = await MeliAPI.getVendedorByNickname(sellerBase.nickname);

  rawItems.seller = seller;

  MeliAdapter.ConvertDataVendedor(rawItems);

  function validarFoco() {
    if (document.visibilityState == 'visible') {
      clearInterval(statusFoco);

      function RemoverLoad() {
        if (document.getElementsByClassName('loader')[0]) {
          try {
            var element1 = document.getElementsByClassName('loader')[0];
            element1.parentNode.removeChild(element1);
            // var element2 = document.getElementById('MLPro2');
            // element2.parentNode.removeChild(element2);
            clearInterval(LoadInterval);
          } catch (error) {

          }
        }
      }
      var LoadInterval = setInterval(RemoverLoad, 500);

      RenderProdutos.ProdutoGratis(rawItems);

      RenderProdutos.VendedorGratis(rawItems);

      RenderProdutos.BaixarGratis();

    }
  }
  var statusFoco = setInterval(validarFoco, 1000);


}

async function getTendenciasGratis() {

  Render.loadingTendencias();

  var url_atual = document.URL;
  var urlSplit = url_atual.split("/");
  urlSplit = urlSplit[3].split("-");
  var idCategoria = urlSplit[0];
  var falhouConsulta = false;

  //let rawTendencias = [];
  let rawTendenciasExtra = [];

  await Promise.all([
    MeliAPI.getTendenciasExtra(idCategoria),
  ]).then(results => {
    rawTendenciasExtra = results[0];
  })
    .catch(() => { falhouConsulta = true })


  if (falhouConsulta) {
    Render.tenteNovamenteTendencias();
  } else {
    console.log('[MeliAPI] Tendencias Extra Resultado: ', { rawTendenciasExtra });

    if (document.contains(document.querySelector(".loading"))) {
      document.querySelector('.loading').remove();
    }

    Render.tendenciasExtraGratis(rawTendenciasExtra);

    window.addEventListener("DOMContentLoaded", function () {

      window.addEventListener("message", (event) => {
        if (event.data.event_id == "emailmlpro") {
          localStorage.setItem('emailmlpro', event.data.data.email);
        }
      }, false);
    });
  }



}

async function getDetalhesProdutoCatalogoGratis() {
  const href = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
  const urlCatalogo = new URL(href)

  const produto = urlCatalogo.searchParams.get('itemId')

  RenderProdutoGratis(produto, true);


  var newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '/?' + produto;
  window.history.pushState({ path: newurl }, '', newurl);

}

async function getAnunciosLogadoGratis(tipo) {
  if (!Page.hasItemsLogados()) {
    return false;
  }

  let itemListLogados = Page.searchIdsLogados();
  console.log('[BuscaDados] Itens encontrados Logados: ', { itemListLogados })


  const rawItems = await MeliAPI.getItems(itemListLogados);
  console.log('[BuscaDados] Itens encontrados', { rawItems });


  // Mapping items
  itemListLogados = MeliAdapter.items(
    itemListLogados,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados', { itemListLogados })


  //ATIVAR STYLE
  Render.dadosAnuncioGratis(itemListLogados);
  Render.dadosAnuncioValorGratis(itemListLogados);
}

async function getAnunciosMaisVendidosGratis() {

  if (!Page.hasItemsMaisVendidos()) {
    return false;
  }

  jquery();

  // Get items IDs
  let itemList = Page.searchIdsMaisVendidos();
  console.log('[Pesquisa] Itens mais vendidos encontrados: ', { itemList })


  // Get items details
  const rawItems = await MeliAPI.getItems(itemList);
  console.log('[MeliAPI] Itens encontrados', { rawItems })


  Render.pesquisaLoadingMaisVendidos(itemList);



  // Mapping items
  itemList = await MeliAdapter.items(
    itemList,
    rawItems
  );
  console.log('[MeliAdapter] Itens Mapeados COM VENDEDOR', { itemList })

  //vendedores unicos
  let idVendedor = await itemList.map(({ seller_id }) => seller_id);

  let idVendedorUnicos = idVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let idVendedorUnicosJson = []

  for (let i = 0; i < idVendedorUnicos.length; i++) {
    idVendedorUnicosJson.push({
      seller_id: idVendedorUnicos[i],
    })
  }


  // Get sellers details
  const rawSellers = await MeliAPI.getSellers(idVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores Encontrados', { rawSellers })


  // Mapping sellers
  itemList = MeliAdapter.sellers(
    itemList,
    rawSellers
  );
  console.log('[MeliAdapter] Vendedores Mapeados com ajuste', { itemList })


  // Get visitas
  let rawVisitas = [];
  let vetorMLB = [];

  for (let i = 0; i < itemList.length; i++) {
    vetorMLB[i] = itemList[i].id;
  }

  try {
    rawVisitas = await MeliAPI.getVisitasByIdNovo({ ITEM: vetorMLB });
    console.log('[MeliAPI] Numero Visitas', { rawVisitas })
  } catch (error) {

  }



  // Mapping Visitas
  itemList = MeliAdapter.visitas(
    itemList,
    rawVisitas
  );
  console.log('[MeliAdapter] Visitas Mapeadas', { itemList })


  // Get sellers details 
  const rawTaxas = await MeliAPI.getTaxas(itemList);
  console.log('[MeliAPI] Taxas Canculadas', { rawTaxas })



  itemList = MeliAdapter.taxas(
    itemList,
    rawTaxas
  );
  console.log('[MeliAdapter] Taxas Mapeadas', { itemList })



  //qtd medalhas
  let qtdSemMedalha = 0;
  let qtdLider = 0;
  let qtdGold = 0;
  let qtdPlatinum = 0;
  let menorPreco = 0;
  let maiorPreco = 0;
  let qtdFull = 0;
  let qtdFreteGratis = 0;
  let qtdClassico = 0;
  let qtdPremium = 0;
  let qtdLojasOficiais = 0;
  let qtdCatalogo = 0;
  let qtdSupermercado = 0;
  let menorVenda = 0;
  let maiorVenda = 0;
  let totalVendas = 0;
  let qtdFlex = 0;
  let qtdInternacional = 0;

  let qtdVendas = itemList.map(({ vendas }) => vendas)
  menorVenda = Math.min(...qtdVendas);
  maiorVenda = Math.max(...qtdVendas);


  let valores = itemList.map(({ price }) => price)
  menorPreco = Math.min(...valores);
  maiorPreco = Math.max(...valores);


  let nicknameVendedor = await itemList.map(({ seller }) => seller.nickname);

  let nicknameVendedorUnicos = nicknameVendedor.filter((el, i, arr) => arr.indexOf(el) == i);

  let nicknameVendedorUnicosJson = []

  for (let i = 0; i < nicknameVendedorUnicos.length; i++) {
    nicknameVendedorUnicosJson.push({
      nickname: nicknameVendedorUnicos[i],
      qtdAnuncio: 0
    })
  }

  // Get items details
  const rawVendedoresCompleto = await MeliAPI.getVendedor(nicknameVendedorUnicosJson);
  console.log('[MeliAPI] Vendedores consulta completa', { rawVendedoresCompleto })

  for (let x = 0; x < rawVendedoresCompleto.length; x++) {
    rawVendedoresCompleto[x].qtdAnuncio = 0;
  }

  let concatTitulos = '';

  for (let i = 0; i < itemList.length; i++) {
    totalVendas += itemList[i].vendas;
    concatTitulos += itemList[i].title.replace(/'/g, ' ').replace(/"/g, ' ').trim() + ' ';
    for (let x = 0; x < rawVendedoresCompleto.length; x++) {
      if (itemList[i].seller.nickname == rawVendedoresCompleto[x].seller.nickname) {
        rawVendedoresCompleto[x].qtdAnuncio += 1;
        rawVendedoresCompleto[x].cidade = itemList[i].seller.address.city;
        rawVendedoresCompleto[x].uf = itemList[i].seller.address.state;
        break;
      }
    }
  }

  // Start
  concatTitulos = concatTitulos.trim();
  let arrayConcatTitulos = concatTitulos.split(" ");
  arrayConcatTitulos = arrayConcatTitulos.filter(x => x.trim());


  var count = {};
  arrayConcatTitulos.forEach(function (i) { count[i] = (count[i] || 0) + 1; });


  var SortArr2 = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val),
        intB = parseInt(b.val);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJson = SortArr2(count);
  //end

  var SortArr = function (j) {
    var arr = [];
    for (var key in j) {
      arr.push({ key: key, val: j[key] });
    }
    arr.sort(function (a, b) {
      var intA = parseInt(a.val.qtdAnuncio),
        intB = parseInt(b.val.qtdAnuncio);
      if (intA > intB)
        return -1;
      if (intA < intB)
        return 1;
      return 0;
    });
    return arr;
  };

  var arrJsonVendedores = SortArr(rawVendedoresCompleto);




  for (let i = 0; i < itemList.length; i++) {
    if (itemList[i].logistic_type == 'fulfillment') qtdFull += 1;
    if (itemList[i].free_shipping) qtdFreteGratis += 1;
    if (itemList[i].listing_type_id == 'gold_special') qtdClassico += 1;
    if (itemList[i].listing_type_id == 'gold_pro') qtdPremium += 1;
    if (itemList[i].loja_oficial) qtdLojasOficiais += 1;
    if (itemList[i].catalogo) qtdCatalogo += 1;
    if (itemList[i].supermercado) qtdSupermercado += 1;
    if (itemList[i].flex) qtdFlex += 1;

    try {
      if (itemList[i].seller.tags.includes('international_seller')) qtdInternacional += 1;
    } catch (error) {

    }
  }


  for (let i = 0; i < itemList.length; i++) {

    switch (itemList[i].seller.seller_reputation.power_seller_status) {
      case 'platinum':
        qtdPlatinum += 1;
        break;
      case 'silver':
        qtdLider += 1;
        break;
      case 'gold':
        qtdGold += 1;
        break;
      default:
        qtdSemMedalha += 1;
        break;
    }
  }


  chrome.storage.local.get(['emailmlpro', 'tokenmlpro'], async function (response) {
    var emailRetornado = response.email;

    Render.botaoPalavrasChavesMaisVendidosGratis(concatTitulos);
    Render.pesquisaPorAnuncioMaisVendidosGratis(itemList, emailRetornado);
    Render.menuLateralMaisVendidosGratis(qtdSemMedalha, qtdLider, qtdGold, qtdPlatinum, qtdFull, menorPreco, maiorPreco, qtdFreteGratis, qtdClassico, qtdPremium, qtdLojasOficiais, qtdCatalogo, arrJsonVendedores, qtdSupermercado, maiorVenda, menorVenda, totalVendas, qtdFlex);
  });

}

async function getAnunciarGratis() {
  var header = document.head;


  function renderizaBotaoEan() {
    if (document.getElementsByClassName('andes-form-control__label')[0] != undefined) {
      let blocoEan = document.getElementsByClassName('andes-form-control__label');
      for (let i = 0; i < blocoEan.length; i++) {
        if (blocoEan[i].innerHTML == 'Código universal de produto') {
          let botaoEan = `<div style="background: gray" class="eananuncio" id="eananuncio" onclick="alert('Assine a versão Premium do Avantpro para liberar o gerador de EAN')"> 
            <img src="http://ramcloud.com.br/img/icones/refresh-barcode-melipro.png" style="margin: auto;width: 90%;"> 
            <span class="eantxt" id="eantxt">Gerar EAN</span> 
          </div>`;
          blocoEan[i].parentNode.parentNode.parentNode.insertAdjacentHTML('afterbegin', botaoEan);

          clearInterval(verificaEan);
        }
      }
    }
  }
  let verificaEan = setInterval(renderizaBotaoEan, 450);

}

/** FIM VERSÃO GRATIS */


/** ********************************** */

async function RenderProduto(produto, catalogo, ultra) {

  var Titulo = document.getElementsByClassName('ui-pdp-header__subtitlex')[0];
  Titulo = document.getElementsByClassName('ui-pdp-header')[0];

  function ValidarLoding() {
    if (document.getElementsByClassName('loader')[0]) {
      clearInterval(Lodinginterval);
      let local = document.getElementsByClassName('ui-pdp-header')[0];
      local.innerHTML = `
      <center>
      <div class="loader">
      <svg width="60" height="73" viewBox="0 0 133 140" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M103.43 131.97C95.9821 127.681 86.6588 122.312 66.7678 122.312C47.6169 122.312 38.6168 127.289 31.0248 131.487C25.4871 134.549 20.6986 137.197 13.2663 137.197C0.74027 137.197 -0.321359 124.408 5.11231 112.823L13.7382 93.9172L13.7629 93.8629L48.2091 18.3666C53.5315 5.48695 71.4825 -10.9077 85.1683 18.3666C99.695 49.4395 119.581 93.9442 127.163 112.823C132.382 125.816 133.008 137.197 118.358 137.197C112.61 137.197 108.529 134.905 103.691 132.12C103.604 132.07 103.517 132.02 103.43 131.97ZM103.43 131.97C103.347 131.922 103.264 131.874 103.181 131.826M70.1134 46.1664C67.8284 41.3163 64.4814 42.3668 62.6013 46.1664L54.0028 65.1749C53.1051 67.3046 53.9061 70.8936 57.3734 70.4037C59.3145 70.1294 60.2864 68.8321 61.2749 67.5127C62.432 65.9681 63.6119 64.3933 66.3956 64.3933C68.9811 64.3933 69.8665 65.7437 70.8294 67.2124C71.6266 68.4281 72.4768 69.7249 74.3884 70.4037C78.5644 71.8866 79.4513 67.4672 78.5644 65.1749C77.0385 61.3757 72.548 51.3341 70.1134 46.1664Z" stroke="url(#paint0_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <path d="M103.43 131.969C95.9821 127.68 86.6588 122.311 66.7678 122.311C47.6169 122.311 38.6168 127.288 31.0248 131.486C25.4871 134.549 20.6986 137.196 13.2663 137.196C0.74027 137.196 -0.321359 124.408 5.11231 112.822L13.7498 93.8911C36.652 82.0706 78.0701 117.366 103.43 131.969Z" stroke="url(#paint1_linear_120_2)" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
      <defs>
      <linearGradient id="paint0_linear_120_2" x1="66" y1="2" x2="66" y2="137" gradientUnits="userSpaceOnUse">
      <stop offset="0.139315" stop-color="#271BEF"/>
      <stop offset="0.942129" stop-color="#00C2FF"/>
      </linearGradient>
      <linearGradient id="paint1_linear_120_2" x1="6.5" y1="106.5" x2="95.5" y2="127.5" gradientUnits="userSpaceOnUse">
      <stop offset="0.0921191" stop-color="#00C2FF"/>
      <stop offset="0.970863" stop-color="#271BEF"/>
      </linearGradient>
      </defs>
      </svg>
      <p style="font-size: 18px;"><strong>Carregando dados Avantpro...</strong></p>
      </div>
      </center>
      ` + Titulo.innerHTML;
    }
    else {
      let local = document.getElementsByClassName('ui-pdp-header')[0];
      local.innerHTML = '' + Titulo.innerHTML;
    }
  }
  var Lodinginterval = setInterval(ValidarLoding, 500);

  var DadosTeste = {};

  try {
    DadosTeste = await ValidaTeste();
  } catch (error) {
    DadosTeste.initialState.app = 'pdp';
  }


  console.log('[BuscaDados] Anucio: ', produto);

  const rawItems = await MeliAPI.getItemUnico(produto);

  try {
    rawItems.numero_vendas = document.getElementsByClassName('ui-pdp-subtitle')[0].innerHTML.replace(/([^\d])+/gim, '');
  } catch (error) {
    rawItems.numero_vendas = 0;
  }

  if (DadosTeste.initialState.app == 'vip') {
    rawItems.event = DadosTeste.initialState.track.gtm_event;
  } else {
    rawItems.event = { 'pageid': 'PDP' }
  }

  console.log('[meliAPI] Resultado: ', rawItems)


  /* VISITAS */
  let visitaSplit = 0;


  try {
    const rawVisitas = await MeliAPI.getVisitaUnico(produto);
    console.log('[meliAPI] Resultado Visita Unico: ', rawVisitas);

    visitaSplit = JSON.stringify(rawVisitas).split(":");
    visitaSplit = visitaSplit[1].replace("}", "");
    visitaSplit = visitaSplit.trim();
    visitaSplit = parseInt(visitaSplit);
  } catch (error) {

  }

  rawItems.visitas = visitaSplit;
  /* FIM VISTAS */

  console.log('[MeliAdapter] Start ')

  MeliAdapter.ConvertDataProduto(rawItems);

  console.log('[MeliAdapter] End: ', rawItems)

  /* [MeliAPI] - Pegar informção da taixa  */
  console.log('[MeliAPI TAXA/FRETE] - START ');

  if (rawItems.seller_address && (rawItems.seller_address.country != undefined && rawItems.seller_address.country.id == 'BR')) {

    var taxa = await MeliAPI.getTaxasByIdEspecifico(rawItems.category_id, rawItems.price, rawItems.listing_type_id);

    rawItems.TAXA = taxa;

    rawItems.internacional = false;

    /* Crindo a linha "Comissão do ML"  */
    let supermercado = rawItems.tags.includes('supermarket_eligible');
    rawItems.supermercado = supermercado;
    console.log('comissao taxa.sale_fee_amount ' + taxa.sale_fee_amount);

    var taxasupermercado = 0;
    if (supermercado) {
      if (parseFloat(rawItems.price) >= 5 && parseFloat(rawItems.price) <= 29.99) { taxasupermercado = 1; }
      if (parseFloat(rawItems.price) >= 30 && parseFloat(rawItems.price) <= 49.99) { taxasupermercado = 2; }
      if (parseFloat(rawItems.price) >= 50 && parseFloat(rawItems.price) <= 198.99) { taxasupermercado = 4; }
      if (parseFloat(rawItems.price) >= 199) { taxasupermercado = 6; }
    }


    var ProcentagemComissao = supermercado ? (((taxa.sale_fee_amount > 6 && rawItems.price < 79) ? ((taxa.sale_fee_amount - 6) + taxasupermercado) : taxa.sale_fee_amount) / rawItems.price) * 100 : ((taxa.sale_fee_amount) / rawItems.price) * 100
    rawItems.COMISSAO = ProcentagemComissao;
    rawItems.TAXA.sale_fee_amount = supermercado ? ((taxa.sale_fee_amount > 6 && rawItems.price < 79) ? ((taxa.sale_fee_amount - 6) + taxasupermercado) : taxa.sale_fee_amount) : taxa.sale_fee_amount;

    /* Crindo a linha "TipoAnuncio"  */
    rawItems.TIPOANUNCIO = taxa.listing_type_name;

    /* Crindo a linha "ValorFrete"  */

    var Frete;

    try {
      Frete = await MeliAPI.getFreteById(rawItems.seller_id, produto);
    } catch (error) {
      Frete = { "coverage": { "all_country": { "list_cost": 0, "currency_id": "BRL", "billable_weight": 0 } } }
    }

    rawItems.FRETE = Frete
    if (rawItems.shipping.free_shipping) {
      rawItems.VALORFRETE = Frete.coverage.all_country.list_cost.toFixed(2);
    } else {
      rawItems.VALORFRETE = 0;
    }


    var ValorImposto = (rawItems.price / 100) * 7;
    var ValorVendedor = rawItems.price - (taxa == undefined ? 0 : rawItems.TAXA.sale_fee_amount) - ValorImposto

    if (rawItems.shipping.free_shipping) {
      ValorVendedor = ValorVendedor - (Frete == undefined ? 0 : Frete.coverage.all_country.list_cost)
    }

    var ProcentagemValorVendedor = ((ValorVendedor) / rawItems.price) * 100

    rawItems.ValorVendedor = ValorVendedor;
    rawItems.ProcentagemValorVendedor = ProcentagemValorVendedor;
    rawItems.ValorImposto = ValorImposto;

    var ValorBase = rawItems.price - (taxa == undefined ? 0 : rawItems.TAXA.sale_fee_amount) - ValorImposto

    if (rawItems.shipping.free_shipping) {
      ValorBase = ValorBase - (Frete == undefined ? 0 : Frete.coverage.all_country.list_cost)
    }

    rawItems.ValorBase = ValorBase;

    /** PONTOS NEGATIVOS */
    let ean = rawItems.attributes.filter(item => String(item.id) == 'GTIN');
    let atributos = [];

    if (ean == '') {
      for (let i = 0; i < rawItems.variations.length; i++) {
        atributos = rawItems.variations[i].attributes.filter(item => String(item.id) == 'GTIN');
        ean += atributos.length > 0 ? (atributos[0].value_name != null ? atributos[0].value_name + ',' : '') : '';
      }
    } else {
      ean = ean[0].value_name;
    }

    if (ean == '') ean = 'Sem EAN';

    let semResolucao = 0;

    for (let i = 0; i < rawItems.pictures.length; i++) {
      let tamanho = rawItems.pictures[i].max_size.split('x');
      if (parseInt(tamanho[0]) < 1200 || parseInt(tamanho[1]) < 1200) {
        semResolucao += 1;
      }
    }
    rawItems.semResolucao = semResolucao;
    rawItems.ean = ean;

    /** FIM PONTOS NEGATIVOS */

    rawItems.catalogo = catalogo;


  } else {
    rawItems.shipping ? '' : rawItems.shipping = {};
    rawItems.COMISSAO = 0;
    rawItems.TIPOANUNCIO = 0;
    rawItems.VALORFRETE = 0;
    rawItems.TAXA ? rawItems.TAXA.sale_fee_amount = 0 : '';
    rawItems.TAXA ? rawItems.TAXA.listing_type_name = '' : '';
    rawItems.shipping.free_shipping = true;
    rawItems.FRETE ? rawItems.FRETE.coverage.all_country.list_cost = 0 : '';
    rawItems.ValorVendedor = 0;
    rawItems.ProcentagemValorVendedor = 0;
    rawItems.ValorImposto = 0;
    rawItems.ValorBase = 0;
    rawItems.semResolucao = 0;
    rawItems.ean = '';
    rawItems.catalogo = '';
    rawItems.internacional = true;
  }

  console.log('[MeliAPI TAXA/FRETE] - END ', rawItems);

  if (rawItems.catalogo) {

    rawItems.availableStock = undefined
  } else {
    
    try {
      let response = await fetch(location.origin + location.pathname, {
        credentials: "omit",
      });

      let result = await response.text()

      let startStock = result.indexOf('"availableStock');
      result = result.substring(startStock);
      let endStock = result.indexOf(',"');
      result = result.substring(0, endStock);
      result = `{${result}}`;
      let dadosJson = JSON.parse(result);

      rawItems.availableStock = dadosJson.availableStock
    } catch (error) {
      rawItems.availableStock = undefined
    }

  }

  /** VENDEDOR */


  console.log('[BuscaDados] Vendedor by ID: ', rawItems.seller_id)

  const sellerBase = await MeliAPI.getSellerById(rawItems.seller_id);

  rawItems.sellerBase = sellerBase;

  console.log('[BuscaDados] Resultado: ', sellerBase)

  console.log('[BuscaDados] Vendedor by NickName: ', sellerBase.nickname);

  const seller = await MeliAPI.getVendedorByNickname(sellerBase.nickname);

  rawItems.seller = seller;

  console.log('[BuscaDados] Resultado: ', seller)


  console.log('[MeliAdapter - Vendedor] Start ')

  MeliAdapter.ConvertDataVendedor(rawItems);

  console.log('[MeliAdapter - Vendedor] End: ', rawItems)

  console.log('[RenderProdutos] Start');

  function validarFoco() {
    if (document.visibilityState == 'visible') {
      clearInterval(statusFoco);

      function RemoverLoad() {
        if (document.getElementsByClassName('loader')[0]) {
          try {
            var element1 = document.getElementsByClassName('loader')[0];
            element1.parentNode.removeChild(element1);
            // var element2 = document.getElementById('MLPro2');
            // element2.parentNode.removeChild(element2);
            clearInterval(LoadInterval);
          } catch (error) {

          }
        }
      }
      var LoadInterval = setInterval(RemoverLoad, 500);

      RenderProdutos.Produto(rawItems, ultra);

      RenderProdutos.Vendedor(rawItems);

      //adiciona scripts
      var header = document.head;
      // var script = document.createElement('script');
      // script.src = "https://ramcloud.com.br/fotosdownload.js?" + Math.round((new Date()).getTime() / 1000);;
      // header.appendChild(script);

      MeliAPI.scriptBase('https://ramcloud.com.br/fotosdownload.js');

      RenderProdutos.Baixar(produto);

      if (ultra) RenderProdutos.ProdutoUltra(rawItems);

      console.log('[RenderProdutos] End')

      function LimparDados(e) {
        window.location.href = this.href
      }

      var btnLista = document.getElementsByClassName('ui-pdp-thumbnail ui-pdp-variations--thumbnail');

      for (let index = 0; index < btnLista.length; index++) {
        const element = btnLista[index];
        element.onclick = LimparDados;
      }
    }
  }

  var statusFoco = setInterval(validarFoco, 1000);

}


async function getDetalhesProduto(ultra) {
  let produto = '';

  if (document.getElementsByClassName('ui-pdp-syi__link')[0]) { produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href") }

  produto = new URL(produto)
  produto = produto.searchParams.get('itemId')

  if (!produto) {
    produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
    produto = new URL(produto)
    produto = produto.searchParams.get('itemId')
  }

  RenderProduto(produto, false, ultra);
  return true;
}

async function getDetalhesProdutoValidacao() {
  setTimeout(async function () {
    let produto = '';

    if (document.getElementsByClassName('ui-pdp-syi__link')[0]) { produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href") }

    produto = new URL(produto)
    produto = produto.searchParams.get('itemId')

    if (!produto) {
      produto = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
      produto = new URL(produto)
      produto = produto.searchParams.get('itemId')
    }

    const rawItems = await MeliAPI.getItemUnico(produto);

    var divSubtitle = document.createElement('div');
    divSubtitle.className = 'divSubtitle';
    divSubtitle.style.border;

    var Titulo = document.getElementsByClassName('ui-pdp-header__subtitle')[0];

    if (Titulo == undefined) {
      if (document.getElementsByClassName('ui-pdp-header__tag').length > 0) {
        Titulo = document.createElement('div');
        Titulo.appendChild(document.getElementsByClassName('ui-pdp-header__tag')[0]);
      } else {
        Titulo = document.createElement('div');
        Titulo.appendChild(document.getElementsByClassName('melipro-head')[0]);
      }
    }
    divSubtitle.appendChild(Titulo);

    var header = document.getElementsByClassName('ui-pdp-header')[0];

    var vendas = document.createElement('div');
    vendas.className = 'vendas';
    vendas.insertBefore(divSubtitle, vendas.firstChild);

    header.insertBefore(vendas, document.getElementsByClassName("ui-pdp-header__title-container")[0]);

    var conteudo = document.createElement('div');
    conteudo.innerHTML =
      `<br><center class="infoDeslogadoProd">
      <div style="background: linear-gradient(90deg, rgba(94,191,240,1) 0%, rgba(10,99,244,1) 100%);width: 110px;border-radius: 5px;display: flex;align-items: center;position: absolute;top: 25px;right: 33%;">
				<img src="https://ramcloud.com.br/img/logoavant.png" alt="" style="width: 21px;margin: 4px;"> 
				<span style="color: white;font-weight: bold;font-size: 17px;">Avantpro</span>
			</div>
      <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 10px;">Comece a usar o Avantpro!</h4>
      <button class="btn btn-primary" style="width: 100%; margin: 5px auto 10px auto;" onclick="(function(){ document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;'); })()">ENTRAR</button>
      <h5 style="text-align: center; color: var(--grey);">Não possui uma conta? <a href="https://www.viapedidos.com/empresa/cadastromlpro" target="blank">Crie uma aqui</a></h5>`

    Titulo.appendChild(conteudo);

  }, 2000)

}

async function getDetalhesProdutoCatalogoValidacao() {
  setTimeout(async function () {
    const href = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
    const urlCatalogo = new URL(href)

    const produto = urlCatalogo.searchParams.get('itemId')

    const rawItems = await MeliAPI.getItemUnico(produto);

    var divSubtitle = document.createElement('div');
    divSubtitle.className = 'divSubtitle';

    divSubtitle.style.border

    var Titulo = document.getElementsByClassName('ui-pdp-header__subtitle')[0];
    divSubtitle.appendChild(Titulo);

    var header = document.getElementsByClassName('ui-pdp-header')[0];

    var vendas = document.createElement('div');
    vendas.className = 'vendas';
    vendas.insertBefore(divSubtitle, vendas.firstChild);

    header.insertBefore(vendas, document.getElementsByClassName("ui-pdp-header__title-container")[0]);

    var conteudo = document.createElement('div');
    conteudo.innerHTML =
      `<br><center class="infoDeslogadoProd">
      <div style="background: linear-gradient(90deg, rgba(94,191,240,1) 0%, rgba(10,99,244,1) 100%);width: 110px;border-radius: 5px;display: flex;align-items: center;position: absolute;top: 25px;right: 33%;">
        <img src="https://ramcloud.com.br/img/logoavant.png" alt="" style="width: 21px;margin: 4px;"> 
        <span style="color: white;font-weight: bold;font-size: 17px;">Avantpro</span>
      </div>
      <h4 style="text-align: center; color: var(--grey); font-weight: 600; margin-bottom: 10px;">Comece a usar o Avantpro!</h4>
      <button class="btn btn-primary" style="width: 100%; margin: 5px auto 10px auto;" onclick="(function(){ document.getElementsByClassName('bodyValidacao')[0].setAttribute('style','display:block;'); })()">ENTRAR</button>
      <h5 style="text-align: center; color: var(--grey);">Não possui uma conta? <a href="https://www.viapedidos.com/empresa/cadastromlpro" target="blank">Crie uma aqui</a></h5>`

    Titulo.appendChild(conteudo);


  }, 2000)
}



async function getDetalhesProdutoCatalogo(ultra) {
  const href = document.getElementsByClassName('ui-pdp-syi__link')[0].getAttribute("href")
  const urlCatalogo = new URL(href)

  const produto = urlCatalogo.searchParams.get('itemId')

  var url = new window.URL(window.location.href)
  if (url.searchParams.has('IDML')) {
    url.searchParams.set('IDML', String(produto));
  } else {
    url.searchParams.append('IDML', String(produto));
  }
  window.history.pushState({ path: url.href }, '', url.href);

  RenderProduto(produto, true, ultra);
}

/** INICIO TENDENCIAS */



async function getTendencias(ultra) {
  //Render.loadingTendencias();


  var DadosTeste = await ValidaTeste();

  var idCategoria = '';
  var falhouConsulta = false;

  if (DadosTeste.initialState == undefined) {
    idCategoria = '';
  } else {
    idCategoria = DadosTeste.initialState.melidata_track.event_data.category_id.replace('MLB', '');
  }

  /*   var url_atual = document.URL;
    var urlSplit = url_atual.split("applied_value_id%3D");
    urlSplit = urlSplit[1].split("%"); */

  //let rawTendencias = [];
  let rawTendenciasExtra = [];
  let rawTendenciasDadosExtra = [];
  let rawAnunciosMaisVendidos = [];
  let urls = [];
  let sazonalidades = [];


  await Promise.all([
    MeliAPI.getTendenciasExtra(idCategoria),
    MeliAPI.getTendenciasDadosExtra(idCategoria),
    (idCategoria > 0 && ultra) ? MeliAPI.getAnunciosMaisVendidos(idCategoria) : '',
    ultra ? MeliAPI.getSazonalidade() : '',
  ]).then(results => {
    rawTendenciasExtra = results[0];
    rawTendenciasDadosExtra = results[1];
    rawAnunciosMaisVendidos = results[2];
    sazonalidades = results[3];
  })
    .catch(() => { falhouConsulta = true })



  if (falhouConsulta) {
    Render.tenteNovamenteTendencias();
  } else {
    console.log('[MeliAPI] Tendencias Extra Resultado: ', { rawTendenciasExtra });
    console.log('[MeliAPI] Tendencias Dados Extra Resultado: ', { rawTendenciasDadosExtra });


    if (document.contains(document.querySelector(".loading"))) {
      document.querySelector('.loading').remove();
    }

    Render.tendenciasExtra(rawTendenciasExtra);
    if (ultra) {
      sazonalidades = JSON.parse(sazonalidades.RESULT[0].TERMO);
      Render.tendenciasCalendario(sazonalidades);
    }

    if (idCategoria > 0) {
      Render.tendenciasExtraDados(rawTendenciasDadosExtra, ultra);
      if (ultra) Render.botaoAnunciosMaisVendidos(rawAnunciosMaisVendidos);
    }


    window.addEventListener("DOMContentLoaded", function () {

      window.addEventListener("message", (event) => {

        if (event.data.event_id == "emailmlpro") {
          localStorage.setItem('emailmlpro', event.data.data.email);
        }
      }, false);
    });
  }


}




/** FIM TENDENCIAS */


async function getMenuMeliPRO(validacao, response) {
  let ultra = false;

  if (response.ULTRA) {
    ultra = true;
  }

  Render.menuMeliPRO(validacao, ultra);

  //adiciona scripts
  var header = document.head;
  MeliAPI.scriptBase('https://code.jquery.com/jquery-3.1.1.min.js');
  if (ultra) {
    MeliAPI.scriptBase('https://ramcloud.com.br/gerador100ean2.js');
    MeliAPI.scriptBase('https://ramcloud.com.br/editarfotos2.js');
  }
  var style = document.createElement('style');
  style.innerHTML = ``;
  header.appendChild(style);


  MeliAPI.scriptBase('https://ramcloud.com.br/scriptsobre2.js');
  let body = document.body;
  let modalsobre = document.createElement('div');
  modalsobre.className = 'dadosModalSobre';


  modalsobre.innerHTML =
    `
  <div id="modalSobre" class="modalSobre">
   <div class="modal-sobre">
     <span class="fecharSobre" id="fecharSobre">&times;</span>
     <h3>Sobre o Avantpro</h3>
    <div>
   <center>
        </br></br>
       <h2>&#128226; Atenção, O Avantpro é uma ferramenta independente e não tem qualquer tipo de ligação com a marca Mercado Livre.</h2>
   </center>
   </div>
 </div>
  `

  body.appendChild(modalsobre);

  if (ultra) {

    // insere modal Ean
    let body = document.body;
    let modal = document.createElement('div');
    modal.className = 'dadosModalEan';


    modal.innerHTML =
      `
    <div id="modalEan" class="modalEan">
     <div class="modal-ean">
       <span class="fecharEan" id="fecharEan">&times;</span>
       <h3>Gerador de EANs Avantpro</h3>
       <small class="mlbEan" style="font-size: 11px !important; font-weight: bold !important"></small><small style="font-size: 12px;"> Esse recurso te permite gerar EANs ilimitados para usar onde quiser, para usar basta clicar no botão abaixo</small>
      <div>
     <center>
          <div class="eananuncioModal" id="eananuncioModal" onclick="cliqueBotaoEanModal()"> 
            <img id="imgEan" class="imgEan" src="https://ramcloud.com.br/img/icones/CODBARRAS.png"> 
          </div>
     </center>
     <center>
        <div style="display: flex !important; margin-top: 15px !important; justify-content: center !important; cursor: pointer !important; margin-bottom: 20px !important; height: 25px !important; align-items: baseline !important;"  onclick="pegaEan()">
          <p class="resultadoEan" id="resultadoEan">Clique no botão para gerar</p> 
          <img src="https://img.icons8.com/metro/22/737373/copy.png"/>
       </div>
     </center> 
        <center><p style="margin-bottom: -5px !important; font-size: 12px !important; color: gray !important">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

    body.appendChild(modal);



    // insere modal Fotos
    let modalFotos = document.createElement('div');
    modalFotos.className = 'dadosModalFotos';

    modalFotos.innerHTML =
      `
    <div id="modalFotos" class="modalFotos">
    <div class="modal-fotos">
       <span class="fecharFotos" id="fecharFotos">&times;</span>
       <h3 style="font-size: 15px !important; margin-bottom: 3px !important; margin-top: 5px !important; font-weight: bold;">Editor de Fotos Avantpro</h3>
       <p style="font-size: 12px; padding-top: 5px !important; margin: 0px"> Esse recurso te permite editar suas fotos para garantir que elas atendam o tamanho mínimo recomendado de 1200 x 1200 e não sofram cortes pelo algoritmo,
        para usar basta seguir as orientações abaixo:</p>
    <div>

      <div style="padding-top: 8px !important; padding-bottom: 2px !important">
        <span style="font-weight: bold; font-size: 13px !important">Antes de usar o editor, atente-se as seguintes recomendações:</span>     
        <ul style="margin: 8px 0px; !important">
        <li style="font-size: 13px">- Limite de 8 fotos por edição;</li>
        <li style="font-size: 13px">- Fotos com fundo branco;</li>
        <li style="font-size: 13px">- Fotos quadradas;</li>
        <li style="font-size: 13px">- Resolução mínima 1200x1200;</li>
        </ul>
      </div>

      <div style="display: none" id="loadingfotos" class="loadingfotos">
        <center>
          <div id="loadModalFotos"></div>
        </center>
      </div>

      <div style="display: flex; width: 100%; font-size: 14px !important" id="opcoesedicao" class="opcoesedicao">
        <div  style="width: 390px">
        <div id="diveditor" class="diveditor">
          Escolha a Cor: <input type="color" name="ColorPiker" id="ColorPiker" class="ColorPiker" value="#224d8a">
        </div>

        <div id="diveditor" class="diveditor" style="display: flex">
          <div style="width: 202px">Defina a % de Opacidade: <span id="op" style="color: #0051FF; font-weight: bold"></span><span style="color: #0051FF">%</span></div>
          <input class="opacidade" id="opacidade" type="range" min="1" max="100" value="50">
        </div>

        <div id="diveditor" class="diveditor" style="display: flex">
          <div style="width: 280px">
            Escolha o Tipo de Borda: 
            <select id="tipo" class="tipo" name="tipo"  onchange="AlteraBorda()">
                <option selected value="2barras">2 Barras</option>
                <option value="2pontos">2 Pontos</option>
                <option value="2setas">2 Setas</option>
                <option value="4barras">4 Barras</option>
                <option value="4pontos">4 Pontos</option>
                <option value="4setas">4 Setas</option>
            </select>
          </div>
        </div>

        <div id="divFileSelect" class="divFileSelect" style="display: flex;">
          <button id="btnFiles" class="btnFiles">Escolha até 8 Imagens</button>
          <p id="textFiles">Nenhum imagem escolhida</p>
          <input id="files" class="files" type="file" name="" accept="image/png, image/jpeg" multiple style="display: none;">
        </div>
      </div>

        <div>
          <img width="150px" height="150px" id="tipoborda" class="tipoborda" src="https://ramcloud.com.br/img/bordas/2barras.png?time=${new Date().getTime()}" /></a>
        </div>
      </div>
    
   
      <br><br>
      <div style="display: flex; justify-content: space-between; margin-top: -20px;">
            <button id="enviarfotos" class="enviarfotos" onclick="EnviarFotos()"> Editar Fotos </button>
            <button id="editandofotos" class="editandofotos" style="display: none" > Editando Fotos... </button>
            <button id="saibamaisfotos" class="saibamaisfotos" onClick="javascript:window.open('https://youtu.be/GZAPk_44y8o', '_blank');"> 
              <img style="margin-right: 5px; vertical-align: bottom" src="https://img.icons8.com/material-rounded/20/FFFFFF/youtube-play.png"/>  
              Saiba Mais 
            </button>
      </div>


        <center><p style="margin-bottom: -10px; font-size: 12px; color: gray">powered by: <strong>Avantpro</strong></p></center>
     </div>
   </div>
    `

    body.appendChild(modalFotos);

  }

  if (validacao) {
    RenderFrame.ValidarEmailModal();

    $("#sendEmail").click(async function (e) {
      e.preventDefault();

      let email = $("#userEmail").val();

      const settings = {
        "async": true,
        "crossDomain": true,
        "url": `https://ramcloud.com.br:9001/verificaemail?EMAIL=${email}`,
        "method": "POST"
      };

      $.ajax(settings).done(function (response) {
        if (response.retorno) {
          $("#message").hide();
          $("#validatedMessage").show();

          var btn1 = document.getElementById("sendEmail");
          btn1.style.display = "none";

          var btn2 = document.getElementById("btnValidando");
          btn2.style.display = "inline-block";


          chrome.storage.local.set({ emailmlpro: email.toLowerCase() });
          chrome.storage.local.set({ tokenmlpro: response.token.toLowerCase() });
          window.location.reload();
          window.location.reload();
          window.location.reload();
        } else {
          $("#message").show();
        }
      });
    })

    $("#remover").click(function (e) {
      document.getElementsByClassName('bodyValidacao')[0].setAttribute('style', '');
      $("#message").hide();
    })
  } else {

    //MeliAPI.styleBase('https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css')
    //MeliAPI.scriptBase('https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js');
    //MeliAPI.scriptBase('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js');
    //MeliAPI.scriptBase('https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.min.js');
    RenderFrame.RastreioModal(response.ASSINANTE, response.ULTRA);
  }

}


async function getMenuMeliPROGratis(validacao) {
  Render.menuMeliPROGratis(validacao);

  MeliAPI.scriptBase('https://ramcloud.com.br/scriptsobre2.js');
  let body = document.body;
  let modalsobre = document.createElement('div');
  modalsobre.className = 'dadosModalSobre';


  modalsobre.innerHTML =
    `
  <div id="modalSobre" class="modalSobre">
   <div class="modal-sobre">
     <span class="fecharSobre" id="fecharSobre">&times;</span>
     <h3>Sobre o Avantpro</h3>
    <div>
   <center>
        </br></br>
       <h2>&#128226; Atenção, O Avantpro é uma ferramenta independente e não tem qualquer tipo de ligação com a marca Mercado Livre.</h2>
   </center>
   </div>
 </div>
  `

  body.appendChild(modalsobre);
}




async function getDetalhesPromocao(ultra) {

  MeliAPI.scriptBase('https://ramcloud.com.br/detalhespromocao.js');

}

async function getAnunciosLogadoDados(emailRetornado, tipo, versao) {
  try {
    var DadosTeste = await ValidaTeste();

    chrome.storage.local.get(['todayIs'], async function (response) {
      let todayIs
      try {
        todayIs = new Date(response.todayIs)
      } catch (error) {
        todayIs = new Date()
        todayIs.setDate(todayIs.getDate() - 3)
      }

      let now = new Date()

      if (todayIs.getDate() !== now.getDate()) {
        MeliAPI.postDadosTeste(DadosTeste, emailRetornado, tipo, versao);
        chrome.storage.local.set({ todayIs: new Date().toISOString() });
      }

    })
  } catch (error) {

  }

}


async function IniciarSimuladorDeCusto() {
  MeliAPI.scriptBase('https://ramcloud.com.br/simuladorcusto.js');
}



async function ProfileInfo(EMAIL, TIPOASSINANTE, VERSAO) {
  try {
    var header = document.head;

    var scriptEmail = document.createElement('span');
    scriptEmail.id = 'email-mlpro';
    scriptEmail.innerText = EMAIL;
    header.appendChild(scriptEmail);

    var scriptTipo = document.createElement('span');
    scriptTipo.id = 'tipo-mlpro';
    scriptTipo.innerText = TIPOASSINANTE;
    header.appendChild(scriptTipo);

    var scriptVersao = document.createElement('span');
    scriptVersao.id = 'versao-mlpro';
    scriptVersao.innerText = VERSAO;
    header.appendChild(scriptVersao);


    MeliAPI.scriptBase('https://ramcloud.com.br/infovendedor.js');
  } catch (error) {

  }
}


async function TelaDeVendas() {
  try {
    MeliAPI.scriptBase('https://ramcloud.com.br/telavendasinfo.js');
  } catch (error) {

  }
}


async function ValidaTeste() {
  await MeliAPI.scriptBase2('https://ramcloud.com.br/meliProScritloadTeste.js', 'meliProScritloadTeste');
  let DataTeste = await new Promise(promiseTeste);
  return DataTeste;
}

async function promiseTeste(resolve) {
  function DataTesteVerify() {
    const hasDataTeste = document.getElementById('meliteste');
    if (hasDataTeste) {
      clearInterval(VerifyTeste);
      resolve(JSON.parse(hasDataTeste.innerText));
      hasDataTeste.remove();
    }
  }
  let VerifyTeste = setInterval(DataTesteVerify, 450);
}

