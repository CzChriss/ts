import{a as x,b as v}from"./chunks/V6QYWDRL.js";import"./chunks/6FCDVDEW.js";import{a as y}from"./chunks/5RRDEUKL.js";import{e as A,f as P}from"./chunks/ZZLXOTOM.js";import"./chunks/REMB6LXX.js";import{a as f}from"./chunks/BFFO2HCF.js";import{q as p}from"./chunks/TMUP5ROH.js";import"./chunks/2ITN2LMB.js";import{N as b,f as g,g as E,h as C,o as _}from"./chunks/6RK5VL4O.js";import"./chunks/ASVYVEQN.js";import{a as S}from"./chunks/BIAB2ZEP.js";import{e as a}from"./chunks/O5NYTI7P.js";var e=a(S()),u=a(x());var R=a(A()),O=a(P());var d=a(b());var N=String("USE_CHAT_GPT_AI").toLowerCase().replace(/_/g,"-");y.unstable_ClassNameGenerator.configure(o=>`${N}--${o}`);if(location.host==="chat.openai.com"){let o=document.createElement("script");o.type="module",o.src=d.default.runtime.getURL("/pages/chatgpt/fileUploadServer.js"),(document.head||document.documentElement).append(o),import("./chunks/5O36TQYH.js").then(s=>{let{default:r}=s,i=document.createElement("div");i.id=E,document.body.appendChild(i);let c=(0,u.createRoot)(i),t=document.createElement("style");t.innerHTML=`#__next.ezmail-ai-running > div > div {
  padding-top: 40px;
}
.ezmail-ai-setting-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  animation: spin 2s linear infinite;
}
#__next.use-chat-gpt-ai-running > div > div {
  padding-top: 40px;
}
.use-chat-gpt-ai-setting-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  animation: spin 2s linear infinite;
}
@keyframes spin {
  100% {
    transform: rotate(1turn);
  }
}
a.chatgpt-ad {
  display: none;
}
`,document.head.appendChild(t),c.render(e.default.createElement(e.default.StrictMode,null,e.default.createElement(r,null)))})}else import("./chunks/FP2NWHSN.js").then(o=>{let{default:s}=o,r=document.createElement("link");r.rel="stylesheet",r.href=d.default.runtime.getURL("content.css"),document.head.appendChild(r);let i="customElements"in window,c=document.createElement(i?"use-chat-gpt-ai-content-menu":"div");c.id=_,p()==="youtube.com"&&(c.contentEditable="true"),document.body.appendChild(c);let t=document.createElement(i?"use-chat-gpt-ai":"div");p()==="youtube.com"&&(t.contentEditable="true"),t.id=g,t.style.display="none",document.body.appendChild(t);let m=t.attachShadow({mode:"open"}),h=document.createElement("style"),n=document.createElement("div");n.id=C,n.style.display="flex",n.style.flexDirection="column",n.style.flex="1",n.style.height="100vh",m.appendChild(h),m.appendChild(n);let l=document.createElement("link");l.rel="stylesheet",l.href=d.default.runtime.getURL("content_style.css"),m.appendChild(l);let T=(0,R.default)({key:`${N}-emotion-cache`,prepend:!0,container:h});(0,u.createRoot)(n).render(e.default.createElement(e.default.StrictMode,null,e.default.createElement(f,null,e.default.createElement(O.CacheProvider,{value:T},e.default.createElement(v,{shadowRootElement:n},e.default.createElement(s,null))))))});
