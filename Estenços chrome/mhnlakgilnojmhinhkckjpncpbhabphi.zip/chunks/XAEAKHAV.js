import{a}from"./GCPSMIV2.js";import"./O5NYTI7P.js";export default a();
