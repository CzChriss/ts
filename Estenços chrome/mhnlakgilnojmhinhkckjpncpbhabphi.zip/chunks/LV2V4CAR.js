import{n as L,o as c}from"./7K3KIATA.js";import{C as S,F as m,d as K,g as i,h as b,i as V,k as W,m as B,n as G}from"./ZZLXOTOM.js";import{a as F}from"./BIAB2ZEP.js";import{e as t}from"./O5NYTI7P.js";var _=t(K()),$=t(G());function w(r){return(0,$.default)("MuiCircularProgress",r)}var Y=(0,_.unstable_generateUtilityClasses)("MuiCircularProgress",["root","determinate","indeterminate","colorPrimary","colorSecondary","svg","circle","circleDeterminate","circleIndeterminate","circleDisableShrink"]),Z=Y;var O=t(F());var j=t(W());var U=t(L()),a=t(B());var f=t(V()),q=["className","color","disableShrink","size","style","thickness","value","variant"],u=r=>r,D,M,R,N,o=44,A=(0,a.keyframes)(D||(D=u`
  0% {
    transform: rotate(0deg);
  }

  100% {
    transform: rotate(360deg);
  }
`)),H=(0,a.keyframes)(M||(M=u`
  0% {
    stroke-dasharray: 1px, 200px;
    stroke-dashoffset: 0;
  }

  50% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -15px;
  }

  100% {
    stroke-dasharray: 100px, 200px;
    stroke-dashoffset: -125px;
  }
`)),J=r=>{let{classes:e,variant:s,color:n,disableShrink:d}=r,y={root:["root",s,`color${c(n)}`],svg:["svg"],circle:["circle",`circle${c(s)}`,d&&"circleDisableShrink"]};return(0,U.unstable_composeClasses)(y,w,e)},Q=m("span",{name:"MuiCircularProgress",slot:"Root",overridesResolver:(r,e)=>{let{ownerState:s}=r;return[e.root,e[s.variant],e[`color${c(s.color)}`]]}})(({ownerState:r,theme:e})=>i({display:"inline-block"},r.variant==="determinate"&&{transition:e.transitions.create("transform")},r.color!=="inherit"&&{color:(e.vars||e).palette[r.color].main}),({ownerState:r})=>r.variant==="indeterminate"&&(0,a.css)(R||(R=u`
      animation: ${0} 1.4s linear infinite;
    `),A)),X=m("svg",{name:"MuiCircularProgress",slot:"Svg",overridesResolver:(r,e)=>e.svg})({display:"block"}),rr=m("circle",{name:"MuiCircularProgress",slot:"Circle",overridesResolver:(r,e)=>{let{ownerState:s}=r;return[e.circle,e[`circle${c(s.variant)}`],s.disableShrink&&e.circleDisableShrink]}})(({ownerState:r,theme:e})=>i({stroke:"currentColor"},r.variant==="determinate"&&{transition:e.transitions.create("stroke-dashoffset")},r.variant==="indeterminate"&&{strokeDasharray:"80px, 200px",strokeDashoffset:0}),({ownerState:r})=>r.variant==="indeterminate"&&!r.disableShrink&&(0,a.css)(N||(N=u`
      animation: ${0} 1.4s ease-in-out infinite;
    `),H)),er=O.forwardRef(function(e,s){let n=S({props:e,name:"MuiCircularProgress"}),{className:d,color:y="primary",disableShrink:z=!1,size:h=40,style:E,thickness:l=3.6,value:P=0,variant:T="indeterminate"}=n,I=b(n,q),p=i({},n,{color:y,disableShrink:z,size:h,thickness:l,value:P,variant:T}),v=J(p),g={},k={},x={};if(T==="determinate"){let C=2*Math.PI*((o-l)/2);g.strokeDasharray=C.toFixed(3),x["aria-valuenow"]=Math.round(P),g.strokeDashoffset=`${((100-P)/100*C).toFixed(3)}px`,k.transform="rotate(-90deg)"}return(0,f.jsx)(Q,i({className:(0,j.default)(v.root,d),style:i({width:h,height:h},k,E),ownerState:p,ref:s,role:"progressbar"},x,I,{children:(0,f.jsx)(X,{className:v.svg,ownerState:p,viewBox:`${o/2} ${o/2} ${o} ${o}`,children:(0,f.jsx)(rr,{className:v.circle,style:g,ownerState:p,cx:o,cy:o,r:(o-l)/2,fill:"none",strokeWidth:l})})}))}),sr=er;export{w as a,Z as b,sr as c};
