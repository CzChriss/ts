import{a}from"./IGNWSMS2.js";import"./O5NYTI7P.js";export{a as default};
