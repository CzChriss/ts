import{N as e}from"./6RK5VL4O.js";import{e as s}from"./O5NYTI7P.js";var t=s(e()),n=r=>t.default.runtime.getURL(`/assets/USE_CHAT_GPT_AI${r}`);export{n as a};
